from __future__ import annotations

from dataclasses import asdict
import queue
import threading

from jarvis_gm.control.bridge import ActionGateway
from jarvis_gm.core.memory import MemoryStore
from jarvis_gm.core.orchestrator import Orchestrator
from jarvis_gm.perception.bus import PerceptionBus
from jarvis_gm.perception.events import PerceptionEvent
from .engine import IntentEngine
from .models import DecisionStatus


class IntentControlBridge:
    """All multimodal control passes through contextual intent arbitration."""

    EVENT_TYPES = {
        "voice.command", "gesture.armed", "gesture.disarmed", "gesture.point",
        "gesture.pinch_start", "gesture.pinch_move", "gesture.pinch_end",
        "gesture.swipe_left", "gesture.swipe_right", "gesture.transform", "gesture.static",
    }

    def __init__(self, orchestrator: Orchestrator, gateway: ActionGateway, bus: PerceptionBus,
                 memory: MemoryStore, engine: IntentEngine) -> None:
        self.orchestrator = orchestrator; self.gateway = gateway; self.bus = bus; self.memory = memory; self.engine = engine
        self._queue: queue.Queue[PerceptionEvent | None] = queue.Queue(maxsize=256)
        self._token: int | None = None; self._thread: threading.Thread | None = None; self._stop = threading.Event()

    def start(self) -> None:
        if self._token is not None: return
        while True:
            try: self._queue.get_nowait()
            except queue.Empty: break
        self._stop.clear(); self._token = self.bus.subscribe(self._enqueue)
        self._thread = threading.Thread(target=self._worker, name="jarvis-intent-bridge", daemon=True); self._thread.start()
        self.bus.publish(PerceptionEvent("intent.bridge", "intent", {"status": "started"}))

    def stop(self) -> None:
        if self._token is not None:
            self.bus.unsubscribe(self._token); self._token = None
        self._stop.set()
        try: self._queue.put_nowait(None)
        except queue.Full: pass
        if self._thread and self._thread.is_alive(): self._thread.join(timeout=1.0)
        self._thread = None

    def _enqueue(self, event: PerceptionEvent) -> None:
        if event.source in {"control", "intent"} or event.type not in self.EVENT_TYPES: return
        try: self._queue.put_nowait(event)
        except queue.Full:
            try: self._queue.get_nowait(); self._queue.put_nowait(event)
            except queue.Empty: pass

    def _worker(self) -> None:
        while not self._stop.is_set():
            try: event = self._queue.get(timeout=0.25)
            except queue.Empty: continue
            if event is None: break
            try: self._handle(event)
            except Exception as exc:
                self.bus.publish(PerceptionEvent("intent.error", "intent", {"event": event.type, "error": str(exc)}))

    def _handle(self, event: PerceptionEvent) -> None:
        decision = self.engine.process(event)
        payload = decision.as_dict()
        self.memory.record_event(event.id, f"intent.{decision.status.value}", payload)
        self.bus.publish(PerceptionEvent(f"intent.{decision.status.value}", "intent", payload))
        if decision.status is not DecisionStatus.EXECUTE or decision.selected is None:
            return
        selected = decision.selected
        if selected.goal_text is not None:
            goal = self.orchestrator.run(selected.goal_text)
            self.bus.publish(PerceptionEvent("intent.goal_result", "intent", {
                "intent": selected.name, "goal_id": goal.id, "state": goal.state.value, "verification": goal.verification,
            }))
            return
        ok = True; executed=[]
        for action in selected.actions:
            action_ok = self.gateway.run(action.name, action.args, event.id)
            executed.append({"name": action.name, "args": action.args, "ok": action_ok})
            if not action_ok:
                ok = False; break
        self.bus.publish(PerceptionEvent("intent.execution_result", "intent", {
            "intent": selected.name, "ok": ok, "executed": executed,
        }))
