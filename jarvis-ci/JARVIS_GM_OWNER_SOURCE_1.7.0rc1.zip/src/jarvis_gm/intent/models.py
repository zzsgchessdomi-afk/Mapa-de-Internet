from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any


class DecisionStatus(str, Enum):
    EXECUTE = "execute"
    HOLD = "hold"
    AMBIGUOUS = "ambiguous"
    IGNORE = "ignore"


@dataclass(slots=True)
class ContextSnapshot:
    timestamp: float
    active_handle: int | None
    active_title: str
    labels: dict[str, float]
    cursor_x: int | None = None
    cursor_y: int | None = None
    screen_width: int | None = None
    screen_height: int | None = None
    override: str | None = None

    @property
    def primary_label(self) -> str:
        if self.override:
            return self.override
        if not self.labels:
            return "unknown"
        return max(self.labels, key=self.labels.get)


@dataclass(slots=True)
class IntentAction:
    name: str
    args: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class IntentCandidate:
    name: str
    score: float
    reason: str
    actions: list[IntentAction] = field(default_factory=list)
    goal_text: str | None = None
    risk: str = "low"
    context_label: str | None = None

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class IntentDecision:
    status: DecisionStatus
    event_id: str
    event_type: str
    reason: str
    context: ContextSnapshot
    selected: IntentCandidate | None = None
    candidates: list[IntentCandidate] = field(default_factory=list)

    def as_dict(self) -> dict[str, Any]:
        return {
            "status": self.status.value,
            "event_id": self.event_id,
            "event_type": self.event_type,
            "reason": self.reason,
            "context": asdict(self.context),
            "selected": self.selected.as_dict() if self.selected else None,
            "candidates": [x.as_dict() for x in self.candidates],
        }
