from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
import re
import time
from typing import Iterable, Any

from jarvis_gm.perception.events import PerceptionEvent
from .context import ContextProvider
from .models import (
    ContextSnapshot, DecisionStatus, IntentAction, IntentCandidate, IntentDecision,
)


@dataclass(slots=True)
class IntentConfig:
    min_confidence: float = 0.58
    min_margin: float = 0.11
    deictic_point_max_age_s: float = 2.0
    context_override_ttl_s: float = 20.0
    require_gesture_arm: bool = True
    mixed_context_margin: float = 0.08

    @classmethod
    def load(cls, path: Path) -> "IntentConfig":
        path = Path(path)
        if not path.exists():
            cfg = cls(); cfg.save(path); return cfg
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
            known = {k: raw[k] for k in cls.__dataclass_fields__ if k in raw}
            return cls(**known)
        except Exception:
            return cls()

    def save(self, path: Path) -> None:
        path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps({k: getattr(self, k) for k in self.__dataclass_fields__}, indent=2), encoding="utf-8")


class IntentEngine:
    """Turns raw multimodal events into contextual, confidence-scored intent.

    Design goals:
    - the same gesture may mean different things in different contexts;
    - mixed contexts remain ambiguous instead of silently guessing;
    - voice + a recent pointing gesture can fuse into one deictic command;
    - no gesture maps to file/app/destructive operations;
    - every decision has explicit evidence and a score.
    """

    MODE_WORDS = {
        "navegador": "browser", "browser": "browser",
        "medios": "media", "media": "media", "reproductor": "media",
        "escritorio": "desktop", "desktop": "desktop",
        "editor": "editor", "jarvis": "jarvis",
    }

    def __init__(self, context: ContextProvider, config: IntentConfig | None = None, grounder: Any | None = None) -> None:
        self.context = context
        self.cfg = config or IntentConfig()
        self.grounder = grounder
        self.gesture_armed = False
        self.drag_active = False
        self._last_point: tuple[float, float, float, float] | None = None  # x,y,time,confidence
        self._override: str | None = None
        self._override_until = 0.0

    @property
    def context_override(self) -> str | None:
        self._expire_override()
        return self._override

    def _expire_override(self) -> None:
        if self._override and time.time() >= self._override_until:
            self._override = None; self._override_until = 0.0

    def _snapshot(self) -> ContextSnapshot:
        self._expire_override()
        return self.context.snapshot(self._override)

    def _decision(self, event: PerceptionEvent, status: DecisionStatus, reason: str,
                  context: ContextSnapshot, candidates: Iterable[IntentCandidate] = (),
                  selected: IntentCandidate | None = None) -> IntentDecision:
        ordered = sorted(list(candidates), key=lambda c: c.score, reverse=True)
        return IntentDecision(status, event.id, event.type, reason, context, selected, ordered)

    def _select(self, event: PerceptionEvent, ctx: ContextSnapshot, candidates: list[IntentCandidate]) -> IntentDecision:
        if not candidates:
            return self._decision(event, DecisionStatus.IGNORE, "No registered semantic intent for this event", ctx)
        candidates = sorted(candidates, key=lambda c: c.score, reverse=True)
        top = candidates[0]
        if top.score < self.cfg.min_confidence:
            return self._decision(event, DecisionStatus.HOLD, f"Confidence {top.score:.2f} is below threshold", ctx, candidates)
        if len(candidates) > 1:
            gap = top.score - candidates[1].score
            if gap < self.cfg.min_margin:
                return self._decision(event, DecisionStatus.AMBIGUOUS,
                                      f"Top intents are too close ({top.score:.2f} vs {candidates[1].score:.2f})", ctx, candidates)
        return self._decision(event, DecisionStatus.EXECUTE, top.reason, ctx, candidates, top)

    def process(self, event: PerceptionEvent) -> IntentDecision:
        ctx = self._snapshot()
        p = event.payload

        if event.type == "gesture.armed":
            self.gesture_armed = True
            return self._decision(event, DecisionStatus.HOLD, "Gesture mode armed; waiting for an intentional gesture", ctx)
        if event.type == "gesture.disarmed":
            self.gesture_armed = False
            self.drag_active = False
            return self._decision(event, DecisionStatus.HOLD, "Gesture mode disarmed", ctx)

        if event.type.startswith("gesture.") and self.cfg.require_gesture_arm and not self.gesture_armed:
            # Pinch-end is allowed through later by the bridge as emergency cleanup;
            # here it is represented as a release intent if a drag was already active.
            if not (event.type == "gesture.pinch_end" and self.drag_active):
                return self._decision(event, DecisionStatus.HOLD, "Gesture ignored because intentional gesture mode is not armed", ctx)

        if event.type == "gesture.point":
            x, y = float(p.get("x", 0.0)), float(p.get("y", 0.0))
            self._last_point = (x, y, event.timestamp, event.confidence)
            c = IntentCandidate(
                "pointer.move", min(0.99, event.confidence * 0.98),
                "Pointing gesture is a low-risk continuous pointer intent",
                [IntentAction("move_cursor_normalized", {"x": x, "y": y})], context_label=ctx.primary_label,
            )
            return self._select(event, ctx, [c])

        if event.type == "gesture.pinch_start":
            x, y = float(p.get("x", 0.0)), float(p.get("y", 0.0))
            c = IntentCandidate(
                "pointer.drag_start", event.confidence * 0.98,
                "Pinch start means grab only after gesture mode was deliberately armed",
                [IntentAction("move_cursor_normalized", {"x": x, "y": y}), IntentAction("mouse_button", {"button": "left", "state": "down"})],
                context_label=ctx.primary_label,
            )
            decision = self._select(event, ctx, [c])
            self.drag_active = decision.status is DecisionStatus.EXECUTE
            return decision

        if event.type == "gesture.pinch_move":
            if not self.drag_active:
                return self._decision(event, DecisionStatus.HOLD, "Pinch movement has no matching grab start", ctx)
            x, y = float(p.get("x", 0.0)), float(p.get("y", 0.0))
            c = IntentCandidate("pointer.drag_move", event.confidence * 0.99, "Continuing an already established drag",
                                [IntentAction("move_cursor_normalized", {"x": x, "y": y})], context_label=ctx.primary_label)
            return self._select(event, ctx, [c])

        if event.type == "gesture.pinch_end":
            if not self.drag_active:
                return self._decision(event, DecisionStatus.IGNORE, "No active drag to release", ctx)
            self.drag_active = False
            c = IntentCandidate("pointer.drag_end", 1.0, "Release is always preferred over leaving an input held",
                                [IntentAction("mouse_button", {"button": "left", "state": "up"})], context_label=ctx.primary_label)
            return self._select(event, ctx, [c])

        if event.type in {"gesture.swipe_left", "gesture.swipe_right"}:
            direction = "left" if event.type.endswith("left") else "right"
            return self._select(event, ctx, self._swipe_candidates(direction, event.confidence, ctx))

        if event.type == "gesture.transform":
            return self._select(event, ctx, self._transform_candidates(event, ctx))

        if event.type == "voice.command":
            text = str(p.get("text", "")).strip()
            if not text:
                return self._decision(event, DecisionStatus.IGNORE, "Empty voice command", ctx)
            mode = self._voice_mode_command(text)
            if mode is not None:
                if mode == "auto":
                    self._override = None; self._override_until = 0.0
                    ctx = self._snapshot()
                    return self._decision(event, DecisionStatus.HOLD, "Context override cleared; automatic intent inference restored", ctx)
                self._override = mode; self._override_until = time.time() + self.cfg.context_override_ttl_s
                ctx = self._snapshot()
                return self._decision(event, DecisionStatus.HOLD, f"Context locked to {mode} for {self.cfg.context_override_ttl_s:.0f}s", ctx)

            if self._is_deictic_click(text):
                return self._deictic_click(event, ctx)
            if self._contains_unresolved_deixis(text):
                return self._decision(event, DecisionStatus.AMBIGUOUS,
                                      "The command refers to 'this/that/there' but no safe grounded target is available", ctx)
            c = IntentCandidate("voice.goal", min(1.0, max(0.0, event.confidence)),
                                "Explicit wake-gated voice command", goal_text=text, risk="planner", context_label=ctx.primary_label)
            return self._select(event, ctx, [c])

        return self._decision(event, DecisionStatus.IGNORE, "Event is perception-only", ctx)

    def _swipe_candidates(self, direction: str, confidence: float, ctx: ContextSnapshot) -> list[IntentCandidate]:
        labels = ctx.labels
        out: list[IntentCandidate] = []
        browser = labels.get("browser", 0.0)
        media = labels.get("media", 0.0)
        desktopish = max(labels.get("desktop", 0.0), labels.get("jarvis", 0.0), labels.get("editor", 0.0), labels.get("terminal", 0.0))

        if browser:
            keys = ["alt", "left" if direction == "left" else "right"]
            out.append(IntentCandidate(
                f"browser.history_{'back' if direction == 'left' else 'forward'}",
                confidence * browser * 0.98,
                f"Active context looks like a browser ({browser:.2f}); horizontal swipe maps to browser history",
                [IntentAction("hotkey", {"keys": keys})], context_label="browser",
            ))
        if media:
            key = "left" if direction == "left" else "right"
            out.append(IntentCandidate(
                f"media.seek_{direction}", confidence * media * 0.98,
                f"Active context looks like media ({media:.2f}); horizontal swipe maps to seek",
                [IntentAction("hotkey", {"keys": [key]})], context_label="media",
            ))
        if desktopish:
            keys = ["alt", "shift", "tab"] if direction == "left" else ["alt", "tab"]
            out.append(IntentCandidate(
                f"window.switch_{direction}", confidence * desktopish * 0.90,
                f"Desktop/editor context ({desktopish:.2f}); swipe maps to window switching",
                [IntentAction("hotkey", {"keys": keys})], context_label="desktop",
            ))

        # Unknown contexts intentionally offer competing hypotheses instead of guessing.
        if not out:
            out.extend([
                IntentCandidate("window.switch_unknown", confidence * 0.57, "Unknown context: window switching is plausible", [IntentAction("hotkey", {"keys": ["alt", "tab"]})], context_label="desktop"),
                IntentCandidate("navigation.unknown", confidence * 0.53, "Unknown context: in-app navigation is also plausible", [], context_label="unknown"),
            ])
        return out

    def _transform_candidates(self, event: PerceptionEvent, ctx: ContextSnapshot) -> list[IntentCandidate]:
        p = event.payload; scale = float(p.get("scale_delta", 1.0)); center = p.get("center", {}) or {}
        if 0.97 <= scale <= 1.03:
            return []
        labels = ctx.labels; out: list[IntentCandidate] = []
        browser = labels.get("browser", 0.0); media = labels.get("media", 0.0)
        desktopish = max(labels.get("desktop", 0.0), labels.get("jarvis", 0.0), labels.get("editor", 0.0), labels.get("terminal", 0.0))
        if browser:
            key = "+" if scale > 1 else "-"
            out.append(IntentCandidate("browser.zoom", event.confidence * browser * 0.95,
                                       "Two-hand scale in browser context maps to page zoom",
                                       [IntentAction("hotkey", {"keys": ["ctrl", key]})], context_label="browser"))
        if media:
            key = "up" if scale > 1 else "down"
            out.append(IntentCandidate("media.volume", event.confidence * media * 0.87,
                                       "Two-hand scale in media context can mean volume",
                                       [IntentAction("hotkey", {"keys": [key]})], context_label="media"))
        if desktopish:
            out.append(IntentCandidate("window.resize", event.confidence * desktopish * 0.94,
                                       "Two-hand scale in desktop/editor context maps to active-window resize",
                                       [IntentAction("resize_active_window", {"scale": scale, "center_x": center.get("x"), "center_y": center.get("y")})], context_label="desktop"))
        return out

    def _voice_mode_command(self, text: str) -> str | None:
        low = re.sub(r"\s+", " ", text.casefold()).strip()
        if low in {"modo automatico", "modo automático", "contexto automatico", "contexto automático"}:
            return "auto"
        m = re.fullmatch(r"(?:modo|contexto)\s+(.+)", low)
        if not m:
            return None
        return self.MODE_WORDS.get(m.group(1).strip())

    @staticmethod
    def _is_deictic_click(text: str) -> bool:
        low = re.sub(r"\s+", " ", text.casefold()).strip()
        has_click = bool(re.search(r"\b(clic|click)\b", low))
        has_deixis = bool(re.search(r"\b(eso|esto|ese|esa|aqui|aquí|ahi|ahí|alli|allí|that|this|there)\b", low))
        return has_click and has_deixis

    @staticmethod
    def _contains_unresolved_deixis(text: str) -> bool:
        low = text.casefold()
        return bool(re.search(r"\b(eso|esto|ese|esa|aqui|aquí|ahi|ahí|alli|allí|that|this|there)\b", low))

    def _deictic_click(self, event: PerceptionEvent, ctx: ContextSnapshot) -> IntentDecision:
        if self._last_point is None:
            return self._decision(event, DecisionStatus.AMBIGUOUS, "'Click there' needs a recent pointing target", ctx)
        x, y, ts, point_conf = self._last_point
        age = max(0.0, event.timestamp - ts)
        if age > self.cfg.deictic_point_max_age_s:
            return self._decision(event, DecisionStatus.AMBIGUOUS, f"Pointing target is stale ({age:.2f}s)", ctx)
        score = min(event.confidence, point_conf) * 0.99
        if self.grounder is not None:
            grounded = self.grounder.ground_point(x, y, voice_text=str(event.payload.get("text", "")),
                                                 point_confidence=min(event.confidence, point_conf))
            status = getattr(grounded.status, "value", str(grounded.status))
            if status == "ambiguous":
                return self._decision(event, DecisionStatus.AMBIGUOUS, f"Screen target is ambiguous: {grounded.reason}", ctx)
            if status != "grounded" or grounded.target is None:
                return self._decision(event, DecisionStatus.AMBIGUOUS, f"Pointing reference is not grounded safely: {grounded.reason}", ctx)
            target = grounded.target
            c = IntentCandidate(
                "multimodal.grounded_click", min(score, target.confidence),
                f"Voice + point grounded to '{target.label}' via {target.source}: {target.reason}",
                [IntentAction("grounded_click", {"target_id": target.id})], risk="grounded_ui",
                context_label=ctx.primary_label,
            )
            return self._select(event, ctx, [c])
        c = IntentCandidate("multimodal.deictic_click", score,
                            f"Voice command fused with a pointing target {age:.2f}s old",
                            [IntentAction("move_cursor_normalized", {"x": x, "y": y}), IntentAction("mouse_button", {"button": "left", "state": "click"})],
                            context_label=ctx.primary_label)
        return self._select(event, ctx, [c])
