from __future__ import annotations

from dataclasses import dataclass
import time

from jarvis_gm.control.windows_backend import DesktopBackend
from .models import ContextSnapshot


_BROWSER = ("chrome", "edge", "firefox", "brave", "opera", "vivaldi", "browser")
_MEDIA = ("youtube", "spotify", "vlc", "media player", "netflix", "prime video", "disney+", "twitch")
_EDITOR = ("visual studio code", "vscode", "notepad", "word", "excel", "powerpoint", "pycharm", "sublime")
_TERMINAL = ("powershell", "command prompt", "terminal", "cmd.exe", "windows terminal")
_JARVIS = ("jarvis gm", "jarvis")


@dataclass(slots=True)
class ContextClassifier:
    """Multi-label context classifier.

    It deliberately returns more than one label. A YouTube tab inside Chrome is
    both `media` and `browser`; that ambiguity is useful evidence, not noise.
    """

    def classify_title(self, title: str) -> dict[str, float]:
        t = (title or "").casefold()
        labels: dict[str, float] = {}
        if any(k in t for k in _BROWSER): labels["browser"] = 0.94
        if any(k in t for k in _MEDIA): labels["media"] = 0.93
        if any(k in t for k in _EDITOR): labels["editor"] = 0.91
        if any(k in t for k in _TERMINAL): labels["terminal"] = 0.95
        if any(k in t for k in _JARVIS): labels["jarvis"] = 0.98
        if not labels:
            labels["desktop"] = 0.62 if title else 0.56
        return labels


class ContextProvider:
    def __init__(self, backend: DesktopBackend, classifier: ContextClassifier | None = None) -> None:
        self.backend = backend
        self.classifier = classifier or ContextClassifier()

    def snapshot(self, override: str | None = None) -> ContextSnapshot:
        title = ""; handle = None; cx = cy = sw = sh = None
        try:
            active = self.backend.active_window()
            if active is not None:
                title = active.title; handle = active.handle
        except Exception:
            pass
        try:
            cx, cy = self.backend.cursor_position()
        except Exception:
            pass
        try:
            sw, sh = self.backend.screen_size()
        except Exception:
            pass
        labels = self.classifier.classify_title(title)
        if override:
            # An explicit user mode is a temporary context lock, not just another hint.
            # Suppress competing automatic labels until the lock expires.
            labels = {override: 1.0}
        return ContextSnapshot(time.time(), handle, title, labels, cx, cy, sw, sh, override)
