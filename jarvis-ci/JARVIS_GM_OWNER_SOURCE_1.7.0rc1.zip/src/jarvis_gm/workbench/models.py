from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any
import time, uuid


class WorkState(str, Enum):
    QUEUED = "queued"
    RUNNABLE = "runnable"
    RUNNING = "running"
    PAUSED = "paused"
    AWAITING_APPROVAL = "awaiting_approval"
    BLOCKED = "blocked"
    FAILED = "failed"
    VERIFIED = "verified"
    CANCELLED = "cancelled"

TERMINAL_STATES = {WorkState.FAILED, WorkState.VERIFIED, WorkState.CANCELLED}


@dataclass(slots=True)
class WorkItem:
    goal: str
    success_criteria: tuple[str, ...] = ()
    dependencies: tuple[str, ...] = ()
    priority: int = 50
    step_budget: int = 30
    replan_budget: int = 12
    quantum: int = 3
    id: str = field(default_factory=lambda: "work_" + uuid.uuid4().hex[:16])
    state: WorkState = WorkState.QUEUED
    mission_id: str = ""
    steps_used: int = 0
    replans_used: int = 0
    cycles: int = 0
    checkpoint_seq: int = 0
    conclusion: str = ""
    blocked_reason: str = ""
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)

    def as_dict(self) -> dict[str, Any]:
        data=asdict(self)
        data["state"]=self.state.value
        data["success_criteria"]=list(self.success_criteria)
        data["dependencies"]=list(self.dependencies)
        return data
