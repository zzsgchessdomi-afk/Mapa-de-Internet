from __future__ import annotations

from dataclasses import dataclass
import threading
from typing import Any, Callable
from jarvis_gm.autonomy.models import AutonomyState
from .models import WorkItem, WorkState, TERMINAL_STATES
from .store import WorkbenchStore


@dataclass(slots=True)
class WorkbenchConfig:
    max_jobs_per_cycle: int = 4
    max_total_steps_per_item: int = 100


class AutonomousWorkbench:
    """Persistent cooperative scheduler over Mission Autopilot.

    Many work items may be queued/paused/waiting simultaneously. World-mutating
    execution is deliberately serialized through one lane to avoid races between
    agents controlling the same desktop/device.
    """
    def __init__(self, store:WorkbenchStore, autonomy_engine, *, kill_switch, run_allowed:Callable[[],bool], manage_allowed:Callable[[],bool], config:WorkbenchConfig|None=None, authorize:Callable[[str,dict],None]|None=None) -> None:
        self.store=store; self.autonomy=autonomy_engine; self.kill_switch=kill_switch; self.run_allowed=run_allowed; self.manage_allowed=manage_allowed; self.config=config or WorkbenchConfig(); self.authorize=authorize; self._lane=threading.Lock()

    def create(self, goal:str, *, success_criteria=(), dependencies=(), priority:int=50, step_budget:int=30, replan_budget:int=12, quantum:int=3) -> WorkItem:
        if not self.manage_allowed(): raise PermissionError("Capability blocked by policy: workbench.manage")
        self._gate("workbench_manage", {"operation":"create"})
        goal=" ".join(str(goal).split()).strip()
        if not goal: raise ValueError("Work goal cannot be empty")
        deps=tuple(dict.fromkeys(str(x) for x in dependencies if str(x)))
        item=WorkItem(goal=goal,success_criteria=tuple(str(x) for x in success_criteria),dependencies=deps,priority=priority,step_budget=min(max(1,int(step_budget)),self.config.max_total_steps_per_item),replan_budget=max(0,int(replan_budget)),quantum=quantum)
        self._validate_dependencies(item)
        self.store.save(item); self.store.event(item.id,"created",goal); return item

    def pause(self,work_id:str)->WorkItem:
        if not self.manage_allowed(): raise PermissionError("Capability blocked by policy: workbench.manage")
        self._gate("workbench_manage", {"operation":"pause","work_id":work_id})
        item=self._required(work_id)
        if item.state in TERMINAL_STATES: return item
        item.state=WorkState.PAUSED; item.conclusion="Paused by owner"; self.store.checkpoint(item,note=item.conclusion); return item

    def resume(self,work_id:str)->WorkItem:
        if not self.manage_allowed(): raise PermissionError("Capability blocked by policy: workbench.manage")
        self._gate("workbench_manage", {"operation":"resume","work_id":work_id})
        item=self._required(work_id)
        if item.state in TERMINAL_STATES: return item
        item.state=WorkState.QUEUED; item.blocked_reason=""; item.conclusion="Resumed by owner"; self.store.checkpoint(item,note=item.conclusion); return item

    def cancel(self,work_id:str)->WorkItem:
        if not self.manage_allowed(): raise PermissionError("Capability blocked by policy: workbench.manage")
        self._gate("workbench_manage", {"operation":"cancel","work_id":work_id})
        item=self._required(work_id)
        if item.state in TERMINAL_STATES: return item
        item.state=WorkState.CANCELLED; item.conclusion="Cancelled by owner"; self.store.checkpoint(item,note=item.conclusion); return item

    def run_cycle(self, *, max_jobs:int|None=None) -> list[WorkItem]:
        if not self.run_allowed(): raise PermissionError("Capability blocked by policy: workbench.run")
        self._gate("workbench_run", {"max_jobs":int(max_jobs or self.config.max_jobs_per_cycle)})
        self.kill_switch.check()
        with self._lane:
            candidates=self._runnable()[:max(1,min(int(max_jobs or self.config.max_jobs_per_cycle),20))]
            out=[]
            for item in candidates:
                self.kill_switch.check(); out.append(self._advance(item))
            return out

    def _advance(self,item:WorkItem)->WorkItem:
        dep_state=self._dependency_state(item)
        if dep_state == "waiting":
            item.state=WorkState.QUEUED; self.store.save(item); return item
        if dep_state.startswith("failed:"):
            item.state=WorkState.BLOCKED; item.blocked_reason=dep_state; item.conclusion=dep_state; self.store.checkpoint(item,note=dep_state); return item

        existing=None
        if item.mission_id:
            try:
                existing=self.autonomy.store.load(item.mission_id)
            except Exception:
                item.state=WorkState.FAILED;item.conclusion="Underlying mission checkpoint is missing or unreadable";self.store.checkpoint(item,note=item.conclusion);return item
            # Reconcile counters after a crash that may have persisted the mission
            # after its action but before the Workbench checkpoint.
            item.steps_used=max(item.steps_used,len(existing.steps))
            item.replans_used=max(item.replans_used,existing.replans)
            if existing.state == AutonomyState.VERIFIED:
                item.state=WorkState.VERIFIED;item.conclusion=existing.conclusion or "Underlying mission already verified"
                self.store.checkpoint(item,mission_state=existing.state.value,note=item.conclusion,payload={"mission_id":existing.id,"recovered":True})
                return item

        if item.replans_used > item.replan_budget:
            item.state=WorkState.FAILED;item.conclusion="Workbench replan budget exhausted";self.store.checkpoint(item,note=item.conclusion);return item
        remaining=item.step_budget-item.steps_used
        if remaining <= 0:
            item.state=WorkState.FAILED; item.conclusion="Workbench step budget exhausted"; self.store.checkpoint(item,note=item.conclusion); return item

        item.state=WorkState.RUNNING; item.cycles+=1; self.store.save(item)
        before_steps=len(existing.steps) if existing else 0; before_replans=existing.replans if existing else 0
        quantum=min(item.quantum,remaining)
        try:
            mission=self.autonomy.run(item.goal,success_criteria=item.success_criteria,max_steps=quantum,existing=existing,pause_on_budget=True)
        except Exception as exc:
            if getattr(self.kill_switch,"engaged",False):
                item.state=WorkState.BLOCKED;item.blocked_reason="STOP GLOBAL engaged";item.conclusion=item.blocked_reason
            else:
                item.state=WorkState.FAILED;item.conclusion=f"Workbench runtime error: {exc}"
            self.store.checkpoint(item,note=item.conclusion,payload={"mission_id":item.mission_id})
            return item

        item.mission_id=mission.id
        item.steps_used=max(item.steps_used,before_steps) + max(0,len(mission.steps)-before_steps)
        item.replans_used=max(item.replans_used,before_replans) + max(0,mission.replans-before_replans)
        if item.replans_used > item.replan_budget:
            item.state=WorkState.FAILED;item.conclusion="Workbench replan budget exhausted"
        elif mission.state == AutonomyState.VERIFIED:
            item.state=WorkState.VERIFIED; item.conclusion=mission.conclusion
        elif mission.state == AutonomyState.AWAITING_APPROVAL:
            item.state=WorkState.AWAITING_APPROVAL; item.conclusion=mission.conclusion
        elif mission.state == AutonomyState.BLOCKED:
            item.state=WorkState.BLOCKED; item.blocked_reason=mission.blocked_reason; item.conclusion=mission.conclusion
        elif mission.state == AutonomyState.FAILED:
            item.state=WorkState.FAILED; item.conclusion=mission.conclusion
        else:
            item.state=WorkState.RUNNABLE; item.conclusion=mission.conclusion or "Checkpoint saved; more work remains"
        self.store.checkpoint(item,mission_state=mission.state.value,note=item.conclusion,payload={"mission_id":mission.id,"verified_evidence":mission.verified_evidence_ids()})
        return item

    def _runnable(self)->list[WorkItem]:
        rows=[]
        for item in self.store.list(500):
            if item.state in TERMINAL_STATES or item.state in {WorkState.PAUSED,WorkState.AWAITING_APPROVAL,WorkState.BLOCKED}: continue
            ds=self._dependency_state(item)
            if ds == "ready": item.state=WorkState.RUNNABLE; rows.append(item)
            elif ds.startswith("failed:"):
                item.state=WorkState.BLOCKED;item.blocked_reason=ds;item.conclusion=ds;self.store.checkpoint(item,note=ds)
        rows.sort(key=lambda x:(-x.priority,x.updated_at,x.created_at)); return rows

    def _dependency_state(self,item:WorkItem)->str:
        for dep_id in item.dependencies:
            dep=self.store.get(dep_id)
            if dep is None: return f"failed:missing_dependency:{dep_id}"
            if dep.state in {WorkState.FAILED,WorkState.CANCELLED,WorkState.BLOCKED}: return f"failed:dependency_{dep.state.value}:{dep_id}"
            if dep.state != WorkState.VERIFIED: return "waiting"
        return "ready"

    def _validate_dependencies(self,item:WorkItem)->None:
        if item.id in item.dependencies: raise ValueError("Work item cannot depend on itself")
        for dep in item.dependencies:
            if self.store.get(dep) is None: raise ValueError(f"Unknown dependency: {dep}")
        # Existing graph + proposed node; detect cycles defensively.
        graph={x.id:set(x.dependencies) for x in self.store.list(1000)}; graph[item.id]=set(item.dependencies)
        visiting=set();done=set()
        def visit(n):
            if n in visiting: raise ValueError("Dependency cycle detected")
            if n in done:return
            visiting.add(n)
            for d in graph.get(n,()):visit(d)
            visiting.remove(n);done.add(n)
        visit(item.id)

    def _gate(self,name:str,args:dict)->None:
        if self.authorize is not None:
            self.authorize(name,args)

    def _required(self,work_id:str)->WorkItem:
        item=self.store.get(work_id)
        if item is None: raise KeyError(work_id)
        return item
