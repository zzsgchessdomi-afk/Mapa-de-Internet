from __future__ import annotations
from typing import Any
from jarvis_gm.actions.base import Action

class WorkbenchListAction(Action):
    name="workbench_list"; capability="workbench.read"
    def __init__(self,wb):self.wb=wb
    def run(self,**kwargs): return [x.as_dict() for x in self.wb.store.list(int(kwargs.get("limit",50)))]

class WorkbenchCreateAction(Action):
    name="workbench_create"; capability="workbench.manage"
    def __init__(self,wb):self.wb=wb
    def run(self,**kwargs):
        x=self.wb.create(str(kwargs.get("goal") or ""),success_criteria=kwargs.get("success_criteria") or (),dependencies=kwargs.get("dependencies") or (),priority=int(kwargs.get("priority",50)),step_budget=int(kwargs.get("step_budget",30)),replan_budget=int(kwargs.get("replan_budget",12)),quantum=int(kwargs.get("quantum",3)))
        return x.as_dict()

class WorkbenchRunCycleAction(Action):
    name="workbench_run_cycle"; capability="workbench.run"
    def __init__(self,wb):self.wb=wb
    def run(self,**kwargs): return [x.as_dict() for x in self.wb.run_cycle(max_jobs=int(kwargs.get("max_jobs",4)))]

class _Ctl(Action):
    capability="workbench.manage"; method=""
    def __init__(self,wb):self.wb=wb
    def run(self,**kwargs): return getattr(self.wb,self.method)(str(kwargs.get("work_id") or "")).as_dict()
class WorkbenchPauseAction(_Ctl): name="workbench_pause";method="pause"
class WorkbenchResumeAction(_Ctl): name="workbench_resume";method="resume"
class WorkbenchCancelAction(_Ctl): name="workbench_cancel";method="cancel"
