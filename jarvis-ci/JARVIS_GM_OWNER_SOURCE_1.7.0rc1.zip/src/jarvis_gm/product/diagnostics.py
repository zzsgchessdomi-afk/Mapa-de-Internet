from __future__ import annotations

from pathlib import Path
import importlib.util
import json
import os
import platform
import sqlite3
from contextlib import closing
import sys
import tempfile
import time


class DiagnosticsRunner:
    def __init__(self, data_dir: Path, product_version: str = "1.2.0a2") -> None:
        self.data_dir = Path(data_dir)
        self.product_version = str(product_version)

    @staticmethod
    def _module(name: str) -> dict:
        try:
            return {"available": importlib.util.find_spec(name) is not None}
        except (ImportError, ValueError):
            return {"available": False}

    def _sqlite(self, name: str = "memory.sqlite3") -> dict:
        path = self.data_dir / name
        if not path.exists():
            return {"status": "missing", "detail": "created on first runtime start"}
        try:
            with closing(sqlite3.connect(path)) as con:
                result = con.execute("PRAGMA quick_check").fetchone()[0]
            return {"status": "ok" if result == "ok" else "error", "detail": result}
        except sqlite3.Error as exc:
            return {"status": "error", "detail": str(exc)}

    def _json_file(self, name: str) -> dict:
        path = self.data_dir / name
        if not path.exists():
            return {"status": "missing"}
        try:
            json.loads(path.read_text(encoding="utf-8"))
            return {"status": "ok"}
        except (OSError, json.JSONDecodeError) as exc:
            return {"status": "error", "detail": str(exc)}

    def _writable(self) -> dict:
        self.data_dir.mkdir(parents=True, exist_ok=True)
        try:
            with tempfile.NamedTemporaryFile(dir=self.data_dir, delete=True) as fh:
                fh.write(b"ok"); fh.flush()
            return {"status": "ok"}
        except OSError as exc:
            return {"status": "error", "detail": str(exc)}

    def run(self, runtime=None) -> dict:
        is_windows = os.name == "nt"
        report = {
            "generated_at": time.time(),
            "product": "JARVIS GM",
            "version": self.product_version,
            "platform": {
                "system": platform.system(),
                "release": platform.release(),
                "machine": platform.machine(),
                "python": sys.version.split()[0],
                "frozen": bool(getattr(sys, "frozen", False)),
                "target_windows": is_windows,
            },
            "storage": {
                "data_dir": str(self.data_dir),
                "writable": self._writable(),
                "sqlite": self._sqlite(),
                "world_model_sqlite": self._sqlite("world_model.sqlite3"),
                "guardian_sqlite": self._sqlite("guardian.sqlite3"),
                "personal_os_sqlite": self._sqlite("personal_os.sqlite3"),
                "workbench_sqlite": self._sqlite("workbench.sqlite3"),
                "swarm_sqlite": self._sqlite("swarm.sqlite3"),
                "evolution_sqlite": self._sqlite("evolution.sqlite3"),
                "reality_sqlite": self._sqlite("reality.sqlite3"),
                "reality_config_json": self._json_file("reality_config.json"),
                "acceptance_json": self._json_file("acceptance.json"),
                "release_state_json": self._json_file("release_state.json"),
                "health_state_json": self._json_file("health_state.json"),
                "permissions_json": self._json_file("permissions.json"),
                "apps_json": self._json_file("apps.json"),
                "allowed_paths_json": self._json_file("allowed_paths.json"),
            },
            "dependencies": {
                "tkinter": self._module("tkinter"),
                "PIL": self._module("PIL"),
                "cv2": self._module("cv2"),
                "mediapipe": self._module("mediapipe"),
                "win32com": self._module("win32com"),
                "pywinauto": self._module("pywinauto"),
            },
            "hardware_acceptance": {
                "status": "pending_physical_windows_test",
                "camera": "not_claimed",
                "microphone": "not_claimed",
                "windows_ui_automation": "not_claimed",
                "real_mouse_keyboard": "not_claimed",
                "android_companion": "source_present_not_built_or_device_tested",
                "mobile_relay": "not_claimed_until_owner_starts_and_pairs",
            },
        }
        if runtime is not None:
            try: report["perception"] = runtime.perception.status()
            except Exception as exc: report["perception"] = {"status": "error", "detail": str(exc)}
            try:
                report["provider"] = {"name": runtime.providers.active_name, "available": bool(runtime.providers.active.available)}
            except Exception as exc: report["provider"] = {"status": "error", "detail": str(exc)}
            try:
                report["kill_switch"] = {"engaged": bool(runtime.kill_switch.engaged)}
                report["safe_mode"] = bool(runtime.recovery_state.safe_mode)
            except Exception: pass
            try: report["mobile"] = runtime.mobile.summary()
            except Exception as exc: report["mobile"] = {"status":"error","detail":str(exc)}
            try: report["world_model"] = runtime.world_model.store.stats()
            except Exception as exc: report["world_model"] = {"status":"error","detail":str(exc)}
            try: report["guardian"] = {"enforced": runtime.policy.is_allowed("guardian.enforce"), "recent_audit_rows": len(runtime.guardian.store.recent_audit(100))}
            except Exception as exc: report["guardian"] = {"status":"error","detail":str(exc)}
            try: report["personal_os"] = {"resources": len(runtime.personal_os.store.list(limit=500)), "handoffs": len(runtime.personal_os.store.handoffs(100)), "route_enabled": runtime.policy.is_allowed("os.route")}
            except Exception as exc: report["personal_os"] = {"status":"error","detail":str(exc)}
            try: report["workbench"] = runtime.workbench.store.stats()
            except Exception as exc: report["workbench"] = {"status":"error","detail":str(exc)}
            try: report["swarm"] = runtime.swarm.store.stats()
            except Exception as exc: report["swarm"] = {"status":"error","detail":str(exc)}
            try: report["evolution"] = runtime.evolution.store.stats()
            except Exception as exc: report["evolution"] = {"status":"error","detail":str(exc)}
            try: report["reality"] = runtime.reality.status()
            except Exception as exc: report["reality"] = {"status":"error","detail":str(exc)}
            try: report["health"] = runtime.health.sample(runtime).as_dict()
            except Exception as exc: report["health"] = {"status":"error","detail":str(exc)}
            try: report["acceptance"] = runtime.acceptance.report()
            except Exception as exc: report["acceptance"] = {"status":"error","detail":str(exc)}
            try: report["release"] = runtime.release.status()
            except Exception as exc: report["release"] = {"status":"error","detail":str(exc)}
            try: report["release_gate"] = runtime.release_gate.evaluate_from_diagnostics(report,runtime)
            except Exception as exc: report["release_gate"] = {"status":"error","detail":str(exc)}
        return report

    def write_report(self, destination: Path, runtime=None) -> Path:
        destination = Path(destination)
        destination.parent.mkdir(parents=True, exist_ok=True)
        payload = self.run(runtime)
        tmp = destination.with_suffix(destination.suffix + ".tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")
        tmp.replace(destination)
        return destination
