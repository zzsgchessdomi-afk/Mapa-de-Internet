from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
import json, time

CHECKS = (
    "windows_installer", "frozen_self_test", "windows_ui_automation", "mouse_keyboard",
    "camera_hands", "microphone_voice", "android_pairing", "android_location",
    "android_lock_auth", "global_stop", "reality_bridge",
)
VALID = {"pending","passed","failed","not_applicable"}

@dataclass(slots=True)
class AcceptanceItem:
    name: str
    status: str = "pending"
    updated_at: float = 0.0
    note: str = ""

class AcceptanceStore:
    """Owner-controlled physical acceptance. Automation may read but never mark PASS."""
    def __init__(self, data_dir: Path) -> None:
        self.path=Path(data_dir)/"acceptance.json"; self.items={name:AcceptanceItem(name) for name in CHECKS}; self._load()
    def _load(self):
        if not self.path.exists(): return
        try:
            raw=json.loads(self.path.read_text(encoding="utf-8"))
            for name,data in raw.get("checks",{}).items():
                if name in self.items and isinstance(data,dict) and data.get("status") in VALID:
                    self.items[name]=AcceptanceItem(name,data.get("status","pending"),float(data.get("updated_at") or 0),str(data.get("note") or "")[:500])
        except (OSError,ValueError,TypeError,json.JSONDecodeError): pass
    def _save(self):
        self.path.parent.mkdir(parents=True,exist_ok=True); tmp=self.path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps({"format":1,"checks":{k:asdict(v) for k,v in self.items.items()}},indent=2,sort_keys=True),encoding="utf-8"); tmp.replace(self.path)
    def set_owner_result(self,name:str,status:str,note:str="") -> AcceptanceItem:
        if name not in self.items: raise KeyError(name)
        if status not in VALID: raise ValueError(status)
        item=AcceptanceItem(name,status,time.time(),str(note)[:500]); self.items[name]=item; self._save(); return item
    def report(self)->dict:
        counts={s:0 for s in VALID}
        for item in self.items.values(): counts[item.status]+=1
        return {"checks":{k:asdict(v) for k,v in self.items.items()},"counts":counts,"all_required_passed":all(x.status in {"passed","not_applicable"} for x in self.items.values())}
