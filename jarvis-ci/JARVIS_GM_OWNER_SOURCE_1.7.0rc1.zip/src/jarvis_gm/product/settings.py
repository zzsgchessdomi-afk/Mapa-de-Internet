from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json


@dataclass(slots=True)
class ProviderSettings:
    path: Path
    active: str = "gemini"
    gemini_model: str = "gemini-3.8-flash"

    @classmethod
    def load(cls, path: Path) -> "ProviderSettings":
        path = Path(path)
        obj = cls(path)
        if path.exists():
            try:
                raw = json.loads(path.read_text(encoding="utf-8"))
                if isinstance(raw, dict):
                    active = raw.get("active")
                    model = raw.get("gemini_model")
                    if isinstance(active, str) and active.strip():
                        obj.active = active.strip()
                    if isinstance(model, str) and model.strip():
                        obj.gemini_model = model.strip()
            except (OSError, json.JSONDecodeError):
                pass
        obj.save()
        return obj

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps({"active": self.active, "gemini_model": self.gemini_model}, indent=2, sort_keys=True), encoding="utf-8")
        tmp.replace(self.path)
