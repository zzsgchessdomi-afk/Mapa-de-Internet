from __future__ import annotations

import os


class CredentialStore:
    """Optional OS credential-store adapter.

    Secrets are never written into JARVIS's data directory or backups. On Windows,
    the `keyring` package normally uses Windows Credential Locker. If no secure
    backend exists, persistence is refused instead of falling back to plaintext.
    """

    def __init__(self, service: str = "JARVIS_GM") -> None:
        self.service = service

    def _backend(self):
        try:
            import keyring
            kr = keyring.get_keyring()
            priority = getattr(kr, "priority", 0)
            if callable(priority):
                priority = priority()
            if not priority or float(priority) <= 0:
                return None
            return keyring
        except Exception:
            return None

    @property
    def available(self) -> bool:
        return self._backend() is not None

    def get(self, name: str) -> str | None:
        env = os.getenv(name)
        if env:
            return env
        backend = self._backend()
        if backend is None:
            return None
        try:
            value = backend.get_password(self.service, name)
            return value if value else None
        except Exception:
            return None

    def set(self, name: str, value: str) -> None:
        value = value.strip()
        if not value:
            raise ValueError("Secret cannot be empty")
        backend = self._backend()
        if backend is None:
            raise RuntimeError("No secure OS credential backend is available")
        backend.set_password(self.service, name, value)

    def delete(self, name: str) -> None:
        backend = self._backend()
        if backend is None:
            return
        try:
            backend.delete_password(self.service, name)
        except Exception:
            pass
