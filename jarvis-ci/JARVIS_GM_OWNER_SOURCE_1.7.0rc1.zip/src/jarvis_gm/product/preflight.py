from __future__ import annotations
from pathlib import Path
import json,tempfile,time
from jarvis_gm.runtime import build_infinity7_runtime
from jarvis_gm.control.simulated_backend import SimulatedDesktopBackend


def run_preflight(destination:Path|None=None)->dict:
    with tempfile.TemporaryDirectory(prefix="jarvis_preflight_") as td:
        rt=build_infinity7_runtime(Path(td),SimulatedDesktopBackend())
        try:
            gate=rt.release_gate.evaluate(rt);diag=rt.diagnostics.run(rt);health=rt.health.sample(rt).as_dict()
            report={"generated_at":time.time(),"product":"JARVIS GM","version":"1.7.0rc1","automated_runtime_constructed":True,"release_gate":gate,"health":health,"frozen":diag.get("platform",{}).get("frozen",False),"physical_acceptance":"pending_owner_hardware_test"}
        finally: rt.clean_shutdown()
    if destination:
        destination=Path(destination);destination.parent.mkdir(parents=True,exist_ok=True);destination.write_text(json.dumps(report,indent=2,sort_keys=True),encoding="utf-8")
    return report
