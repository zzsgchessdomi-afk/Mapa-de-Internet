from __future__ import annotations
from pathlib import Path
import json, re, time, zipfile

_SECRET_RE = re.compile(r"(?i)(api[_ -]?key|password|secret|token|authorization|pin)(\s*[:=]\s*)([^\s,;\"']+)")

def _scrub(text:str)->str:
    text=_SECRET_RE.sub(lambda m: m.group(1)+m.group(2)+"<redacted>",text)
    return text[-50000:]

class SupportBundleExporter:
    def __init__(self,data_dir:Path,diagnostics,acceptance,health):
        self.data_dir=Path(data_dir);self.diagnostics=diagnostics;self.acceptance=acceptance;self.health=health
    def create(self,destination:Path,runtime=None)->Path:
        destination=Path(destination);destination.parent.mkdir(parents=True,exist_ok=True)
        diag=self.diagnostics.run(runtime); acc=self.acceptance.report(); health=self.health.recent(100)
        try:
            if isinstance(diag.get("storage"),dict): diag["storage"]["data_dir"]="<redacted-local-path>"
            mobile=diag.get("mobile")
            if isinstance(mobile,dict) and isinstance(mobile.get("devices"),list):
                mobile["device_count"]=len(mobile["devices"]); mobile["devices"]=[{"platform":d.get("platform"),"enabled":bool(d.get("enabled")),"capabilities":list(d.get("capabilities") or ())} for d in mobile["devices"] if isinstance(d,dict)]
                mobile["relay_cert_sha256"]="<redacted>" if mobile.get("relay_cert_sha256") else None
            for container in (acc, diag.get("acceptance") if isinstance(diag.get("acceptance"),dict) else {}):
                for item in container.get("checks",{}).values():
                    if isinstance(item,dict) and item.get("note"): item["note"]="<redacted-by-support-export>"
        except Exception: pass
        crash_path=self.data_dir/"logs"/"crash.jsonl"; crash=_scrub(crash_path.read_text(encoding="utf-8",errors="replace")) if crash_path.exists() else ""
        perms={}
        try: perms={k:bool(v) for k,v in runtime.policy.rules.items()} if runtime is not None else {}
        except Exception: pass
        tmp=destination.with_suffix(destination.suffix+".tmp")
        with zipfile.ZipFile(tmp,"w",compression=zipfile.ZIP_DEFLATED) as z:
            z.writestr("support_manifest.json",json.dumps({"format":1,"product":"JARVIS GM","created_at":time.time(),"privacy":"No workspace files, secrets, screenshots, audio or contact data are included."},indent=2))
            z.writestr("diagnostics.json",json.dumps(diag,ensure_ascii=False,indent=2,default=str))
            z.writestr("acceptance.json",_scrub(json.dumps(acc,ensure_ascii=False,indent=2,default=str)))
            z.writestr("health_recent.json",_scrub(json.dumps(health,ensure_ascii=False,indent=2,default=str)))
            z.writestr("permissions.json",json.dumps(perms,indent=2,sort_keys=True))
            if crash: z.writestr("crash_tail.txt",crash)
        tmp.replace(destination);return destination
