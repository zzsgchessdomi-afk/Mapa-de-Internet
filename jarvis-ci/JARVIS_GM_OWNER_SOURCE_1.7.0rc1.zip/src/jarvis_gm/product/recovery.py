from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json
import os
import time
import uuid

from jarvis_gm.core.permissions import PermissionPolicy

SAFE_MODE_CAPABILITIES = (
    "system.control",
    "input.control",
    "window.control",
    "app.launch",
    "browser.open",
    "filesystem.read",
    "filesystem.write",
    "external.send",
    "security.sensitive",
    "agent.run",
    "research.web",
    "research.deep",
    "autonomy.run",
    "memory.cloud",
    "memory.manage",
    "skill.learn",
    "skill.manage",
    "skill.execute",
    "screen.cloud",
    "perception.continuous",
    "perception.cloud",
    "mobile.location",
    "mobile.control",
    "mobile.security",
    "mobile.messaging",
    "mobile.contacts",
    "mobile.relay",
    "world.cloud",
    "os.cloud",
    "os.route",
    "os.handoff",
    "os.manage",
    "workbench.run",
    "workbench.manage",
    "workbench.cloud",
    "swarm.run",
    "swarm.cloud",
    "evolution.run",
    "evolution.manage",
    "evolution.cloud",
    "reality.continuous",
    "reality.control",
    "reality.manage",
    "reality.security",
    "reality.cloud",
    "support.export",
    "release.manage",
)


def _atomic_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")
    tmp.replace(path)


@dataclass(slots=True)
class RecoveryState:
    session_id: str
    safe_mode: bool
    previous_unclean: bool
    started_at: float
    reason: str = ""


class RecoveryManager:
    """Crash marker + fail-safe capability downgrade.

    A previous unclean session never grants authority. On the next start, risky
    capabilities are disabled in the owner's persisted policy and must be
    deliberately re-enabled by the owner.
    """

    def __init__(self, data_dir: Path) -> None:
        self.data_dir = Path(data_dir)
        self.path = self.data_dir / "runtime_state.json"
        self._state: RecoveryState | None = None

    def _load(self) -> dict:
        if not self.path.exists():
            return {}
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            return raw if isinstance(raw, dict) else {}
        except (OSError, json.JSONDecodeError):
            return {"status": "corrupt"}

    def begin(self, policy: PermissionPolicy) -> RecoveryState:
        previous = self._load()
        previous_unclean = previous.get("status") in {"running", "corrupt"}
        safe_mode = bool(previous_unclean)
        reason = ""
        if safe_mode:
            reason = "Previous session did not record a clean shutdown; risky capabilities were disabled."
            for capability in SAFE_MODE_CAPABILITIES:
                if policy.is_allowed(capability):
                    policy.set(capability, False)
            # A crash never leaves the independent supervisor disabled. The owner
            # can deliberately disable it again after reviewing Safe Mode.
            if not policy.is_allowed("guardian.enforce"):
                policy.set("guardian.enforce", True)
        state = RecoveryState(
            session_id=f"session_{uuid.uuid4().hex}",
            safe_mode=safe_mode,
            previous_unclean=previous_unclean,
            started_at=time.time(),
            reason=reason,
        )
        self._state = state
        _atomic_json(self.path, {
            "status": "running",
            "session_id": state.session_id,
            "started_at": state.started_at,
            "pid": os.getpid(),
            "safe_mode": state.safe_mode,
            "reason": state.reason,
        })
        return state

    @property
    def state(self) -> RecoveryState | None:
        return self._state

    def mark_clean(self) -> None:
        now = time.time()
        state = self._state
        _atomic_json(self.path, {
            "status": "clean",
            "session_id": state.session_id if state else None,
            "started_at": state.started_at if state else None,
            "ended_at": now,
            "pid": os.getpid(),
            "safe_mode": False,
            "reason": "clean shutdown",
        })
        if state is not None:
            state.safe_mode = False

    def clear_safe_mode_marker(self) -> None:
        """Owner acknowledgement only; permissions stay as currently configured."""
        if self._state is not None:
            self._state.safe_mode = False
            self._state.reason = ""
        current = self._load()
        current["safe_mode"] = False
        current["reason"] = "owner acknowledged recovery mode"
        _atomic_json(self.path, current)
