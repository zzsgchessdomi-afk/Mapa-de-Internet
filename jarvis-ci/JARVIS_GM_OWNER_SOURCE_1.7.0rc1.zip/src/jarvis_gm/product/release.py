from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path, PurePosixPath
import hashlib,json,re,shutil,time,zipfile
from jarvis_gm.core.models import ActionRequest

MAX_UPDATE_FILES=5000
MAX_MANIFEST_BYTES=2_000_000
MAX_UPDATE_UNCOMPRESSED=2_000_000_000

_VER_RE=re.compile(r"^(\d+)\.(\d+)\.(\d+)(?:(a|b|rc)(\d+))?$")

def version_key(v:str):
    m=_VER_RE.fullmatch(str(v).strip())
    if not m: raise ValueError(f"Unsupported version: {v}")
    major,minor,patch=map(int,m.group(1,2,3)); tag=m.group(4); n=int(m.group(5) or 0); rank={"a":0,"b":1,"rc":2,None:3}[tag]
    return major,minor,patch,rank,n

def _safe(path:str)->PurePosixPath:
    p=PurePosixPath(path)
    if p.is_absolute() or ".." in p.parts or not p.parts: raise ValueError(f"Unsafe update path: {path}")
    return p

@dataclass(slots=True)
class UpdateValidation:
    ok: bool
    version: str|None=None
    errors: tuple[str,...]=()
    files: int=0

class ReleaseManager:
    """Verifies and stages owner-approved update packages; never self-overwrites the running EXE."""
    def __init__(self,data_dir:Path,current_version:str,*,policy,guardian):
        self.data_dir=Path(data_dir);self.current_version=current_version;self.policy=policy;self.guardian=guardian
        self.updates=self.data_dir/"updates";self.state_path=self.data_dir/"release_state.json";self.updates.mkdir(parents=True,exist_ok=True)
    @staticmethod
    def validate_package(path:Path,current_version:str)->UpdateValidation:
        errors=[]
        try:
            with zipfile.ZipFile(path) as z:
                infos=z.infolist(); raw_names=[i.filename for i in infos]; names=set(raw_names)
                if len(raw_names)!=len(names): errors.append("Duplicate archive member names are not allowed")
                if len(infos)>MAX_UPDATE_FILES+1: errors.append("Update contains too many members")
                if sum(max(0,i.file_size) for i in infos)>MAX_UPDATE_UNCOMPRESSED: errors.append("Update uncompressed size exceeds safety limit")
                if "release_manifest.json" not in names:return UpdateValidation(False,errors=("Missing release_manifest.json",))
                mi=z.getinfo("release_manifest.json")
                if mi.file_size>MAX_MANIFEST_BYTES:return UpdateValidation(False,errors=("Release manifest is too large",))
                manifest=json.loads(z.read("release_manifest.json").decode("utf-8"))
                if manifest.get("format")!=1: errors.append("Unsupported release manifest format")
                if manifest.get("product")!="JARVIS GM":errors.append("Wrong product")
                version=str(manifest.get("version") or "")
                try:
                    if version_key(version)<=version_key(current_version):errors.append("Update must be newer than installed version")
                except ValueError as exc:errors.append(str(exc))
                files=manifest.get("files")
                if not isinstance(files,list) or not files:errors.append("Manifest has no payload files");files=[]
                expected={"release_manifest.json"}
                seen=set()
                for item in files:
                    rel=_safe(str(item.get("path") or "")); key=rel.as_posix()
                    if key in seen:errors.append(f"Duplicate path: {key}");continue
                    seen.add(key);arc=f"payload/{key}";expected.add(arc)
                    if arc not in names:errors.append(f"Missing payload: {key}");continue
                    data=z.read(arc)
                    if hashlib.sha256(data).hexdigest()!=item.get("sha256"):errors.append(f"Hash mismatch: {key}")
                    if len(data)!=item.get("size"):errors.append(f"Size mismatch: {key}")
                extras=names-expected
                if extras:errors.append("Unexpected members: "+", ".join(sorted(extras)[:8]))
                return UpdateValidation(not errors,version or None,tuple(errors),len(files))
        except (OSError,zipfile.BadZipFile,json.JSONDecodeError,UnicodeDecodeError,ValueError) as exc:
            return UpdateValidation(False,errors=(str(exc),))
    def stage(self,path:Path)->Path:
        self.policy.require("release.manage")
        req=ActionRequest("release_stage",{"package":Path(path).name},"release.manage")
        dec=self.guardian.authorize(req)
        if not dec.allowed: raise PermissionError(dec.reason)
        # Copy first, then validate the exact bytes that will be staged. This closes
        # a validate-then-swap race on the source path (TOCTOU).
        dst=self.updates/"pending.jarvisupdate";tmp=dst.with_suffix(".tmp")
        shutil.copy2(path,tmp)
        val=self.validate_package(tmp,self.current_version)
        if not val.ok:
            tmp.unlink(missing_ok=True)
            raise ValueError("Update validation failed: "+"; ".join(val.errors))
        package_hash=hashlib.sha256(tmp.read_bytes()).hexdigest();tmp.replace(dst)
        # Recheck the staged bytes before recording them as pending.
        if hashlib.sha256(dst.read_bytes()).hexdigest()!=package_hash:
            dst.unlink(missing_ok=True);raise RuntimeError("Staged update changed during commit")
        state={"status":"staged","version":val.version,"files":val.files,"staged_at":time.time(),"package_sha256":package_hash,"apply":"Run the verified newer installer after clean shutdown; JARVIS never overwrites its running executable."}
        t=self.state_path.with_suffix(".json.tmp");t.write_text(json.dumps(state,indent=2,sort_keys=True),encoding="utf-8");t.replace(self.state_path);return dst
    def status(self)->dict:
        if not self.state_path.exists(): return {"status":"none","current_version":self.current_version}
        try:return {"current_version":self.current_version,**json.loads(self.state_path.read_text(encoding="utf-8"))}
        except Exception:return {"status":"corrupt","current_version":self.current_version}
    def clear(self)->None:
        self.policy.require("release.manage");(self.updates/"pending.jarvisupdate").unlink(missing_ok=True);self.state_path.unlink(missing_ok=True)

class ReleaseGate:
    def __init__(self,version:str,diagnostics,acceptance):self.version=version;self.diagnostics=diagnostics;self.acceptance=acceptance
    def evaluate_from_diagnostics(self,diag:dict,runtime=None)->dict:
        acc=self.acceptance.report(); blockers=[]
        storage=diag.get("storage",{})
        for name,state in storage.items():
            if isinstance(state,dict) and state.get("status")=="error":blockers.append(f"storage:{name}")
        if runtime is not None:
            try:
                if runtime.kill_switch.engaged:blockers.append("kill_switch_engaged")
            except Exception:pass
            try:
                if runtime.recovery_state.safe_mode:blockers.append("safe_mode")
            except Exception:pass
            try:
                if not runtime.policy.is_allowed("guardian.enforce"):blockers.append("guardian_disabled")
            except Exception:pass
        automated_ready=not blockers
        physical_ready=bool(acc.get("all_required_passed"))
        if blockers:status="release-blocked"
        elif not physical_ready:status="physical-pending"
        else:status="release-ready"
        return {"product":"JARVIS GM","version":self.version,"status":status,"automated_ready":automated_ready,"physical_ready":physical_ready,"blockers":blockers,"acceptance":acc.get("counts",{}),"truth":"Automated checks never mark physical hardware acceptance as passed."}
    def evaluate(self,runtime=None)->dict:
        diag=self.diagnostics.run(None)
        return self.evaluate_from_diagnostics(diag,runtime)
