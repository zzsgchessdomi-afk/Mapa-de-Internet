from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path, PurePosixPath
import hashlib
import json
import shutil
import tempfile
import time
import zipfile

BACKUP_FORMAT = 1
BACKUP_ENTRIES = (
    "memory.sqlite3",
    "world_model.sqlite3",
    "guardian.sqlite3",
    "personal_os.sqlite3",
    "workbench.sqlite3",
    "swarm.sqlite3",
    "evolution.sqlite3",
    "reality.sqlite3",
    "reality_config.json",
    "permissions.json",
    "apps.json",
    "allowed_paths.json",
    "intent_config.json",
    "provider_config.json",
    "acceptance.json",
    "workspace",
    "skills",
    "mission_runs",
)


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _safe_member(name: str) -> PurePosixPath:
    p = PurePosixPath(name)
    if p.is_absolute() or ".." in p.parts or not p.parts:
        raise ValueError(f"Unsafe backup member: {name}")
    return p


def _allowed_payload_path(path: PurePosixPath) -> bool:
    if not path.parts:
        return False
    top = path.parts[0]
    allowed_files = {x for x in BACKUP_ENTRIES if "/" not in x and "." in x}
    allowed_dirs = {x for x in BACKUP_ENTRIES if "/" not in x and "." not in x}
    if top in allowed_files:
        return len(path.parts) == 1
    return top in allowed_dirs


@dataclass(slots=True)
class BackupValidation:
    ok: bool
    errors: tuple[str, ...]
    files: int = 0
    created_at: float | None = None


class BackupManager:
    def __init__(self, data_dir: Path, product_version: str = "1.3.0a3") -> None:
        self.data_dir = Path(data_dir)
        self.product_version = product_version

    def _iter_files(self):
        for entry in BACKUP_ENTRIES:
            path = self.data_dir / entry
            if path.is_file():
                yield path, path.relative_to(self.data_dir)
            elif path.is_dir():
                for file in sorted(path.rglob("*")):
                    if file.is_file() and "__pycache__" not in file.parts:
                        yield file, file.relative_to(self.data_dir)

    def create(self, destination: Path) -> Path:
        destination = Path(destination)
        destination.parent.mkdir(parents=True, exist_ok=True)
        manifest_files = []
        payloads: list[tuple[Path, str]] = []
        for file, rel in self._iter_files():
            data = file.read_bytes()
            arc = f"payload/{rel.as_posix()}"
            manifest_files.append({"path": rel.as_posix(), "sha256": _sha256_bytes(data), "size": len(data)})
            payloads.append((file, arc))
        manifest = {
            "format": BACKUP_FORMAT,
            "product": "JARVIS GM",
            "version": self.product_version,
            "created_at": time.time(),
            "files": manifest_files,
        }
        tmp = destination.with_suffix(destination.suffix + ".tmp")
        with zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
            zf.writestr("backup_manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True))
            for file, arc in payloads:
                zf.write(file, arc)
        tmp.replace(destination)
        return destination

    @staticmethod
    def validate(archive: Path) -> BackupValidation:
        archive = Path(archive)
        errors: list[str] = []
        try:
            with zipfile.ZipFile(archive, "r") as zf:
                names = zf.namelist()
                if len(names) != len(set(names)):
                    errors.append("Duplicate archive member names are not allowed")
                for name in names:
                    _safe_member(name)
                if "backup_manifest.json" not in names:
                    return BackupValidation(False, ("backup_manifest.json missing",))
                manifest = json.loads(zf.read("backup_manifest.json").decode("utf-8"))
                if manifest.get("format") != BACKUP_FORMAT:
                    errors.append("Unsupported backup format")
                files = manifest.get("files")
                if not isinstance(files, list):
                    return BackupValidation(False, ("Invalid manifest files list",))
                expected_names = {"backup_manifest.json"}
                seen_paths: set[str] = set()
                for item in files:
                    if not isinstance(item, dict) or not isinstance(item.get("path"), str):
                        errors.append("Invalid manifest entry")
                        continue
                    rel = _safe_member(item["path"])
                    if not _allowed_payload_path(rel):
                        errors.append(f"Disallowed payload path: {rel}")
                        continue
                    if rel.as_posix() in seen_paths:
                        errors.append(f"Duplicate manifest path: {rel}")
                        continue
                    seen_paths.add(rel.as_posix())
                    arc = f"payload/{rel.as_posix()}"
                    expected_names.add(arc)
                    if arc not in names:
                        errors.append(f"Missing payload: {rel}")
                        continue
                    data = zf.read(arc)
                    if _sha256_bytes(data) != item.get("sha256"):
                        errors.append(f"Hash mismatch: {rel}")
                    if len(data) != item.get("size"):
                        errors.append(f"Size mismatch: {rel}")
                extras = set(names) - expected_names
                if extras:
                    errors.append("Unexpected members: " + ", ".join(sorted(extras)[:8]))
                return BackupValidation(not errors, tuple(errors), files=len(files), created_at=manifest.get("created_at"))
        except (OSError, zipfile.BadZipFile, json.JSONDecodeError, UnicodeDecodeError, ValueError) as exc:
            return BackupValidation(False, (str(exc),))

    def stage_restore(self, archive: Path) -> Path:
        validation = self.validate(archive)
        if not validation.ok:
            raise ValueError("Backup validation failed: " + "; ".join(validation.errors))
        pending = self.data_dir / "pending_restore.jarvisbackup"
        tmp = pending.with_suffix(pending.suffix + ".tmp")
        shutil.copy2(archive, tmp)
        tmp.replace(pending)
        return pending


def apply_pending_restore(data_dir: Path) -> bool:
    """Apply a previously validated restore before runtime stores are opened."""
    root = Path(data_dir)
    pending = root / "pending_restore.jarvisbackup"
    if not pending.exists():
        return False
    validation = BackupManager.validate(pending)
    if not validation.ok:
        bad = root / f"rejected_restore_{int(time.time())}.jarvisbackup"
        pending.replace(bad)
        raise ValueError("Pending restore rejected: " + "; ".join(validation.errors))
    with tempfile.TemporaryDirectory(prefix="jarvis_restore_") as td:
        staging = Path(td)
        with zipfile.ZipFile(pending, "r") as zf:
            manifest = json.loads(zf.read("backup_manifest.json").decode("utf-8"))
            for item in manifest["files"]:
                rel = _safe_member(item["path"])
                data = zf.read(f"payload/{rel.as_posix()}")
                dst = staging / Path(*rel.parts)
                dst.parent.mkdir(parents=True, exist_ok=True)
                dst.write_bytes(data)
        # Merge restore atomically file-by-file. Existing unrelated owner data is retained.
        for file in sorted(staging.rglob("*")):
            if not file.is_file():
                continue
            rel = file.relative_to(staging)
            dst = root / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            tmp = dst.with_suffix(dst.suffix + ".restoretmp")
            shutil.copy2(file, tmp)
            tmp.replace(dst)
    pending.unlink(missing_ok=True)
    return True
