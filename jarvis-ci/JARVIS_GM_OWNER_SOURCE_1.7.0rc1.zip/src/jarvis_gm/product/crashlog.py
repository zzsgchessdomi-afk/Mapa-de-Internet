from __future__ import annotations

from pathlib import Path
import json
import re
import time
import traceback

_SECRET_PATTERNS=(
    re.compile(r"(?i)((?:api[_ -]?key|password|passwd|secret|token|authorization|pin)\s*[:=]\s*)([^\s,;\"']+)"),
    re.compile(r"(?i)(bearer\s+)([A-Za-z0-9._~+/=-]{8,})"),
    re.compile(r"(?i)([?&](?:key|token|api_key)=)([^&\s]+)"),
)

def _scrub(text:str)->str:
    value=str(text)
    for pattern in _SECRET_PATTERNS:value=pattern.sub(lambda m:m.group(1)+"<redacted>",value)
    return value

class CrashJournal:
    def __init__(self, data_dir: Path, max_bytes: int = 2_000_000) -> None:
        self.path = Path(data_dir) / "logs" / "crash.jsonl"
        self.max_bytes = max_bytes
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def _rotate(self) -> None:
        try:
            if self.path.exists() and self.path.stat().st_size > self.max_bytes:
                old = self.path.with_suffix(".jsonl.1")
                old.unlink(missing_ok=True)
                self.path.replace(old)
        except OSError:
            pass

    def record_exception(self, exc_type, exc_value, exc_tb, *, source: str = "runtime") -> None:
        self._rotate()
        payload = {
            "timestamp": time.time(),
            "source": _scrub(source)[:200],
            "type": getattr(exc_type, "__name__", str(exc_type)),
            "message": _scrub(str(exc_value))[:4000],
            "traceback": _scrub("".join(traceback.format_exception(exc_type, exc_value, exc_tb))[-20000:]),
        }
        try:
            with self.path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(payload, ensure_ascii=False) + "\n")
        except OSError:
            pass
