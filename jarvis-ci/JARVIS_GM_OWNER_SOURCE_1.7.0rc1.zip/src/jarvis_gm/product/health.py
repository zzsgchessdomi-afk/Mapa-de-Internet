from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
from threading import Event, Thread, Lock
from typing import Any
import json
import time


SENSITIVE_KEYS = {"pin","password","secret","token","api_key","apikey","authorization","cookie","message","content","text"}


def _redact(value: Any, key: str = "") -> Any:
    if key.casefold() in SENSITIVE_KEYS:
        return "<redacted>"
    if isinstance(value, dict):
        return {str(k): _redact(v, str(k)) for k, v in value.items()}
    if isinstance(value, list):
        return [_redact(v) for v in value[:50]]
    if isinstance(value, tuple):
        return tuple(_redact(v) for v in value[:50])
    if isinstance(value, str) and len(value) > 1000:
        return value[:1000] + "…"
    return value


@dataclass(slots=True)
class HealthSnapshot:
    timestamp: float
    overall: str
    safe_mode: bool
    kill_switch: bool
    provider_available: bool
    perception: str
    mobile: str
    reality: str
    workbench: str
    guardian: str

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


class HealthSupervisor:
    """Local bounded observability without raw screen/audio/workspace capture."""

    def __init__(self, data_dir: Path, *, interval_s: float = 15.0, max_bytes: int = 1_000_000) -> None:
        self.data_dir = Path(data_dir)
        self.path = self.data_dir / "logs" / "health.jsonl"
        self.state_path = self.data_dir / "health_state.json"
        self.interval_s = max(2.0, float(interval_s))
        self.max_bytes = int(max_bytes)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._stop = Event(); self._thread: Thread | None = None; self._runtime = None; self._lock = Lock()

    @property
    def running(self) -> bool:
        return bool(self._thread and self._thread.is_alive())

    def _rotate(self) -> None:
        try:
            if self.path.exists() and self.path.stat().st_size > self.max_bytes:
                old = self.path.with_suffix(".jsonl.1")
                old.unlink(missing_ok=True); self.path.replace(old)
        except OSError:
            pass

    def event(self, kind: str, payload: dict[str, Any] | None = None, *, severity: str = "info") -> None:
        record = {"timestamp": time.time(), "kind": str(kind), "severity": str(severity), "payload": _redact(payload or {})}
        self._rotate()
        try:
            with self._lock, self.path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")
        except OSError:
            pass

    def sample(self, runtime) -> HealthSnapshot:
        def status(fn, fallback="unknown"):
            try: return str(fn())
            except Exception: return fallback
        safe = bool(getattr(getattr(runtime, "recovery_state", None), "safe_mode", False))
        kill = bool(getattr(getattr(runtime, "kill_switch", None), "engaged", False))
        try: provider = bool(runtime.providers.active.available)
        except Exception: provider = False
        try:
            ps = runtime.perception.status(); perception = "ok" if isinstance(ps, dict) else "unknown"
        except Exception: perception = "error"
        try:
            ms = runtime.mobile.summary(); mobile = "ok" if isinstance(ms, dict) else "unknown"
        except Exception: mobile = "error"
        try:
            rs = runtime.reality.status(); reality = "ok" if isinstance(rs, dict) else "unknown"
        except Exception: reality = "error"
        try:
            ws = runtime.workbench.store.stats(); workbench = "ok" if isinstance(ws, dict) else "unknown"
        except Exception: workbench = "error"
        try: guardian = "on" if runtime.policy.is_allowed("guardian.enforce") else "off"
        except Exception: guardian = "unknown"
        if safe or kill: overall = "guarded"
        elif any(x == "error" for x in (perception,mobile,reality,workbench)): overall = "degraded"
        else: overall = "ok"
        snap = HealthSnapshot(time.time(), overall, safe, kill, provider, perception, mobile, reality, workbench, guardian)
        tmp = self.state_path.with_suffix(".json.tmp")
        try:
            tmp.write_text(json.dumps(snap.as_dict(), indent=2, sort_keys=True), encoding="utf-8"); tmp.replace(self.state_path)
        except OSError: pass
        return snap

    def recent(self, limit: int = 100) -> list[dict[str, Any]]:
        if not self.path.exists(): return []
        try:
            lines = self.path.read_text(encoding="utf-8", errors="replace").splitlines()[-max(1,min(int(limit),500)):]
            out=[]
            for line in lines:
                try: out.append(json.loads(line))
                except json.JSONDecodeError: continue
            return out
        except OSError: return []

    def start(self, runtime, *, allowed=lambda: True) -> None:
        if self.running: return
        self._runtime = runtime; self._stop.clear()
        def loop():
            while not self._stop.is_set():
                if not allowed(): break
                try:
                    snap=self.sample(runtime); self.event("health.sample", {"overall":snap.overall,"safe_mode":snap.safe_mode,"kill_switch":snap.kill_switch})
                except Exception as exc:
                    self.event("health.error", {"type":type(exc).__name__}, severity="warning")
                # Wake frequently so STOP / policy changes terminate observability quickly.
                end=time.time()+self.interval_s
                while time.time()<end and not self._stop.is_set():
                    if not allowed():
                        self._stop.set(); break
                    self._stop.wait(min(0.25,max(0.0,end-time.time())))
        self._thread = Thread(target=loop, name="jarvis-health", daemon=True); self._thread.start()

    def stop(self) -> None:
        self._stop.set(); t=self._thread
        if t and t.is_alive(): t.join(timeout=min(2.0, self.interval_s))
        self._thread=None
