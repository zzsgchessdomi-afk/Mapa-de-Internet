from __future__ import annotations

import json
import queue
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
from dataclasses import asdict

from .runtime import build_infinity7_runtime
from .perception.events import PerceptionEvent

OPERATOR_CAPS=("input.control","window.control","app.launch","browser.open")


class JarvisApp(tk.Tk):
    def __init__(self)->None:
        super().__init__(); self.title("JARVIS GM — Infinity 7"); self.geometry("1240x860"); self.minsize(980,700)
        self.runtime=build_infinity7_runtime(); self.orchestrator=self.runtime.orchestrator; self.policy=self.runtime.policy
        self.kill=self.runtime.kill_switch; self.providers=self.runtime.providers; self.perception=self.runtime.perception
        self._events:queue.Queue[PerceptionEvent]=queue.Queue(maxsize=1500); self._bus_token=self.perception.bus.subscribe(self._capture_event)
        self.runtime.start_bridge(); self._build_ui(); self._refresh_status(); self.after(100,self._poll_events); self.protocol("WM_DELETE_WINDOW",self._close)
        self.report_callback_exception=self._tk_exception
        if self.runtime.recovery_state.safe_mode:
            self.after(250, lambda: messagebox.showwarning("JARVIS — Modo seguro", "El cierre anterior no quedó registrado como limpio. JARVIS desactivó automáticamente permisos de riesgo. Revisa Diagnóstico y vuelve a habilitar solo lo que quieras."))
        elif self.runtime.restored_on_start:
            self.after(250, lambda: messagebox.showinfo("JARVIS", "La restauración pendiente se aplicó antes de abrir la memoria y configuración."))

    def _build_ui(self)->None:
        root=ttk.Frame(self,padding=14); root.pack(fill="both",expand=True)
        ttk.Label(root,text="JARVIS GM",font=("Segoe UI",22,"bold")).pack(anchor="w")
        ttk.Label(root,text="Infinity 7 — Infinity Release • observabilidad, aceptación y release gate",font=("Segoe UI",10)).pack(anchor="w",pady=(0,8))
        self.status_var=tk.StringVar(); ttk.Label(root,textvariable=self.status_var,wraplength=1120).pack(anchor="w",pady=(0,8))

        toolbar=ttk.Frame(root); toolbar.pack(fill="x",pady=(0,8))
        self.operator_var=tk.BooleanVar(value=all(self.policy.is_allowed(c) for c in OPERATOR_CAPS)); ttk.Checkbutton(toolbar,text="MODO OPERADOR",variable=self.operator_var,command=self._toggle_operator).pack(side="left")
        self.memory_read_var=tk.BooleanVar(value=self.policy.is_allowed("memory.read")); ttk.Checkbutton(toolbar,text="Leer memoria",variable=self.memory_read_var,command=self._toggle_memory).pack(side="left",padx=(12,0))
        self.memory_write_var=tk.BooleanVar(value=self.policy.is_allowed("memory.write")); ttk.Checkbutton(toolbar,text="Guardar continuidad",variable=self.memory_write_var,command=self._toggle_memory).pack(side="left",padx=(8,0))
        self.memory_cloud_var=tk.BooleanVar(value=self.policy.is_allowed("memory.cloud")); ttk.Checkbutton(toolbar,text="Memoria → cloud",variable=self.memory_cloud_var,command=self._toggle_memory).pack(side="left",padx=(8,0))
        self.files_var=tk.BooleanVar(value=self.policy.is_allowed("filesystem.write")); ttk.Checkbutton(toolbar,text="Escritura de archivos",variable=self.files_var,command=self._toggle_files).pack(side="left",padx=(12,0))
        self.screen_observe_var=tk.BooleanVar(value=self.policy.is_allowed("screen.observe")); ttk.Checkbutton(toolbar,text="Pantalla local",variable=self.screen_observe_var,command=self._toggle_screen_observe).pack(side="left",padx=(12,0))
        self.cloud_screen_var=tk.BooleanVar(value=self.policy.is_allowed("screen.cloud")); ttk.Checkbutton(toolbar,text="Visión cloud",variable=self.cloud_screen_var,command=self._toggle_cloud_screen).pack(side="left",padx=(8,0))
        ttk.Button(toolbar,text="STOP GLOBAL",command=self.stop_now).pack(side="right"); ttk.Button(toolbar,text="Rearmar",command=self.reset_stop).pack(side="right",padx=6)

        autonomy=ttk.Frame(root); autonomy.pack(fill="x",pady=(0,8))
        self.agent_var=tk.BooleanVar(value=self.policy.is_allowed("agent.run")); ttk.Checkbutton(autonomy,text="Agent Director",variable=self.agent_var,command=self._toggle_autonomy).pack(side="left")
        self.skill_learn_var=tk.BooleanVar(value=self.policy.is_allowed("skill.learn")); ttk.Checkbutton(autonomy,text="Aprender skills",variable=self.skill_learn_var,command=self._toggle_autonomy).pack(side="left",padx=(12,0))
        self.skill_exec_var=tk.BooleanVar(value=self.policy.is_allowed("skill.execute")); ttk.Checkbutton(autonomy,text="Ejecutar skills",variable=self.skill_exec_var,command=self._toggle_autonomy).pack(side="left",padx=(8,0))
        self.web_research_var=tk.BooleanVar(value=self.policy.is_allowed("research.web")); ttk.Checkbutton(autonomy,text="Web research",variable=self.web_research_var,command=self._toggle_autonomy).pack(side="left",padx=(12,0))
        self.deep_research_var=tk.BooleanVar(value=self.policy.is_allowed("research.deep")); ttk.Checkbutton(autonomy,text="RESEARCH CORPS",variable=self.deep_research_var,command=self._toggle_autonomy).pack(side="left",padx=(8,0))
        self.autopilot_var=tk.BooleanVar(value=self.policy.is_allowed("autonomy.run")); ttk.Checkbutton(autonomy,text="MISSION AUTOPILOT",variable=self.autopilot_var,command=self._toggle_autonomy).pack(side="left",padx=(12,0))
        self.sentinel_var=tk.BooleanVar(value=self.policy.is_allowed("perception.continuous")); ttk.Checkbutton(autonomy,text="SENTINEL",variable=self.sentinel_var,command=self._toggle_sentinel).pack(side="left",padx=(12,0))
        self.perception_cloud_var=tk.BooleanVar(value=self.policy.is_allowed("perception.cloud")); ttk.Checkbutton(autonomy,text="Contexto multimodal → cloud",variable=self.perception_cloud_var,command=self._toggle_sentinel).pack(side="left",padx=(8,0))
        self.swarm_var=tk.BooleanVar(value=self.policy.is_allowed("swarm.run")); ttk.Checkbutton(autonomy,text="COGNITIVE SWARM",variable=self.swarm_var,command=self._toggle_autonomy).pack(side="left",padx=(12,0))
        self.evolution_var=tk.BooleanVar(value=self.policy.is_allowed("evolution.run")); ttk.Checkbutton(autonomy,text="SELF-EVOLUTION",variable=self.evolution_var,command=self._toggle_autonomy).pack(side="left",padx=(8,0))

        tools=ttk.Frame(root); tools.pack(fill="x",pady=(0,8))
        ttk.Button(tools,text="Continuidad / memoria…",command=self._open_continuity).pack(side="left")
        ttk.Button(tools,text="Skills…",command=self._open_skills).pack(side="left",padx=(6,0))
        ttk.Button(tools,text="Misiones autónomas…",command=self._open_autonomy_missions).pack(side="left",padx=(6,0))
        ttk.Button(tools,text="Research Corps…",command=self._open_research).pack(side="left",padx=(6,0))
        ttk.Button(tools,text="JARVIS Móvil / anti-theft…",command=self._open_mobile).pack(side="left",padx=(6,0))
        ttk.Button(tools,text="World Model…",command=self._open_world_model).pack(side="left",padx=(6,0))
        ttk.Button(tools,text="Guardian…",command=self._open_guardian).pack(side="left",padx=(6,0))
        ttk.Button(tools,text="Personal AI OS…",command=self._open_personal_os).pack(side="left",padx=(6,0))
        ttk.Button(tools,text="Autonomous Workbench…",command=self._open_workbench).pack(side="left",padx=(6,0))
        ttk.Button(tools,text="Cognitive Swarm…",command=self._open_swarm).pack(side="left",padx=(6,0))
        ttk.Button(tools,text="Self-Evolution…",command=self._open_evolution).pack(side="left",padx=(6,0))
        ttk.Button(tools,text="Reality Bridge…",command=self._open_reality).pack(side="left",padx=(6,0))
        ttk.Button(tools,text="Infinity Release…",command=self._open_release_center).pack(side="left",padx=(6,0))
        ttk.Button(tools,text="Autorizar carpeta…",command=self._add_folder).pack(side="left",padx=(6,14))
        ttk.Button(tools,text="Iniciar cámara + manos",command=self.perception.start_vision).pack(side="left")
        ttk.Button(tools,text="Detener cámara",command=self.perception.stop_vision).pack(side="left",padx=(6,14))
        ttk.Button(tools,text="Iniciar voz",command=self.perception.start_voice).pack(side="left")
        ttk.Button(tools,text="Detener voz",command=self.perception.stop_voice).pack(side="left",padx=6)
        ttk.Button(tools,text="Inspeccionar pantalla",command=self._inspect_screen).pack(side="left",padx=(12,0))

        product=ttk.Frame(root); product.pack(fill="x",pady=(0,8))
        ttk.Button(product,text="Proveedor IA…",command=self._configure_provider).pack(side="left")
        ttk.Button(product,text="Diagnóstico",command=self._open_diagnostics).pack(side="left",padx=(6,0))
        ttk.Button(product,text="Crear backup…",command=self._create_backup).pack(side="left",padx=(6,0))
        ttk.Button(product,text="Restaurar backup…",command=self._restore_backup).pack(side="left",padx=(6,0))
        if self.runtime.recovery_state.safe_mode:
            ttk.Button(product,text="Reconocer modo seguro",command=self._ack_safe_mode).pack(side="left",padx=(12,0))

        ttk.Separator(root).pack(fill="x",pady=5); ttk.Label(root,text="Objetivo / comando").pack(anchor="w")
        self.goal=tk.Text(root,height=3,wrap="word"); self.goal.pack(fill="x"); self.goal.insert("1.0","estado")
        goalbar=ttk.Frame(root);goalbar.pack(fill="x",pady=7)
        ttk.Button(goalbar,text="Ejecutar objetivo",command=self.run_goal).pack(side="left")
        ttk.Button(goalbar,text="Ejecutar como MISIÓN AUTÓNOMA",command=self.run_autonomous_goal).pack(side="left",padx=(8,0))
        panes=ttk.Panedwindow(root,orient="horizontal"); panes.pack(fill="both",expand=True)
        left=ttk.Labelframe(panes,text="Resultado verificado"); right=ttk.Labelframe(panes,text="Percepción + control"); panes.add(left,weight=1); panes.add(right,weight=1)
        self.output=tk.Text(left,wrap="word"); self.output.pack(fill="both",expand=True,padx=6,pady=6)
        self.event_output=tk.Text(right,wrap="word"); self.event_output.pack(fill="both",expand=True,padx=6,pady=6)
        ttk.Label(root,text="JARVIS ejecuta solo capacidades autorizadas. Skills nuevas quedan VALIDATED hasta que tú las habilitas. Si una acción es ambigua, cambia el contexto o pide confirmación en vez de improvisar.",wraplength=1200).pack(anchor="w",pady=(8,0))

    def _toggle_operator(self):
        enabled=bool(self.operator_var.get())
        if not enabled:self.runtime.emergency_release_inputs()
        for cap in OPERATOR_CAPS:self.policy.set(cap,enabled)
        self._refresh_status()
    def _toggle_memory(self):
        self.policy.set("memory.read",bool(self.memory_read_var.get())); self.policy.set("memory.write",bool(self.memory_write_var.get())); self.policy.set("memory.cloud",bool(self.memory_cloud_var.get())); self._refresh_status()
    def _toggle_files(self):
        self.policy.set("filesystem.read",bool(self.files_var.get())); self.policy.set("filesystem.write",bool(self.files_var.get())); self._refresh_status()
    def _toggle_screen_observe(self):
        enabled=bool(self.screen_observe_var.get()); self.policy.set("screen.observe",enabled)
        if not enabled:
            self.policy.set("screen.cloud",False);self.cloud_screen_var.set(False)
            self.policy.set("perception.continuous",False);self.sentinel_var.set(False);self.runtime.sentinel.stop()
        self._refresh_status()
    def _toggle_cloud_screen(self):
        enabled=bool(self.cloud_screen_var.get())
        if enabled and not self.policy.is_allowed("screen.observe"):self.screen_observe_var.set(True);self.policy.set("screen.observe",True)
        self.policy.set("screen.cloud",enabled);self._refresh_status()
    def _toggle_autonomy(self):
        self.policy.set("agent.run",bool(self.agent_var.get()))
        self.policy.set("skill.learn",bool(self.skill_learn_var.get()))
        self.policy.set("skill.execute",bool(self.skill_exec_var.get()))
        self.policy.set("research.web",bool(self.web_research_var.get()))
        self.policy.set("research.deep",bool(self.deep_research_var.get()))
        self.policy.set("autonomy.run",bool(self.autopilot_var.get()))
        self.policy.set("swarm.run",bool(self.swarm_var.get())); self.policy.set("swarm.cloud",bool(self.swarm_var.get()))
        self.policy.set("evolution.run",bool(self.evolution_var.get())); self.policy.set("evolution.cloud",bool(self.evolution_var.get()))
        self._refresh_status()

    def _add_folder(self):
        path=filedialog.askdirectory(title="Carpeta que JARVIS puede usar")
        if path:self.runtime.file_scope.add_root(Path(path));self.policy.set("filesystem.read",True);self._refresh_status();messagebox.showinfo("JARVIS",f"Carpeta autorizada:\n{path}")

    def _toggle_sentinel(self):
        enabled=bool(self.sentinel_var.get())
        self.policy.set("perception.continuous",enabled)
        self.policy.set("perception.cloud",bool(self.perception_cloud_var.get()))
        if enabled:
            try:self.runtime.start_sentinel()
            except Exception as exc:
                self.sentinel_var.set(False);self.policy.set("perception.continuous",False);messagebox.showerror("JARVIS — Sentinel",str(exc))
        else:
            self.runtime.sentinel.stop()
        self._refresh_status()

    def _refresh_status(self):
        provider=self.providers.active;ps=self.perception.status();operator=all(self.policy.is_allowed(c) for c in OPERATOR_CAPS);project=self.runtime.memory_manager.active_project
        ws=self.runtime.world_model.store.stats()
        try: os_count=len(self.runtime.personal_os.store.list(limit=500))
        except Exception: os_count=0
        self.status_var.set(f"AI: {self.providers.active_name} ({'configurado' if provider.available else 'sin API key'}) • Kill: {'ACTIVO' if self.kill.engaged else 'listo'} • SafeMode: {'ON' if self.runtime.recovery_state.safe_mode else 'OFF'} • Guardian: {'ON' if self.policy.is_allowed('guardian.enforce') else 'OFF'} • World: {ws['entities']}E/{ws['relations']}R Cloud={'ON' if self.policy.is_allowed('world.cloud') else 'OFF'} • PersonalOS: {os_count}R route={'ON' if self.policy.is_allowed('os.route') else 'OFF'}/cloud={'ON' if self.policy.is_allowed('os.cloud') else 'OFF'} • Operador: {'ON' if operator else 'OFF'} • Agent: {'ON' if self.policy.is_allowed('agent.run') else 'OFF'} • Autopilot: {'ON' if self.policy.is_allowed('autonomy.run') else 'OFF'} • Swarm: {'ON' if self.policy.is_allowed('swarm.run') and self.policy.is_allowed('swarm.cloud') else 'OFF'} • Evolution: {'ON' if self.policy.is_allowed('evolution.run') and self.policy.is_allowed('evolution.cloud') else 'OFF'} • Reality: {'ON' if self.policy.is_allowed('reality.control') else 'READ' if self.policy.is_allowed('reality.read') else 'OFF'} • Skills: learn={'ON' if self.policy.is_allowed('skill.learn') else 'OFF'}/run={'ON' if self.policy.is_allowed('skill.execute') else 'OFF'} • Research: {'CORPS' if self.policy.is_allowed('research.deep') else 'off'}/{'WEB' if self.policy.is_allowed('research.web') else 'web-off'} • Memoria: R={'ON' if self.policy.is_allowed('memory.read') else 'OFF'}/W={'ON' if self.policy.is_allowed('memory.write') else 'OFF'}/Cloud={'ON' if self.policy.is_allowed('memory.cloud') else 'OFF'} • Proyecto: {project.name if project else 'GLOBAL'} • Pantalla: {'LOCAL' if self.policy.is_allowed('screen.observe') else 'OFF'}/{'CLOUD' if self.policy.is_allowed('screen.cloud') else 'privada'} • Sentinel: {'ON' if self.runtime.sentinel.running else 'OFF'}/Cloud={'ON' if self.policy.is_allowed('perception.cloud') else 'OFF'} • Vision: {ps['vision']['status']} • Voz: {ps['voice']['status']} • Contexto: {self.runtime.intent.context_override or 'AUTO'}")

    def _capture_event(self,event):
        try:self._events.put_nowait(event)
        except queue.Full:
            try:self._events.get_nowait();self._events.put_nowait(event)
            except queue.Empty:pass
    def _poll_events(self):
        changed=False
        while True:
            try:event=self._events.get_nowait()
            except queue.Empty:break
            changed=True;self.event_output.insert("end",json.dumps(event.as_dict(),ensure_ascii=False)+"\n");self.event_output.see("end")
        if changed:self._refresh_status()
        self.after(100,self._poll_events)
    def run_goal(self):
        text=self.goal.get("1.0","end").strip();result=self.orchestrator.run(text);payload={"goal_id":result.id,"state":result.state.value,"verification":result.verification,"plan":[asdict(x) for x in result.plan],"results":[asdict(x) for x in result.results]};self.output.delete("1.0","end");self.output.insert("1.0",json.dumps(payload,ensure_ascii=False,indent=2));self._refresh_status()
    def run_autonomous_goal(self):
        text=self.goal.get("1.0","end").strip()
        if not text:return
        result=self.orchestrator.run("autonomía: "+text)
        payload={"goal_id":result.id,"state":result.state.value,"verification":result.verification,"plan":[asdict(x) for x in result.plan],"results":[asdict(x) for x in result.results]}
        self.output.delete("1.0","end");self.output.insert("1.0",json.dumps(payload,ensure_ascii=False,indent=2));self._refresh_status()

    def stop_now(self):self.runtime.emergency_release_inputs();self.kill.engage();self.runtime.guardian.revoke_all();self.runtime.sentinel.stop();self.runtime.reality.stop_monitor();self.perception.stop_all();self._refresh_status()
    def reset_stop(self):self.kill.reset();self.runtime.ensure_health_monitor();self._refresh_status()
    def _inspect_screen(self):
        try:snap=self.runtime.screen.snapshot(include_image=False);self.output.delete("1.0","end");self.output.insert("1.0",json.dumps(snap.compact(limit=120),ensure_ascii=False,indent=2))
        except Exception as exc:self.event_output.insert("end",json.dumps({"screen_error":str(exc)},ensure_ascii=False)+"\n")
        self._refresh_status()

    def _tk_exception(self, exc_type, exc_value, exc_tb):
        self.runtime.crash_journal.record_exception(exc_type,exc_value,exc_tb,source="tk_callback")
        messagebox.showerror("JARVIS — Error", f"La acción falló y quedó registrada.\n\n{exc_type.__name__}: {exc_value}")

    def _configure_provider(self):
        provider=self.providers.active
        current_model=getattr(provider,"model",self.runtime.provider_settings.gemini_model)
        model=simpledialog.askstring("JARVIS — Proveedor IA","Modelo Gemini:",initialvalue=current_model,parent=self)
        if model is None:return
        model=model.strip() or current_model
        key=simpledialog.askstring("JARVIS — Proveedor IA","API key (déjalo vacío para mantener la actual):",show="*",parent=self)
        self.runtime.provider_settings.gemini_model=model
        self.runtime.provider_settings.active=self.providers.active_name
        self.runtime.provider_settings.save()
        if hasattr(provider,"model"):provider.model=model
        if key and key.strip():
            key=key.strip()
            if hasattr(provider,"api_key"):provider.api_key=key
            if self.runtime.credentials.available:
                try:
                    self.runtime.credentials.set("GEMINI_API_KEY",key)
                    messagebox.showinfo("JARVIS","Proveedor actualizado. La API key se guardó mediante el almacén seguro del sistema.")
                except Exception as exc:
                    messagebox.showwarning("JARVIS",f"El modelo se actualizó, pero la clave solo queda activa en esta sesión porque el almacén seguro falló:\n{exc}")
            else:
                messagebox.showwarning("JARVIS","El modelo se actualizó y la clave queda activa en esta sesión. No existe un backend seguro disponible, así que JARVIS no la guardó en texto plano.")
        else:
            messagebox.showinfo("JARVIS","Configuración del modelo actualizada; la API key existente no se modificó.")
        self._refresh_status()

    def _open_diagnostics(self):
        report=self.runtime.diagnostics.run(self.runtime)
        win=tk.Toplevel(self);win.title("JARVIS — Diagnóstico");win.geometry("900x650")
        text=tk.Text(win,wrap="word");text.pack(fill="both",expand=True,padx=10,pady=10)
        text.insert("1.0",json.dumps(report,ensure_ascii=False,indent=2));text.configure(state="disabled")
        bar=ttk.Frame(win,padding=(10,0,10,10));bar.pack(fill="x")
        def save():
            path=filedialog.asksaveasfilename(parent=win,title="Guardar diagnóstico",defaultextension=".json",filetypes=[("JSON","*.json")])
            if path:self.runtime.diagnostics.write_report(Path(path),self.runtime)
        ttk.Button(bar,text="Guardar reporte…",command=save).pack(side="left")

    def _create_backup(self):
        path=filedialog.asksaveasfilename(title="Crear backup JARVIS",defaultextension=".jarvisbackup",filetypes=[("JARVIS backup","*.jarvisbackup")])
        if not path:return
        try:
            out=self.runtime.backup.create(Path(path));validation=self.runtime.backup.validate(out)
            if not validation.ok:raise RuntimeError("; ".join(validation.errors))
            messagebox.showinfo("JARVIS",f"Backup creado y validado: {validation.files} archivos.\n\n{out}")
        except Exception as exc:messagebox.showerror("JARVIS",f"No se pudo crear el backup:\n{exc}")

    def _restore_backup(self):
        path=filedialog.askopenfilename(title="Restaurar backup JARVIS",filetypes=[("JARVIS backup","*.jarvisbackup"),("ZIP","*.zip")])
        if not path:return
        validation=self.runtime.backup.validate(Path(path))
        if not validation.ok:
            messagebox.showerror("JARVIS","Backup rechazado:\n"+"\n".join(validation.errors));return
        if not messagebox.askyesno("JARVIS — Restaurar",f"Backup válido ({validation.files} archivos).\n\nSe aplicará al PRÓXIMO inicio, antes de abrir memoria/configuración. ¿Programar restauración?"):
            return
        self.runtime.backup.stage_restore(Path(path));messagebox.showinfo("JARVIS","Restauración validada y programada. Cierra y vuelve a abrir JARVIS para aplicarla.")

    def _ack_safe_mode(self):
        self.runtime.recovery.clear_safe_mode_marker();self._refresh_status()
        messagebox.showinfo("JARVIS","Modo seguro reconocido. Los permisos peligrosos permanecen apagados hasta que tú los habilites.")

    def _open_continuity(self):
        win=tk.Toplevel(self);win.title("JARVIS — Continuidad bajo tu control");win.geometry("900x650")
        top=ttk.Frame(win,padding=10);top.pack(fill="both",expand=True)
        active=tk.StringVar();ttk.Label(top,textvariable=active,font=("Segoe UI",11,"bold")).pack(anchor="w")
        projects=tk.Listbox(top,height=5);projects.pack(fill="x",pady=6)
        buttons=ttk.Frame(top);buttons.pack(fill="x")
        def refresh():
            projects.delete(0,"end"); plist=self.runtime.memory_manager.store.list_projects();
            for p in plist:projects.insert("end",p.name)
            ap=self.runtime.memory_manager.active_project;active.set(f"Proyecto activo: {ap.name if ap else 'GLOBAL'} • sesión: {self.runtime.memory_manager.store.current_session_id() or '-'}")
            snap=self.runtime.memory_manager.resume().compact();text.delete("1.0","end");text.insert("1.0",json.dumps(snap,ensure_ascii=False,indent=2));self._refresh_status()
        def create():
            name=simpledialog.askstring("Nuevo proyecto","Nombre del proyecto",parent=win)
            if name:self.runtime.memory_manager.create_project(name);refresh()
        def activate():
            sel=projects.curselection()
            if sel:self.runtime.memory_manager.activate_project(projects.get(sel[0]));refresh()
        def add_memory():
            value=simpledialog.askstring("Memoria explícita","¿Qué debe recordar JARVIS?",parent=win)
            if value:self.runtime.memory_manager.remember(value,source="user.ui",importance=.8);refresh()
        def search_memory():
            q=simpledialog.askstring("Buscar memoria","Texto a buscar",parent=win)
            if q is None:return
            rows=self.runtime.memory_manager.retrieve(q,limit=20)
            text.delete("1.0","end");text.insert("1.0",json.dumps([{"id":x.id,"kind":x.kind.value,"title":x.title,"content":x.content,"source":x.source,"score":x.score} for x in rows],ensure_ascii=False,indent=2))
        def correct_memory():
            mid=simpledialog.askstring("Corregir recuerdo","ID del recuerdo",parent=win)
            if not mid:return
            current=self.runtime.memory_manager.store.get_memory(mid)
            if not current:messagebox.showerror("JARVIS","Ese recuerdo activo no existe.",parent=win);return
            value=simpledialog.askstring("Corrección",f"Contenido actual:\n{current.content}\n\nNuevo contenido:",parent=win)
            if value:self.runtime.memory_manager.store.correct_memory(mid,value,source="user.ui.correction");refresh()
        def forget_memory():
            mid=simpledialog.askstring("Olvidar recuerdo","ID del recuerdo",parent=win)
            if not mid:return
            current=self.runtime.memory_manager.store.get_memory(mid)
            if not current:messagebox.showerror("JARVIS","Ese recuerdo activo no existe.",parent=win);return
            if messagebox.askyesno("Confirmar",f"Marcar como olvidado:\n{current.title}\n\n{current.content}",parent=win):
                self.runtime.memory_manager.store.forget_memory(mid);refresh()
        ttk.Button(buttons,text="Nuevo proyecto",command=create).pack(side="left");ttk.Button(buttons,text="Activar",command=activate).pack(side="left",padx=6);ttk.Button(buttons,text="Añadir recuerdo",command=add_memory).pack(side="left")
        ttk.Button(buttons,text="Buscar",command=search_memory).pack(side="left",padx=(6,0));ttk.Button(buttons,text="Corregir por ID",command=correct_memory).pack(side="left",padx=(6,0));ttk.Button(buttons,text="Olvidar por ID",command=forget_memory).pack(side="left",padx=(6,0))
        ttk.Button(buttons,text="Actualizar",command=refresh).pack(side="right")
        text=tk.Text(top,wrap="word");text.pack(fill="both",expand=True,pady=(10,0));refresh()

    def _open_autonomy_missions(self):
        win=tk.Toplevel(self);win.title("JARVIS — Mission Autopilot");win.geometry("980x660")
        top=ttk.Frame(win,padding=10);top.pack(fill="both",expand=True)
        ttk.Label(top,text="Mission Autopilot — cada paso queda persistido y debe pasar Executor + Verifier.",font=("Segoe UI",11,"bold")).pack(anchor="w")
        ttk.Label(top,text="El modelo propone un paso; no recibe acceso directo al PC. STOP GLOBAL y todos tus permisos siguen teniendo prioridad.").pack(anchor="w",pady=(2,8))
        missions=tk.Listbox(top,height=9);missions.pack(fill="x")
        detail=tk.Text(top,wrap="word");detail.pack(fill="both",expand=True,pady=(8,0))
        rows=[]
        def refresh():
            nonlocal rows
            rows=self.runtime.autonomy_store.list(limit=100);missions.delete(0,"end")
            for row in rows:missions.insert("end",f"{row.get('id')}  [{row.get('state')}]  {row.get('goal')}")
            detail.delete("1.0","end")
        def show(_event=None):
            sel=missions.curselection()
            if not sel:return
            try:data=self.runtime.autonomy_store.load(str(rows[sel[0]].get("id"))).as_dict()
            except Exception as exc:data={"error":str(exc)}
            detail.delete("1.0","end");detail.insert("1.0",json.dumps(data,ensure_ascii=False,indent=2,default=str))
        bar=ttk.Frame(top);bar.pack(fill="x",pady=(8,0))
        def selected_report():
            sel=missions.curselection()
            if not sel:return None
            try:return self.runtime.autonomy_store.load(str(rows[sel[0]].get("id")))
            except Exception as exc:
                messagebox.showerror("JARVIS",str(exc),parent=win);return None
        def approve_pending():
            report=selected_report()
            if not report or not report.pending_skill:
                messagebox.showinfo("JARVIS","La misión seleccionada no tiene una skill pendiente.",parent=win);return
            skill=self.runtime.skill_store.get(report.pending_skill)
            if not skill:
                messagebox.showerror("JARVIS","La skill pendiente ya no existe.",parent=win);return
            validation=self.runtime.skill_forge.validate_existing(skill.name)
            preflight=self.runtime.skill_forge.preflight(skill)
            if not validation.ok or not preflight.get("ok"):
                messagebox.showerror("JARVIS","La skill ya no supera validación/preflight y no puede habilitarse.",parent=win);return
            if not messagebox.askyesno("Autorizar skill",f"Habilitar '{skill.name}'?\n\nCapacidades subyacentes: {', '.join(validation.required_capabilities) or '-'}\n\nEsto NO habilita automáticamente esas capacidades; seguirán requiriendo tus permisos.",parent=win):return
            from .skills.models import SkillStatus
            self.runtime.skill_store.set_status(skill.name,SkillStatus.ENABLED);show();self._refresh_status()
        def resume_selected():
            report=selected_report()
            if not report:return
            try:
                resumed=self.runtime.autonomy_engine.resume(report.id)
                detail.delete("1.0","end");detail.insert("1.0",json.dumps(resumed.as_dict(),ensure_ascii=False,indent=2,default=str));refresh()
            except Exception as exc:messagebox.showerror("JARVIS",f"No se pudo reanudar:\n{exc}",parent=win)
        ttk.Button(bar,text="Habilitar skill pendiente…",command=approve_pending).pack(side="left")
        ttk.Button(bar,text="Reanudar misión",command=resume_selected).pack(side="left",padx=6)
        ttk.Button(bar,text="Actualizar",command=refresh).pack(side="right")
        missions.bind("<<ListboxSelect>>",show);refresh()

    def _open_research(self):
        win=tk.Toplevel(self);win.title("JARVIS — Research Corps");win.geometry("980x680")
        top=ttk.Frame(win,padding=10);top.pack(fill="both",expand=True)
        ttk.Label(top,text="Research Corps — planner → scouts → evidence analyst → contradiction auditor → synthesis",font=("Segoe UI",11,"bold")).pack(anchor="w")
        ttk.Label(top,text="No controla el PC. Usa web solo cuando research.web está autorizado y conserva fuentes/procedencia.").pack(anchor="w",pady=(2,8))
        rows=[]; items=tk.Listbox(top,height=9);items.pack(fill="x")
        detail=tk.Text(top,wrap="word");detail.pack(fill="both",expand=True,pady=(8,0))
        def refresh():
            nonlocal rows
            rows=self.runtime.research_corps.list(limit=100);items.delete(0,"end")
            for row in rows:items.insert("end",f"{row.get('id')}  [{row.get('state')}]  {row.get('question')}")
            detail.delete("1.0","end")
        def show(_event=None):
            sel=items.curselection()
            if not sel:return
            try:data=self.runtime.research_corps.load(str(rows[sel[0]].get("id")))
            except Exception as exc:data={"error":str(exc)}
            detail.delete("1.0","end");detail.insert("1.0",json.dumps(data,ensure_ascii=False,indent=2,default=str))
        bar=ttk.Frame(top);bar.pack(fill="x",pady=(8,0));ttk.Button(bar,text="Actualizar",command=refresh).pack(side="right")
        items.bind("<<ListboxSelect>>",show);refresh()

    def _open_world_model(self):
        win=tk.Toplevel(self);win.title("JARVIS — World Model");win.geometry("1040x720")
        top=ttk.Frame(win,padding=10);top.pack(fill="both",expand=True)
        ttk.Label(top,text="World Model — estado vivo local con procedencia, confianza y caducidad",font=("Segoe UI",11,"bold")).pack(anchor="w")
        ttk.Label(top,text="Leer localmente y compartir con IA son permisos independientes. Las ventanas/targets efímeros caducan para evitar contexto viejo.",wraplength=980).pack(anchor="w",pady=(2,8))
        bar=ttk.Frame(top);bar.pack(fill="x")
        local_var=tk.BooleanVar(value=self.policy.is_allowed("world.read")); cloud_var=tk.BooleanVar(value=self.policy.is_allowed("world.cloud"))
        def toggle():
            self.policy.set("world.read",bool(local_var.get()));self.policy.set("world.cloud",bool(cloud_var.get()) and bool(local_var.get()));self._refresh_status();refresh()
        ttk.Checkbutton(bar,text="World Model local",variable=local_var,command=toggle).pack(side="left")
        ttk.Checkbutton(bar,text="World Model → cloud",variable=cloud_var,command=toggle).pack(side="left",padx=(10,0))
        text=tk.Text(top,wrap="word");text.pack(fill="both",expand=True,pady=(8,0))
        def refresh():
            try:data=self.runtime.world_model.context_for_goal("")
            except Exception as exc:data={"error":str(exc)}
            text.delete("1.0","end");text.insert("1.0",json.dumps(data,ensure_ascii=False,indent=2,default=str))
        ttk.Button(bar,text="Actualizar",command=refresh).pack(side="right");refresh()

    def _open_guardian(self):
        win=tk.Toplevel(self);win.title("JARVIS — Guardian");win.geometry("1060x740")
        top=ttk.Frame(win,padding=10);top.pack(fill="both",expand=True)
        ttk.Label(top,text="Guardian — supervisor local independiente del modelo",font=("Segoe UI",11,"bold")).pack(anchor="w")
        ttk.Label(top,text="Permiso = puede usarse. Guardian = ¿es seguro ejecutar ESTA acción ahora? Las acciones de alto riesgo requieren una autorización temporal del propietario.",wraplength=1000).pack(anchor="w",pady=(2,8))
        bar=ttk.Frame(top);bar.pack(fill="x")
        enforce=tk.BooleanVar(value=self.policy.is_allowed("guardian.enforce"))
        def toggle_guardian():self.policy.set("guardian.enforce",bool(enforce.get()));self._refresh_status()
        ttk.Checkbutton(bar,text="Guardian activo",variable=enforce,command=toggle_guardian).pack(side="left")
        text=tk.Text(top,wrap="word");text.pack(fill="both",expand=True,pady=(8,0))
        def refresh():
            rows=self.runtime.guardian.store.recent_audit(100);text.delete("1.0","end");text.insert("1.0",json.dumps(rows,ensure_ascii=False,indent=2,default=str))
        def grant_action():
            action=simpledialog.askstring("Guardian","Acción exacta a autorizar temporalmente (ej. mobile_lock):",parent=win)
            if not action:return
            seconds=simpledialog.askinteger("Guardian","Duración en segundos (1–3600):",initialvalue=120,minvalue=1,maxvalue=3600,parent=win)
            if not seconds:return
            lease=self.runtime.guardian.grant_action(action.strip(),ttl_s=seconds,uses=1);messagebox.showinfo("Guardian",f"Autorización emitida: {lease}\n1 uso • {seconds}s",parent=win);refresh()
        def revoke():self.runtime.guardian.revoke_all();messagebox.showinfo("Guardian","Todas las autorizaciones temporales fueron revocadas.",parent=win);refresh()
        ttk.Button(bar,text="Autorizar UNA acción…",command=grant_action).pack(side="left",padx=(10,0))
        ttk.Button(bar,text="Revocar autorizaciones",command=revoke).pack(side="left",padx=(6,0))
        ttk.Button(bar,text="Actualizar auditoría",command=refresh).pack(side="right");refresh()

    def _open_personal_os(self):
        win=tk.Toplevel(self);win.title("JARVIS — Personal AI OS");win.geometry("1080x760")
        top=ttk.Frame(win,padding=10);top.pack(fill="both",expand=True)
        ttk.Label(top,text="Personal AI OS — recursos unificados y routing verificable",font=("Segoe UI",11,"bold")).pack(anchor="w")
        ttk.Label(top,text="Un recurso puede ser PC, Android, app, URL, carpeta, proyecto, contacto o misión. Una ruta genérica vuelve a pasar por permisos + Guardian + Executor + Verifier.",wraplength=1020).pack(anchor="w",pady=(2,8))
        flags=ttk.Frame(top);flags.pack(fill="x")
        route=tk.BooleanVar(value=self.policy.is_allowed("os.route"));handoff=tk.BooleanVar(value=self.policy.is_allowed("os.handoff"));manage=tk.BooleanVar(value=self.policy.is_allowed("os.manage"));cloud=tk.BooleanVar(value=self.policy.is_allowed("os.cloud"))
        def toggle():
            self.policy.set("os.route",bool(route.get()));self.policy.set("os.handoff",bool(handoff.get()));self.policy.set("os.manage",bool(manage.get()));self.policy.set("os.cloud",bool(cloud.get()));self._refresh_status()
        ttk.Checkbutton(flags,text="Routing",variable=route,command=toggle).pack(side="left")
        ttk.Checkbutton(flags,text="Handoff entre dispositivos",variable=handoff,command=toggle).pack(side="left",padx=(10,0))
        ttk.Checkbutton(flags,text="Administrar recursos",variable=manage,command=toggle).pack(side="left",padx=(10,0))
        ttk.Checkbutton(flags,text="Recursos → cloud",variable=cloud,command=toggle).pack(side="left",padx=(10,0))
        rows=[];items=tk.Listbox(top,height=11);items.pack(fill="x",pady=(8,0));detail=tk.Text(top,wrap="word");detail.pack(fill="both",expand=True,pady=(8,0))
        def refresh():
            nonlocal rows
            try: rows=self.runtime.personal_os.resources(limit=250)
            except Exception as exc: rows=[];detail.delete("1.0","end");detail.insert("1.0",str(exc))
            items.delete(0,"end")
            for r in rows:items.insert("end",f"{r.get('kind'):8}  {r.get('label')}  [{r.get('id')}]")
        def show(_event=None):
            sel=items.curselection()
            if not sel:return
            detail.delete("1.0","end");detail.insert("1.0",json.dumps(rows[sel[0]],ensure_ascii=False,indent=2,default=str))
        def pin_url():
            if not self.policy.is_allowed("os.manage"):messagebox.showwarning("JARVIS","Activa Administrar recursos.",parent=win);return
            url=simpledialog.askstring("Recurso URL","URL http/https",parent=win);
            if not url:return
            alias=simpledialog.askstring("Alias","Alias opcional",parent=win)
            try:self.runtime.personal_os.register_url(url,alias=alias or None);refresh()
            except Exception as exc:messagebox.showerror("JARVIS",str(exc),parent=win)
        def pin_file():
            if not self.policy.is_allowed("os.manage"):messagebox.showwarning("JARVIS","Activa Administrar recursos.",parent=win);return
            path=filedialog.askopenfilename(parent=win)
            if not path:return
            try:self.runtime.personal_os.register_file(path);refresh()
            except Exception as exc:messagebox.showerror("JARVIS",str(exc),parent=win)
        def handoffs():
            detail.delete("1.0","end");detail.insert("1.0",json.dumps(self.runtime.personal_os.store.handoffs(100),ensure_ascii=False,indent=2,default=str))
        bar=ttk.Frame(top);bar.pack(fill="x",pady=(8,0))
        ttk.Button(bar,text="Fijar URL…",command=pin_url).pack(side="left");ttk.Button(bar,text="Fijar archivo…",command=pin_file).pack(side="left",padx=6);ttk.Button(bar,text="Historial handoff",command=handoffs).pack(side="left")
        ttk.Button(bar,text="Actualizar",command=refresh).pack(side="right")
        items.bind("<<ListboxSelect>>",show);refresh()

    def _open_release_center(self):
        win=tk.Toplevel(self);win.title("JARVIS — Infinity Release");win.geometry("980x720")
        top=ttk.Frame(win,padding=10);top.pack(fill="both",expand=True)
        ttk.Label(top,text="Infinity Release — salud, aceptación física y release gate",font=("Segoe UI",11,"bold")).pack(anchor="w")
        ttk.Label(top,text="Los tests automáticos nunca marcan como aprobada una prueba física. Tú registras PASS/FAIL después de probar el hardware real.",wraplength=920).pack(anchor="w",pady=(2,8))
        status=tk.Text(top,height=12,wrap="word");status.pack(fill="x")
        checks=tk.Listbox(top,height=11);checks.pack(fill="x",pady=(8,0))
        rows=[]
        def refresh():
            nonlocal rows
            gate=self.runtime.release_gate.evaluate(self.runtime);health=self.runtime.health.sample(self.runtime).as_dict();rel=self.runtime.release.status();acc=self.runtime.acceptance.report()
            status.delete("1.0","end");status.insert("1.0",json.dumps({"release_gate":gate,"health":health,"update":rel},ensure_ascii=False,indent=2,default=str))
            rows=list(acc["checks"].values());checks.delete(0,"end")
            for x in rows:checks.insert("end",f"{x['status'].upper():14} {x['name']}  {x.get('note','')}")
        def mark(value):
            sel=checks.curselection()
            if not sel:return
            item=rows[sel[0]];note=simpledialog.askstring("Aceptación física",f"Nota para {item['name']} (opcional)",parent=win) or ""
            self.runtime.acceptance.set_owner_result(item['name'],value,note);refresh()
        def export_support():
            self.policy.set("support.export",True);self.runtime.guardian.grant_action("support_export",ttl_s=60,uses=1)
            path=filedialog.asksaveasfilename(parent=win,defaultextension=".zip",initialfile="JARVIS_support_bundle.zip",filetypes=[("ZIP","*.zip")])
            if not path:return
            try:self.runtime.export_support(Path(path));messagebox.showinfo("JARVIS","Bundle de soporte creado sin workspace, capturas, audio ni secretos.",parent=win)
            except Exception as exc:messagebox.showerror("JARVIS",str(exc),parent=win)
        def stage_update():
            path=filedialog.askopenfilename(parent=win,filetypes=[("JARVIS update","*.jarvisupdate"),("ZIP","*.zip")])
            if not path:return
            self.policy.set("release.manage",True);self.runtime.guardian.grant_action("release_stage",ttl_s=60,uses=1)
            try:self.runtime.release.stage(Path(path));messagebox.showinfo("JARVIS","Actualización verificada y preparada. Se aplicará mediante un instalador nuevo después de cerrar JARVIS; el programa no se sobrescribe mientras está abierto.",parent=win);refresh()
            except Exception as exc:messagebox.showerror("JARVIS",str(exc),parent=win)
        bar=ttk.Frame(top);bar.pack(fill="x",pady=(8,0))
        ttk.Button(bar,text="Marcar PASS",command=lambda:mark("passed")).pack(side="left")
        ttk.Button(bar,text="Marcar FAIL",command=lambda:mark("failed")).pack(side="left",padx=6)
        ttk.Button(bar,text="Pendiente",command=lambda:mark("pending")).pack(side="left")
        ttk.Button(bar,text="Exportar soporte…",command=export_support).pack(side="left",padx=(18,0))
        ttk.Button(bar,text="Verificar/stage update…",command=stage_update).pack(side="left",padx=6)
        ttk.Button(bar,text="Actualizar",command=refresh).pack(side="right")
        refresh()

    def _open_mobile(self):
        win=tk.Toplevel(self);win.title("JARVIS — Móvil / Anti-Theft");win.geometry("980x720")
        top=ttk.Frame(win,padding=10);top.pack(fill="both",expand=True)
        ttk.Label(top,text="JARVIS Everywhere — teléfono emparejado bajo control del propietario",font=("Segoe UI",11,"bold")).pack(anchor="w")
        ttk.Label(top,text="El relay usa HTTPS con certificado fijado y comandos firmados. El PIN de la pantalla de bloqueo no se guarda ni se transmite.",wraplength=920).pack(anchor="w",pady=(2,8))
        caps=(
            ("mobile.read","Estado del teléfono"),("mobile.location","Ubicación del dispositivo"),("mobile.control","Control móvil"),
            ("mobile.security","Bloqueo / autenticación"),("mobile.contacts","Buscar contactos"),("mobile.messaging","Preparar mensajes"),("mobile.relay","Relay móvil"),
        )
        capvars={}
        capbar=ttk.Frame(top);capbar.pack(fill="x",pady=(0,8))
        def toggle_cap(cap,var):self.policy.set(cap,bool(var.get()));self._refresh_status()
        for cap,label in caps:
            var=tk.BooleanVar(value=self.policy.is_allowed(cap));capvars[cap]=var;ttk.Checkbutton(capbar,text=label,variable=var,command=lambda c=cap,v=var:toggle_cap(c,v)).pack(side="left",padx=(0,8))
        status=tk.StringVar();ttk.Label(top,textvariable=status,wraplength=920).pack(anchor="w",pady=(0,8))
        devices=tk.Listbox(top,height=8);devices.pack(fill="x")
        detail=tk.Text(top,wrap="word");detail.pack(fill="both",expand=True,pady=(8,0))
        rows=[]
        def refresh():
            nonlocal rows
            rows=self.runtime.mobile.manager.devices.list();devices.delete(0,"end")
            for d in rows:devices.insert("end",f"{d.id} — {d.name} — last_seen={d.last_seen or '-'}")
            summary=self.runtime.mobile.summary();status.set(f"Relay: {'ACTIVO' if summary['relay_running'] else 'apagado'} • secretos: {summary['secret_persistence']} • dispositivos: {len(rows)}")
        def selected():
            sel=devices.curselection();return rows[sel[0]] if sel else None
        def show(_event=None):
            d=selected();detail.delete("1.0","end")
            if not d:return
            payload=self.runtime.mobile.manager.status(d.id);detail.insert("1.0",json.dumps(payload,ensure_ascii=False,indent=2,default=str))
        def start_relay():
            if not self.policy.is_allowed("mobile.relay"):
                messagebox.showwarning("JARVIS","Activa primero el permiso Relay móvil.",parent=win);return
            port=simpledialog.askinteger("Relay móvil","Puerto HTTPS",initialvalue=8765,minvalue=1024,maxvalue=65535,parent=win)
            if not port:return
            try:info=self.runtime.mobile.start_relay(port=port);detail.delete("1.0","end");detail.insert("1.0",json.dumps(info,ensure_ascii=False,indent=2));refresh()
            except Exception as exc:messagebox.showerror("JARVIS",f"No se pudo iniciar el relay:\n{exc}",parent=win)
        def pair():
            if not self.runtime.mobile.relay_running:
                messagebox.showwarning("JARVIS","Inicia primero el relay para fijar su certificado TLS.",parent=win);return
            name=simpledialog.askstring("Emparejar Android","Nombre del teléfono",initialvalue="Mi Android",parent=win)
            if not name:return
            device_id=simpledialog.askstring("ID del dispositivo","ID corto, por ejemplo phone-main",initialvalue="phone-main",parent=win)
            if not device_id:return
            suggested=self.runtime.mobile.suggest_relay_url()
            relay_url=simpledialog.askstring("Dirección del relay","Dirección HTTPS que el teléfono puede alcanzar. Para fuera de casa necesitará una dirección pública/VPN.",initialvalue=suggested,parent=win)
            if not relay_url:return
            try:
                bundle=self.runtime.mobile.pair_device(name,device_id,relay_url);detail.delete("1.0","end");detail.insert("1.0","COPIA ESTE URI SOLO EN TU TELÉFONO JARVIS. CONTIENE EL SECRETO DE EMPAREJAMIENTO.\n\n"+bundle["pairing_uri"]+"\n\nFingerprint secreto: "+bundle["secret_fingerprint"]);refresh()
            except Exception as exc:messagebox.showerror("JARVIS",f"No se pudo emparejar:\n{exc}",parent=win)
        def locate():
            d=selected()
            if not d:return
            try:payload=self.runtime.mobile.manager.last_location(d.id);detail.delete("1.0","end");detail.insert("1.0",json.dumps(payload,ensure_ascii=False,indent=2))
            except Exception as exc:messagebox.showerror("JARVIS",str(exc),parent=win)
        def forget():
            d=selected()
            if not d:return
            if messagebox.askyesno("Olvidar teléfono",f"Eliminar emparejamiento de {d.name}?",parent=win):self.runtime.mobile.manager.devices.forget(d.id);refresh()
        bar=ttk.Frame(top);bar.pack(fill="x",pady=(8,0))
        ttk.Button(bar,text="Iniciar relay HTTPS",command=start_relay).pack(side="left")
        ttk.Button(bar,text="Detener relay",command=lambda:(self.runtime.mobile.stop_relay(),refresh())).pack(side="left",padx=6)
        ttk.Button(bar,text="Emparejar Android…",command=pair).pack(side="left",padx=(8,0))
        ttk.Button(bar,text="Última ubicación",command=locate).pack(side="left",padx=6)
        ttk.Button(bar,text="Olvidar dispositivo",command=forget).pack(side="left")
        ttk.Button(bar,text="Actualizar",command=refresh).pack(side="right")
        devices.bind("<<ListboxSelect>>",show);refresh()

    def _open_skills(self):
        win=tk.Toplevel(self);win.title("JARVIS — Skills bajo tu control");win.geometry("900x620")
        top=ttk.Frame(win,padding=10);top.pack(fill="both",expand=True)
        ttk.Label(top,text="Skill Forge — las skills nuevas quedan VALIDATED, nunca ENABLED automáticamente.",font=("Segoe UI",11,"bold")).pack(anchor="w")
        skills=tk.Listbox(top,height=10);skills.pack(fill="x",pady=8)
        detail=tk.Text(top,wrap="word");detail.pack(fill="both",expand=True)
        rows=[]
        def refresh():
            nonlocal rows
            rows=self.runtime.skill_store.list(include_retired=True);skills.delete(0,"end")
            for item in rows:skills.insert("end",f"{item.name}  v{item.version}  [{item.status.value}]  caps={','.join(item.required_capabilities) or '-'}")
            detail.delete("1.0","end")
        def show(_event=None):
            sel=skills.curselection()
            if not sel:return
            item=rows[sel[0]];detail.delete("1.0","end");detail.insert("1.0",json.dumps(item.as_dict(),ensure_ascii=False,indent=2))
        def set_enabled(enabled):
            sel=skills.curselection()
            if not sel:return
            item=rows[sel[0]]
            validation=self.runtime.skill_forge.validate_existing(item.name)
            if enabled and not validation.ok:
                messagebox.showerror("JARVIS", "La skill no compila:\n" + "\n".join(validation.errors), parent=win); return
            if enabled:
                practice=self.runtime.skill_forge.practice_existing(item.name)
                if not practice.get("ok"):
                    messagebox.showerror("JARVIS", "Skill Lab rechazó la skill:\n" + str(practice.get("error") or practice), parent=win); return
            from .skills.models import SkillStatus
            self.runtime.skill_store.set_status(item.name,SkillStatus.ENABLED if enabled else SkillStatus.VALIDATED);refresh();self._refresh_status()
        buttons=ttk.Frame(top);buttons.pack(fill="x",pady=(0,8))
        ttk.Button(buttons,text="Habilitar seleccionada",command=lambda:set_enabled(True)).pack(side="left")
        ttk.Button(buttons,text="Deshabilitar",command=lambda:set_enabled(False)).pack(side="left",padx=6)
        def practice_selected():
            sel=skills.curselection()
            if not sel:return
            report=self.runtime.skill_forge.practice_existing(rows[sel[0]].name);detail.delete("1.0","end");detail.insert("1.0",json.dumps(report,ensure_ascii=False,indent=2))
        ttk.Button(buttons,text="Practicar en Skill Lab",command=practice_selected).pack(side="left",padx=6)
        ttk.Button(buttons,text="Actualizar",command=refresh).pack(side="right")
        skills.bind("<<ListboxSelect>>",show);refresh()


    def _open_workbench(self):
        win=tk.Toplevel(self);win.title("JARVIS — Autonomous Workbench");win.geometry("1120x760")
        top=ttk.Frame(win,padding=10);top.pack(fill="both",expand=True)
        ttk.Label(top,text="Autonomous Workbench — trabajos persistentes con dependencias, presupuestos y checkpoints",font=("Segoe UI",11,"bold")).pack(anchor="w")
        perms=ttk.Frame(top);perms.pack(fill="x",pady=(8,4))
        run_var=tk.BooleanVar(value=self.policy.is_allowed("workbench.run"));manage_var=tk.BooleanVar(value=self.policy.is_allowed("workbench.manage"));cloud_var=tk.BooleanVar(value=self.policy.is_allowed("workbench.cloud"))
        def apply_perms():
            self.policy.set("workbench.run",bool(run_var.get()));self.policy.set("workbench.manage",bool(manage_var.get()));self.policy.set("workbench.cloud",bool(cloud_var.get()));self._refresh_status()
        ttk.Checkbutton(perms,text="Ejecutar Workbench",variable=run_var,command=apply_perms).pack(side="left")
        ttk.Checkbutton(perms,text="Administrar trabajos",variable=manage_var,command=apply_perms).pack(side="left",padx=10)
        ttk.Checkbutton(perms,text="Catálogo Workbench → cloud",variable=cloud_var,command=apply_perms).pack(side="left")
        pan=ttk.Panedwindow(top,orient="horizontal");pan.pack(fill="both",expand=True,pady=6)
        left=ttk.Frame(pan);right=ttk.Frame(pan);pan.add(left,weight=1);pan.add(right,weight=1)
        jobs=tk.Listbox(left);jobs.pack(fill="both",expand=True);detail=tk.Text(right,wrap="word");detail.pack(fill="both",expand=True)
        rows=[]
        def refresh():
            nonlocal rows
            rows=self.runtime.workbench.store.list(200);jobs.delete(0,"end")
            for x in rows: jobs.insert("end",f"P{x.priority:03d} [{x.state.value}] {x.id} — {x.goal[:80]}")
            detail.delete("1.0","end")
        def selected():
            sel=jobs.curselection();return rows[sel[0]] if sel else None
        def show(_e=None):
            x=selected();detail.delete("1.0","end")
            if not x:return
            payload=x.as_dict();payload["checkpoints"]=self.runtime.workbench.store.checkpoints(x.id,30);detail.insert("1.0",json.dumps(payload,ensure_ascii=False,indent=2,default=str))
        def lease_manage(): self.runtime.guardian.grant_action("workbench_manage",ttl_s=60,uses=1)
        def create():
            goal=simpledialog.askstring("Nuevo trabajo","Objetivo persistente",parent=win)
            if not goal:return
            priority=simpledialog.askinteger("Prioridad","0-100",initialvalue=50,minvalue=0,maxvalue=100,parent=win)
            budget=simpledialog.askinteger("Presupuesto","Máximo de pasos de misión",initialvalue=30,minvalue=1,maxvalue=100,parent=win)
            try: lease_manage();self.runtime.workbench.create(goal,priority=priority or 50,step_budget=budget or 30);refresh()
            except Exception as exc:messagebox.showerror("JARVIS",str(exc),parent=win)
        def cycle():
            try:
                self.runtime.guardian.grant_action("workbench_run",ttl_s=60,uses=1);out=self.runtime.workbench.run_cycle(max_jobs=4);refresh();detail.insert("1.0",json.dumps([x.as_dict() for x in out],ensure_ascii=False,indent=2,default=str))
            except Exception as exc:messagebox.showerror("JARVIS",str(exc),parent=win)
        def ctl(method):
            x=selected()
            if not x:return
            try: lease_manage();getattr(self.runtime.workbench,method)(x.id);refresh()
            except Exception as exc:messagebox.showerror("JARVIS",str(exc),parent=win)
        bar=ttk.Frame(top);bar.pack(fill="x",pady=(4,0))
        ttk.Button(bar,text="Nuevo trabajo…",command=create).pack(side="left")
        ttk.Button(bar,text="Ejecutar ciclo",command=cycle).pack(side="left",padx=6)
        ttk.Button(bar,text="Pausar",command=lambda:ctl("pause")).pack(side="left",padx=(12,0))
        ttk.Button(bar,text="Reanudar",command=lambda:ctl("resume")).pack(side="left",padx=6)
        ttk.Button(bar,text="Cancelar",command=lambda:ctl("cancel")).pack(side="left")
        ttk.Button(bar,text="Actualizar",command=refresh).pack(side="right")
        jobs.bind("<<ListboxSelect>>",show);refresh()

    def _open_swarm(self):
        win=tk.Toplevel(self);win.title("JARVIS — Cognitive Swarm");win.geometry("980x700")
        top=ttk.Frame(win,padding=10);top.pack(fill="both",expand=True)
        ttk.Label(top,text="Cognitive Swarm — equipo temporal de especialistas sin acceso directo a herramientas",font=("Segoe UI",11,"bold")).pack(anchor="w")
        perms=ttk.Frame(top);perms.pack(fill="x",pady=6)
        runv=tk.BooleanVar(value=self.policy.is_allowed("swarm.run"));cloudv=tk.BooleanVar(value=self.policy.is_allowed("swarm.cloud"))
        def apply():
            self.policy.set("swarm.run",bool(runv.get()));self.policy.set("swarm.cloud",bool(cloudv.get()));self.swarm_var.set(bool(runv.get()) and bool(cloudv.get()));self._refresh_status()
        ttk.Checkbutton(perms,text="Permitir Swarm",variable=runv,command=apply).pack(side="left")
        ttk.Checkbutton(perms,text="Swarm → cloud",variable=cloudv,command=apply).pack(side="left",padx=8)
        goal=tk.Text(top,height=4,wrap="word");goal.pack(fill="x",pady=6);goal.insert("1.0","Analiza este problema con un equipo de especialistas")
        out=tk.Text(top,wrap="word");out.pack(fill="both",expand=True,pady=6)
        def run():
            try:
                report=self.runtime.swarm.run(goal.get("1.0","end").strip());out.delete("1.0","end");out.insert("1.0",json.dumps(report.as_dict(),ensure_ascii=False,indent=2))
            except Exception as exc: messagebox.showerror("JARVIS",str(exc),parent=win)
        ttk.Button(top,text="Formar equipo y ejecutar",command=run).pack(anchor="w")

    def _open_evolution(self):
        win=tk.Toplevel(self);win.title("JARVIS — Self-Evolution");win.geometry("1050x720")
        top=ttk.Frame(win,padding=10);top.pack(fill="both",expand=True)
        ttk.Label(top,text="Self-Evolution — benchmark, propuesta y promoción controlada de skills",font=("Segoe UI",11,"bold")).pack(anchor="w")
        perms=ttk.Frame(top);perms.pack(fill="x",pady=6)
        runv=tk.BooleanVar(value=self.policy.is_allowed("evolution.run"));managev=tk.BooleanVar(value=self.policy.is_allowed("evolution.manage"));cloudv=tk.BooleanVar(value=self.policy.is_allowed("evolution.cloud"))
        def apply():
            self.policy.set("evolution.run",bool(runv.get()));self.policy.set("evolution.manage",bool(managev.get()));self.policy.set("evolution.cloud",bool(cloudv.get()));self.evolution_var.set(bool(runv.get()) and bool(cloudv.get()));self._refresh_status()
        ttk.Checkbutton(perms,text="Proponer mejoras",variable=runv,command=apply).pack(side="left")
        ttk.Checkbutton(perms,text="Administrar/promover",variable=managev,command=apply).pack(side="left",padx=8)
        ttk.Checkbutton(perms,text="Evolution → cloud",variable=cloudv,command=apply).pack(side="left")
        pane=ttk.Panedwindow(top,orient="horizontal");pane.pack(fill="both",expand=True,pady=6)
        left=ttk.Frame(pane);right=ttk.Frame(pane);pane.add(left,weight=1);pane.add(right,weight=1)
        skills=tk.Listbox(left);skills.pack(fill="both",expand=True);detail=tk.Text(right,wrap="word");detail.pack(fill="both",expand=True)
        rows=[]
        def refresh():
            nonlocal rows;rows=self.runtime.skill_store.list(include_retired=False);skills.delete(0,"end")
            for x in rows:skills.insert("end",f"v{x.version} [{x.status.value}] {x.name}")
        def selected():
            sel=skills.curselection();return rows[sel[0]] if sel else None
        def scan_all():
            try:r=self.runtime.evolution.scan();detail.delete("1.0","end");detail.insert("1.0",json.dumps(r,ensure_ascii=False,indent=2))
            except Exception as exc:messagebox.showerror("JARVIS",str(exc),parent=win)
        def benchmark():
            x=selected();
            if not x:return
            try:r=self.runtime.evolution.benchmark(x);detail.delete("1.0","end");detail.insert("1.0",json.dumps(r.as_dict(),ensure_ascii=False,indent=2))
            except Exception as exc:messagebox.showerror("JARVIS",str(exc),parent=win)
        def propose():
            x=selected();
            if not x:return
            objective=simpledialog.askstring("Self-Evolution","Objetivo de mejora",initialvalue="Improve reliability while preserving intent",parent=win)
            if not objective:return
            try:c=self.runtime.evolution.propose(x.name,objective);detail.delete("1.0","end");detail.insert("1.0",json.dumps(c.as_dict(),ensure_ascii=False,indent=2))
            except Exception as exc:messagebox.showerror("JARVIS",str(exc),parent=win)
        def promote():
            cid=simpledialog.askstring("Self-Evolution","Candidate ID a promover",parent=win)
            if not cid:return
            try:self.runtime.guardian.grant_action("evolution_promote",ttl_s=60,uses=1);x=self.runtime.evolution.promote(cid);messagebox.showinfo("JARVIS",f"Promovida como v{x.version} VALIDATED. Aún NO está habilitada.",parent=win);refresh()
            except Exception as exc:messagebox.showerror("JARVIS",str(exc),parent=win)
        def rollback():
            cid=simpledialog.askstring("Self-Evolution","Candidate ID promovido a revertir",parent=win)
            if not cid:return
            try:self.runtime.guardian.grant_action("evolution_rollback",ttl_s=60,uses=1);x=self.runtime.evolution.rollback(cid);messagebox.showinfo("JARVIS",f"Rollback guardado como v{x.version} VALIDATED. Aún NO está habilitado.",parent=win);refresh()
            except Exception as exc:messagebox.showerror("JARVIS",str(exc),parent=win)
        bar=ttk.Frame(top);bar.pack(fill="x")
        ttk.Button(bar,text="Escanear todas",command=scan_all).pack(side="left")
        ttk.Button(bar,text="Benchmark",command=benchmark).pack(side="left",padx=6)
        ttk.Button(bar,text="Proponer revisión",command=propose).pack(side="left",padx=6)
        ttk.Button(bar,text="Promover candidate ID…",command=promote).pack(side="left",padx=6)
        ttk.Button(bar,text="Rollback candidate ID…",command=rollback).pack(side="left",padx=6)
        ttk.Button(bar,text="Actualizar",command=refresh).pack(side="right");refresh()

    def _open_reality(self):
        win=tk.Toplevel(self);win.title("JARVIS — Reality Bridge");win.geometry("1040x720")
        top=ttk.Frame(win,padding=10);top.pack(fill="both",expand=True)
        ttk.Label(top,text="Reality Bridge — solo dispositivos enrolados explícitamente",font=("Segoe UI",11,"bold")).pack(anchor="w")
        ttk.Label(top,text="Lectura puede alimentar World Model. Control físico está OFF por defecto y toda acción pasa por PermissionPolicy + Guardian + verificación.",wraplength=980).pack(anchor="w",pady=(2,8))
        perms=ttk.Frame(top);perms.pack(fill="x")
        readv=tk.BooleanVar(value=self.policy.is_allowed("reality.read")); ctrlv=tk.BooleanVar(value=self.policy.is_allowed("reality.control")); manv=tk.BooleanVar(value=self.policy.is_allowed("reality.manage")); contv=tk.BooleanVar(value=self.policy.is_allowed("reality.continuous")); cloudv=tk.BooleanVar(value=self.policy.is_allowed("reality.cloud"))
        def apply():
            self.policy.set("reality.read",bool(readv.get()));self.policy.set("reality.control",bool(ctrlv.get()));self.policy.set("reality.manage",bool(manv.get()));self.policy.set("reality.continuous",bool(contv.get()));self.policy.set("reality.cloud",bool(cloudv.get()))
            if contv.get():
                try:self.runtime.reality.start_monitor()
                except Exception as exc:contv.set(False);self.policy.set("reality.continuous",False);messagebox.showerror("JARVIS",str(exc),parent=win)
            else:self.runtime.reality.stop_monitor()
            self._refresh_status()
        ttk.Checkbutton(perms,text="Leer sensores",variable=readv,command=apply).pack(side="left")
        ttk.Checkbutton(perms,text="Monitor continuo",variable=contv,command=apply).pack(side="left",padx=8)
        ttk.Checkbutton(perms,text="Reality → cloud",variable=cloudv,command=apply).pack(side="left",padx=8)
        ttk.Checkbutton(perms,text="Controlar dispositivos enrolados",variable=ctrlv,command=apply).pack(side="left",padx=8)
        ttk.Checkbutton(perms,text="Administrar/enrolar",variable=manv,command=apply).pack(side="left")
        devices=tk.Listbox(top,height=10);devices.pack(fill="x",pady=8);detail=tk.Text(top,wrap="word");detail.pack(fill="both",expand=True)
        rows=[]
        def refresh():
            nonlocal rows
            try: rows=self.runtime.reality.list_devices() if self.policy.is_allowed("reality.read") else []
            except Exception as exc: rows=[]; detail.delete("1.0","end");detail.insert("1.0",str(exc))
            devices.delete(0,"end")
            for d in rows:devices.insert("end",f"{d['label']}  [{d['kind']}]  {d['adapter']}:{d['native_id']}  risk={d['risk']}")
        def selected():
            sel=devices.curselection(); return rows[sel[0]] if sel else None
        def configure_ha():
            url=simpledialog.askstring("Home Assistant","URL base (ej. http://192.168.1.20:8123)",parent=win)
            if not url:return
            token=simpledialog.askstring("Home Assistant","Long-Lived Access Token (se guardará en el almacén seguro del SO, no en archivos)",parent=win,show="•")
            if not token:return
            try:self.runtime.guardian.grant_action("reality_configure",ttl_s=60,uses=1);self.runtime.reality.configure_home_assistant(url,token);messagebox.showinfo("JARVIS","Home Assistant configurado. El token no se guardó en texto plano.",parent=win)
            except Exception as exc:messagebox.showerror("JARVIS",str(exc),parent=win)
        def enroll():
            native=simpledialog.askstring("Enrolar dispositivo","Entity ID (ej. light.desk)",parent=win)
            if not native:return
            label=simpledialog.askstring("Enrolar dispositivo","Nombre para JARVIS",parent=win) or native
            domain=native.split('.',1)[0]
            caps={"light":["on","off","toggle"],"media_player":["play","pause","play_pause","volume"]}.get(domain)
            if not caps:messagebox.showerror("JARVIS","Reality Bridge solo permite enrolar actuadores de bajo riesgo soportados: light y media_player.",parent=win);return
            try:
                self.runtime.guardian.grant_action("reality_enroll",ttl_s=60,uses=1)
                self.runtime.reality.enroll(adapter="home_assistant",native_id=native,label=label,kind=domain,capabilities=tuple(caps));refresh()
            except Exception as exc:messagebox.showerror("JARVIS",str(exc),parent=win)
        def observe():
            d=selected()
            if not d:return
            try: out=self.runtime.reality.observe(d['id']);detail.delete("1.0","end");detail.insert("1.0",json.dumps(out,ensure_ascii=False,indent=2,default=str))
            except Exception as exc:messagebox.showerror("JARVIS",str(exc),parent=win)
        def command():
            d=selected()
            if not d:return
            cmd=simpledialog.askstring("Comando","Comando permitido: "+", ".join(d.get('capabilities') or []),parent=win)
            if not cmd:return
            args={}
            if cmd=="volume":
                level=simpledialog.askfloat("Volumen","Nivel 0.0–1.0",parent=win,minvalue=0.0,maxvalue=1.0)
                if level is None:return
                args["level"]=level
            try: out=self.runtime.reality.command(d['id'],cmd,args);detail.delete("1.0","end");detail.insert("1.0",json.dumps({"ok":out.ok,"before":out.before.state if out.before else None,"after":out.after.state if out.after else None,"detail":out.detail},ensure_ascii=False,indent=2))
            except Exception as exc:messagebox.showerror("JARVIS",str(exc),parent=win)
        bar=ttk.Frame(top);bar.pack(fill="x",pady=(0,6))
        ttk.Button(bar,text="Configurar Home Assistant…",command=configure_ha).pack(side="left")
        ttk.Button(bar,text="Enrolar dispositivo…",command=enroll).pack(side="left",padx=6)
        ttk.Button(bar,text="Observar",command=observe).pack(side="left",padx=(12,0))
        ttk.Button(bar,text="Ejecutar comando…",command=command).pack(side="left",padx=6)
        ttk.Button(bar,text="Actualizar",command=refresh).pack(side="right")
        refresh()

    def _close(self):
        self.runtime.memory_manager.end_session("UI closed");self.runtime.clean_shutdown();self.perception.bus.unsubscribe(self._bus_token);self.destroy()

def main()->None:JarvisApp().mainloop()
if __name__=="__main__":main()
