from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
import os
import shutil
import subprocess
import sys
import time
import webbrowser
from typing import Any, Protocol


@dataclass(slots=True)
class WindowInfo:
    handle: int
    title: str
    left: int
    top: int
    right: int
    bottom: int
    minimized: bool = False
    maximized: bool = False

    @property
    def width(self) -> int:
        return max(0, self.right - self.left)

    @property
    def height(self) -> int:
        return max(0, self.bottom - self.top)

    def as_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["width"] = self.width
        data["height"] = self.height
        return data


class DesktopBackend(Protocol):
    def screen_size(self) -> tuple[int, int]: ...
    def cursor_position(self) -> tuple[int, int]: ...
    def move_cursor(self, x: int, y: int) -> tuple[int, int]: ...
    def mouse_down(self, button: str = "left") -> None: ...
    def mouse_up(self, button: str = "left") -> None: ...
    def click(self, button: str = "left") -> None: ...
    def hotkey(self, keys: list[str]) -> None: ...
    def type_text(self, text: str) -> None: ...
    def list_windows(self) -> list[WindowInfo]: ...
    def active_window(self) -> WindowInfo | None: ...
    def focus_window(self, title_contains: str) -> WindowInfo: ...
    def move_active_window(self, left: int, top: int, width: int, height: int) -> WindowInfo: ...
    def resize_active_window(self, scale: float, center_x: float | None = None, center_y: float | None = None) -> WindowInfo: ...
    def maximize_active_window(self) -> WindowInfo: ...
    def minimize_active_window(self) -> None: ...
    def open_app(self, executable: str, args: list[str] | None = None) -> dict[str, Any]: ...
    def open_url(self, url: str) -> dict[str, Any]: ...


class UnsupportedDesktopBackend:
    """Fails explicitly outside Windows instead of pretending OS control worked."""

    def _fail(self, *_: Any, **__: Any) -> Any:
        raise RuntimeError("Desktop control requires Windows in Phase 3")

    screen_size = cursor_position = move_cursor = mouse_down = mouse_up = click = hotkey = type_text = _fail
    list_windows = active_window = focus_window = move_active_window = resize_active_window = _fail
    maximize_active_window = minimize_active_window = open_app = open_url = _fail


class WindowsDesktopBackend:
    """Native Windows control using pywin32. No shell command execution is exposed."""

    VK = {
        "ctrl": 0x11, "control": 0x11, "shift": 0x10, "alt": 0x12, "win": 0x5B,
        "enter": 0x0D, "tab": 0x09, "esc": 0x1B, "escape": 0x1B, "space": 0x20,
        "backspace": 0x08, "delete": 0x2E, "home": 0x24, "end": 0x23,
        "left": 0x25, "up": 0x26, "right": 0x27, "down": 0x28,
        "pageup": 0x21, "pagedown": 0x22,
        "f1": 0x70, "f2": 0x71, "f3": 0x72, "f4": 0x73, "f5": 0x74, "f6": 0x75,
        "f7": 0x76, "f8": 0x77, "f9": 0x78, "f10": 0x79, "f11": 0x7A, "f12": 0x7B,
    }

    def __init__(self) -> None:
        if os.name != "nt":
            raise RuntimeError("WindowsDesktopBackend can only run on Windows")
        try:
            import win32api  # type: ignore
            import win32con  # type: ignore
            import win32gui  # type: ignore
            import win32clipboard  # type: ignore
        except ImportError as exc:
            raise RuntimeError("pywin32 is required for Windows desktop control") from exc
        self.api = win32api
        self.con = win32con
        self.gui = win32gui
        self.clipboard = win32clipboard

    def screen_size(self) -> tuple[int, int]:
        return int(self.api.GetSystemMetrics(0)), int(self.api.GetSystemMetrics(1))

    def cursor_position(self) -> tuple[int, int]:
        x, y = self.api.GetCursorPos()
        return int(x), int(y)

    def move_cursor(self, x: int, y: int) -> tuple[int, int]:
        width, height = self.screen_size()
        x = max(0, min(width - 1, int(x)))
        y = max(0, min(height - 1, int(y)))
        self.api.SetCursorPos((x, y))
        return self.cursor_position()

    def _mouse_flag(self, button: str, down: bool) -> int:
        key = button.lower().strip()
        mapping = {
            ("left", True): self.con.MOUSEEVENTF_LEFTDOWN,
            ("left", False): self.con.MOUSEEVENTF_LEFTUP,
            ("right", True): self.con.MOUSEEVENTF_RIGHTDOWN,
            ("right", False): self.con.MOUSEEVENTF_RIGHTUP,
            ("middle", True): self.con.MOUSEEVENTF_MIDDLEDOWN,
            ("middle", False): self.con.MOUSEEVENTF_MIDDLEUP,
        }
        if (key, down) not in mapping:
            raise ValueError(f"Unsupported mouse button: {button}")
        return mapping[(key, down)]

    def mouse_down(self, button: str = "left") -> None:
        self.api.mouse_event(self._mouse_flag(button, True), 0, 0, 0, 0)

    def mouse_up(self, button: str = "left") -> None:
        self.api.mouse_event(self._mouse_flag(button, False), 0, 0, 0, 0)

    def click(self, button: str = "left") -> None:
        self.mouse_down(button); self.mouse_up(button)

    def _vk(self, key: str) -> int:
        k = key.strip().lower()
        if k in self.VK:
            return self.VK[k]
        if len(k) == 1:
            code = self.api.VkKeyScan(k)
            if code == -1:
                raise ValueError(f"Unsupported key: {key}")
            return code & 0xFF
        raise ValueError(f"Unsupported key: {key}")

    def hotkey(self, keys: list[str]) -> None:
        if not keys:
            raise ValueError("Hotkey requires at least one key")
        vks = [self._vk(k) for k in keys]
        for vk in vks:
            self.api.keybd_event(vk, 0, 0, 0)
        for vk in reversed(vks):
            self.api.keybd_event(vk, 0, self.con.KEYEVENTF_KEYUP, 0)

    def type_text(self, text: str) -> None:
        # Unicode-safe paste, preserving a text clipboard when possible.
        old_text: str | None = None
        try:
            self.clipboard.OpenClipboard()
            try:
                if self.clipboard.IsClipboardFormatAvailable(self.con.CF_UNICODETEXT):
                    old_text = self.clipboard.GetClipboardData(self.con.CF_UNICODETEXT)
            finally:
                self.clipboard.CloseClipboard()
        except Exception:
            old_text = None
        self.clipboard.OpenClipboard()
        try:
            self.clipboard.EmptyClipboard()
            self.clipboard.SetClipboardText(str(text), self.con.CF_UNICODETEXT)
        finally:
            self.clipboard.CloseClipboard()
        self.hotkey(["ctrl", "v"])
        time.sleep(0.08)
        if old_text is not None:
            try:
                self.clipboard.OpenClipboard()
                try:
                    self.clipboard.EmptyClipboard()
                    self.clipboard.SetClipboardText(old_text, self.con.CF_UNICODETEXT)
                finally:
                    self.clipboard.CloseClipboard()
            except Exception:
                pass

    def _window(self, hwnd: int) -> WindowInfo:
        left, top, right, bottom = self.gui.GetWindowRect(hwnd)
        return WindowInfo(
            int(hwnd), self.gui.GetWindowText(hwnd), int(left), int(top), int(right), int(bottom),
            bool(self.gui.IsIconic(hwnd)), bool(self.gui.IsZoomed(hwnd)),
        )

    def list_windows(self) -> list[WindowInfo]:
        items: list[WindowInfo] = []
        def callback(hwnd: int, _: Any) -> bool:
            try:
                if self.gui.IsWindowVisible(hwnd):
                    title = self.gui.GetWindowText(hwnd).strip()
                    if title:
                        items.append(self._window(hwnd))
            except Exception:
                pass
            return True
        self.gui.EnumWindows(callback, None)
        return items

    def active_window(self) -> WindowInfo | None:
        hwnd = int(self.gui.GetForegroundWindow())
        if not hwnd:
            return None
        try:
            return self._window(hwnd)
        except Exception:
            return None

    def focus_window(self, title_contains: str) -> WindowInfo:
        needle = title_contains.casefold().strip()
        matches = [w for w in self.list_windows() if needle in w.title.casefold()]
        if not matches:
            raise FileNotFoundError(f"No visible window contains: {title_contains}")
        win = matches[0]
        if win.minimized:
            self.gui.ShowWindow(win.handle, self.con.SW_RESTORE)
        self.gui.SetForegroundWindow(win.handle)
        time.sleep(0.05)
        active = self.active_window()
        if active is None or active.handle != win.handle:
            raise RuntimeError("Windows refused foreground focus")
        return active

    def move_active_window(self, left: int, top: int, width: int, height: int) -> WindowInfo:
        win = self.active_window()
        if win is None:
            raise RuntimeError("No active window")
        if width < 120 or height < 80:
            raise ValueError("Window size too small")
        self.gui.MoveWindow(win.handle, int(left), int(top), int(width), int(height), True)
        return self._window(win.handle)

    def resize_active_window(self, scale: float, center_x: float | None = None, center_y: float | None = None) -> WindowInfo:
        if not 0.50 <= float(scale) <= 1.75:
            raise ValueError("Scale delta outside safe range 0.50..1.75")
        win = self.active_window()
        if win is None:
            raise RuntimeError("No active window")
        width, height = self.screen_size()
        new_w = max(220, min(width, int(win.width * float(scale))))
        new_h = max(140, min(height, int(win.height * float(scale))))
        if center_x is None or center_y is None:
            cx = win.left + win.width / 2
            cy = win.top + win.height / 2
        else:
            cx = max(0.0, min(1.0, float(center_x))) * width
            cy = max(0.0, min(1.0, float(center_y))) * height
        left = max(0, min(width - new_w, int(cx - new_w / 2)))
        top = max(0, min(height - new_h, int(cy - new_h / 2)))
        return self.move_active_window(left, top, new_w, new_h)

    def maximize_active_window(self) -> WindowInfo:
        win = self.active_window()
        if win is None:
            raise RuntimeError("No active window")
        self.gui.ShowWindow(win.handle, self.con.SW_MAXIMIZE)
        time.sleep(0.05)
        return self._window(win.handle)

    def minimize_active_window(self) -> None:
        win = self.active_window()
        if win is None:
            raise RuntimeError("No active window")
        self.gui.ShowWindow(win.handle, self.con.SW_MINIMIZE)

    def open_app(self, executable: str, args: list[str] | None = None) -> dict[str, Any]:
        args = list(args or [])
        candidate = shutil.which(executable) or executable
        if not (Path(candidate).is_file() or shutil.which(candidate)):
            raise FileNotFoundError(f"Executable not found: {executable}")
        proc = subprocess.Popen([candidate, *args], shell=False, close_fds=True)
        return {"pid": int(proc.pid), "executable": str(candidate), "args": args}

    def open_url(self, url: str) -> dict[str, Any]:
        opened = bool(webbrowser.open(url, new=2, autoraise=True))
        if not opened:
            raise RuntimeError("Default browser rejected the open request")
        return {"url": url, "request_accepted": True}


def build_desktop_backend() -> DesktopBackend:
    if os.name == "nt":
        return WindowsDesktopBackend()
    return UnsupportedDesktopBackend()
