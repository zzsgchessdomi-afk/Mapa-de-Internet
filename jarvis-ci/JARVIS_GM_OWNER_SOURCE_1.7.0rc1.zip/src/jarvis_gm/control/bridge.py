from __future__ import annotations

from dataclasses import asdict
import queue
import threading
from typing import Any

from jarvis_gm.core.models import ActionRequest
from jarvis_gm.core.orchestrator import Orchestrator
from jarvis_gm.core.executor import Executor
from jarvis_gm.core.verifier import Verifier
from jarvis_gm.core.memory import MemoryStore
from jarvis_gm.perception.bus import PerceptionBus
from jarvis_gm.perception.events import PerceptionEvent


class ActionGateway:
    """Single audited path for gesture-driven direct actions."""
    def __init__(self, executor: Executor, verifier: Verifier, memory: MemoryStore, bus: PerceptionBus) -> None:
        self.executor = executor; self.verifier = verifier; self.memory = memory; self.bus = bus

    def run(self, name: str, args: dict[str, Any], source: str) -> bool:
        action = self.executor.actions.get(name)
        if action is None:
            return False
        req = ActionRequest(name, args, action.capability)
        self.memory.record_event(source, "interaction.request", {"action": name, "args": args})
        result = self.executor.execute(req)
        ok, detail = self.verifier.verify(req, result)
        self.memory.record_event(source, "interaction.verified", {"action": name, "result": asdict(result), "ok": ok, "detail": detail})
        self.bus.publish(PerceptionEvent("control.result", "control", {"action": name, "ok": ok, "detail": detail, "error": result.error}))
        return ok


class PerceptionControlBridge:
    """Maps voice/gesture events to the same permissioned action system as typed goals."""
    def __init__(self, orchestrator: Orchestrator, gateway: ActionGateway, bus: PerceptionBus) -> None:
        self.orchestrator = orchestrator; self.gateway = gateway; self.bus = bus
        self._queue: queue.Queue[PerceptionEvent | None] = queue.Queue(maxsize=256)
        self._token: int | None = None; self._thread: threading.Thread | None = None; self._stop = threading.Event()

    def start(self) -> None:
        if self._token is not None: return
        while True:
            try: self._queue.get_nowait()
            except queue.Empty: break
        self._stop.clear(); self._token = self.bus.subscribe(self._enqueue)
        self._thread = threading.Thread(target=self._worker, name="jarvis-control-bridge", daemon=True); self._thread.start()
        self.bus.publish(PerceptionEvent("control.bridge", "control", {"status": "started"}))

    def stop(self) -> None:
        if self._token is not None:
            self.bus.unsubscribe(self._token); self._token = None
        self._stop.set()
        try: self._queue.put_nowait(None)
        except queue.Full: pass
        if self._thread and self._thread.is_alive(): self._thread.join(timeout=1.0)
        self._thread = None

    def _enqueue(self, event: PerceptionEvent) -> None:
        if event.source == "control": return
        if event.type not in {"voice.command", "gesture.point", "gesture.pinch_start", "gesture.pinch_move", "gesture.pinch_end", "gesture.swipe_left", "gesture.swipe_right", "gesture.transform"}:
            return
        try: self._queue.put_nowait(event)
        except queue.Full:
            try: self._queue.get_nowait(); self._queue.put_nowait(event)
            except queue.Empty: pass

    def _worker(self) -> None:
        while not self._stop.is_set():
            try: event = self._queue.get(timeout=0.25)
            except queue.Empty: continue
            if event is None: break
            try: self._handle(event)
            except Exception as exc:
                self.bus.publish(PerceptionEvent("control.error", "control", {"event": event.type, "error": str(exc)}))

    def _handle(self, event: PerceptionEvent) -> None:
        p = event.payload
        if event.type == "voice.command":
            text = str(p.get("text", "")).strip()
            if not text: return
            goal = self.orchestrator.run(text)
            self.bus.publish(PerceptionEvent("control.goal", "control", {"text": text, "state": goal.state.value, "verification": goal.verification, "goal_id": goal.id}))
            return
        if event.type in {"gesture.point", "gesture.pinch_move"}:
            self.gateway.run("move_cursor_normalized", {"x": p["x"], "y": p["y"]}, event.id)
        elif event.type == "gesture.pinch_start":
            self.gateway.run("move_cursor_normalized", {"x": p["x"], "y": p["y"]}, event.id)
            self.gateway.run("mouse_button", {"button": "left", "state": "down"}, event.id)
        elif event.type == "gesture.pinch_end":
            self.gateway.run("mouse_button", {"button": "left", "state": "up"}, event.id)
        elif event.type == "gesture.swipe_right":
            self.gateway.run("hotkey", {"keys": ["alt", "tab"]}, event.id)
        elif event.type == "gesture.swipe_left":
            self.gateway.run("hotkey", {"keys": ["alt", "shift", "tab"]}, event.id)
        elif event.type == "gesture.transform":
            c = p.get("center", {})
            self.gateway.run("resize_active_window", {"scale": p.get("scale_delta", 1.0), "center_x": c.get("x"), "center_y": c.get("y")}, event.id)
