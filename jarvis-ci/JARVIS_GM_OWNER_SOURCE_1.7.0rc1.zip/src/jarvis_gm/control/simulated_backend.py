from __future__ import annotations

from dataclasses import replace
from typing import Any
from .windows_backend import WindowInfo


class SimulatedDesktopBackend:
    """Deterministic backend used only by tests/self-test; never selected in production."""
    def __init__(self) -> None:
        self.width=1920; self.height=1080; self.cursor=(0,0); self.buttons=set(); self.typed=[]; self.hotkeys=[]
        self.windows=[WindowInfo(1,"JARVIS Test Window",100,100,900,700)]; self.active=1; self.next_pid=1000
        self.opened_apps=[]; self.opened_urls=[]
    def screen_size(self): return self.width,self.height
    def cursor_position(self): return self.cursor
    def move_cursor(self,x,y): self.cursor=(max(0,min(self.width-1,int(x))),max(0,min(self.height-1,int(y)))); return self.cursor
    def mouse_down(self,button="left"): self.buttons.add(button)
    def mouse_up(self,button="left"): self.buttons.discard(button)
    def click(self,button="left"): self.mouse_down(button); self.mouse_up(button)
    def hotkey(self,keys): self.hotkeys.append(tuple(keys))
    def type_text(self,text): self.typed.append(text)
    def list_windows(self): return [replace(w) for w in self.windows]
    def active_window(self):
        for w in self.windows:
            if w.handle==self.active: return replace(w)
        return None
    def focus_window(self,title_contains):
        needle=title_contains.casefold()
        for w in self.windows:
            if needle in w.title.casefold(): self.active=w.handle; w.minimized=False; return replace(w)
        raise FileNotFoundError(title_contains)
    def move_active_window(self,left,top,width,height):
        for i,w in enumerate(self.windows):
            if w.handle==self.active:
                self.windows[i]=WindowInfo(w.handle,w.title,int(left),int(top),int(left)+int(width),int(top)+int(height),False,False); return replace(self.windows[i])
        raise RuntimeError("No active window")
    def resize_active_window(self,scale,center_x=None,center_y=None):
        w=self.active_window()
        if not w: raise RuntimeError("No active window")
        nw=max(220,int(w.width*float(scale))); nh=max(140,int(w.height*float(scale)))
        return self.move_active_window(w.left,w.top,nw,nh)
    def maximize_active_window(self):
        for i,w in enumerate(self.windows):
            if w.handle==self.active:
                self.windows[i]=WindowInfo(w.handle,w.title,0,0,self.width,self.height,False,True); return replace(self.windows[i])
        raise RuntimeError("No active window")
    def minimize_active_window(self):
        for i,w in enumerate(self.windows):
            if w.handle==self.active: self.windows[i]=replace(w,minimized=True); return
        raise RuntimeError("No active window")
    def open_app(self,executable,args=None):
        self.next_pid+=1; self.opened_apps.append((executable,list(args or []))); return {"pid":self.next_pid,"executable":executable,"args":list(args or [])}
    def open_url(self,url): self.opened_urls.append(url); return {"url":url,"request_accepted":True}
