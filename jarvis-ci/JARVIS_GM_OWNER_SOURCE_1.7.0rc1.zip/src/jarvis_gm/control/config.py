from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import json
import os
import re
from urllib.parse import urlparse


DEFAULT_APPS = {
    "notepad": "notepad.exe",
    "bloc de notas": "notepad.exe",
    "calculadora": "calc.exe",
    "calculator": "calc.exe",
    "paint": "mspaint.exe",
    "explorador": "explorer.exe",
    "explorer": "explorer.exe",
}


@dataclass
class AppRegistry:
    path: Path
    apps: dict[str, str] = field(default_factory=lambda: dict(DEFAULT_APPS))

    def __post_init__(self) -> None:
        self.path = Path(self.path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if self.path.exists():
            try:
                raw = json.loads(self.path.read_text(encoding="utf-8"))
                if isinstance(raw, dict):
                    for key, value in raw.items():
                        if isinstance(key, str) and isinstance(value, str) and key.strip() and value.strip():
                            self.apps[key.casefold().strip()] = value.strip()
            except Exception:
                pass
        self.save()

    def save(self) -> None:
        self.path.write_text(json.dumps(self.apps, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")

    def resolve(self, alias: str) -> str:
        key = alias.casefold().strip()
        if key not in self.apps:
            raise PermissionError(f"App is not registered: {alias}")
        return self.apps[key]

    def register(self, alias: str, executable: str) -> None:
        if not alias.strip() or not executable.strip():
            raise ValueError("Alias and executable are required")
        self.apps[alias.casefold().strip()] = executable.strip()
        self.save()


@dataclass
class FileScope:
    path: Path
    roots: list[Path]

    @classmethod
    def load(cls, path: Path, defaults: list[Path]) -> "FileScope":
        path = Path(path)
        roots = [Path(p).expanduser().resolve() for p in defaults]
        if path.exists():
            try:
                raw = json.loads(path.read_text(encoding="utf-8"))
                if isinstance(raw, list):
                    roots = [Path(str(p)).expanduser().resolve() for p in raw if str(p).strip()]
            except Exception:
                pass
        obj = cls(path, roots)
        obj.save()
        return obj

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps([str(p) for p in self.roots], ensure_ascii=False, indent=2), encoding="utf-8")

    def add_root(self, root: Path) -> None:
        p = Path(root).expanduser().resolve()
        if p not in self.roots:
            self.roots.append(p)
            self.save()

    def require(self, target: Path, *, must_exist: bool = False) -> Path:
        p = Path(target).expanduser()
        p = p.resolve(strict=must_exist)
        for root in self.roots:
            try:
                p.relative_to(root)
                return p
            except ValueError:
                continue
        raise PermissionError(f"Path is outside JARVIS allowed roots: {p}")


def validate_url(url: str) -> str:
    value = url.strip()
    parsed = urlparse(value)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ValueError("Only valid http/https URLs are allowed")
    return value
