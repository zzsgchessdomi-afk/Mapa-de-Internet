from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any
import time
import uuid


class AutonomyState(str, Enum):
    RECEIVED = "received"
    RUNNING = "running"
    VERIFIED = "verified"
    BLOCKED = "blocked"
    FAILED = "failed"
    PAUSED = "paused"
    AWAITING_APPROVAL = "awaiting_approval"


class StepState(str, Enum):
    PROPOSED = "proposed"
    VERIFIED = "verified"
    FAILED = "failed"
    BLOCKED = "blocked"


@dataclass(slots=True)
class MissionStep:
    index: int
    action: str
    args: dict[str, Any]
    capability: str
    rationale: str = ""
    expected_effect: str = ""
    state: StepState = StepState.PROPOSED
    output: Any = None
    verification: str = ""
    error: str | None = None
    evidence_kind: str = "effect"
    created_at: float = field(default_factory=time.time)

    @property
    def evidence_id(self) -> str:
        return f"step:{self.index}"

    def as_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["state"] = self.state.value
        value["evidence_id"] = self.evidence_id
        return value


@dataclass(slots=True)
class AutonomousMission:
    goal: str
    success_criteria: tuple[str, ...] = ()
    id: str = field(default_factory=lambda: "auto_" + uuid.uuid4().hex[:16])
    state: AutonomyState = AutonomyState.RECEIVED
    steps: list[MissionStep] = field(default_factory=list)
    conclusion: str = ""
    blocked_reason: str = ""
    replans: int = 0
    pending_skill: str = ""
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)

    def verified_evidence_ids(self) -> tuple[str, ...]:
        return tuple(x.evidence_id for x in self.steps if x.state == StepState.VERIFIED and x.evidence_kind == "effect")

    def as_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "goal": self.goal,
            "success_criteria": list(self.success_criteria),
            "state": self.state.value,
            "steps": [x.as_dict() for x in self.steps],
            "conclusion": self.conclusion,
            "blocked_reason": self.blocked_reason,
            "replans": self.replans,
            "pending_skill": self.pending_skill,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }
