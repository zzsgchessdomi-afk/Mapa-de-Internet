from __future__ import annotations

from dataclasses import dataclass
import json
import re
import time
from typing import Any, Callable

from jarvis_gm.core.models import ActionRequest
from jarvis_gm.core.executor import Executor
from jarvis_gm.core.verifier import Verifier
from jarvis_gm.core.kill_switch import KillSwitch
from jarvis_gm.screen.observer import ScreenObserver
from jarvis_gm.skills.models import SkillStatus

from .models import AutonomousMission, AutonomyState, MissionStep, StepState
from .store import MissionStore


@dataclass(slots=True)
class AutonomyConfig:
    max_steps: int = 10
    max_replans: int = 4
    repeat_limit: int = 2
    screen_element_limit: int = 45


class AutonomyEngine:
    """Closed-loop mission controller with owner-gated skill acquisition.

    The model chooses at most ONE next action/skill/learning request per cycle.
    Ordinary actions always pass through Executor + Verifier. Skills execute only
    through SkillRunner, which re-checks every underlying action/capability. Newly
    learned skills are never auto-enabled: the mission pauses awaiting owner
    approval, then can be resumed.
    """

    META_ACTIONS = {
        "run_autonomous_mission", "resume_autonomous_mission", "list_autonomous_missions",
        "run_mission", "learn_skill", "enable_skill", "run_skill",
        "correct_memory", "forget_memory",
        "workbench_create", "workbench_run_cycle", "workbench_pause", "workbench_resume", "workbench_cancel",
        "evolution_promote", "evolution_reject", "evolution_rollback",
    }

    def __init__(self, provider_resolver: Callable[[], Any], executor: Executor, verifier: Verifier,
                 kill_switch: KillSwitch, store: MissionStore, *, observer: ScreenObserver | None = None,
                 memory_context: Callable[[str], dict[str, Any] | None] | None = None,
                 config: AutonomyConfig | None = None,
                 skill_forge: Any | None = None, skill_store: Any | None = None, skill_runner: Any | None = None,
                 multimodal_context: Callable[[], dict[str, Any] | None] | None = None,
                 world_context: Callable[[str], dict[str, Any] | None] | None = None) -> None:
        self.provider_resolver=provider_resolver
        self.executor=executor
        self.verifier=verifier
        self.kill_switch=kill_switch
        self.store=store
        self.observer=observer
        self.memory_context=memory_context
        self.config=config or AutonomyConfig()
        self.skill_forge=skill_forge
        self.skill_store=skill_store
        self.skill_runner=skill_runner
        self.multimodal_context=multimodal_context
        self.world_context=world_context

    def run(self, goal: str, *, success_criteria: list[str] | tuple[str,...] | None = None,
            max_steps: int | None = None, existing: AutonomousMission | None = None, pause_on_budget: bool = False) -> AutonomousMission:
        provider=self.provider_resolver()
        if not getattr(provider,"available",False):
            raise RuntimeError("Autonomous missions require a configured cloud AI provider")
        mission=existing or AutonomousMission(goal=goal.strip(), success_criteria=tuple(success_criteria or ()))
        if not mission.goal:
            raise ValueError("Mission goal cannot be empty")
        if mission.pending_skill:
            if self.skill_store is None:
                mission.state=AutonomyState.FAILED;mission.conclusion="Pending skill cannot be resolved because Skill Store is unavailable";self.store.save(mission);return mission
            pending=self.skill_store.get(mission.pending_skill)
            if pending is None:
                mission.state=AutonomyState.FAILED;mission.conclusion=f"Pending skill disappeared: {mission.pending_skill}";mission.pending_skill="";self.store.save(mission);return mission
            if pending.status != SkillStatus.ENABLED:
                mission.state=AutonomyState.AWAITING_APPROVAL
                mission.conclusion=f"Owner approval required: enable skill '{mission.pending_skill}' and resume this mission"
                mission.updated_at=time.time();self.store.save(mission);return mission
            mission.pending_skill=""

        mission.state=AutonomyState.RUNNING; mission.blocked_reason=""; mission.updated_at=time.time(); self.store.save(mission)
        additional_budget=max(1,min(int(max_steps or self.config.max_steps),25))
        step_limit=len(mission.steps)+additional_budget
        replans_at_start=mission.replans
        seen: dict[str,int]={}
        for prior in mission.steps:
            key=self._fingerprint(prior.action,prior.args);seen[key]=seen.get(key,0)+1

        try:
            while len(mission.steps) < step_limit:
                self.kill_switch.check()
                decision=self._decide(provider,mission)
                kind=str(decision.get("decision","")).lower().strip()
                if kind == "blocked":
                    mission.state=AutonomyState.BLOCKED
                    mission.blocked_reason=str(decision.get("reason") or "The mission cannot continue safely with current tools/permissions")
                    mission.conclusion=mission.blocked_reason
                    break
                if kind == "done":
                    evidence=tuple(str(x) for x in decision.get("evidence",[]) if str(x))
                    valid=set(mission.verified_evidence_ids())
                    if not evidence or not set(evidence).issubset(valid):
                        mission.replans += 1
                        if mission.replans-replans_at_start > self.config.max_replans:
                            mission.state=AutonomyState.FAILED; mission.conclusion="Completion was claimed without valid locally verified evidence"
                            break
                        continue
                    mission.state=AutonomyState.VERIFIED
                    mission.conclusion=str(decision.get("reason") or "Mission success criteria satisfied by verified evidence")
                    break
                if kind == "learn":
                    outcome=self._learn_for_mission(mission,decision)
                    if outcome in {AutonomyState.AWAITING_APPROVAL,AutonomyState.BLOCKED,AutonomyState.FAILED}:
                        mission.state=outcome
                        break
                    continue
                if kind == "skill":
                    outcome=self._run_skill_step(mission,decision)
                    if outcome in {AutonomyState.BLOCKED,AutonomyState.FAILED}:
                        mission.state=outcome
                        break
                    if outcome is None:
                        mission.replans += 1
                        if mission.replans-replans_at_start > self.config.max_replans:
                            mission.state=AutonomyState.FAILED;mission.conclusion="Replan budget exhausted after skill failures";break
                    continue
                if kind != "act":
                    mission.replans += 1
                    if mission.replans-replans_at_start > self.config.max_replans:
                        mission.state=AutonomyState.FAILED; mission.conclusion="Planner repeatedly returned invalid mission decisions"
                        break
                    continue

                action_name=str(decision.get("action") or "")
                if action_name in self.META_ACTIONS or action_name not in self.executor.actions:
                    mission.replans += 1
                    if mission.replans-replans_at_start > self.config.max_replans:
                        mission.state=AutonomyState.FAILED; mission.conclusion=f"Planner repeatedly requested unavailable/forbidden action: {action_name}"
                        break
                    continue
                args=decision.get("args") or {}
                if not isinstance(args,dict):
                    mission.replans += 1
                    if mission.replans-replans_at_start > self.config.max_replans:
                        mission.state=AutonomyState.FAILED; mission.conclusion="Planner repeatedly returned invalid action arguments"
                        break
                    continue
                action=self.executor.actions[action_name]
                key=self._fingerprint(action_name,args);seen[key]=seen.get(key,0)+1
                if seen[key] > self.config.repeat_limit:
                    mission.state=AutonomyState.BLOCKED
                    mission.blocked_reason=f"Loop guard stopped repeated action: {action_name}"
                    mission.conclusion=mission.blocked_reason
                    break

                step=MissionStep(
                    index=len(mission.steps)+1, action=action_name, args=dict(args), capability=action.capability,
                    rationale=str(decision.get("rationale") or ""), expected_effect=str(decision.get("expected_effect") or ""),
                )
                mission.steps.append(step); mission.updated_at=time.time(); self.store.save(mission)
                req=ActionRequest(action_name,dict(args),action.capability)
                result=self.executor.execute(req)
                step.output=self._safe_output(result.output)
                if not result.ok:
                    step.error=result.error
                    step.state=StepState.BLOCKED if result.blocked else StepState.FAILED
                    step.verification=result.error or "Action failed"
                    mission.updated_at=time.time(); self.store.save(mission)
                    if result.blocked:
                        mission.state=AutonomyState.BLOCKED; mission.blocked_reason=step.verification; mission.conclusion=step.verification
                        break
                    mission.replans += 1
                    if mission.replans-replans_at_start > self.config.max_replans:
                        mission.state=AutonomyState.FAILED; mission.conclusion="Replan budget exhausted after action failures"
                        break
                    continue

                ok,detail=self.verifier.verify(req,result)
                step.verification=detail
                step.state=StepState.VERIFIED if ok else StepState.FAILED
                mission.updated_at=time.time(); self.store.save(mission)
                if not ok:
                    mission.replans += 1
                    if mission.replans-replans_at_start > self.config.max_replans:
                        mission.state=AutonomyState.FAILED; mission.conclusion="Replan budget exhausted after verification failures"
                        break
            else:
                mission.state=AutonomyState.PAUSED if pause_on_budget else AutonomyState.FAILED
                mission.conclusion=f"Step budget exhausted ({additional_budget} additional steps) before success was verified"
        except Exception as exc:
            if self.kill_switch.engaged:
                mission.state=AutonomyState.BLOCKED
                mission.blocked_reason="STOP GLOBAL engaged"
                mission.conclusion=mission.blocked_reason
            else:
                mission.state=AutonomyState.FAILED
                mission.conclusion=f"Autonomy runtime error: {exc}"
        mission.updated_at=time.time(); self.store.save(mission)
        return mission

    def _learn_for_mission(self, mission: AutonomousMission, decision: dict[str,Any]) -> AutonomyState | None:
        if self.skill_forge is None or self.skill_store is None:
            mission.conclusion="Skill Forge is unavailable to Mission Autopilot";return AutonomyState.FAILED
        if not self.executor.policy.is_allowed("skill.learn"):
            mission.blocked_reason="Capability blocked by policy: skill.learn";mission.conclusion=mission.blocked_reason;return AutonomyState.BLOCKED
        use_web=bool(decision.get("use_web",False))
        if use_web and not self.executor.policy.is_allowed("research.web"):
            mission.blocked_reason="Capability blocked by policy: research.web";mission.conclusion=mission.blocked_reason;return AutonomyState.BLOCKED
        learning_goal=" ".join(str(decision.get("goal") or "").split()).strip()
        if not learning_goal:
            return None
        try:
            result=self.skill_forge.learn(learning_goal,documentation=str(decision.get("documentation") or ""),allow_web=use_web)
        except PermissionError as exc:
            mission.blocked_reason=str(exc);mission.conclusion=str(exc);return AutonomyState.BLOCKED
        except Exception as exc:
            mission.conclusion=f"Skill learning failed: {exc}";return AutonomyState.FAILED
        step=MissionStep(
            index=len(mission.steps)+1,action="learn_skill",args={"goal":learning_goal,"use_web":use_web},capability="skill.learn",
            rationale=str(decision.get("rationale") or "Mission lacks a reusable procedure"),expected_effect="Validated skill proposal awaiting owner approval",
            state=StepState.VERIFIED if result.validation.ok and result.preflight.get("ok") and result.practice.get("ok") else StepState.FAILED,
            output={"skill":result.skill.name,"status":result.skill.status.value,"preflight":result.preflight,"practice":result.practice,"citations":result.research.get("citations",[])},
            verification="Skill compiled, preflighted and passed shadow-world practice" if result.validation.ok and result.preflight.get("ok") and result.practice.get("ok") else "Skill failed validation/preflight/practice",
            evidence_kind="capability",
        )
        mission.steps.append(step)
        if step.state != StepState.VERIFIED:
            mission.conclusion=step.verification;return AutonomyState.FAILED
        mission.pending_skill=result.skill.name
        mission.conclusion=f"Owner approval required: skill '{result.skill.name}' is VALIDATED, not enabled. Enable it and resume the mission."
        return AutonomyState.AWAITING_APPROVAL

    def _run_skill_step(self, mission: AutonomousMission, decision: dict[str,Any]) -> AutonomyState | None:
        if self.skill_store is None or self.skill_runner is None:
            mission.conclusion="Skill execution is unavailable to Mission Autopilot";return AutonomyState.FAILED
        if not self.executor.policy.is_allowed("skill.execute"):
            mission.blocked_reason="Capability blocked by policy: skill.execute";mission.conclusion=mission.blocked_reason;return AutonomyState.BLOCKED
        name=str(decision.get("skill") or decision.get("name") or "").strip()
        inputs=decision.get("inputs") or {}
        if not name or not isinstance(inputs,dict):
            return None
        skill=self.skill_store.get(name)
        if skill is None:
            return None
        if skill.status != SkillStatus.ENABLED:
            mission.pending_skill=skill.name
            mission.conclusion=f"Owner approval required: enable skill '{skill.name}' and resume this mission"
            return AutonomyState.AWAITING_APPROVAL
        step=MissionStep(index=len(mission.steps)+1,action="run_skill",args={"name":name,"inputs":dict(inputs)},capability="skill.execute",
                         rationale=str(decision.get("rationale") or "Use an owner-approved reusable skill"),expected_effect=str(decision.get("expected_effect") or "Skill steps complete and verify"))
        mission.steps.append(step);mission.updated_at=time.time();self.store.save(mission)
        report=self.skill_runner.run(skill,inputs,dry_run=False)
        step.output={"skill":report.skill,"ok":report.ok,"steps":report.steps,"error":report.error}
        if report.ok:
            step.state=StepState.VERIFIED;step.verification="Owner-enabled skill completed; every underlying step passed normal verification";return AutonomyState.RUNNING
        blocked=False
        for row in report.steps:
            result=row.get("result") if isinstance(row,dict) else None
            if isinstance(result,dict) and result.get("blocked"):
                blocked=True;break
        step.state=StepState.BLOCKED if blocked else StepState.FAILED
        step.error=report.error;step.verification=report.error or "Skill execution failed"
        if blocked:
            mission.blocked_reason=step.verification;mission.conclusion=step.verification;return AutonomyState.BLOCKED
        return None

    def resume(self, mission_id: str, *, max_steps: int | None = None) -> AutonomousMission:
        mission=self.store.load(mission_id)
        if mission.state == AutonomyState.VERIFIED:
            return mission
        if mission.state == AutonomyState.RUNNING:
            mission.state=AutonomyState.PAUSED
        return self.run(mission.goal, success_criteria=mission.success_criteria,
                        max_steps=max_steps or self.config.max_steps, existing=mission)

    def _decide(self, provider: Any, mission: AutonomousMission) -> dict[str, Any]:
        actions=[]
        for name,action in sorted(self.executor.actions.items()):
            if name in self.META_ACTIONS:
                continue
            actions.append({"name":name,"capability":action.capability,"currently_allowed":self.executor.policy.is_allowed(action.capability)})
        skills=[]
        if self.skill_store is not None:
            try:
                for skill in self.skill_store.list():
                    skills.append({"name":skill.name,"description":skill.description,"status":skill.status.value,"inputs":skill.inputs,"required_capabilities":list(skill.required_capabilities)})
            except Exception:
                pass
        screen=None
        if self.observer is not None and self.executor.policy.is_allowed("screen.observe") and self.executor.policy.is_allowed("screen.cloud"):
            try: screen=self.observer.snapshot(include_image=False).compact(limit=self.config.screen_element_limit)
            except Exception as exc: screen={"error":str(exc)}
        memory=None
        if self.memory_context is not None and self.executor.policy.is_allowed("memory.read") and self.executor.policy.is_allowed("memory.cloud"):
            try: memory=self.memory_context(mission.goal)
            except Exception as exc: memory={"error":str(exc)}
        multimodal=None
        if self.multimodal_context is not None:
            try: multimodal=self.multimodal_context()
            except Exception as exc: multimodal={"error":str(exc)}
        world=None
        if self.world_context is not None:
            try: world=self.world_context(mission.goal)
            except Exception as exc: world={"error":str(exc)}
        steps=[{
            "evidence_id":x.evidence_id,"evidence_kind":x.evidence_kind,"action":x.action,"args":x.args,"state":x.state.value,
            "verification":x.verification,"error":x.error,"output":x.output,
        } for x in mission.steps[-8:]]
        schema={
            "decision":"act|skill|learn|done|blocked",
            "action":"registered action when decision=act","args":{},
            "skill":"enabled skill name when decision=skill","inputs":{},
            "goal":"procedure to learn when decision=learn","use_web":False,"documentation":"optional supplied docs",
            "rationale":"short reason","expected_effect":"observable effect",
            "evidence":["step:1"],"reason":"completion/block reason"
        }
        prompt=(
            "You control a CLOSED-LOOP desktop mission by selecting AT MOST ONE next action, owner-enabled skill, or bounded learning request. "
            "You do not have direct tool access. Never invent actions, never change permissions, never claim an effect that is not in VERIFIED effect steps. "
            "If a required capability is currently denied, return blocked rather than trying to bypass it. "
            "Use decision=skill only for an ENABLED skill. If a reusable procedure is missing but CAN be composed from existing registered primitive actions, decision=learn may request Skill Forge. "
            "Learning never creates a new primitive capability and never auto-enables the resulting skill; the mission will pause for owner approval. "
            "Set use_web=true only when current/official documentation is materially needed. If MULTIMODAL reports ambiguous=true or contradictions, never infer a deictic target from it; choose a clarifying/safe step or return blocked. If the last action failed verification, choose a materially different recovery step or return blocked. "
            "Return done ONLY when local verified EFFECT evidence proves the mission success criteria; learning/preflight evidence is not proof of task completion. JSON only.\n"
            f"SCHEMA={json.dumps(schema)}\nGOAL={mission.goal}\nSUCCESS_CRITERIA={json.dumps(mission.success_criteria,ensure_ascii=False)}\n"
            f"ACTIONS={json.dumps(actions,ensure_ascii=False)}\nSKILLS={json.dumps(skills,ensure_ascii=False)[:16000]}\nVERIFIED_STEPS={json.dumps(steps,ensure_ascii=False,default=str)[:26000]}\n"
            f"SCREEN={json.dumps(screen,ensure_ascii=False,default=str)[:18000]}\nMEMORY={json.dumps(memory,ensure_ascii=False,default=str)[:10000]}\n"
            f"WORLD={json.dumps(world,ensure_ascii=False,default=str)[:12000]}\nMULTIMODAL={json.dumps(multimodal,ensure_ascii=False,default=str)[:8000]}"
        )
        raw=provider.generate(prompt,system="You are JARVIS Mission Autopilot. Safety, owner approval and local verification outrank task completion.")
        return self._json(raw)

    @staticmethod
    def _json(raw: str) -> dict[str, Any]:
        text=str(raw).strip()
        if text.startswith("```"):
            text=re.sub(r"^```(?:json)?\s*","",text,flags=re.I); text=re.sub(r"\s*```$","",text)
        try: value=json.loads(text)
        except json.JSONDecodeError:
            a,b=text.find("{"),text.rfind("}")
            if a<0 or b<=a: raise RuntimeError("Autonomy planner did not return JSON")
            value=json.loads(text[a:b+1])
        if not isinstance(value,dict): raise RuntimeError("Autonomy planner JSON must be an object")
        return value

    @staticmethod
    def _fingerprint(action: str, args: dict[str,Any]) -> str:
        return action+":"+json.dumps(args,sort_keys=True,ensure_ascii=False,default=str,separators=(",",":"))

    @staticmethod
    def _safe_output(value: Any) -> Any:
        try:
            json.dumps(value,default=str)
            return value
        except Exception:
            return str(value)
