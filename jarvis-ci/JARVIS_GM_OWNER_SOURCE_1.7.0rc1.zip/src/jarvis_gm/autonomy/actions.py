from __future__ import annotations

from typing import Any

from jarvis_gm.actions.base import Action
from .engine import AutonomyEngine
from .store import MissionStore


class RunAutonomousMissionAction(Action):
    name="run_autonomous_mission"
    capability="autonomy.run"
    def __init__(self, engine: AutonomyEngine) -> None:self.engine=engine
    def run(self, **kwargs: Any) -> Any:
        goal=str(kwargs.get("goal") or "").strip()
        criteria=kwargs.get("success_criteria") or []
        if not isinstance(criteria,list): raise ValueError("success_criteria must be a list")
        report=self.engine.run(goal,success_criteria=[str(x) for x in criteria],max_steps=kwargs.get("max_steps"))
        if report.state.value in {"blocked","awaiting_approval"}:
            raise PermissionError(report.blocked_reason or report.conclusion or "Autonomous mission blocked or awaiting owner approval")
        if report.state.value != "verified":
            raise RuntimeError(report.conclusion or f"Autonomous mission ended as {report.state.value}")
        return report.as_dict()
    def verify(self, output: Any, **kwargs: Any) -> tuple[bool,str]:
        state=str((output or {}).get("state", ""))
        if state=="verified":return True,"Autonomous mission completed with locally verified evidence"
        return False,f"Autonomous mission ended as {state}: {(output or {}).get('conclusion') or (output or {}).get('blocked_reason') or 'no detail'}"


class ResumeAutonomousMissionAction(Action):
    name="resume_autonomous_mission"
    capability="autonomy.run"
    def __init__(self, engine: AutonomyEngine) -> None:self.engine=engine
    def run(self, **kwargs: Any) -> Any:
        report=self.engine.resume(str(kwargs["mission_id"]),max_steps=kwargs.get("max_steps"))
        if report.state.value in {"blocked","awaiting_approval"}: raise PermissionError(report.blocked_reason or report.conclusion or "Autonomous mission blocked or awaiting owner approval")
        if report.state.value != "verified": raise RuntimeError(report.conclusion or f"Autonomous mission ended as {report.state.value}")
        return report.as_dict()
    def verify(self, output: Any, **kwargs: Any) -> tuple[bool,str]:
        state=str((output or {}).get("state", "")); return state=="verified",f"Mission resume ended as {state}"


class ListAutonomousMissionsAction(Action):
    name="list_autonomous_missions"
    capability="safe.read"
    def __init__(self, store: MissionStore) -> None:self.store=store
    def run(self, **kwargs: Any) -> Any:return self.store.list(limit=int(kwargs.get("limit",50)))
