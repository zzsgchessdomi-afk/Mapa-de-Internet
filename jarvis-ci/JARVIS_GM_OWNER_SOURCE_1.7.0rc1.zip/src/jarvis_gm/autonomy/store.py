from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .models import AutonomousMission, AutonomyState, MissionStep, StepState


class MissionStore:
    def __init__(self, root: Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def path_for(self, mission_id: str) -> Path:
        safe = "".join(c for c in mission_id if c.isalnum() or c in "-_")
        if safe != mission_id or not safe:
            raise ValueError("Invalid mission id")
        return self.root / f"{safe}.json"

    def save(self, mission: AutonomousMission) -> Path:
        path = self.path_for(mission.id)
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(mission.as_dict(), ensure_ascii=False, indent=2, default=str), encoding="utf-8")
        tmp.replace(path)
        return path

    def load(self, mission_id: str) -> AutonomousMission:
        path = self.path_for(mission_id)
        raw: dict[str, Any] = json.loads(path.read_text(encoding="utf-8"))
        mission = AutonomousMission(
            goal=str(raw["goal"]),
            success_criteria=tuple(str(x) for x in raw.get("success_criteria", [])),
            id=str(raw["id"]),
            state=AutonomyState(str(raw.get("state", "received"))),
            conclusion=str(raw.get("conclusion", "")),
            blocked_reason=str(raw.get("blocked_reason", "")),
            replans=int(raw.get("replans", 0)),
            pending_skill=str(raw.get("pending_skill", "")),
            created_at=float(raw.get("created_at", 0.0) or 0.0),
            updated_at=float(raw.get("updated_at", 0.0) or 0.0),
        )
        for row in raw.get("steps", []):
            mission.steps.append(MissionStep(
                index=int(row["index"]),
                action=str(row["action"]),
                args=dict(row.get("args") or {}),
                capability=str(row.get("capability", "safe.read")),
                rationale=str(row.get("rationale", "")),
                expected_effect=str(row.get("expected_effect", "")),
                state=StepState(str(row.get("state", "proposed"))),
                output=row.get("output"),
                verification=str(row.get("verification", "")),
                error=row.get("error"),
                evidence_kind=str(row.get("evidence_kind", "effect")),
                created_at=float(row.get("created_at", 0.0) or 0.0),
            ))
        return mission

    def list(self, limit: int = 50) -> list[dict[str, Any]]:
        rows=[]
        for path in sorted(self.root.glob("auto_*.json"), key=lambda p: p.stat().st_mtime, reverse=True)[:max(1, limit)]:
            try:
                raw=json.loads(path.read_text(encoding="utf-8"))
                rows.append({k:raw.get(k) for k in ("id","goal","state","conclusion","pending_skill","updated_at")})
            except Exception:
                continue
        return rows
