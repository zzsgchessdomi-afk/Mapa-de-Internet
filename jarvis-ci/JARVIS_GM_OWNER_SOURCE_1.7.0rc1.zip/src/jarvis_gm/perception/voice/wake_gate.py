from __future__ import annotations

from dataclasses import dataclass
import re
import time


@dataclass(frozen=True, slots=True)
class WakeDecision:
    kind: str
    text: str = ""


class WakeGate:
    """Turns transcripts into deliberate wake/command decisions."""

    def __init__(self, wake_words: tuple[str, ...] = ("jarvis", "jervis"), command_window_s: float = 7.0) -> None:
        self.wake_words = tuple(x.lower().strip() for x in wake_words if x.strip())
        self.command_window_s = command_window_s
        self._awake_until = 0.0

    def process(self, transcript: str, now: float | None = None) -> WakeDecision:
        now = time.time() if now is None else now
        clean = " ".join(transcript.strip().split())
        low = clean.lower()
        for wake in self.wake_words:
            match = re.search(rf"\b{re.escape(wake)}\b", low)
            if match:
                self._awake_until = now + self.command_window_s
                after = clean[match.end():].strip(" ,.:;-—")
                return WakeDecision("command", after) if after else WakeDecision("wake", "")
        if now <= self._awake_until and clean:
            self._awake_until = now + self.command_window_s
            return WakeDecision("command", clean)
        return WakeDecision("ignored", "")

    def sleep(self) -> None:
        self._awake_until = 0.0
