from __future__ import annotations

from pathlib import Path
from urllib import request


GESTURE_MODEL_URL = (
    "https://storage.googleapis.com/mediapipe-models/gesture_recognizer/"
    "gesture_recognizer/float16/1/gesture_recognizer.task"
)


class ModelManager:
    def __init__(self, model_dir: Path) -> None:
        self.model_dir = Path(model_dir)
        self.model_dir.mkdir(parents=True, exist_ok=True)

    @property
    def gesture_model(self) -> Path:
        return self.model_dir / "gesture_recognizer.task"

    def ensure_gesture_model(self, timeout: float = 45.0) -> Path:
        path = self.gesture_model
        if path.exists() and path.stat().st_size > 1024 * 1024:
            return path
        tmp = path.with_suffix(".download")
        try:
            with request.urlopen(GESTURE_MODEL_URL, timeout=timeout) as response, tmp.open("wb") as out:
                while True:
                    block = response.read(1024 * 1024)
                    if not block:
                        break
                    out.write(block)
            if tmp.stat().st_size <= 1024 * 1024:
                raise RuntimeError("Downloaded gesture model is unexpectedly small")
            tmp.replace(path)
            return path
        except Exception:
            if tmp.exists():
                tmp.unlink()
            raise
