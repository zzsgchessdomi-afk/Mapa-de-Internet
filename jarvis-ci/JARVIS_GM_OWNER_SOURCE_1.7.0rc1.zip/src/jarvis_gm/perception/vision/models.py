from __future__ import annotations

from dataclasses import dataclass, field
import time


@dataclass(frozen=True, slots=True)
class Point3:
    x: float
    y: float
    z: float = 0.0


@dataclass(frozen=True, slots=True)
class HandObservation:
    handedness: str
    landmarks: tuple[Point3, ...]
    static_gesture: str = "None"
    confidence: float = 0.0

    def point(self, index: int) -> Point3:
        return self.landmarks[index]


@dataclass(frozen=True, slots=True)
class VisionFrame:
    hands: tuple[HandObservation, ...] = field(default_factory=tuple)
    timestamp: float = field(default_factory=time.time)
    frame_width: int = 0
    frame_height: int = 0
