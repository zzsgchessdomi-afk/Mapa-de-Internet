from __future__ import annotations

from collections.abc import Callable
from pathlib import Path
import os
import threading
import time

from .model_manager import ModelManager
from .models import HandObservation, Point3, VisionFrame


FrameCallback = Callable[[VisionFrame], None]
StatusCallback = Callable[[str, str], None]


class MediaPipeGestureTracker:
    """Real webcam tracker using MediaPipe Gesture Recognizer.

    Imports heavy optional dependencies lazily so the JARVIS core still starts
    on machines where camera support has not yet been installed.
    """

    def __init__(
        self,
        data_dir: Path,
        *,
        camera_index: int = 0,
        mirror: bool = True,
        target_fps: float = 30.0,
    ) -> None:
        self.data_dir = Path(data_dir)
        self.camera_index = camera_index
        self.mirror = mirror
        self.target_fps = max(5.0, target_fps)
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._status = "stopped"
        self._detail = "not started"
        self._model_manager = ModelManager(self.data_dir / "models")

    @property
    def running(self) -> bool:
        return bool(self._thread and self._thread.is_alive())

    @property
    def status(self) -> tuple[str, str]:
        return self._status, self._detail

    def dependencies_available(self) -> tuple[bool, str]:
        try:
            import cv2  # noqa: F401
            import mediapipe  # noqa: F401
        except Exception as exc:
            return False, f"vision dependency unavailable: {exc}"
        return True, "ready"

    def start(self, on_frame: FrameCallback, on_status: StatusCallback | None = None) -> None:
        if self.running:
            return
        ok, detail = self.dependencies_available()
        if not ok:
            self._status, self._detail = "unavailable", detail
            if on_status:
                on_status(self._status, self._detail)
            return
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._run,
            args=(on_frame, on_status),
            name="jarvis-vision",
            daemon=True,
        )
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        thread = self._thread
        if thread and thread.is_alive() and thread is not threading.current_thread():
            thread.join(timeout=2.5)
        self._thread = None
        self._status, self._detail = "stopped", "stopped by user"

    def _set_status(self, status: str, detail: str, callback: StatusCallback | None) -> None:
        self._status, self._detail = status, detail
        if callback:
            callback(status, detail)

    def _run(self, on_frame: FrameCallback, on_status: StatusCallback | None) -> None:
        cv2 = None
        cap = None
        recognizer = None
        try:
            import cv2 as _cv2
            import mediapipe as mp
            cv2 = _cv2
            self._set_status("preparing", "checking gesture model", on_status)
            model_path = self._model_manager.ensure_gesture_model()

            BaseOptions = mp.tasks.BaseOptions
            VisionRunningMode = mp.tasks.vision.RunningMode
            GestureRecognizer = mp.tasks.vision.GestureRecognizer
            GestureRecognizerOptions = mp.tasks.vision.GestureRecognizerOptions
            options = GestureRecognizerOptions(
                base_options=BaseOptions(model_asset_path=str(model_path)),
                running_mode=VisionRunningMode.VIDEO,
                num_hands=2,
                min_hand_detection_confidence=0.60,
                min_hand_presence_confidence=0.60,
                min_tracking_confidence=0.60,
            )
            recognizer = GestureRecognizer.create_from_options(options)

            backend = cv2.CAP_DSHOW if os.name == "nt" and hasattr(cv2, "CAP_DSHOW") else cv2.CAP_ANY
            cap = cv2.VideoCapture(self.camera_index, backend)
            if not cap.isOpened():
                raise RuntimeError(f"camera {self.camera_index} could not be opened")
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
            cap.set(cv2.CAP_PROP_FPS, self.target_fps)
            self._set_status("running", f"camera {self.camera_index} active", on_status)

            interval = 1.0 / self.target_fps
            last = 0.0
            start_mono = time.monotonic()
            while not self._stop.is_set():
                ok, frame = cap.read()
                if not ok:
                    raise RuntimeError("camera frame read failed")
                now_mono = time.monotonic()
                if now_mono - last < interval:
                    continue
                last = now_mono
                if self.mirror:
                    frame = cv2.flip(frame, 1)
                rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
                timestamp_ms = int((now_mono - start_mono) * 1000)
                result = recognizer.recognize_for_video(mp_image, timestamp_ms)
                hands: list[HandObservation] = []
                for i, landmarks in enumerate(result.hand_landmarks):
                    handedness = "Unknown"
                    if i < len(result.handedness) and result.handedness[i]:
                        handedness = result.handedness[i][0].category_name or "Unknown"
                    gesture = "None"
                    confidence = 0.0
                    if i < len(result.gestures) and result.gestures[i]:
                        cat = result.gestures[i][0]
                        gesture = cat.category_name or "None"
                        confidence = float(cat.score or 0.0)
                    pts = tuple(Point3(float(p.x), float(p.y), float(p.z or 0.0)) for p in landmarks)
                    hands.append(HandObservation(handedness, pts, gesture, confidence))
                h, w = frame.shape[:2]
                on_frame(VisionFrame(tuple(hands), time.time(), w, h))
        except Exception as exc:
            self._set_status("error", str(exc), on_status)
        finally:
            if recognizer is not None:
                try:
                    recognizer.close()
                except Exception:
                    pass
            if cap is not None:
                try:
                    cap.release()
                except Exception:
                    pass
            if self._status not in {"error", "unavailable"}:
                self._set_status("stopped", "vision loop ended", on_status)
