from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from math import atan2, degrees, hypot
from typing import Iterable

from jarvis_gm.perception.events import PerceptionEvent
from .models import HandObservation, VisionFrame, Point3


WRIST = 0
THUMB_TIP = 4
INDEX_MCP = 5
INDEX_PIP = 6
INDEX_TIP = 8
MIDDLE_PIP = 10
MIDDLE_TIP = 12
RING_PIP = 14
RING_TIP = 16
PINKY_MCP = 17
PINKY_PIP = 18
PINKY_TIP = 20


def _dist(a: Point3, b: Point3) -> float:
    return hypot(a.x - b.x, a.y - b.y)


def _angle(a: Point3, b: Point3) -> float:
    return degrees(atan2(b.y - a.y, b.x - a.x))


@dataclass(slots=True)
class GestureConfig:
    arm_dwell_s: float = 0.45
    no_hands_disarm_s: float = 1.20
    pinch_ratio: float = 0.34
    pinch_release_ratio: float = 0.46
    point_throttle_s: float = 0.055
    pinch_move_throttle_s: float = 0.045
    swipe_window_s: float = 0.36
    swipe_min_dx: float = 0.20
    swipe_cooldown_s: float = 0.75
    static_dwell_s: float = 0.28
    static_cooldown_s: float = 0.65
    transform_throttle_s: float = 0.055
    min_static_confidence: float = 0.55


class GestureEngine:
    """Stateful gesture interpreter above raw landmarks.

    Safety/UX rules:
    - Open palm must be held before gesture mode is armed.
    - No hands for a short period automatically disarms the mode.
    - Hysteresis is used for pinch start/end to avoid chatter.
    - Swipes and static gestures have cooldowns.
    - Two-hand output is a continuous transform event (scale + rotation), which
      Phase 3 can map to windows or 3D objects after permission checks.
    """

    def __init__(self, config: GestureConfig | None = None) -> None:
        self.cfg = config or GestureConfig()
        self.armed = False
        self._open_since: float | None = None
        self._arm_latched = False
        self._last_hands_at: float | None = None
        self._pinching = False
        self._last_pinch_move = 0.0
        self._last_point = 0.0
        self._wrist_history: deque[tuple[float, float]] = deque(maxlen=32)
        self._last_swipe = -1e9
        self._static_name = "None"
        self._static_since = 0.0
        self._last_static_emit: dict[str, float] = {}
        self._two_hand_baseline: tuple[float, float] | None = None
        self._last_transform = 0.0

    def reset(self) -> None:
        cfg = self.cfg
        self.__init__(cfg)

    def process(self, frame: VisionFrame) -> list[PerceptionEvent]:
        now = frame.timestamp
        events: list[PerceptionEvent] = []

        if not frame.hands:
            self._open_since = None
            self._arm_latched = False
            self._wrist_history.clear()
            self._two_hand_baseline = None
            if self._pinching:
                self._pinching = False
                events.append(self._event("gesture.pinch_end", now, {}))
            if self.armed and self._last_hands_at is not None and now - self._last_hands_at >= self.cfg.no_hands_disarm_s:
                self.armed = False
                events.append(self._event("gesture.disarmed", now, {"reason": "hands_left_view"}))
            return events

        self._last_hands_at = now
        primary = self._primary_hand(frame.hands)
        static = self._static(primary)

        # Deliberate open-palm dwell arms interaction mode.
        if static == "Open_Palm":
            if self._open_since is None:
                self._open_since = now
            if not self.armed and not self._arm_latched and now - self._open_since >= self.cfg.arm_dwell_s:
                self.armed = True
                self._arm_latched = True
                events.append(self._event("gesture.armed", now, {"hand": primary.handedness}))
        else:
            self._open_since = None
            self._arm_latched = False

        if not self.armed:
            return events

        events.extend(self._static_events(primary, static, now))
        events.extend(self._pinch_events(primary, now))
        events.extend(self._point_events(primary, static, now))
        events.extend(self._swipe_events(primary, now))
        events.extend(self._two_hand_events(frame.hands, now))
        return events

    def _event(self, typ: str, timestamp: float, payload: dict, confidence: float = 1.0) -> PerceptionEvent:
        return PerceptionEvent(typ, "vision.hand", payload, max(0.0, min(1.0, confidence)), timestamp)

    @staticmethod
    def _primary_hand(hands: Iterable[HandObservation]) -> HandObservation:
        return max(hands, key=lambda h: h.confidence)

    def _static(self, hand: HandObservation) -> str:
        if hand.static_gesture and hand.static_gesture != "None" and hand.confidence >= self.cfg.min_static_confidence:
            return hand.static_gesture
        if len(hand.landmarks) < 21:
            return "None"
        lm = hand.landmarks
        ext = [lm[INDEX_TIP].y < lm[INDEX_PIP].y, lm[MIDDLE_TIP].y < lm[MIDDLE_PIP].y,
               lm[RING_TIP].y < lm[RING_PIP].y, lm[PINKY_TIP].y < lm[PINKY_PIP].y]
        if all(ext):
            return "Open_Palm"
        if ext[0] and not any(ext[1:]):
            return "Pointing_Up"
        if not any(ext):
            return "Closed_Fist"
        return "None"

    def _scale(self, hand: HandObservation) -> float:
        lm = hand.landmarks
        if len(lm) < 21:
            return 0.15
        return max(_dist(lm[INDEX_MCP], lm[PINKY_MCP]), 1e-4)

    def _pinch_events(self, hand: HandObservation, now: float) -> list[PerceptionEvent]:
        if len(hand.landmarks) < 21:
            return []
        lm = hand.landmarks
        ratio = _dist(lm[THUMB_TIP], lm[INDEX_TIP]) / self._scale(hand)
        p = lm[INDEX_TIP]
        payload = {"x": p.x, "y": p.y, "ratio": ratio, "hand": hand.handedness}
        if not self._pinching and ratio <= self.cfg.pinch_ratio:
            self._pinching = True
            self._last_pinch_move = now
            return [self._event("gesture.pinch_start", now, payload, hand.confidence)]
        if self._pinching and ratio >= self.cfg.pinch_release_ratio:
            self._pinching = False
            return [self._event("gesture.pinch_end", now, payload, hand.confidence)]
        if self._pinching and now - self._last_pinch_move >= self.cfg.pinch_move_throttle_s:
            self._last_pinch_move = now
            return [self._event("gesture.pinch_move", now, payload, hand.confidence)]
        return []

    def _point_events(self, hand: HandObservation, static: str, now: float) -> list[PerceptionEvent]:
        if static != "Pointing_Up" or self._pinching or len(hand.landmarks) < 21:
            return []
        if now - self._last_point < self.cfg.point_throttle_s:
            return []
        self._last_point = now
        p = hand.landmarks[INDEX_TIP]
        return [self._event("gesture.point", now, {"x": p.x, "y": p.y, "hand": hand.handedness}, hand.confidence)]

    def _swipe_events(self, hand: HandObservation, now: float) -> list[PerceptionEvent]:
        if len(hand.landmarks) < 1:
            return []
        x = hand.landmarks[WRIST].x
        self._wrist_history.append((now, x))
        while self._wrist_history and now - self._wrist_history[0][0] > self.cfg.swipe_window_s:
            self._wrist_history.popleft()
        if len(self._wrist_history) < 3 or now - self._last_swipe < self.cfg.swipe_cooldown_s:
            return []
        t0, x0 = self._wrist_history[0]
        dt = now - t0
        dx = x - x0
        if dt <= 0 or abs(dx) < self.cfg.swipe_min_dx:
            return []
        self._last_swipe = now
        self._wrist_history.clear()
        direction = "right" if dx > 0 else "left"
        return [self._event(f"gesture.swipe_{direction}", now, {"dx": dx, "duration": dt}, hand.confidence)]

    def _static_events(self, hand: HandObservation, static: str, now: float) -> list[PerceptionEvent]:
        if static in {"None", "Open_Palm", "Pointing_Up", "Closed_Fist"}:
            self._static_name = static
            self._static_since = now
            return []
        if static != self._static_name:
            self._static_name = static
            self._static_since = now
            return []
        if now - self._static_since < self.cfg.static_dwell_s:
            return []
        last = self._last_static_emit.get(static, -1e9)
        if now - last < self.cfg.static_cooldown_s:
            return []
        self._last_static_emit[static] = now
        return [self._event("gesture.static", now, {"name": static, "hand": hand.handedness}, hand.confidence)]

    def _two_hand_events(self, hands: tuple[HandObservation, ...], now: float) -> list[PerceptionEvent]:
        if len(hands) < 2 or any(len(h.landmarks) < 21 for h in hands[:2]):
            self._two_hand_baseline = None
            return []
        a = hands[0].landmarks[INDEX_TIP]
        b = hands[1].landmarks[INDEX_TIP]
        distance = max(_dist(a, b), 1e-5)
        angle = _angle(a, b)
        if self._two_hand_baseline is None:
            self._two_hand_baseline = (distance, angle)
            return []
        base_distance, base_angle = self._two_hand_baseline
        if now - self._last_transform < self.cfg.transform_throttle_s:
            return []
        self._last_transform = now
        scale = distance / max(base_distance, 1e-5)
        rotation = angle - base_angle
        while rotation > 180:
            rotation -= 360
        while rotation < -180:
            rotation += 360
        center = {"x": (a.x + b.x) / 2, "y": (a.y + b.y) / 2}
        self._two_hand_baseline = (distance, angle)
        if abs(scale - 1.0) < 0.015 and abs(rotation) < 1.5:
            return []
        confidence = min(hands[0].confidence, hands[1].confidence)
        return [self._event("gesture.transform", now, {
            "center": center,
            "scale_delta": scale,
            "rotation_delta_deg": rotation,
        }, confidence)]
