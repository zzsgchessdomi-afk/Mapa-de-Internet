from __future__ import annotations

from collections import deque
from dataclasses import dataclass, asdict
import re
import threading
import time
from typing import Callable, Any

from .events import PerceptionEvent


@dataclass(slots=True)
class FusionConfig:
    event_ttl_s: float = 3.0
    point_ttl_s: float = 1.2
    scene_ttl_s: float = 5.0
    max_events: int = 96


@dataclass(slots=True)
class MultimodalContext:
    timestamp: float
    active_title: str = ''
    scene_fingerprint: str = ''
    voice_text: str = ''
    gesture: str = ''
    point: tuple[float,float] | None = None
    confidence: float = 0.0
    ambiguous: bool = False
    contradictions: tuple[str,...] = ()
    sources: tuple[str,...] = ()

    def as_dict(self) -> dict:
        data=asdict(self)
        if self.point is not None: data['point']={'x':self.point[0],'y':self.point[1]}
        return data


class FusionCore:
    """Fuses recent local signals while treating staleness/contradictions as first-class state.

    It is not an executor. It only produces a compact context envelope. Cloud export
    is a separate owner permission supplied by `cloud_allowed`.
    """
    DEICTIC=re.compile(r'\b(aqui|aquí|ahi|ahí|eso|ese|esa|este|esta)\b',re.I)

    def __init__(self,bus,*,cloud_allowed:Callable[[],bool]|None=None,screen_cloud_allowed:Callable[[],bool]|None=None,config:FusionConfig|None=None) -> None:
        self.bus=bus; self.cloud_allowed=cloud_allowed or (lambda:False); self.screen_cloud_allowed=screen_cloud_allowed or (lambda:False); self.config=config or FusionConfig()
        self._events:deque[PerceptionEvent]=deque(maxlen=self.config.max_events); self._lock=threading.RLock()
        self._token=bus.subscribe(self._on_event)

    def close(self) -> None:
        self.bus.unsubscribe(self._token)

    def _on_event(self,event:PerceptionEvent) -> None:
        with self._lock: self._events.append(event)

    def resolve(self,now:float|None=None) -> MultimodalContext:
        now=time.time() if now is None else float(now)
        with self._lock: events=list(self._events)
        events=[e for e in events if now-e.timestamp <= max(self.config.scene_ttl_s,self.config.event_ttl_s)]
        scene=next((e for e in reversed(events) if e.type=='environment.changed' and now-e.timestamp<=self.config.scene_ttl_s),None)
        voice=next((e for e in reversed(events) if e.type=='voice.command' and now-e.timestamp<=self.config.event_ttl_s),None)
        point=next((e for e in reversed(events) if e.type=='gesture.point' and now-e.timestamp<=self.config.point_ttl_s),None)
        gesture=next((e for e in reversed(events) if e.type.startswith('gesture.') and e.type not in {'gesture.point','gesture.armed'} and now-e.timestamp<=self.config.event_ttl_s),None)
        contradictions=[]; sources=[]; confidence=1.0
        voice_text=str((voice.payload if voice else {}).get('text','')).strip(); deictic=bool(self.DEICTIC.search(voice_text))
        point_value=None
        if point:
            try: point_value=(float(point.payload['x']),float(point.payload['y']))
            except Exception: point_value=None
        if deictic and point_value is None:
            contradictions.append('deictic_voice_without_fresh_point')
        if voice: sources.append('voice'); confidence=min(confidence,float(voice.confidence))
        if point: sources.append('point'); confidence=min(confidence,float(point.confidence))
        if gesture: sources.append('gesture'); confidence=min(confidence,float(gesture.confidence))
        if scene: sources.append('scene')
        if point and scene and point.timestamp < scene.timestamp and scene.payload.get('changed'):
            contradictions.append('scene_changed_after_point')
        if not sources: confidence=0.0
        return MultimodalContext(
            timestamp=now,active_title=str((scene.payload if scene else {}).get('active_title','')),
            scene_fingerprint=str((scene.payload if scene else {}).get('fingerprint','')),voice_text=voice_text,
            gesture=gesture.type if gesture else '',point=point_value,confidence=max(0.0,min(1.0,confidence)),
            ambiguous=bool(contradictions),contradictions=tuple(contradictions),sources=tuple(sources),
        )

    def cloud_summary(self) -> dict[str,Any] | None:
        if not self.cloud_allowed(): return None
        ctx=self.resolve(); data=ctx.as_dict()
        # Fingerprints are local synchronization tokens, not useful model context.
        data.pop('scene_fingerprint',None)
        if not self.screen_cloud_allowed():
            data['active_title']=''
            data['sources']=[x for x in data.get('sources',[]) if x!='scene']
        return data
