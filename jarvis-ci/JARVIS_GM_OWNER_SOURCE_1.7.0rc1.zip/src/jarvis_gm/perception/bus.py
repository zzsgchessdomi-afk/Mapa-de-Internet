from __future__ import annotations

from collections import deque
from collections.abc import Callable
import threading

from .events import PerceptionEvent


Subscriber = Callable[[PerceptionEvent], None]


class PerceptionBus:
    """Thread-safe in-process event bus.

    Sensors may publish from worker threads. Subscribers are isolated: one
    failing subscriber cannot break sensor processing.
    """

    def __init__(self, history_size: int = 256) -> None:
        self._lock = threading.RLock()
        self._subs: dict[int, Subscriber] = {}
        self._next_token = 1
        self._history: deque[PerceptionEvent] = deque(maxlen=history_size)

    def subscribe(self, callback: Subscriber) -> int:
        with self._lock:
            token = self._next_token
            self._next_token += 1
            self._subs[token] = callback
            return token

    def unsubscribe(self, token: int) -> None:
        with self._lock:
            self._subs.pop(token, None)

    def publish(self, event: PerceptionEvent) -> None:
        with self._lock:
            self._history.append(event)
            subscribers = tuple(self._subs.values())
        for callback in subscribers:
            try:
                callback(event)
            except Exception:
                # Perception must not be killed by a UI/logging subscriber.
                continue

    def recent(self, limit: int = 50) -> list[PerceptionEvent]:
        if limit <= 0:
            return []
        with self._lock:
            return list(self._history)[-limit:]
