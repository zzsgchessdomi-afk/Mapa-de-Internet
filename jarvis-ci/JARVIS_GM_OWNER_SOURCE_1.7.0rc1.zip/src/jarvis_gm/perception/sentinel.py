from __future__ import annotations

from collections import deque
from dataclasses import dataclass, asdict
import threading
import time
from typing import Callable

from jarvis_gm.perception.events import PerceptionEvent
from jarvis_gm.screen.observer import ScreenObserver


@dataclass(slots=True)
class SentinelConfig:
    interval_s: float = 0.8
    max_observations_per_minute: int = 75
    history_size: int = 120
    publish_heartbeats: bool = False


@dataclass(slots=True)
class SceneRecord:
    timestamp: float
    active_handle: int | None
    active_title: str
    fingerprint: str
    element_count: int
    changed: bool

    def as_dict(self) -> dict:
        return asdict(self)


class PerceptionSentinel:
    """Budgeted, local-only continuous environment observer.

    It deliberately stores no screenshots and never talks to a cloud provider.
    Continuous observation is owner opt-in and only publishes compact scene-change
    metadata onto the in-process perception bus.
    """

    def __init__(self, observer: ScreenObserver, bus, *, allowed: Callable[[], bool],
                 stop_check: Callable[[], None] | None = None,
                 config: SentinelConfig | None = None) -> None:
        self.observer=observer; self.bus=bus; self.allowed=allowed; self.stop_check=stop_check or (lambda: None)
        self.config=config or SentinelConfig()
        self._history: deque[SceneRecord]=deque(maxlen=self.config.history_size)
        self._recent_times: deque[float]=deque()
        self._thread: threading.Thread | None=None; self._stop=threading.Event(); self._lock=threading.RLock()

    @property
    def running(self) -> bool:
        return bool(self._thread and self._thread.is_alive())

    def start(self) -> None:
        if not self.allowed():
            raise PermissionError('Capability blocked by policy: perception.continuous')
        if self.running: return
        self._stop.clear(); self._thread=threading.Thread(target=self._loop,name='JarvisPerceptionSentinel',daemon=True); self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread and self._thread.is_alive() and threading.current_thread() is not self._thread:
            self._thread.join(timeout=max(1.0,self.config.interval_s*2))
        self._thread=None

    def _budget_ok(self, now: float) -> bool:
        while self._recent_times and now-self._recent_times[0] >= 60.0: self._recent_times.popleft()
        return len(self._recent_times) < max(1,self.config.max_observations_per_minute)

    def poll_once(self, now: float | None=None) -> SceneRecord | None:
        if not self.allowed(): return None
        self.stop_check()
        now=time.time() if now is None else float(now)
        with self._lock:
            if not self._budget_ok(now): return None
            self._recent_times.append(now)
        snap=self.observer.snapshot(include_image=False)
        fp=snap.visual_fingerprint or ''
        with self._lock:
            previous=self._history[-1] if self._history else None
            changed=previous is None or previous.active_handle!=snap.active_handle or previous.fingerprint!=fp or previous.active_title!=snap.active_title
            rec=SceneRecord(now,snap.active_handle,snap.active_title,fp,len(snap.elements),changed)
            self._history.append(rec)
        if changed:
            self.bus.publish(PerceptionEvent('environment.changed','sentinel',{
                'active_handle':rec.active_handle,'active_title':rec.active_title,'fingerprint':rec.fingerprint,
                'element_count':rec.element_count,'changed':True,
            },timestamp=now))
        elif self.config.publish_heartbeats:
            self.bus.publish(PerceptionEvent('environment.heartbeat','sentinel',{
                'active_handle':rec.active_handle,'active_title':rec.active_title,'fingerprint':rec.fingerprint,
            },timestamp=now))
        return rec

    def recent(self, limit: int=20) -> list[SceneRecord]:
        with self._lock: return list(self._history)[-max(0,int(limit)):]

    def _loop(self) -> None:
        while not self._stop.is_set():
            try:
                if not self.allowed(): break
                self.poll_once()
            except Exception as exc:
                self.bus.publish(PerceptionEvent('sensor.sentinel','sentinel',{'status':'error','detail':str(exc)}))
                text=str(exc).casefold()
                if isinstance(exc, PermissionError) or 'kill switch' in text or 'emergency stop' in text: break
            self._stop.wait(max(.1,self.config.interval_s))
        self.bus.publish(PerceptionEvent('sensor.sentinel','sentinel',{'status':'stopped'}))
