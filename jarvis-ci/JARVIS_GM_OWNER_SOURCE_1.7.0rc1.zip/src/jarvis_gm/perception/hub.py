from __future__ import annotations

from pathlib import Path
import threading

from .bus import PerceptionBus
from .events import PerceptionEvent
from .vision.gesture_engine import GestureEngine
from .vision.mediapipe_backend import MediaPipeGestureTracker
from .vision.models import VisionFrame
from .voice.wake_gate import WakeGate
from .voice.windows_sapi import WindowsSapiRecognizer, WindowsSapiVoice


class PerceptionHub:
    """Coordinates sensors without granting them execution permissions."""

    def __init__(self, data_dir: Path, bus: PerceptionBus | None = None) -> None:
        self.data_dir = Path(data_dir)
        self.bus = bus or PerceptionBus()
        self.gestures = GestureEngine()
        self.vision = MediaPipeGestureTracker(self.data_dir)
        self.wake = WakeGate()
        self.voice = WindowsSapiRecognizer()
        self.tts = WindowsSapiVoice()
        self._lock = threading.RLock()

    def start_vision(self) -> None:
        self.vision.start(self._on_frame, self._on_vision_status)

    def stop_vision(self) -> None:
        self.vision.stop()
        self.gestures.reset()
        self.bus.publish(PerceptionEvent("sensor.vision", "vision", {"status": "stopped"}))

    def start_voice(self) -> None:
        self.voice.start(self._on_transcript, self._on_voice_status)

    def stop_voice(self) -> None:
        self.voice.stop()
        self.wake.sleep()
        self.bus.publish(PerceptionEvent("sensor.voice", "voice", {"status": "stopped"}))

    def stop_all(self) -> None:
        self.stop_vision()
        self.stop_voice()

    def speak(self, text: str) -> None:
        self.tts.speak(text)

    def status(self) -> dict:
        vs, vd = self.vision.status
        ss, sd = self.voice.status
        tts_ok, tts_detail = self.tts.available()
        return {
            "vision": {"status": vs, "detail": vd, "running": self.vision.running},
            "voice": {"status": ss, "detail": sd, "running": self.voice.running},
            "tts": {"available": tts_ok, "detail": tts_detail},
            "gesture_mode_armed": self.gestures.armed,
        }

    def _on_frame(self, frame: VisionFrame) -> None:
        with self._lock:
            events = self.gestures.process(frame)
        for event in events:
            self.bus.publish(event)

    def _on_transcript(self, transcript: str, timestamp: float) -> None:
        self.bus.publish(PerceptionEvent("voice.transcript", "voice", {"text": transcript}, timestamp=timestamp))
        decision = self.wake.process(transcript, timestamp)
        if decision.kind == "wake":
            self.bus.publish(PerceptionEvent("voice.wake", "voice", {"wake_word": "jarvis"}, timestamp=timestamp))
        elif decision.kind == "command":
            self.bus.publish(PerceptionEvent("voice.command", "voice", {"text": decision.text}, timestamp=timestamp))

    def _on_vision_status(self, status: str, detail: str) -> None:
        self.bus.publish(PerceptionEvent("sensor.vision", "vision", {"status": status, "detail": detail}))

    def _on_voice_status(self, status: str, detail: str) -> None:
        self.bus.publish(PerceptionEvent("sensor.voice", "voice", {"status": status, "detail": detail}))
