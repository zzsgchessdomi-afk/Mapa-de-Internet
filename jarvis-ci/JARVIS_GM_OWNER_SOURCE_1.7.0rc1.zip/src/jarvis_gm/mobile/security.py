from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol
import base64
import hashlib
import hmac
import json
import secrets
import time


class SecretVault(Protocol):
    def get(self, name: str) -> str | None: ...
    def set(self, name: str, value: str) -> None: ...
    def delete(self, name: str) -> None: ...


class MemorySecretVault:
    def __init__(self) -> None:
        self.values: dict[str, str] = {}

    def get(self, name: str) -> str | None:
        return self.values.get(name)

    def set(self, name: str, value: str) -> None:
        self.values[name] = value

    def delete(self, name: str) -> None:
        self.values.pop(name, None)


def new_shared_secret() -> str:
    return base64.urlsafe_b64encode(secrets.token_bytes(32)).decode("ascii").rstrip("=")


def secret_fingerprint(secret: str) -> str:
    digest = hashlib.sha256(secret.encode("utf-8")).hexdigest().upper()
    return ":".join(digest[i:i+4] for i in range(0, 24, 4))


def canonical_bytes(payload: dict) -> bytes:
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":"), sort_keys=True).encode("utf-8")


def sign_payload(secret: str, payload: dict) -> str:
    return hmac.new(secret.encode("utf-8"), canonical_bytes(payload), hashlib.sha256).hexdigest()


def verify_signature(secret: str, payload: dict, signature: str) -> bool:
    expected = sign_payload(secret, payload)
    return hmac.compare_digest(expected, signature or "")


@dataclass(slots=True)
class ReplayGuard:
    max_skew_seconds: float = 180.0
    _seen: dict[str, float] = field(default_factory=dict, init=False, repr=False)

    def check(self, nonce: str, timestamp: float, *, now: float | None = None) -> None:
        now = time.time() if now is None else float(now)
        if not nonce or len(nonce) < 12:
            raise PermissionError("Invalid mobile nonce")
        if abs(now - float(timestamp)) > self.max_skew_seconds:
            raise PermissionError("Mobile request outside allowed time window")
        cutoff = now - self.max_skew_seconds * 2
        self._seen = {k: v for k, v in self._seen.items() if v >= cutoff}
        if nonce in self._seen:
            raise PermissionError("Replay detected")
        self._seen[nonce] = now

class CredentialSecretVault:
    """Use the OS credential store when available, otherwise keep secrets session-only.

    Session fallback is deliberate: JARVIS never writes pairing secrets to plain JSON.
    The UI can report ``persistent`` so the owner knows whether re-pairing will be
    required after restart.
    """
    def __init__(self, credential_store) -> None:
        self.store = credential_store
        self.session: dict[str, str] = {}

    @property
    def persistent(self) -> bool:
        return bool(getattr(self.store, "available", False))

    def get(self, name: str) -> str | None:
        value = self.store.get(name)
        return value if value else self.session.get(name)

    def set(self, name: str, value: str) -> None:
        try:
            self.store.set(name, value)
            self.session.pop(name, None)
        except Exception:
            self.session[name] = value

    def delete(self, name: str) -> None:
        self.session.pop(name, None)
        try: self.store.delete(name)
        except Exception: pass

def sign_text(secret: str, message: str) -> str:
    return hmac.new(secret.encode("utf-8"), message.encode("utf-8"), hashlib.sha256).hexdigest()


def verify_text_signature(secret: str, message: str, signature: str) -> bool:
    return hmac.compare_digest(sign_text(secret, message), signature or "")


def request_auth_message(method: str, path: str, device_id: str, timestamp_ms: int, nonce: str, body: bytes) -> str:
    body_hash = hashlib.sha256(body).hexdigest()
    return "\n".join(("JARVIS-REQ-1", method.upper(), path, device_id, str(int(timestamp_ms)), nonce, body_hash))


def command_auth_message(command_id: str, device_id: str, kind: str, expires_at_ms: int, payload: dict) -> str:
    payload_hash = hashlib.sha256(canonical_bytes(payload)).hexdigest()
    return "\n".join(("JARVIS-CMD-1", command_id, device_id, kind, str(int(expires_at_ms)), payload_hash))
