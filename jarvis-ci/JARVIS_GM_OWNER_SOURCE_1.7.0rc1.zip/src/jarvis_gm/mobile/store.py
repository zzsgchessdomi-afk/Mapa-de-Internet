from __future__ import annotations

from pathlib import Path
import json
from ..core.sqlite import sqlite_session
import time
from typing import Iterable

from .models import MobileCommand, MobileCommandKind, MobileCommandState, MobileDevice, MobileHeartbeat
from .security import SecretVault, new_shared_secret, secret_fingerprint


class MobileDeviceStore:
    def __init__(self, path: Path, vault: SecretVault) -> None:
        self.path = Path(path)
        self.vault = vault
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self._write([])

    def _read(self) -> list[MobileDevice]:
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            if not isinstance(raw, list):
                raise ValueError("mobile devices registry must be a list")
            return [MobileDevice.from_dict(x) for x in raw if isinstance(x, dict)]
        except (OSError, json.JSONDecodeError, TypeError, ValueError):
            return []

    def _write(self, devices: Iterable[MobileDevice]) -> None:
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps([x.as_dict() for x in devices], ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")
        tmp.replace(self.path)

    @staticmethod
    def _secret_key(device_id: str) -> str:
        return f"MOBILE_SHARED_SECRET_{device_id}"

    def pair(self, name: str, *, device_id: str, relay_url: str | None = None, cert_fingerprint: str | None = None,
             secret: str | None = None, capabilities: tuple[str, ...] = ()) -> tuple[MobileDevice, str]:
        device_id = device_id.strip()
        if not device_id or any(ch not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_." for ch in device_id):
            raise ValueError("Invalid device id")
        if self.get(device_id):
            raise ValueError("Device already paired")
        secret = secret or new_shared_secret()
        self.vault.set(self._secret_key(device_id), secret)
        device = MobileDevice(device_id, name.strip() or device_id, relay_url=relay_url,
                              cert_fingerprint=cert_fingerprint, capabilities=tuple(capabilities))
        devices = self._read(); devices.append(device); self._write(devices)
        return device, secret

    def list(self) -> list[MobileDevice]:
        return self._read()

    def get(self, device_id: str) -> MobileDevice | None:
        return next((x for x in self._read() if x.id == device_id), None)

    def secret(self, device_id: str) -> str | None:
        return self.vault.get(self._secret_key(device_id))

    def forget(self, device_id: str) -> bool:
        devices = self._read(); kept = [x for x in devices if x.id != device_id]
        if len(kept) == len(devices):
            return False
        self._write(kept); self.vault.delete(self._secret_key(device_id)); return True

    def touch(self, device_id: str, timestamp: float | None = None) -> None:
        devices = self._read(); changed = False
        for device in devices:
            if device.id == device_id:
                device.last_seen = float(timestamp or time.time()); changed = True
        if changed: self._write(devices)

    def pairing_bundle(self, device_id: str) -> dict:
        device = self.get(device_id); secret = self.secret(device_id)
        if device is None or not secret:
            raise KeyError(device_id)
        return {
            "format": 1,
            "device_id": device.id,
            "device_name": device.name,
            "relay_url": device.relay_url,
            "relay_cert_sha256": device.cert_fingerprint,
            "shared_secret": secret,
            "secret_fingerprint": secret_fingerprint(secret),
        }


class MobileCommandStore:
    def __init__(self, path: Path) -> None:
        self.path = Path(path); self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as con:
            con.executescript("""
            CREATE TABLE IF NOT EXISTS commands(
              id TEXT PRIMARY KEY, device_id TEXT NOT NULL, kind TEXT NOT NULL, payload_json TEXT NOT NULL,
              created_at REAL NOT NULL, expires_at REAL NOT NULL, state TEXT NOT NULL,
              delivered_at REAL, completed_at REAL, result_json TEXT, error TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_mobile_commands_device_state ON commands(device_id,state,created_at);
            CREATE TABLE IF NOT EXISTS heartbeats(
              id INTEGER PRIMARY KEY AUTOINCREMENT, device_id TEXT NOT NULL, timestamp REAL NOT NULL,
              payload_json TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_mobile_heartbeat_device_time ON heartbeats(device_id,timestamp DESC);
            """)

    def _connect(self):
        return sqlite_session(self.path, row_factory=False)

    def enqueue(self, command: MobileCommand) -> MobileCommand:
        with self._connect() as con:
            con.execute("INSERT INTO commands VALUES(?,?,?,?,?,?,?,?,?,?,?)", (
                command.id, command.device_id, command.kind.value, json.dumps(command.payload, ensure_ascii=False, sort_keys=True),
                command.created_at, command.expires_at, command.state.value, command.delivered_at, command.completed_at,
                None if command.result is None else json.dumps(command.result, ensure_ascii=False, sort_keys=True), command.error,
            ))
        return command

    @staticmethod
    def _row_to_command(row) -> MobileCommand:
        return MobileCommand(
            id=row[0], device_id=row[1], kind=MobileCommandKind(row[2]), payload=json.loads(row[3]),
            created_at=row[4], expires_at=row[5], state=MobileCommandState(row[6]), delivered_at=row[7], completed_at=row[8],
            result=None if row[9] is None else json.loads(row[9]), error=row[10],
        )

    def get(self, command_id: str) -> MobileCommand | None:
        with self._connect() as con:
            row = con.execute("SELECT * FROM commands WHERE id=?", (command_id,)).fetchone()
        return self._row_to_command(row) if row else None

    def next_for_device(self, device_id: str, *, now: float | None = None, retry_after: float = 30.0) -> MobileCommand | None:
        """Deliver each command at most once.

        A lost phone response leaves the command DELIVERED rather than silently
        executing it a second time. The owner can issue a fresh command if needed.
        This is deliberately safer for lock/ring/auth/message actions than automatic
        redelivery. ``retry_after`` remains in the signature for compatibility but
        is intentionally ignored.
        """
        now = float(now or time.time())
        with self._connect() as con:
            con.execute("UPDATE commands SET state=? WHERE device_id=? AND state IN (?,?) AND expires_at<?",
                        (MobileCommandState.EXPIRED.value, device_id, MobileCommandState.QUEUED.value, MobileCommandState.DELIVERED.value, now))
            row = con.execute(
                "SELECT * FROM commands WHERE device_id=? AND expires_at>=? AND state=? ORDER BY created_at LIMIT 1",
                (device_id, now, MobileCommandState.QUEUED.value)
            ).fetchone()
            if not row: return None
            delivered = time.time()
            con.execute("UPDATE commands SET state=?, delivered_at=? WHERE id=?",
                        (MobileCommandState.DELIVERED.value, delivered, row[0]))
        cmd = self._row_to_command(row); cmd.state = MobileCommandState.DELIVERED; cmd.delivered_at = delivered; return cmd

    def complete(self, command_id: str, *, ok: bool, result: dict | None = None, error: str | None = None) -> MobileCommand:
        """Finalize only a command that was actually delivered, exactly once."""
        with self._connect() as con:
            row = con.execute("SELECT * FROM commands WHERE id=?", (command_id,)).fetchone()
            if row is None: raise KeyError(command_id)
            current = self._row_to_command(row)
            if current.state in (MobileCommandState.VERIFIED, MobileCommandState.FAILED, MobileCommandState.EXPIRED):
                return current
            if current.state != MobileCommandState.DELIVERED:
                raise ValueError("Mobile command response received before delivery")
            state = MobileCommandState.VERIFIED if ok else MobileCommandState.FAILED
            con.execute("UPDATE commands SET state=?, completed_at=?, result_json=?, error=? WHERE id=?", (
                state.value, time.time(), None if result is None else json.dumps(result, ensure_ascii=False, sort_keys=True), error, command_id
            ))
        cmd = self.get(command_id)
        if cmd is None: raise KeyError(command_id)
        return cmd

    def list(self, device_id: str | None = None, limit: int = 100) -> list[MobileCommand]:
        with self._connect() as con:
            if device_id:
                rows = con.execute("SELECT * FROM commands WHERE device_id=? ORDER BY created_at DESC LIMIT ?", (device_id, limit)).fetchall()
            else:
                rows = con.execute("SELECT * FROM commands ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()
        return [self._row_to_command(x) for x in rows]

    def record_heartbeat(self, heartbeat: MobileHeartbeat) -> None:
        with self._connect() as con:
            con.execute("INSERT INTO heartbeats(device_id,timestamp,payload_json) VALUES(?,?,?)",
                        (heartbeat.device_id, heartbeat.timestamp, json.dumps(heartbeat.as_dict(), ensure_ascii=False, sort_keys=True)))
            con.execute("DELETE FROM heartbeats WHERE id IN (SELECT id FROM heartbeats WHERE device_id=? ORDER BY timestamp DESC LIMIT -1 OFFSET 500)",
                        (heartbeat.device_id,))

    def latest_heartbeat(self, device_id: str) -> MobileHeartbeat | None:
        with self._connect() as con:
            row = con.execute("SELECT payload_json FROM heartbeats WHERE device_id=? ORDER BY timestamp DESC LIMIT 1", (device_id,)).fetchone()
        return MobileHeartbeat(**json.loads(row[0])) if row else None
