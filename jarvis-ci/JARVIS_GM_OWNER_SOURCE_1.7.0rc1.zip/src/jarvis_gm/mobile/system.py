from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import socket

from .manager import MobileManager
from .relay import MobileRelayServer, ensure_tls_identity, tls_fingerprint
from .security import CredentialSecretVault, secret_fingerprint


@dataclass(slots=True)
class MobileSubsystem:
    root: Path
    manager: MobileManager
    vault: CredentialSecretVault
    relay: MobileRelayServer | None = None
    relay_cert_fingerprint: str | None = None

    @classmethod
    def create(cls, data_dir: Path, credential_store) -> "MobileSubsystem":
        root = Path(data_dir) / "mobile"
        root.mkdir(parents=True, exist_ok=True)
        vault = CredentialSecretVault(credential_store)
        manager = MobileManager.create(Path(data_dir), vault)
        return cls(root, manager, vault)

    @property
    def relay_running(self) -> bool:
        return bool(self.relay and self.relay.running)

    def start_relay(self, host: str = "0.0.0.0", port: int = 8765) -> dict:
        if self.relay and self.relay.running:
            addr = self.relay._server.server_address if self.relay._server else (host, port)
            return {"running": True, "host": addr[0], "port": addr[1], "cert_sha256": self.relay_cert_fingerprint,
                    "secret_persistence": "os_credential_store" if self.vault.persistent else "session_only"}
        cert, key, fp = ensure_tls_identity(self.root / "relay_identity")
        relay = MobileRelayServer(self.manager.devices, self.manager.commands, cert, key, host=host, port=int(port))
        address = relay.start(); self.relay = relay; self.relay_cert_fingerprint = fp
        return {"running": True, "host": address[0], "port": address[1], "cert_sha256": fp,
                "secret_persistence": "os_credential_store" if self.vault.persistent else "session_only"}

    def stop_relay(self) -> None:
        if self.relay: self.relay.stop()

    def suggest_relay_url(self, port: int = 8765) -> str:
        # A loopback address is useless to a separate Android device (it would
        # point back to the phone). Prefer a real LAN IPv4 and fail explicitly
        # rather than presenting localhost/127.0.0.1 as if it were reachable.
        candidates=[]
        try:
            for item in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET, socket.SOCK_STREAM):
                candidates.append(item[4][0])
        except OSError:
            pass
        try:
            sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
            try:
                sock.connect(("8.8.8.8",80)); candidates.insert(0,sock.getsockname()[0])
            finally: sock.close()
        except OSError:
            pass
        for host in candidates:
            if host and not host.startswith("127.") and host!="0.0.0.0":
                return f"https://{host}:{int(port)}"
        raise RuntimeError("JARVIS could not determine a LAN address reachable by Android. Connect PC and phone to a reachable network/VPN, then retry pairing.")

    def pair_device(self, name: str, device_id: str, relay_url: str | None = None) -> dict:
        if not self.relay_cert_fingerprint:
            cert = self.root / "relay_identity" / "relay_cert.pem"
            if cert.exists(): self.relay_cert_fingerprint = tls_fingerprint(cert)
        if not self.relay_cert_fingerprint:
            raise RuntimeError("Start the mobile relay before pairing so Android can pin its TLS certificate")
        relay_url = (relay_url or self.suggest_relay_url()).rstrip("/")
        device, secret = self.manager.devices.pair(name, device_id=device_id, relay_url=relay_url,
                                                   cert_fingerprint=self.relay_cert_fingerprint)
        bundle = self.manager.devices.pairing_bundle(device.id)
        bundle["pairing_uri"] = self.pairing_uri(bundle)
        bundle["secret_persistence"] = "os_credential_store" if self.vault.persistent else "session_only"
        return bundle

    @staticmethod
    def pairing_uri(bundle: dict) -> str:
        import base64, json
        raw = json.dumps({k:v for k,v in bundle.items() if k != "pairing_uri"}, separators=(",", ":"), sort_keys=True).encode()
        token = base64.urlsafe_b64encode(raw).decode().rstrip("=")
        return "jarvisgm://pair/" + token

    def summary(self) -> dict:
        return {
            "devices": [x.as_dict() for x in self.manager.devices.list()],
            "relay_running": self.relay_running,
            "relay_cert_sha256": self.relay_cert_fingerprint,
            "secret_persistence": "os_credential_store" if self.vault.persistent else "session_only",
        }
