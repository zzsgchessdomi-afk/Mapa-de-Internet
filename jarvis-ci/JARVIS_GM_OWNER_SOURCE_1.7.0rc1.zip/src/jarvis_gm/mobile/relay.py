from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from threading import Thread
from urllib.parse import urlparse, parse_qs
import hashlib
import json
import os
import ssl
import time

from .models import MobileHeartbeat
from .security import ReplayGuard, sign_text, verify_text_signature, request_auth_message, command_auth_message
from .store import MobileDeviceStore, MobileCommandStore


def tls_fingerprint(cert_path: Path) -> str:
    import ssl as _ssl
    der = _ssl.PEM_cert_to_DER_cert(Path(cert_path).read_text(encoding="utf-8"))
    digest = hashlib.sha256(der).hexdigest().upper()
    return ":".join(digest[i:i+2] for i in range(0, len(digest), 2))


def ensure_tls_identity(root: Path) -> tuple[Path, Path, str]:
    """Create a local self-signed relay identity.

    The Android companion pins the SHA-256 certificate fingerprint from the
    pairing bundle, so the certificate does not need a public CA for owner-run
    LAN/private-network operation.
    """
    root = Path(root); root.mkdir(parents=True, exist_ok=True)
    cert_path = root / "relay_cert.pem"; key_path = root / "relay_key.pem"
    if cert_path.exists() and key_path.exists():
        return cert_path, key_path, tls_fingerprint(cert_path)
    try:
        from cryptography import x509
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import ec
        from cryptography.x509.oid import NameOID
    except Exception as exc:  # pragma: no cover - platform dependency
        raise RuntimeError("Mobile relay TLS requires the 'cryptography' package") from exc
    key = ec.generate_private_key(ec.SECP256R1())
    subject = issuer = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "JARVIS GM Mobile Relay")])
    now = datetime.now(timezone.utc)
    cert = (
        x509.CertificateBuilder().subject_name(subject).issuer_name(issuer).public_key(key.public_key())
        .serial_number(x509.random_serial_number()).not_valid_before(now - timedelta(minutes=5))
        .not_valid_after(now + timedelta(days=3650))
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .sign(key, hashes.SHA256())
    )
    key_path.write_bytes(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
    cert_path.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
    try:
        os.chmod(key_path, 0o600); os.chmod(cert_path, 0o644)
    except OSError:
        pass
    return cert_path, key_path, tls_fingerprint(cert_path)


def _heartbeat_from_payload(device_id: str, data: dict) -> MobileHeartbeat:
    """Create trusted telemetry using server receive time and bounded fields.

    The paired phone authenticates the request, but the relay still treats payload
    fields as untrusted data. In particular, phone wall-clock time is not allowed
    to poison heartbeat ordering with a far-future timestamp.
    """
    def _num(name: str):
        value = data.get(name)
        if value is None: return None
        if isinstance(value, bool): raise ValueError(f"Invalid {name}")
        return float(value)

    lat = _num("latitude"); lon = _num("longitude"); accuracy = _num("accuracy_m")
    if (lat is None) != (lon is None):
        lat = lon = accuracy = None
    if lat is not None and not (-90.0 <= lat <= 90.0): raise ValueError("Invalid latitude")
    if lon is not None and not (-180.0 <= lon <= 180.0): raise ValueError("Invalid longitude")
    if accuracy is not None and not (0.0 <= accuracy <= 100000.0): raise ValueError("Invalid location accuracy")
    battery = data.get("battery_percent")
    if battery is not None:
        if isinstance(battery, bool): raise ValueError("Invalid battery percent")
        battery = int(battery)
        if not 0 <= battery <= 100: raise ValueError("Invalid battery percent")
    network = data.get("network")
    network = None if network is None else str(network)[:64]
    charging = data.get("charging") if isinstance(data.get("charging"), bool) else None
    locked = data.get("device_locked") if isinstance(data.get("device_locked"), bool) else None
    return MobileHeartbeat(
        device_id=device_id, timestamp=time.time(), battery_percent=battery, charging=charging,
        network=network, latitude=lat, longitude=lon, accuracy_m=accuracy,
        anti_theft_enabled=bool(data.get("anti_theft_enabled", False)), device_locked=locked,
    )


@dataclass(slots=True)
class MobileRelayServer:
    devices: MobileDeviceStore
    commands: MobileCommandStore
    cert_path: Path
    key_path: Path
    host: str = "0.0.0.0"
    port: int = 8765
    _server: ThreadingHTTPServer | None = field(default=None, init=False, repr=False)
    _thread: Thread | None = field(default=None, init=False, repr=False)
    _guards: dict[str, ReplayGuard] = field(default_factory=dict, init=False, repr=False)

    def __post_init__(self) -> None:
        self.cert_path = Path(self.cert_path); self.key_path = Path(self.key_path)

    def _secret(self, device_id: str) -> str:
        device = self.devices.get(device_id)
        secret = self.devices.secret(device_id)
        if device is None or not device.enabled or not secret:
            raise PermissionError("Unpaired or disabled device")
        return secret

    def _authenticate(self, handler: BaseHTTPRequestHandler, body: bytes) -> str:
        device_id = (handler.headers.get("X-Jarvis-Device") or "").strip()
        nonce = (handler.headers.get("X-Jarvis-Nonce") or "").strip()
        signature = (handler.headers.get("X-Jarvis-Signature") or "").strip()
        try: timestamp_ms = int(handler.headers.get("X-Jarvis-Timestamp") or "0")
        except ValueError as exc: raise PermissionError("Invalid timestamp") from exc
        secret = self._secret(device_id)
        path = urlparse(handler.path).path
        message = request_auth_message(handler.command, path, device_id, timestamp_ms, nonce, body)
        if not verify_text_signature(secret, message, signature):
            raise PermissionError("Invalid mobile signature")
        guard = self._guards.setdefault(device_id, ReplayGuard())
        guard.check(nonce, timestamp_ms / 1000.0)
        self.devices.touch(device_id)
        return device_id

    def handler_class(self):
        relay = self
        class Handler(BaseHTTPRequestHandler):
            server_version = "JarvisMobileRelay/1"
            def log_message(self, format, *args):
                return
            def _json(self, code: int, payload: dict | None = None):
                data = b"" if payload is None else json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
                self.send_response(code)
                if data:
                    self.send_header("Content-Type", "application/json; charset=utf-8")
                    self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                if data: self.wfile.write(data)
            def _body(self) -> bytes:
                length = int(self.headers.get("Content-Length") or "0")
                if length < 0 or length > 1024 * 1024: raise ValueError("Invalid request size")
                return self.rfile.read(length) if length else b""
            def do_GET(self):
                try:
                    if urlparse(self.path).path == "/v1/ping":
                        return self._json(200, {"product":"JARVIS GM","relay":"ok","time":time.time()})
                    body=b""; device_id=relay._authenticate(self,body)
                    if urlparse(self.path).path != "/v1/poll": return self._json(404,{"error":"not_found"})
                    q=parse_qs(urlparse(self.path).query)
                    if q.get("device_id",[device_id])[0] != device_id: raise PermissionError("Device mismatch")
                    cmd=relay.commands.next_for_device(device_id)
                    if cmd is None: return self._json(204)
                    expires_at_ms=int(cmd.expires_at*1000)
                    payload={"id":cmd.id,"device_id":cmd.device_id,"kind":cmd.kind.value,"payload":cmd.payload,"expires_at_ms":expires_at_ms}
                    message=command_auth_message(cmd.id,cmd.device_id,cmd.kind.value,expires_at_ms,cmd.payload)
                    payload["signature"]=sign_text(relay._secret(device_id),message)
                    return self._json(200,payload)
                except PermissionError as exc: return self._json(401,{"error":str(exc)})
                except Exception as exc: return self._json(400,{"error":str(exc)})
            def do_POST(self):
                try:
                    body=self._body(); device_id=relay._authenticate(self,body)
                    data=json.loads(body.decode("utf-8") or "{}")
                    path=urlparse(self.path).path
                    if path == "/v1/heartbeat":
                        if data.get("device_id") != device_id: raise PermissionError("Device mismatch")
                        hb=_heartbeat_from_payload(device_id,data); relay.commands.record_heartbeat(hb); relay.devices.touch(device_id,hb.timestamp)
                        return self._json(200,{"ok":True})
                    if path == "/v1/response":
                        if data.get("device_id") != device_id: raise PermissionError("Device mismatch")
                        command_id=str(data.get("command_id") or "")
                        cmd=relay.commands.get(command_id)
                        if cmd is None or cmd.device_id != device_id: raise PermissionError("Unknown command")
                        completed=relay.commands.complete(command_id,ok=bool(data.get("ok")),result=data.get("result") if isinstance(data.get("result"),dict) else None,error=str(data.get("error")) if data.get("error") else None)
                        return self._json(200,{"ok":True,"state":completed.state.value})
                    return self._json(404,{"error":"not_found"})
                except PermissionError as exc: return self._json(401,{"error":str(exc)})
                except (ValueError,json.JSONDecodeError,TypeError) as exc: return self._json(400,{"error":str(exc)})
                except Exception as exc: return self._json(500,{"error":str(exc)})
        return Handler

    @property
    def running(self) -> bool:
        return self._server is not None

    def start(self) -> tuple[str, int]:
        if self._server is not None:
            return self._server.server_address[0], self._server.server_address[1]
        server=ThreadingHTTPServer((self.host,int(self.port)),self.handler_class())
        context=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER); context.load_cert_chain(str(self.cert_path),str(self.key_path))
        server.socket=context.wrap_socket(server.socket,server_side=True)
        self._server=server
        self._thread=Thread(target=server.serve_forever,name="jarvis-mobile-relay",daemon=True);self._thread.start()
        return server.server_address[0],server.server_address[1]

    def stop(self) -> None:
        server=self._server; thread=self._thread; self._server=None;self._thread=None
        if server is not None:
            server.shutdown();server.server_close()
        if thread is not None and thread.is_alive(): thread.join(timeout=2.0)
