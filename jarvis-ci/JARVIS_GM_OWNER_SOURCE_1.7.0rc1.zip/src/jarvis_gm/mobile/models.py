from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any
import time
import uuid


class MobileCommandKind(str, Enum):
    STATUS = "status"
    LOCATION_NOW = "location.now"
    RING = "device.ring"
    LOCK = "device.lock"
    REQUEST_AUTH = "device.request_auth"
    OPEN_URL = "app.open_url"
    OPEN_APP = "app.open"
    COMPOSE_MESSAGE = "message.compose"
    CONTACT_SEARCH = "contacts.search"


class MobileCommandState(str, Enum):
    QUEUED = "queued"
    DELIVERED = "delivered"
    VERIFIED = "verified"
    FAILED = "failed"
    EXPIRED = "expired"


@dataclass(slots=True)
class MobileDevice:
    id: str
    name: str
    platform: str = "android"
    paired_at: float = field(default_factory=time.time)
    last_seen: float | None = None
    cert_fingerprint: str | None = None
    relay_url: str | None = None
    capabilities: tuple[str, ...] = ()
    enabled: bool = True

    def as_dict(self) -> dict[str, Any]:
        out = asdict(self)
        out["capabilities"] = list(self.capabilities)
        return out

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "MobileDevice":
        payload = dict(data)
        payload["capabilities"] = tuple(str(x) for x in payload.get("capabilities") or ())
        return cls(**payload)


@dataclass(slots=True)
class MobileCommand:
    device_id: str
    kind: MobileCommandKind
    payload: dict[str, Any] = field(default_factory=dict)
    id: str = field(default_factory=lambda: uuid.uuid4().hex)
    created_at: float = field(default_factory=time.time)
    expires_at: float = field(default_factory=lambda: time.time() + 120.0)
    state: MobileCommandState = MobileCommandState.QUEUED
    delivered_at: float | None = None
    completed_at: float | None = None
    result: dict[str, Any] | None = None
    error: str | None = None

    def as_dict(self) -> dict[str, Any]:
        out = asdict(self)
        out["kind"] = self.kind.value
        out["state"] = self.state.value
        return out

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "MobileCommand":
        payload = dict(data)
        payload["kind"] = MobileCommandKind(payload["kind"])
        payload["state"] = MobileCommandState(payload.get("state", MobileCommandState.QUEUED.value))
        return cls(**payload)


@dataclass(slots=True)
class MobileHeartbeat:
    device_id: str
    timestamp: float
    battery_percent: int | None = None
    charging: bool | None = None
    network: str | None = None
    latitude: float | None = None
    longitude: float | None = None
    accuracy_m: float | None = None
    anti_theft_enabled: bool = False
    device_locked: bool | None = None

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)
