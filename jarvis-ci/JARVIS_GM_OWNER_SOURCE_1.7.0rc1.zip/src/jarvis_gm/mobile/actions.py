from __future__ import annotations

from typing import Any
from urllib.parse import urlparse

from jarvis_gm.actions.base import Action
from .manager import MobileManager
from .models import MobileCommandKind


def _valid_url(url: str) -> bool:
    p = urlparse(url)
    return p.scheme in {"https", "http"} and bool(p.netloc)


class ListMobileDevicesAction(Action):
    name = "mobile_devices"; capability = "mobile.read"
    def __init__(self, manager: MobileManager) -> None: self.manager = manager
    def run(self, **kwargs: Any): return [x.as_dict() for x in self.manager.devices.list()]


class MobileStatusAction(Action):
    name = "mobile_status"; capability = "mobile.read"
    def __init__(self, manager: MobileManager) -> None: self.manager = manager
    def run(self, device_id: str | None = None, **kwargs: Any): return self.manager.status(device_id)


class MobileLastLocationAction(Action):
    name = "mobile_last_location"; capability = "mobile.location"
    def __init__(self, manager: MobileManager) -> None: self.manager = manager
    def run(self, device_id: str | None = None, **kwargs: Any): return self.manager.last_location(device_id)
    def verify(self, output: Any, **kwargs: Any):
        return bool(output.get("available")), "Last owner-authorized device location available" if output.get("available") else "No location heartbeat available"


class MobileRequestLocationAction(Action):
    name = "mobile_request_location"; capability = "mobile.location"
    def __init__(self, manager: MobileManager) -> None: self.manager = manager
    def run(self, device_id: str | None = None, **kwargs: Any): return self.manager.dispatch(self.manager.resolve_device_id(device_id), MobileCommandKind.LOCATION_NOW, ttl_seconds=300)
    def verify(self, output: Any, **kwargs: Any): return output.get("state") == "verified", "Phone confirmed a fresh location" if output.get("state")=="verified" else f"Location request not confirmed by phone (state={output.get('state')})"


class MobileRingAction(Action):
    name = "mobile_ring"; capability = "mobile.control"
    def __init__(self, manager: MobileManager) -> None: self.manager = manager
    def run(self, device_id: str | None = None, seconds: int = 20, **kwargs: Any):
        return self.manager.dispatch(self.manager.resolve_device_id(device_id), MobileCommandKind.RING, {"seconds": max(1, min(int(seconds), 120))}, ttl_seconds=300)


class MobileLockAction(Action):
    name = "mobile_lock"; capability = "mobile.security"
    def __init__(self, manager: MobileManager) -> None: self.manager = manager
    def run(self, device_id: str | None = None, **kwargs: Any): return self.manager.dispatch(self.manager.resolve_device_id(device_id), MobileCommandKind.LOCK, ttl_seconds=300)


class MobileRequestAuthAction(Action):
    """Ask Android to present system-owned authentication UI.

    It deliberately does not accept or transport a PIN/password. Android remains
    the authority that verifies the lock-screen credential.
    """
    name = "mobile_request_auth"; capability = "mobile.security"
    def __init__(self, manager: MobileManager) -> None: self.manager = manager
    def run(self, device_id: str | None = None, **kwargs: Any): return self.manager.dispatch(self.manager.resolve_device_id(device_id), MobileCommandKind.REQUEST_AUTH, ttl_seconds=60)


class MobileOpenUrlAction(Action):
    name = "mobile_open_url"; capability = "mobile.control"
    def __init__(self, manager: MobileManager) -> None: self.manager = manager
    def run(self, device_id: str | None = None, url: str = "", **kwargs: Any):
        if not _valid_url(url): raise ValueError("Only http/https URLs are allowed")
        return self.manager.dispatch(self.manager.resolve_device_id(device_id), MobileCommandKind.OPEN_URL, {"url": url})


class MobileOpenAppAction(Action):
    name = "mobile_open_app"; capability = "mobile.control"
    def __init__(self, manager: MobileManager) -> None: self.manager = manager
    def run(self, device_id: str | None = None, package: str = "", **kwargs: Any):
        package = package.strip()
        if not package or len(package) > 180 or any(ch not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._" for ch in package):
            raise ValueError("Invalid Android package name")
        return self.manager.dispatch(self.manager.resolve_device_id(device_id), MobileCommandKind.OPEN_APP, {"package": package})


class MobileComposeMessageAction(Action):
    """Prepare an outbound message in an installed app.

    For personal WhatsApp this intentionally stops at compose/open. The supported
    Android surface does not provide JARVIS with a general silent-send authority.
    """
    name = "mobile_compose_message"; capability = "mobile.messaging"
    def __init__(self, manager: MobileManager) -> None: self.manager = manager
    def run(self, device_id: str | None = None, channel: str = "whatsapp", recipient: str = "", text: str = "", **kwargs: Any):
        channel = channel.strip().lower()
        if channel not in {"whatsapp", "sms", "share"}: raise ValueError("Unsupported message channel")
        if not recipient.strip(): raise ValueError("Recipient is required")
        if not text.strip(): raise ValueError("Message text is required")
        return self.manager.dispatch(self.manager.resolve_device_id(device_id), MobileCommandKind.COMPOSE_MESSAGE,
                                  {"channel": channel, "recipient": recipient.strip(), "text": text}, ttl_seconds=120)



class MobileFindContactAction(Action):
    name = "mobile_find_contact"; capability = "mobile.contacts"
    def __init__(self, manager: MobileManager) -> None: self.manager = manager
    def run(self, device_id: str | None = None, query: str = "", **kwargs: Any):
        query = query.strip()
        if not query: raise ValueError("Contact query is required")
        return self.manager.dispatch(self.manager.resolve_device_id(device_id), MobileCommandKind.CONTACT_SEARCH, {"query": query}, ttl_seconds=90)
    def verify(self, output: Any, **kwargs: Any):
        return _mobile_command_verify(output)

def _mobile_command_verify(output: Any) -> tuple[bool, str]:
    state = output.get("state") if isinstance(output, dict) else None
    if state == "verified": return True, "Paired phone executed and confirmed the command"
    if state == "failed": return False, f"Phone rejected/failed the command: {output.get('error') or 'unknown error'}"
    if state == "expired": return False, "Mobile command expired before confirmation"
    return False, f"Mobile command has not been confirmed by the phone (state={state})"

for _cls in (MobileRingAction, MobileLockAction, MobileRequestAuthAction, MobileOpenUrlAction, MobileOpenAppAction, MobileComposeMessageAction):
    _cls.verify = lambda self, output, **kwargs: _mobile_command_verify(output)
