from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any
import time

from .models import MobileCommand, MobileCommandKind
from .store import MobileDeviceStore, MobileCommandStore
from .security import SecretVault


@dataclass(slots=True)
class MobileManager:
    devices: MobileDeviceStore
    commands: MobileCommandStore

    @classmethod
    def create(cls, root: Path, vault: SecretVault) -> "MobileManager":
        root = Path(root); mobile_dir = root / "mobile"; mobile_dir.mkdir(parents=True, exist_ok=True)
        return cls(MobileDeviceStore(mobile_dir / "devices.json", vault), MobileCommandStore(mobile_dir / "mobile.sqlite3"))

    def resolve_device_id(self, device_id: str | None = None) -> str:
        if device_id and str(device_id).strip():
            candidate = str(device_id).strip()
            device = self.devices.get(candidate)
            if device is None or not device.enabled:
                raise ValueError("Mobile device is not paired/enabled")
            return candidate
        enabled = [x for x in self.devices.list() if x.enabled]
        if len(enabled) == 1:
            return enabled[0].id
        if not enabled:
            raise ValueError("No paired mobile device")
        raise ValueError("More than one mobile device is paired; specify which device")

    def queue(self, device_id: str, kind: MobileCommandKind, payload: dict[str, Any] | None = None,
              *, ttl_seconds: float = 120.0) -> MobileCommand:
        device_id = self.resolve_device_id(device_id)
        device = self.devices.get(device_id)
        now = time.time()
        return self.commands.enqueue(MobileCommand(device_id=device_id, kind=kind, payload=dict(payload or {}),
                                                   created_at=now, expires_at=now + max(5.0, float(ttl_seconds))))


    def wait_for(self, command_id: str, timeout: float = 8.0, poll_seconds: float = 0.1) -> dict[str, Any]:
        deadline = time.time() + max(0.0, float(timeout))
        while True:
            cmd = self.commands.get(command_id)
            if cmd is None: raise KeyError(command_id)
            if cmd.state.value in {"verified", "failed", "expired"}:
                return cmd.as_dict()
            if time.time() >= deadline:
                return cmd.as_dict()
            time.sleep(max(0.02, float(poll_seconds)))

    def dispatch(self, device_id: str, kind: MobileCommandKind, payload: dict[str, Any] | None = None,
                 *, ttl_seconds: float = 120.0, wait_seconds: float = 8.0) -> dict[str, Any]:
        cmd = self.queue(device_id, kind, payload, ttl_seconds=ttl_seconds)
        return self.wait_for(cmd.id, timeout=wait_seconds)

    def status(self, device_id: str | None = None) -> dict[str, Any]:
        device_id = self.resolve_device_id(device_id)
        device = self.devices.get(device_id)
        if device is None: raise ValueError("Unknown mobile device")
        hb = self.commands.latest_heartbeat(device_id)
        return {"device": device.as_dict(), "heartbeat": hb.as_dict() if hb else None}

    def last_location(self, device_id: str | None = None) -> dict[str, Any]:
        device_id = self.resolve_device_id(device_id)
        hb = self.commands.latest_heartbeat(device_id)
        if hb is None or hb.latitude is None or hb.longitude is None:
            return {"available": False, "device_id": device_id}
        return {"available": True, "device_id": device_id, "latitude": hb.latitude, "longitude": hb.longitude,
                "accuracy_m": hb.accuracy_m, "timestamp": hb.timestamp, "anti_theft_enabled": hb.anti_theft_enabled}
