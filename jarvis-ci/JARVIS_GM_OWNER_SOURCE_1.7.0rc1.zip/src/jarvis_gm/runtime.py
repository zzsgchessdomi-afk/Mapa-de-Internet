from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import os

from jarvis_gm.actions.builtin import CreateNoteAction, ReadNoteAction, RememberAction, StatusAction
from jarvis_gm.actions.screen import GroundedClickAction, ScreenSnapshotAction
from jarvis_gm.actions.windows import (
    ScreenInfoAction, MoveCursorAction, MoveCursorNormalizedAction, MouseButtonAction, HotkeyAction,
    TypeTextAction, ListWindowsAction, FocusWindowAction, MoveWindowAction, ResizeWindowAction,
    MaximizeWindowAction, MinimizeWindowAction, OpenAppAction, OpenUrlAction, ListDirectoryAction,
    CreateFolderAction, CopyFileAction, MoveFileAction,
)
from jarvis_gm.control.config import AppRegistry, FileScope
from jarvis_gm.control.windows_backend import DesktopBackend, build_desktop_backend
from jarvis_gm.control.bridge import ActionGateway, PerceptionControlBridge
from jarvis_gm.core.executor import Executor
from jarvis_gm.core.kill_switch import KillSwitch
from jarvis_gm.core.memory import MemoryStore
from jarvis_gm.core.orchestrator import Orchestrator
from jarvis_gm.core.permissions import PermissionPolicy
from jarvis_gm.core.planner import Planner
from jarvis_gm.core.verifier import Verifier
from jarvis_gm.providers.registry import ProviderRegistry
from jarvis_gm.perception.hub import PerceptionHub
from jarvis_gm.perception.sentinel import PerceptionSentinel
from jarvis_gm.perception.fusion import FusionCore
from jarvis_gm.intent.context import ContextProvider
from jarvis_gm.intent.engine import IntentConfig, IntentEngine
from jarvis_gm.intent.bridge import IntentControlBridge
from jarvis_gm.screen.accessibility import NullAccessibilityScanner, PywinautoAccessibilityScanner
from jarvis_gm.screen.capture import NullScreenCapture, PillowScreenCapture
from jarvis_gm.screen.cloud_vision import GeminiScreenGrounder
from jarvis_gm.screen.grounding import GroundingEngine, TargetRegistry
from jarvis_gm.screen.observer import ScreenObserver
from jarvis_gm.memory.store import ContinuityStore
from jarvis_gm.memory.manager import MemoryManager
from jarvis_gm.memory.actions import (CreateProjectAction, ActivateProjectAction, ListProjectsAction, StructuredRememberAction, MemorySearchAction, CorrectMemoryAction, ForgetMemoryAction, AddTaskAction, CompleteTaskAction, RecordDecisionAction, ResumeContextAction)
from jarvis_gm.skills.store import SkillStore
from jarvis_gm.skills.lab import SkillLab
from jarvis_gm.skills.runner import SkillRunner
from jarvis_gm.skills.forge import SkillForge
from jarvis_gm.skills.actions import ListSkillsAction, LearnSkillAction, EnableSkillAction, RunSkillAction
from jarvis_gm.agents.director import AgentDirector
from jarvis_gm.agents.research import ResearchCorps
from jarvis_gm.agents.actions import RunMissionAction, DeepResearchAction
from jarvis_gm.product.backup import BackupManager, apply_pending_restore
from jarvis_gm.product.diagnostics import DiagnosticsRunner
from jarvis_gm.product.recovery import RecoveryManager, RecoveryState
from jarvis_gm.product.crashlog import CrashJournal
from jarvis_gm.product.secrets import CredentialStore
from jarvis_gm.product.settings import ProviderSettings
from jarvis_gm.product.instance_lock import InstanceLock
from jarvis_gm.product.health import HealthSupervisor
from jarvis_gm.product.acceptance import AcceptanceStore
from jarvis_gm.product.support import SupportBundleExporter
from jarvis_gm.product.release import ReleaseManager, ReleaseGate
from jarvis_gm.autonomy.engine import AutonomyEngine
from jarvis_gm.autonomy.store import MissionStore
from jarvis_gm.autonomy.actions import RunAutonomousMissionAction, ResumeAutonomousMissionAction, ListAutonomousMissionsAction
from jarvis_gm.mobile.system import MobileSubsystem
from jarvis_gm.mobile.actions import (ListMobileDevicesAction, MobileStatusAction, MobileLastLocationAction, MobileRequestLocationAction, MobileRingAction, MobileLockAction, MobileRequestAuthAction, MobileOpenUrlAction, MobileOpenAppAction, MobileComposeMessageAction, MobileFindContactAction)
from jarvis_gm.world.store import WorldModelStore
from jarvis_gm.world.manager import WorldModelManager
from jarvis_gm.world.actions import WorldStatusAction, WorldEntitiesAction
from jarvis_gm.guardian.store import GuardianStore
from jarvis_gm.guardian.engine import Guardian
from jarvis_gm.aios.store import ResourceStore
from jarvis_gm.aios.kernel import PersonalAIOS
from jarvis_gm.aios.actions import OSResourcesAction, OSResolveAction, OSPlanAction, OSExecuteAction, OSPinURLAction, OSPinFileAction, OSPinContactAction, OSHandoffsAction
from jarvis_gm.workbench.store import WorkbenchStore
from jarvis_gm.workbench.engine import AutonomousWorkbench
from jarvis_gm.workbench.actions import WorkbenchListAction, WorkbenchCreateAction, WorkbenchRunCycleAction, WorkbenchPauseAction, WorkbenchResumeAction, WorkbenchCancelAction
from jarvis_gm.swarm.store import SwarmStore
from jarvis_gm.swarm.engine import CognitiveSwarm
from jarvis_gm.swarm.actions import SwarmRunAction, SwarmListAction
from jarvis_gm.evolution.store import EvolutionStore
from jarvis_gm.evolution.engine import SelfEvolutionEngine
from jarvis_gm.evolution.actions import EvolutionListAction, EvolutionScanAction, EvolutionBenchmarkAction, EvolutionProposeAction, EvolutionPromoteAction, EvolutionRejectAction, EvolutionRollbackAction
from jarvis_gm.core.models import ActionRequest
from jarvis_gm.reality.store import RealityStore
from jarvis_gm.reality.engine import RealityBridge
from jarvis_gm.reality.actions import RealityListAction, RealityObserveAction, RealityCommandAction, RealityEnrollAction


def default_data_dir() -> Path:
    if os.name == "nt":
        base = Path(os.getenv("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
        return base / "JARVIS_GM"
    return Path.home() / ".jarvis_gm"


@dataclass(slots=True)
class Phase3Runtime:
    orchestrator: Orchestrator
    policy: PermissionPolicy
    kill_switch: KillSwitch
    providers: ProviderRegistry
    perception: PerceptionHub
    data_dir: Path
    backend: DesktopBackend
    apps: AppRegistry
    file_scope: FileScope
    bridge: PerceptionControlBridge

    def start_bridge(self) -> None:
        self.bridge.start()

    def emergency_release_inputs(self) -> None:
        for button in ("left", "right", "middle"):
            try: self.backend.mouse_up(button)
            except Exception: pass

    def stop_all(self) -> None:
        self.emergency_release_inputs(); self.bridge.stop(); self.perception.stop_all()


@dataclass(slots=True)
class Phase4Runtime:
    orchestrator: Orchestrator
    policy: PermissionPolicy
    kill_switch: KillSwitch
    providers: ProviderRegistry
    perception: PerceptionHub
    data_dir: Path
    backend: DesktopBackend
    apps: AppRegistry
    file_scope: FileScope
    bridge: IntentControlBridge
    intent: IntentEngine

    def start_bridge(self) -> None:
        self.bridge.start()

    def emergency_release_inputs(self) -> None:
        for button in ("left", "right", "middle"):
            try: self.backend.mouse_up(button)
            except Exception: pass
        self.intent.drag_active = False

    def stop_all(self) -> None:
        self.emergency_release_inputs(); self.bridge.stop(); self.perception.stop_all()



@dataclass(slots=True)
class Phase5Runtime:
    orchestrator: Orchestrator
    policy: PermissionPolicy
    kill_switch: KillSwitch
    providers: ProviderRegistry
    perception: PerceptionHub
    data_dir: Path
    backend: DesktopBackend
    apps: AppRegistry
    file_scope: FileScope
    bridge: IntentControlBridge
    intent: IntentEngine
    screen: ScreenObserver
    grounding: GroundingEngine
    targets: TargetRegistry

    def start_bridge(self) -> None:
        self.bridge.start()

    def emergency_release_inputs(self) -> None:
        for button in ("left", "right", "middle"):
            try: self.backend.mouse_up(button)
            except Exception: pass
        self.intent.drag_active = False

    def stop_all(self) -> None:
        self.emergency_release_inputs(); self.bridge.stop(); self.perception.stop_all()



@dataclass(slots=True)
class Phase6Runtime:
    orchestrator: Orchestrator
    policy: PermissionPolicy
    kill_switch: KillSwitch
    providers: ProviderRegistry
    perception: PerceptionHub
    data_dir: Path
    backend: DesktopBackend
    apps: AppRegistry
    file_scope: FileScope
    bridge: IntentControlBridge
    intent: IntentEngine
    screen: ScreenObserver
    grounding: GroundingEngine
    targets: TargetRegistry
    memory_manager: MemoryManager

    def start_bridge(self) -> None:
        self.bridge.start()

    def emergency_release_inputs(self) -> None:
        for button in ("left", "right", "middle"):
            try: self.backend.mouse_up(button)
            except Exception: pass
        self.intent.drag_active = False

    def stop_all(self) -> None:
        self.emergency_release_inputs(); self.bridge.stop(); self.perception.stop_all()



@dataclass(slots=True)
class Phase7Runtime:
    orchestrator: Orchestrator
    policy: PermissionPolicy
    kill_switch: KillSwitch
    providers: ProviderRegistry
    perception: PerceptionHub
    data_dir: Path
    backend: DesktopBackend
    apps: AppRegistry
    file_scope: FileScope
    bridge: IntentControlBridge
    intent: IntentEngine
    screen: ScreenObserver
    grounding: GroundingEngine
    targets: TargetRegistry
    memory_manager: MemoryManager
    skill_store: SkillStore
    skill_forge: SkillForge
    skill_runner: SkillRunner
    agent_director: AgentDirector
    research_corps: ResearchCorps

    def start_bridge(self) -> None:
        self.bridge.start()

    def emergency_release_inputs(self) -> None:
        for button in ("left", "right", "middle"):
            try: self.backend.mouse_up(button)
            except Exception: pass
        self.intent.drag_active = False

    def stop_all(self) -> None:
        self.emergency_release_inputs(); self.bridge.stop(); self.perception.stop_all()


@dataclass(slots=True)
class Phase8Runtime:
    orchestrator: Orchestrator
    policy: PermissionPolicy
    kill_switch: KillSwitch
    providers: ProviderRegistry
    perception: PerceptionHub
    data_dir: Path
    backend: DesktopBackend
    apps: AppRegistry
    file_scope: FileScope
    bridge: IntentControlBridge
    intent: IntentEngine
    screen: ScreenObserver
    grounding: GroundingEngine
    targets: TargetRegistry
    memory_manager: MemoryManager
    skill_store: SkillStore
    skill_forge: SkillForge
    skill_runner: SkillRunner
    agent_director: AgentDirector
    research_corps: ResearchCorps
    autonomy_store: MissionStore
    autonomy_engine: AutonomyEngine
    backup: BackupManager
    diagnostics: DiagnosticsRunner
    recovery: RecoveryManager
    recovery_state: RecoveryState
    crash_journal: CrashJournal
    credentials: CredentialStore
    provider_settings: ProviderSettings
    instance_lock: InstanceLock
    mobile: MobileSubsystem
    sentinel: PerceptionSentinel
    fusion: FusionCore
    skill_lab: SkillLab
    restored_on_start: bool = False

    def start_bridge(self) -> None:
        self.bridge.start()

    def emergency_release_inputs(self) -> None:
        for button in ("left", "right", "middle"):
            try:
                self.backend.mouse_up(button)
            except Exception:
                pass
        self.intent.drag_active = False

    def stop_all(self) -> None:
        self.emergency_release_inputs()
        self.bridge.stop()
        try: self.sentinel.stop()
        except Exception: pass
        self.perception.stop_all()
        try: self.mobile.stop_relay()
        except Exception: pass

    def start_sentinel(self) -> None:
        self.sentinel.start()

    def clean_shutdown(self) -> None:
        self.stop_all()
        try: self.fusion.close()
        except Exception: pass
        self.recovery.mark_clean()
        self.instance_lock.release()



@dataclass(slots=True)
class Infinity1Runtime:
    base: Phase8Runtime
    world_model: WorldModelManager
    guardian: Guardian
    world_bus_token: int

    def __getattr__(self, name):
        return getattr(self.base, name)

    def start_bridge(self) -> None:
        self.base.start_bridge()

    def start_sentinel(self) -> None:
        self.base.start_sentinel()

    def emergency_release_inputs(self) -> None:
        self.base.emergency_release_inputs()

    def stop_all(self) -> None:
        try: self.guardian.revoke_all()
        except Exception: pass
        self.base.stop_all()

    def clean_shutdown(self) -> None:
        try: self.base.perception.bus.unsubscribe(self.world_bus_token)
        except Exception: pass
        try: self.guardian.revoke_all()
        except Exception: pass
        self.base.clean_shutdown()



@dataclass(slots=True)
class Infinity2Runtime:
    base: Infinity1Runtime
    personal_os: PersonalAIOS

    def __getattr__(self, name):
        return getattr(self.base, name)

    def start_bridge(self) -> None:
        self.base.start_bridge()

    def start_sentinel(self) -> None:
        self.base.start_sentinel()

    def emergency_release_inputs(self) -> None:
        self.base.emergency_release_inputs()

    def stop_all(self) -> None:
        self.base.stop_all()

    def clean_shutdown(self) -> None:
        self.base.clean_shutdown()


@dataclass(slots=True)
class Infinity3Runtime:
    base: Infinity2Runtime
    workbench: AutonomousWorkbench

    def __getattr__(self, name):
        return getattr(self.base, name)

    def start_bridge(self) -> None:
        self.base.start_bridge()

    def start_sentinel(self) -> None:
        self.base.start_sentinel()

    def emergency_release_inputs(self) -> None:
        self.base.emergency_release_inputs()

    def stop_all(self) -> None:
        self.base.stop_all()

    def clean_shutdown(self) -> None:
        self.base.clean_shutdown()


@dataclass(slots=True)
class Infinity4Runtime:
    base: Infinity3Runtime
    swarm: CognitiveSwarm

    def __getattr__(self, name): return getattr(self.base, name)
    def start_bridge(self) -> None: self.base.start_bridge()
    def start_sentinel(self) -> None: self.base.start_sentinel()
    def emergency_release_inputs(self) -> None: self.base.emergency_release_inputs()
    def stop_all(self) -> None: self.base.stop_all()
    def clean_shutdown(self) -> None: self.base.clean_shutdown()


@dataclass(slots=True)
class Infinity5Runtime:
    base: Infinity4Runtime
    evolution: SelfEvolutionEngine

    def __getattr__(self, name): return getattr(self.base, name)
    def start_bridge(self) -> None: self.base.start_bridge()
    def start_sentinel(self) -> None: self.base.start_sentinel()
    def emergency_release_inputs(self) -> None: self.base.emergency_release_inputs()
    def stop_all(self) -> None: self.base.stop_all()
    def clean_shutdown(self) -> None: self.base.clean_shutdown()


@dataclass(slots=True)
class Infinity6Runtime:
    base: Infinity5Runtime
    reality: RealityBridge

    def __getattr__(self, name): return getattr(self.base, name)
    def start_bridge(self) -> None: self.base.start_bridge()
    def start_sentinel(self) -> None: self.base.start_sentinel()
    def emergency_release_inputs(self) -> None: self.base.emergency_release_inputs()
    def stop_all(self) -> None:
        try:self.reality.stop_monitor()
        except Exception:pass
        self.base.stop_all()
    def clean_shutdown(self) -> None:
        try:self.reality.stop_monitor()
        except Exception:pass
        self.base.clean_shutdown()



@dataclass(slots=True)
class Infinity7Runtime:
    base: Infinity6Runtime
    health: HealthSupervisor
    acceptance: AcceptanceStore
    release: ReleaseManager
    release_gate: ReleaseGate
    support: SupportBundleExporter

    def __getattr__(self, name): return getattr(self.base, name)
    def start_bridge(self) -> None: self.base.start_bridge()
    def start_sentinel(self) -> None: self.base.start_sentinel()
    def emergency_release_inputs(self) -> None: self.base.emergency_release_inputs()
    def export_support(self, destination: Path) -> Path:
        self.policy.require("support.export")
        decision=self.guardian.authorize(ActionRequest("support_export", {"destination": Path(destination).name}, "support.export"))
        if not decision.allowed: raise PermissionError(decision.reason)
        return self.support.create(destination,self)
    def ensure_health_monitor(self) -> None:
        if self.policy.is_allowed("health.monitor") and not self.kill_switch.engaged and not self.health.running:
            self.health.start(self,allowed=lambda:self.policy.is_allowed("health.monitor") and not self.kill_switch.engaged)
    def stop_all(self) -> None:
        try:self.health.stop()
        except Exception:pass
        self.base.stop_all()
    def clean_shutdown(self) -> None:
        try:self.health.stop()
        except Exception:pass
        self.base.clean_shutdown()

def _default_screen_observer(backend: DesktopBackend) -> ScreenObserver:
    try: accessibility = PywinautoAccessibilityScanner()
    except Exception: accessibility = NullAccessibilityScanner()
    try: capture = PillowScreenCapture()
    except Exception: capture = NullScreenCapture()
    return ScreenObserver(backend, accessibility=accessibility, capture=capture)

def _build_core(root: Path, backend: DesktopBackend, perception: PerceptionHub | None = None, phase: int = 3):
    root.mkdir(parents=True, exist_ok=True)
    memory = MemoryStore(root / "memory.sqlite3")
    policy = PermissionPolicy(path=root / "permissions.json")
    kill = KillSwitch(root / "STOP")
    providers = ProviderRegistry()
    apps = AppRegistry(root / "apps.json")
    scope = FileScope.load(root / "allowed_paths.json", [root / "workspace"])

    actions = {
        "remember": RememberAction(memory),
        "create_note": CreateNoteAction(root / "workspace"),
        "read_note": ReadNoteAction(root / "workspace"),
        "status": StatusAction(phase=phase),
        "screen_info": ScreenInfoAction(backend),
        "move_cursor": MoveCursorAction(backend),
        "move_cursor_normalized": MoveCursorNormalizedAction(backend),
        "mouse_button": MouseButtonAction(backend),
        "hotkey": HotkeyAction(backend),
        "type_text": TypeTextAction(backend),
        "list_windows": ListWindowsAction(backend),
        "focus_window": FocusWindowAction(backend),
        "move_window": MoveWindowAction(backend),
        "resize_active_window": ResizeWindowAction(backend),
        "maximize_window": MaximizeWindowAction(backend),
        "minimize_window": MinimizeWindowAction(backend),
        "open_app": OpenAppAction(backend, apps),
        "open_url": OpenUrlAction(backend),
        "list_directory": ListDirectoryAction(scope),
        "create_folder": CreateFolderAction(scope),
        "copy_file": CopyFileAction(scope),
        "move_file": MoveFileAction(scope),
    }
    planner = Planner(providers.active)
    executor = Executor(actions, policy, kill)
    verifier = Verifier(actions)
    orchestrator = Orchestrator(planner, executor, verifier, memory)
    return orchestrator, policy, kill, providers, apps, scope, executor, verifier


def build_runtime(data_dir: Path | None = None, backend: DesktopBackend | None = None) -> tuple[Orchestrator, PermissionPolicy, KillSwitch, ProviderRegistry]:
    root = Path(data_dir or default_data_dir()); desktop = backend or build_desktop_backend()
    orchestrator, policy, kill, providers, *_ = _build_core(root, desktop)
    return orchestrator, policy, kill, providers


def build_phase3_runtime(data_dir: Path | None = None, backend: DesktopBackend | None = None) -> Phase3Runtime:
    root = Path(data_dir or default_data_dir()); desktop = backend or build_desktop_backend(); perception = PerceptionHub(root)
    orchestrator, policy, kill, providers, apps, scope, executor, verifier = _build_core(root, desktop, perception, phase=3)
    gateway = ActionGateway(executor, verifier, orchestrator.memory, perception.bus)
    bridge = PerceptionControlBridge(orchestrator, gateway, perception.bus)
    return Phase3Runtime(orchestrator, policy, kill, providers, perception, root, desktop, apps, scope, bridge)


def build_phase4_runtime(data_dir: Path | None = None, backend: DesktopBackend | None = None) -> Phase4Runtime:
    root = Path(data_dir or default_data_dir()); desktop = backend or build_desktop_backend(); perception = PerceptionHub(root)
    orchestrator, policy, kill, providers, apps, scope, executor, verifier = _build_core(root, desktop, perception, phase=4)
    gateway = ActionGateway(executor, verifier, orchestrator.memory, perception.bus)
    intent_cfg = IntentConfig.load(root / "intent_config.json")
    intent = IntentEngine(ContextProvider(desktop), intent_cfg)
    bridge = IntentControlBridge(orchestrator, gateway, perception.bus, orchestrator.memory, intent)
    return Phase4Runtime(orchestrator, policy, kill, providers, perception, root, desktop, apps, scope, bridge, intent)


def build_phase5_runtime(data_dir: Path | None = None, backend: DesktopBackend | None = None,
                         screen_observer: ScreenObserver | None = None) -> Phase5Runtime:
    root = Path(data_dir or default_data_dir()); desktop = backend or build_desktop_backend(); perception = PerceptionHub(root)
    orchestrator, policy, kill, providers, apps, scope, executor, verifier = _build_core(root, desktop, perception, phase=5)
    observer = screen_observer or _default_screen_observer(desktop)
    targets = TargetRegistry()
    cloud = GeminiScreenGrounder(providers.active)
    grounding = GroundingEngine(observer, targets, cloud=cloud,
                                cloud_allowed=lambda: policy.is_allowed("screen.cloud"),
                                observe_allowed=lambda: policy.is_allowed("screen.observe"))
    screen_action = ScreenSnapshotAction(observer)
    click_action = GroundedClickAction(desktop, observer, grounding, targets)
    executor.actions[screen_action.name] = screen_action; executor.actions[click_action.name] = click_action
    verifier.actions[screen_action.name] = screen_action; verifier.actions[click_action.name] = click_action
    gateway = ActionGateway(executor, verifier, orchestrator.memory, perception.bus)
    intent_cfg = IntentConfig.load(root / "intent_config.json")
    intent = IntentEngine(ContextProvider(desktop), intent_cfg, grounder=grounding)
    bridge = IntentControlBridge(orchestrator, gateway, perception.bus, orchestrator.memory, intent)
    return Phase5Runtime(orchestrator, policy, kill, providers, perception, root, desktop, apps, scope, bridge, intent, observer, grounding, targets)



def build_phase6_runtime(data_dir: Path | None = None, backend: DesktopBackend | None = None,
                         screen_observer: ScreenObserver | None = None) -> Phase6Runtime:
    root = Path(data_dir or default_data_dir()); desktop = backend or build_desktop_backend(); perception = PerceptionHub(root)
    orchestrator, policy, kill, providers, apps, scope, executor, verifier = _build_core(root, desktop, perception, phase=6)
    continuity_store = ContinuityStore(root / "memory.sqlite3")
    memory_manager = MemoryManager(continuity_store)
    memory_actions = [
        CreateProjectAction(memory_manager), ActivateProjectAction(memory_manager), ListProjectsAction(memory_manager),
        StructuredRememberAction(memory_manager), MemorySearchAction(memory_manager), CorrectMemoryAction(memory_manager),
        ForgetMemoryAction(memory_manager), AddTaskAction(memory_manager), CompleteTaskAction(memory_manager),
        RecordDecisionAction(memory_manager), ResumeContextAction(memory_manager),
    ]
    for action in memory_actions:
        executor.actions[action.name] = action; verifier.actions[action.name] = action
    orchestrator.continuity = memory_manager

    observer = screen_observer or _default_screen_observer(desktop)
    targets = TargetRegistry(); cloud = GeminiScreenGrounder(providers.active)
    grounding = GroundingEngine(observer, targets, cloud=cloud,
                                cloud_allowed=lambda: policy.is_allowed("screen.cloud"),
                                observe_allowed=lambda: policy.is_allowed("screen.observe"))
    screen_action = ScreenSnapshotAction(observer); click_action = GroundedClickAction(desktop, observer, grounding, targets)
    executor.actions[screen_action.name] = screen_action; executor.actions[click_action.name] = click_action
    verifier.actions[screen_action.name] = screen_action; verifier.actions[click_action.name] = click_action
    gateway = ActionGateway(executor, verifier, orchestrator.memory, perception.bus)
    intent_cfg = IntentConfig.load(root / "intent_config.json"); intent = IntentEngine(ContextProvider(desktop), intent_cfg, grounder=grounding)
    bridge = IntentControlBridge(orchestrator, gateway, perception.bus, orchestrator.memory, intent)
    return Phase6Runtime(orchestrator, policy, kill, providers, perception, root, desktop, apps, scope, bridge, intent, observer, grounding, targets, memory_manager)



def build_phase7_runtime(data_dir: Path | None = None, backend: DesktopBackend | None = None,
                         screen_observer: ScreenObserver | None = None) -> Phase7Runtime:
    base = build_phase6_runtime(data_dir, backend, screen_observer)
    root=base.data_dir; executor=base.orchestrator.executor; verifier=base.orchestrator.verifier
    status=executor.actions.get("status")
    if status is not None and hasattr(status,"phase"): status.phase=7

    skill_store=SkillStore(root / "skills")
    skill_runner=SkillRunner(executor,verifier,base.orchestrator.memory)
    research_corps=ResearchCorps(lambda:base.providers.active,root / "research_runs",
                                 web_allowed=lambda:base.policy.is_allowed("research.web"),
                                 stop_check=base.kill_switch.check)
    skill_forge=SkillForge(skill_store,executor.actions,lambda:base.providers.active,
                           web_allowed=lambda:base.policy.is_allowed("research.web"),
                           research_callback=research_corps.skill_evidence,
                           research_corps_allowed=lambda:base.policy.is_allowed("research.deep"))
    director=AgentDirector(lambda:base.providers.active,root / "mission_runs",
                           web_allowed=lambda:base.policy.is_allowed("research.web"))
    cloud_context=lambda goal: base.memory_manager.context_for_goal(goal) if base.policy.is_allowed("memory.read") and base.policy.is_allowed("memory.cloud") else {}
    actions=[
        ListSkillsAction(skill_store), LearnSkillAction(skill_forge), EnableSkillAction(skill_store,skill_forge),
        RunSkillAction(skill_store,skill_runner),
        RunMissionAction(director,context_provider=cloud_context),
        DeepResearchAction(research_corps,context_provider=cloud_context),
    ]
    for action in actions:
        executor.actions[action.name]=action; verifier.actions[action.name]=action
    return Phase7Runtime(base.orchestrator,base.policy,base.kill_switch,base.providers,base.perception,root,base.backend,
                         base.apps,base.file_scope,base.bridge,base.intent,base.screen,base.grounding,base.targets,
                         base.memory_manager,skill_store,skill_forge,skill_runner,director,research_corps)


def build_phase8_runtime(data_dir: Path | None = None, backend: DesktopBackend | None = None,
                         screen_observer: ScreenObserver | None = None) -> Phase8Runtime:
    root = Path(data_dir or default_data_dir())
    root.mkdir(parents=True, exist_ok=True)
    instance_lock = InstanceLock(root / "runtime.lock")
    instance_lock.acquire()
    try:
        restored = apply_pending_restore(root)
        base = build_phase7_runtime(root, backend, screen_observer)
        status = base.orchestrator.executor.actions.get("status")
        if status is not None and hasattr(status, "phase"):
            status.phase = 8

        settings = ProviderSettings.load(root / "provider_config.json")
        try:
            base.providers.set_active(settings.active)
        except KeyError:
            settings.active = base.providers.active_name
            settings.save()
        provider = base.providers.active
        if hasattr(provider, "model"):
            provider.model = settings.gemini_model
        credentials = CredentialStore()
        if hasattr(provider, "api_key") and not getattr(provider, "api_key", None):
            provider.api_key = credentials.get("GEMINI_API_KEY")

        fusion = FusionCore(base.perception.bus, cloud_allowed=lambda: base.policy.is_allowed("perception.cloud"),
                            screen_cloud_allowed=lambda: base.policy.is_allowed("screen.cloud"))
        sentinel = PerceptionSentinel(base.screen, base.perception.bus,
                                      allowed=lambda: base.policy.is_allowed("perception.continuous") and base.policy.is_allowed("screen.observe"),
                                      stop_check=base.kill_switch.check)
        skill_lab = SkillLab(base.orchestrator.executor.actions)
        base.skill_forge.lab = skill_lab
        base.skill_runner.lab = skill_lab

        autonomy_store = MissionStore(root / "autonomy_runs")
        autonomy_engine = AutonomyEngine(
            lambda: base.providers.active, base.orchestrator.executor, base.orchestrator.verifier,
            base.kill_switch, autonomy_store, observer=base.screen,
            memory_context=lambda goal: base.memory_manager.context_for_goal(goal) if base.policy.is_allowed("memory.read") and base.policy.is_allowed("memory.cloud") else {},
            skill_forge=base.skill_forge, skill_store=base.skill_store, skill_runner=base.skill_runner,
            multimodal_context=fusion.cloud_summary,
        )
        autonomy_actions = [
            RunAutonomousMissionAction(autonomy_engine),
            ResumeAutonomousMissionAction(autonomy_engine),
            ListAutonomousMissionsAction(autonomy_store),
        ]
        for action in autonomy_actions:
            base.orchestrator.executor.actions[action.name] = action
            base.orchestrator.verifier.actions[action.name] = action

        mobile = MobileSubsystem.create(root, credentials)
        mobile_actions = [
            ListMobileDevicesAction(mobile.manager), MobileStatusAction(mobile.manager),
            MobileLastLocationAction(mobile.manager), MobileRequestLocationAction(mobile.manager),
            MobileRingAction(mobile.manager), MobileLockAction(mobile.manager), MobileRequestAuthAction(mobile.manager),
            MobileOpenUrlAction(mobile.manager), MobileOpenAppAction(mobile.manager), MobileComposeMessageAction(mobile.manager), MobileFindContactAction(mobile.manager),
        ]
        for action in mobile_actions:
            base.orchestrator.executor.actions[action.name] = action
            base.orchestrator.verifier.actions[action.name] = action

        recovery = RecoveryManager(root)
        recovery_state = recovery.begin(base.policy)
        backup = BackupManager(root, product_version="1.2.0a2")
        diagnostics = DiagnosticsRunner(root)
        crash_journal = CrashJournal(root)
        return Phase8Runtime(
            base.orchestrator, base.policy, base.kill_switch, base.providers, base.perception, root, base.backend,
            base.apps, base.file_scope, base.bridge, base.intent, base.screen, base.grounding, base.targets,
            base.memory_manager, base.skill_store, base.skill_forge, base.skill_runner, base.agent_director, base.research_corps,
            autonomy_store, autonomy_engine, backup, diagnostics, recovery, recovery_state, crash_journal, credentials, settings, instance_lock, mobile, sentinel, fusion, skill_lab, restored
        )
    except Exception:
        instance_lock.release()
        raise


def build_infinity1_runtime(data_dir: Path | None = None, backend: DesktopBackend | None = None,
                            screen_observer: ScreenObserver | None = None) -> Infinity1Runtime:
    base = build_phase8_runtime(data_dir, backend, screen_observer)
    root = base.data_dir
    try:
        world_store = WorldModelStore(root / "world_model.sqlite3")
        world = WorldModelManager(world_store, memory_manager=base.memory_manager, mobile=base.mobile, fusion=base.fusion, write_allowed=lambda: base.policy.is_allowed("world.write"), memory_allowed=lambda: base.policy.is_allowed("memory.read"), mobile_allowed=lambda: base.policy.is_allowed("mobile.read"))
        token = base.perception.bus.subscribe(world.ingest_perception)
        world.sync()

        guardian_store = GuardianStore(root / "guardian.sqlite3")
        guardian = Guardian(guardian_store, policy=base.policy, kill_switch=base.kill_switch, world=world)
        base.orchestrator.executor.guardian = guardian
        base.orchestrator.world_model = world
        base.autonomy_engine.world_context = lambda goal: world.cloud_context_for_goal(goal, allow_screen=base.policy.is_allowed("screen.cloud"), allow_perception=base.policy.is_allowed("perception.cloud"), allow_memory=base.policy.is_allowed("memory.cloud"), allow_reality=base.policy.is_allowed("reality.cloud")) if base.policy.is_allowed("world.read") and base.policy.is_allowed("world.cloud") else None

        for action in (WorldStatusAction(world), WorldEntitiesAction(world)):
            base.orchestrator.executor.actions[action.name] = action
            base.orchestrator.verifier.actions[action.name] = action
        status = base.orchestrator.executor.actions.get("status")
        if status is not None and hasattr(status, "phase"):
            status.phase = "Infinity-1"
        return Infinity1Runtime(base, world, guardian, token)
    except Exception:
        base.clean_shutdown()
        raise


def build_infinity2_runtime(data_dir: Path | None = None, backend: DesktopBackend | None = None,
                            screen_observer: ScreenObserver | None = None) -> Infinity2Runtime:
    base = build_infinity1_runtime(data_dir, backend, screen_observer)
    root = base.data_dir
    try:
        store = ResourceStore(root / "personal_os.sqlite3")
        kernel = PersonalAIOS(
            store, executor=base.orchestrator.executor, verifier=base.orchestrator.verifier, policy=base.policy,
            apps=base.apps, file_scope=base.file_scope, backend=base.backend, mobile=base.mobile,
            memory_manager=base.memory_manager, autonomy_store=base.autonomy_store, world=base.world_model, guardian=base.guardian,
        )
        for action in (OSResourcesAction(kernel), OSResolveAction(kernel), OSPlanAction(kernel), OSExecuteAction(kernel),
                       OSPinURLAction(kernel), OSPinFileAction(kernel), OSPinContactAction(kernel), OSHandoffsAction(kernel)):
            base.orchestrator.executor.actions[action.name] = action
            base.orchestrator.verifier.actions[action.name] = action
        kernel.sync()
        base.orchestrator.personal_os = kernel
        previous_world_context = base.autonomy_engine.world_context
        def _combined_world_context(goal):
            world = previous_world_context(goal) if callable(previous_world_context) else None
            os_ctx = kernel.cloud_context()
            if world is None and os_ctx is None: return None
            return {"world": world, "personal_os": os_ctx}
        base.autonomy_engine.world_context = _combined_world_context
        base.base.backup = BackupManager(root, product_version="1.2.0a2")
        status = base.orchestrator.executor.actions.get("status")
        if status is not None and hasattr(status, "phase"):
            status.phase = "Infinity-2"
        return Infinity2Runtime(base, kernel)
    except Exception:
        base.clean_shutdown()
        raise



def build_infinity3_runtime(data_dir: Path | None = None, backend: DesktopBackend | None = None,
                            screen_observer: ScreenObserver | None = None) -> Infinity3Runtime:
    base = build_infinity2_runtime(data_dir, backend, screen_observer)
    root = base.data_dir
    try:
        store = WorkbenchStore(root / "workbench.sqlite3")

        def _authorize(name: str, args: dict) -> None:
            capability = "workbench.run" if name == "workbench_run" else "workbench.manage"
            decision = base.guardian.authorize(ActionRequest(name, dict(args), capability))
            if not decision.allowed:
                raise PermissionError(decision.reason)

        workbench = AutonomousWorkbench(
            store, base.autonomy_engine, kill_switch=base.kill_switch,
            run_allowed=lambda: base.policy.is_allowed("workbench.run") and base.policy.is_allowed("autonomy.run"),
            manage_allowed=lambda: base.policy.is_allowed("workbench.manage"),
            authorize=_authorize,
        )
        for action in (WorkbenchListAction(workbench), WorkbenchCreateAction(workbench), WorkbenchRunCycleAction(workbench),
                       WorkbenchPauseAction(workbench), WorkbenchResumeAction(workbench), WorkbenchCancelAction(workbench)):
            base.orchestrator.executor.actions[action.name] = action
            base.orchestrator.verifier.actions[action.name] = action

        # A crash never causes automatic replay of a possibly half-completed desktop action.
        if base.recovery_state.safe_mode:
            for item in store.list(500):
                if item.state.value == "running":
                    item.state = __import__("jarvis_gm.workbench.models", fromlist=["WorkState"]).WorkState.PAUSED
                    item.conclusion = "Recovery pause: prior session ended while this work item was running; owner review/resume required"
                    store.checkpoint(item, note=item.conclusion)

        # Personal AI OS can expose work items as resources without granting execution authority.
        base.personal_os.workbench_store = store
        base.personal_os.sync()
        base.orchestrator.workbench = workbench
        base.base.base.backup = BackupManager(root, product_version="1.3.0a3")
        base.base.base.diagnostics = DiagnosticsRunner(root, product_version="1.3.0a3")
        status = base.orchestrator.executor.actions.get("status")
        if status is not None and hasattr(status, "phase"):
            status.phase = "Infinity-3"
        return Infinity3Runtime(base, workbench)
    except Exception:
        base.clean_shutdown()
        raise


def build_infinity4_runtime(data_dir: Path | None = None, backend: DesktopBackend | None = None,
                            screen_observer: ScreenObserver | None = None) -> Infinity4Runtime:
    base = build_infinity3_runtime(data_dir, backend, screen_observer)
    root = base.data_dir
    try:
        store = SwarmStore(root / "swarm.sqlite3")
        def _authorize(name: str, args: dict) -> None:
            decision = base.guardian.authorize(ActionRequest(name, dict(args), "swarm.run"))
            if not decision.allowed: raise PermissionError(decision.reason)
        def _context(goal: str):
            ctx = {}
            if base.policy.is_allowed("world.read") and base.policy.is_allowed("world.cloud"):
                ctx["world"] = base.world_model.cloud_context_for_goal(goal, allow_screen=base.policy.is_allowed("screen.cloud"), allow_perception=base.policy.is_allowed("perception.cloud"), allow_memory=base.policy.is_allowed("memory.cloud"), allow_reality=base.policy.is_allowed("reality.cloud"))
            if base.policy.is_allowed("os.read") and base.policy.is_allowed("os.cloud"): ctx["personal_os"] = base.personal_os.cloud_context()
            if base.policy.is_allowed("memory.read") and base.policy.is_allowed("memory.cloud"): ctx["memory"] = base.memory_manager.context_for_goal(goal)
            if base.policy.is_allowed("workbench.read") and base.policy.is_allowed("workbench.cloud"):
                ctx["workbench"] = [{"id":x.id,"goal":x.goal,"state":x.state.value} for x in base.workbench.store.list(25)]
            return ctx
        swarm = CognitiveSwarm(lambda: base.providers.active, store, run_allowed=lambda: base.policy.is_allowed("swarm.run"), cloud_allowed=lambda: base.policy.is_allowed("swarm.cloud"), research_allowed=lambda: base.policy.is_allowed("research.deep") and base.policy.is_allowed("research.web"), research_corps=base.research_corps, stop_check=base.kill_switch.check, authorize=_authorize)
        for action in (SwarmRunAction(swarm,_context), SwarmListAction(store)):
            base.orchestrator.executor.actions[action.name]=action; base.orchestrator.verifier.actions[action.name]=action
        base.orchestrator.swarm = swarm
        base.base.base.base.backup = BackupManager(root, product_version="1.4.0a4")
        base.base.base.base.diagnostics = DiagnosticsRunner(root, product_version="1.4.0a4")
        status=base.orchestrator.executor.actions.get("status")
        if status is not None and hasattr(status,"phase"): status.phase="Infinity-4"
        return Infinity4Runtime(base, swarm)
    except Exception:
        base.clean_shutdown(); raise


def build_infinity5_runtime(data_dir: Path | None = None, backend: DesktopBackend | None = None,
                            screen_observer: ScreenObserver | None = None) -> Infinity5Runtime:
    base = build_infinity4_runtime(data_dir, backend, screen_observer)
    root=base.data_dir
    try:
        store=EvolutionStore(root / "evolution.sqlite3")
        def _authorize(name: str,args: dict)->None:
            capability="evolution.manage" if name in {"evolution_promote","evolution_rollback","evolution_manage"} else "evolution.run"
            decision=base.guardian.authorize(ActionRequest(name,dict(args),capability))
            if not decision.allowed: raise PermissionError(decision.reason)
        evolution=SelfEvolutionEngine(store,base.skill_store,base.skill_lab,base.skill_forge.compiler,lambda:base.providers.active,base.orchestrator.executor.actions,read_allowed=lambda:base.policy.is_allowed("evolution.read"),run_allowed=lambda:base.policy.is_allowed("evolution.run"),manage_allowed=lambda:base.policy.is_allowed("evolution.manage"),cloud_allowed=lambda:base.policy.is_allowed("evolution.cloud"),authorize=_authorize,swarm=base.swarm,swarm_allowed=lambda:base.policy.is_allowed("swarm.run") and base.policy.is_allowed("swarm.cloud"))
        for action in (EvolutionListAction(store),EvolutionScanAction(evolution),EvolutionBenchmarkAction(evolution,base.skill_store),EvolutionProposeAction(evolution),EvolutionPromoteAction(evolution),EvolutionRejectAction(evolution),EvolutionRollbackAction(evolution)):
            base.orchestrator.executor.actions[action.name]=action;base.orchestrator.verifier.actions[action.name]=action
        base.orchestrator.evolution=evolution
        base.base.base.base.base.backup=BackupManager(root,product_version="1.5.0a5")
        base.base.base.base.base.diagnostics=DiagnosticsRunner(root,product_version="1.5.0a5")
        status=base.orchestrator.executor.actions.get("status")
        if status is not None and hasattr(status,"phase"):status.phase="Infinity-5"
        return Infinity5Runtime(base,evolution)
    except Exception:
        base.clean_shutdown();raise


def build_infinity6_runtime(data_dir: Path | None = None, backend: DesktopBackend | None = None,
                            screen_observer: ScreenObserver | None = None) -> Infinity6Runtime:
    base = build_infinity5_runtime(data_dir, backend, screen_observer)
    root=base.data_dir
    try:
        store=RealityStore(root / "reality.sqlite3")
        reality=RealityBridge(store,policy=base.policy,guardian=base.guardian,kill_switch=base.kill_switch,world=base.world_model,credentials=base.credentials,config_path=root / "reality_config.json")
        for action in (RealityListAction(reality),RealityObserveAction(reality),RealityCommandAction(reality),RealityEnrollAction(reality)):
            base.orchestrator.executor.actions[action.name]=action; base.orchestrator.verifier.actions[action.name]=action
        base.orchestrator.reality=reality
        base.personal_os.reality=reality
        base.personal_os.sync()
        base.base.base.base.base.base.backup=BackupManager(root,product_version="1.6.0a6")
        base.base.base.base.base.base.diagnostics=DiagnosticsRunner(root,product_version="1.6.0a6")
        status=base.orchestrator.executor.actions.get("status")
        if status is not None and hasattr(status,"phase"): status.phase="Infinity-6"
        return Infinity6Runtime(base,reality)
    except Exception:
        base.clean_shutdown(); raise



def build_infinity7_runtime(data_dir: Path | None = None, backend: DesktopBackend | None = None,
                            screen_observer: ScreenObserver | None = None) -> Infinity7Runtime:
    base = build_infinity6_runtime(data_dir, backend, screen_observer)
    root=base.data_dir
    try:
        # Final Infinity release infrastructure is local and model-independent.
        base.base.base.base.base.base.base.backup=BackupManager(root,product_version="1.7.0rc1")
        base.base.base.base.base.base.base.diagnostics=DiagnosticsRunner(root,product_version="1.7.0rc1")
        acceptance=AcceptanceStore(root)
        health=HealthSupervisor(root)
        release=ReleaseManager(root,"1.7.0rc1",policy=base.policy,guardian=base.guardian)
        release_gate=ReleaseGate("1.7.0rc1",base.diagnostics,acceptance)
        support=SupportBundleExporter(root,base.diagnostics,acceptance,health)
        status=base.orchestrator.executor.actions.get("status")
        if status is not None and hasattr(status,"phase"): status.phase="Infinity-7"
        runtime=Infinity7Runtime(base,health,acceptance,release,release_gate,support)
        if base.policy.is_allowed("health.monitor"):
            health.start(runtime,allowed=lambda:base.policy.is_allowed("health.monitor") and not base.kill_switch.engaged)
        return runtime
    except Exception:
        base.clean_shutdown(); raise

def build_phase2_runtime(data_dir: Path | None = None) -> Phase3Runtime:
    return build_phase3_runtime(data_dir)
