from __future__ import annotations

from pathlib import Path
import json
import re
from typing import Any, Callable

from .models import AgentRole, MissionReport, MissionState, SpecialistResult, SpecialistTask


class AgentDirector:
    """Coordinates bounded specialists. Specialists never receive direct tool access.

    They produce research/analysis/work products. Any desktop action still has to be
    executed later by the normal permissioned Core or by an owner-enabled skill.
    """
    MAX_TASKS = 6

    def __init__(self, provider_resolver: Callable[[], Any], runs_dir: Path, *, web_allowed: Callable[[], bool]) -> None:
        self.provider_resolver=provider_resolver
        self.runs_dir=Path(runs_dir); self.runs_dir.mkdir(parents=True,exist_ok=True)
        self.web_allowed=web_allowed

    def plan(self, goal: str, *, request_web: bool = False) -> list[SpecialistTask]:
        provider=self.provider_resolver()
        if not getattr(provider,"available",False):
            raise RuntimeError("Agent Director requires a configured cloud AI provider")
        schema={"tasks":[{"id":"t1","role":"researcher|planner|builder|reviewer","objective":"...","depends_on":[],"web_research":False}]}
        raw=provider.generate(
            "Decompose the user's mission into 2-6 bounded specialist tasks. Always include a final reviewer task. "
            "Specialists have NO direct computer/tool access. Web research may only be requested for facts or current documentation. "
            "Return JSON only.\nSCHEMA="+json.dumps(schema)+"\nMISSION="+goal,
            system="You are a mission director. Prefer small verifiable tasks and explicit dependencies."
        )
        data=_json(raw); rows=data.get("tasks",[]) if isinstance(data,dict) else []
        if not isinstance(rows,list) or not (1 <= len(rows) <= self.MAX_TASKS):
            raise RuntimeError("Agent Director returned an invalid task graph")
        tasks=[]; seen=set()
        for i,row in enumerate(rows,1):
            tid=str(row.get("id") or f"t{i}")[:32]
            if tid in seen: raise RuntimeError("Agent Director returned duplicate task ids")
            seen.add(tid)
            try: role=AgentRole(str(row.get("role","planner")).lower())
            except ValueError as exc: raise RuntimeError(f"Invalid specialist role: {row.get('role')}") from exc
            deps=tuple(str(x) for x in row.get("depends_on",[]) if str(x))
            if any(x not in seen for x in deps):
                raise RuntimeError(f"Task {tid} depends on a future/unknown task")
            use_web=bool(row.get("web_research",False)) and bool(request_web)
            tasks.append(SpecialistTask(tid,role,str(row.get("objective") or "").strip(),deps,use_web))
        if not any(t.role==AgentRole.REVIEWER for t in tasks):
            if len(tasks)>=self.MAX_TASKS: tasks[-1]=SpecialistTask(tasks[-1].id,AgentRole.REVIEWER,"Review the mission outputs for correctness, gaps, and unsupported claims.",tasks[-1].depends_on,False)
            else: tasks.append(SpecialistTask("review",AgentRole.REVIEWER,"Review all prior outputs for correctness, gaps, and unsupported claims.",tuple(t.id for t in tasks),False))
        return tasks

    def run(self, goal: str, *, request_web: bool = False, context: dict[str,Any] | None = None) -> MissionReport:
        report=MissionReport(goal=goal)
        report.tasks=self.plan(goal,request_web=request_web); report.state=MissionState.RUNNING
        completed: dict[str,SpecialistResult]={}
        provider=self.provider_resolver()
        try:
            for task in report.tasks:
                missing=[x for x in task.depends_on if x not in completed or not completed[x].ok]
                if missing:
                    result=SpecialistResult(task.id,task.role,False,error="Blocked dependencies: "+", ".join(missing))
                    report.results.append(result); completed[task.id]=result; report.state=MissionState.BLOCKED; break
                prior={k:v.output for k,v in completed.items() if k in task.depends_on}
                citations=[]
                if task.web_research:
                    if not self.web_allowed():
                        raise PermissionError("Capability blocked by policy: research.web")
                    grounded=getattr(provider,"grounded_search",None)
                    if grounded is None: raise RuntimeError("Active provider does not support grounded web research")
                    research=grounded(task.objective); output=str(research.get("text", "")); citations=list(research.get("citations",[]))
                else:
                    prompt=(
                        f"MISSION={goal}\nROLE={task.role.value}\nOBJECTIVE={task.objective}\n"
                        f"DEPENDENCY_OUTPUTS={json.dumps(prior,ensure_ascii=False)[:20000]}\n"
                        f"USER_CONTEXT={json.dumps(context or {},ensure_ascii=False)[:8000]}\n"
                        "Produce a concise work product. Do not claim to have used tools or changed the computer. "
                        "Identify uncertainty explicitly."
                    )
                    output=provider.generate(prompt,system=f"You are JARVIS specialist: {task.role.value}. You have no direct tool access.")
                result=SpecialistResult(task.id,task.role,True,output,citations)
                report.results.append(result); completed[task.id]=result
            if report.state != MissionState.BLOCKED:
                synthesis="\n\n".join(f"[{x.role.value}/{x.task_id}] {x.output}" for x in report.results if x.ok)
                report.final=provider.generate(
                    "Synthesize the mission work into a final answer/plan. Separate verified evidence from proposals. "
                    "Do not claim any computer action was executed.\nMISSION="+goal+"\nWORK=\n"+synthesis[:30000],
                    system="You are JARVIS Mission Director. Report only what the specialists actually established."
                )
                report.state=MissionState.VERIFIED
        except PermissionError as exc:
            report.state=MissionState.BLOCKED; report.final=str(exc)
        except Exception as exc:
            report.state=MissionState.FAILED; report.final=str(exc)
        self._persist(report)
        return report

    def _persist(self, report: MissionReport) -> None:
        path=self.runs_dir/f"{report.id}.json"; tmp=path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(report.as_dict(),ensure_ascii=False,indent=2),encoding="utf-8");tmp.replace(path)


def _json(raw: str):
    text=raw.strip()
    if text.startswith("```"):
        text=re.sub(r"^```(?:json)?\s*","",text,flags=re.I);text=re.sub(r"\s*```$","",text)
    try:return json.loads(text)
    except json.JSONDecodeError:
        a,b=text.find("{"),text.rfind("}")
        if a>=0 and b>a:
            try:return json.loads(text[a:b+1])
            except json.JSONDecodeError:pass
        raise RuntimeError("Agent Director did not return valid JSON")
