from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any
import time
import uuid


class AgentRole(str, Enum):
    RESEARCHER = "researcher"
    PLANNER = "planner"
    BUILDER = "builder"
    REVIEWER = "reviewer"


class MissionState(str, Enum):
    PLANNED = "planned"
    RUNNING = "running"
    VERIFIED = "verified"
    BLOCKED = "blocked"
    FAILED = "failed"


@dataclass(slots=True)
class SpecialistTask:
    id: str
    role: AgentRole
    objective: str
    depends_on: tuple[str, ...] = ()
    web_research: bool = False


@dataclass(slots=True)
class SpecialistResult:
    task_id: str
    role: AgentRole
    ok: bool
    output: str = ""
    citations: list[dict[str, str]] = field(default_factory=list)
    error: str | None = None


@dataclass(slots=True)
class MissionReport:
    goal: str
    id: str = field(default_factory=lambda: "mission_" + uuid.uuid4().hex[:16])
    state: MissionState = MissionState.PLANNED
    tasks: list[SpecialistTask] = field(default_factory=list)
    results: list[SpecialistResult] = field(default_factory=list)
    final: str = ""
    created_at: float = field(default_factory=time.time)

    def as_dict(self) -> dict[str, Any]:
        value=asdict(self); value["state"]=self.state.value
        for task in value["tasks"]: task["role"] = task["role"].value if hasattr(task["role"],"value") else task["role"]
        for result in value["results"]: result["role"] = result["role"].value if hasattr(result["role"],"value") else result["role"]
        return value
