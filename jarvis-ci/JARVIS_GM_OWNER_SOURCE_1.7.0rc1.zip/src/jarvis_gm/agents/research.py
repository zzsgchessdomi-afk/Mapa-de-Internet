from __future__ import annotations

from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Callable
import json
import re
import time
import uuid


@dataclass(slots=True)
class ResearchTrace:
    role: str
    objective: str
    output: str
    citations: list[dict[str, str]] = field(default_factory=list)


@dataclass(slots=True)
class ResearchReport:
    question: str
    id: str = field(default_factory=lambda: "research_" + uuid.uuid4().hex[:16])
    state: str = "received"
    queries: list[str] = field(default_factory=list)
    traces: list[ResearchTrace] = field(default_factory=list)
    claims: list[dict[str, Any]] = field(default_factory=list)
    contradictions: list[dict[str, Any]] = field(default_factory=list)
    gaps: list[str] = field(default_factory=list)
    citations: list[dict[str, str]] = field(default_factory=list)
    synthesis: str = ""
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


class ResearchCorps:
    """Bounded multi-agent research pipeline with explicit provenance.

    The corps has no desktop/tool access. It can only ask the active provider to
    perform grounded search and analysis. Search is separately permission-gated.
    """

    DEPTH_QUERY_LIMITS = {"focused": 2, "standard": 4, "deep": 6}

    def __init__(self, provider_resolver: Callable[[], Any], runs_dir: Path,
                 *, web_allowed: Callable[[], bool], stop_check: Callable[[], None] | None = None) -> None:
        self.provider_resolver = provider_resolver
        self.runs_dir = Path(runs_dir)
        self.runs_dir.mkdir(parents=True, exist_ok=True)
        self.web_allowed = web_allowed
        self.stop_check = stop_check or (lambda: None)

    def run(self, question: str, *, depth: str = "standard", context: dict[str, Any] | None = None) -> ResearchReport:
        question = " ".join(str(question).split()).strip()
        if not question:
            raise ValueError("Research question cannot be empty")
        if depth not in self.DEPTH_QUERY_LIMITS:
            raise ValueError("Research depth must be focused, standard, or deep")
        if not self.web_allowed():
            raise PermissionError("Capability blocked by policy: research.web")
        provider = self.provider_resolver()
        if not getattr(provider, "available", False):
            raise RuntimeError("Research Corps requires a configured cloud AI provider")
        grounded = getattr(provider, "grounded_search", None)
        if grounded is None:
            raise RuntimeError("Active provider does not support grounded web research")

        report = ResearchReport(question=question, state="running")
        try:
            self.stop_check()
            report.queries = self._plan_queries(provider, question, depth, context)
            evidence_chunks: list[str] = []
            citations: list[dict[str, str]] = []
            for index, query in enumerate(report.queries, 1):
                self.stop_check()
                result = grounded(
                    "Research this sub-question with a strong preference for primary/official sources. "
                    "Separate direct evidence from interpretation and mention uncertainty. "
                    f"Main question: {question}\nSub-question/query: {query}"
                )
                text = str(result.get("text", "")).strip()
                rows = _clean_citations(result.get("citations", []))
                report.traces.append(ResearchTrace("source_scout", query, text, rows))
                evidence_chunks.append(f"[SCOUT {index}] {text}")
                citations.extend(rows)

            report.citations = _dedupe_citations(citations)[:40]
            self.stop_check()
            evidence = "\n\n".join(evidence_chunks)[:50000]
            try:
                analysis = self._analyze_evidence(provider, question, evidence, report.citations)
            except Exception as exc:
                analysis = {
                    "claims": [{"claim": evidence[:4000], "support_urls": [x.get("url") for x in report.citations if x.get("url")], "confidence": 0.5, "status": "uncertain"}] if evidence else [],
                    "gaps": [f"Structured evidence analysis unavailable: {exc}"],
                }
            report.claims = list(analysis.get("claims", []))[:30]
            report.gaps = [str(x) for x in analysis.get("gaps", []) if str(x)][:20]
            report.traces.append(ResearchTrace("evidence_analyst", "Map evidence to claims", json.dumps(analysis, ensure_ascii=False)))

            self.stop_check()
            try:
                critique = self._challenge(provider, question, report.claims, report.gaps, evidence)
            except Exception as exc:
                critique = {"contradictions": [], "gaps": [f"Structured contradiction audit unavailable: {exc}"]}
            report.contradictions = list(critique.get("contradictions", []))[:20]
            extra_gaps = [str(x) for x in critique.get("gaps", []) if str(x)]
            for item in extra_gaps:
                if item not in report.gaps:
                    report.gaps.append(item)
            report.traces.append(ResearchTrace("skeptic", "Find contradictions, weak support, and missing evidence", json.dumps(critique, ensure_ascii=False)))

            self.stop_check()
            report.synthesis = self._synthesize(provider, question, report.claims, report.contradictions, report.gaps, report.citations)
            report.traces.append(ResearchTrace("synthesizer", "Produce evidence-aware synthesis", report.synthesis, report.citations))
            report.state = "verified" if report.synthesis.strip() and report.citations else "failed"
        except PermissionError:
            report.state = "blocked"
            raise
        except Exception as exc:
            if "kill switch" in str(exc).lower() or "stop global" in str(exc).lower():
                report.state = "blocked"
                report.synthesis = "Research stopped by owner safety control"
            else:
                report.state = "failed"
                report.synthesis = f"Research failed: {exc}"
        finally:
            report.updated_at = time.time()
            self._persist(report)
        return report

    def skill_evidence(self, goal: str) -> dict[str, Any]:
        report = self.run(
            "Find a reliable, current, operational procedure for this task and its constraints. "
            "Prefer official documentation. Task: " + goal,
            depth="focused",
        )
        if report.state == "blocked":
            raise PermissionError(report.synthesis or "Research Corps was stopped or blocked")
        if report.state != "verified":
            raise RuntimeError(report.synthesis or "Research Corps could not verify skill evidence")
        return {
            "text": report.synthesis,
            "citations": report.citations,
            "queries": report.queries,
            "research_id": report.id,
            "claims": report.claims,
            "contradictions": report.contradictions,
            "gaps": report.gaps,
        }

    def _plan_queries(self, provider: Any, question: str, depth: str, context: dict[str, Any] | None) -> list[str]:
        limit = self.DEPTH_QUERY_LIMITS[depth]
        raw = provider.generate(
            "Create a compact research plan. Return JSON only with key queries, an array of specific search queries. "
            "Cover definitions/facts, primary documentation, and at least one query intended to challenge the main assumption. "
            f"Return at most {limit} queries.\nQUESTION={question}\nCONTEXT={json.dumps(context or {}, ensure_ascii=False)[:6000]}",
            system="You are JARVIS Research Planner. Optimize for evidence quality, not volume.",
        )
        try:
            data = _json_object(raw)
            queries = [" ".join(str(x).split()).strip() for x in data.get("queries", []) if str(x).strip()]
        except Exception:
            queries = []
        if not queries:
            queries = [question]
        deduped: list[str] = []
        for item in queries:
            if item not in deduped:
                deduped.append(item)
        return deduped[:limit]

    def _analyze_evidence(self, provider: Any, question: str, evidence: str, citations: list[dict[str, str]]) -> dict[str, Any]:
        schema = {
            "claims": [{"claim": "...", "support_urls": ["https://..."], "confidence": 0.0, "status": "supported|mixed|uncertain"}],
            "gaps": ["..."],
        }
        raw = provider.generate(
            "Analyze the evidence. Do not invent sources. Each claim must list only URLs present in CITATIONS. "
            "Lower confidence when evidence is indirect or conflicting. JSON only.\n"
            f"SCHEMA={json.dumps(schema)}\nQUESTION={question}\nCITATIONS={json.dumps(citations, ensure_ascii=False)}\nEVIDENCE={evidence}",
            system="You are JARVIS Evidence Analyst. Evidence provenance is mandatory.",
        )
        data = _json_object(raw)
        allowed = {x.get("url") for x in citations if x.get("url")}
        claims = []
        for row in data.get("claims", []) if isinstance(data.get("claims"), list) else []:
            if not isinstance(row, dict) or not str(row.get("claim", "")).strip():
                continue
            urls = [str(x) for x in row.get("support_urls", []) if str(x) in allowed]
            try:
                confidence = max(0.0, min(1.0, float(row.get("confidence", 0.5))))
            except Exception:
                confidence = 0.5
            claims.append({
                "claim": str(row.get("claim")).strip(),
                "support_urls": urls,
                "confidence": confidence,
                "status": str(row.get("status") or "uncertain"),
            })
        return {"claims": claims, "gaps": [str(x) for x in data.get("gaps", []) if str(x)]}

    def _challenge(self, provider: Any, question: str, claims: list[dict[str, Any]], gaps: list[str], evidence: str) -> dict[str, Any]:
        schema = {"contradictions": [{"issue": "...", "claim_indexes": [0, 1], "severity": "low|medium|high"}], "gaps": ["..."]}
        raw = provider.generate(
            "Act as a skeptical reviewer. Look for contradictions, overclaiming, missing evidence, stale evidence, and alternative explanations. "
            "Do not add new factual claims. JSON only.\n"
            f"SCHEMA={json.dumps(schema)}\nQUESTION={question}\nCLAIMS={json.dumps(claims, ensure_ascii=False)}\nKNOWN_GAPS={json.dumps(gaps, ensure_ascii=False)}\nEVIDENCE={evidence[:30000]}",
            system="You are JARVIS Contradiction Auditor. Try to falsify weak conclusions.",
        )
        return _json_object(raw)

    def _synthesize(self, provider: Any, question: str, claims: list[dict[str, Any]], contradictions: list[dict[str, Any]], gaps: list[str], citations: list[dict[str, str]]) -> str:
        return provider.generate(
            "Synthesize a concise research report using only the supplied claim ledger and citations. "
            "Distinguish well-supported findings, contested/uncertain points, and remaining gaps. Do not claim certainty beyond the ledger. "
            "When mentioning evidence, include the relevant source URL in parentheses so provenance survives export.\n"
            f"QUESTION={question}\nCLAIMS={json.dumps(claims, ensure_ascii=False)}\nCONTRADICTIONS={json.dumps(contradictions, ensure_ascii=False)}\nGAPS={json.dumps(gaps, ensure_ascii=False)}\nCITATIONS={json.dumps(citations, ensure_ascii=False)}",
            system="You are JARVIS Research Synthesizer. Accuracy and traceability outrank eloquence.",
        ).strip()

    def _persist(self, report: ResearchReport) -> None:
        path = self.runs_dir / f"{report.id}.json"
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(report.as_dict(), ensure_ascii=False, indent=2, default=str), encoding="utf-8")
        tmp.replace(path)

    def load(self, research_id: str) -> dict[str, Any]:
        safe="".join(c for c in str(research_id) if c.isalnum() or c in "-_")
        if not safe or safe != research_id:
            raise ValueError("Invalid research id")
        return json.loads((self.runs_dir / f"{safe}.json").read_text(encoding="utf-8"))

    def list(self, limit: int = 50) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        for path in sorted(self.runs_dir.glob("research_*.json"), key=lambda p: p.stat().st_mtime, reverse=True)[:max(1, limit)]:
            try:
                raw = json.loads(path.read_text(encoding="utf-8"))
                rows.append({k: raw.get(k) for k in ("id", "question", "state", "updated_at")})
            except Exception:
                continue
        return rows


def _clean_citations(value: Any) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    if not isinstance(value, list):
        return rows
    for item in value:
        if not isinstance(item, dict) or not item.get("url"):
            continue
        rows.append({"url": str(item["url"]), "title": str(item.get("title") or "")})
    return rows


def _dedupe_citations(rows: list[dict[str, str]]) -> list[dict[str, str]]:
    out: list[dict[str, str]] = []
    seen: set[str] = set()
    for row in rows:
        url = row.get("url", "")
        if not url or url in seen:
            continue
        seen.add(url)
        out.append(row)
    return out


def _json_object(raw: str) -> dict[str, Any]:
    text = str(raw).strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.I)
        text = re.sub(r"\s*```$", "", text)
    try:
        value = json.loads(text)
    except json.JSONDecodeError:
        a, b = text.find("{"), text.rfind("}")
        if a < 0 or b <= a:
            raise RuntimeError("Research agent did not return JSON")
        value = json.loads(text[a:b+1])
    if not isinstance(value, dict):
        raise RuntimeError("Research agent JSON must be an object")
    return value
