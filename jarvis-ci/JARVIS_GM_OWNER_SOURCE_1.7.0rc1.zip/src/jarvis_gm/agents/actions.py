from __future__ import annotations

from jarvis_gm.actions.base import Action


class RunMissionAction(Action):
    name="run_mission"; capability="agent.run"
    def __init__(self,director,context_provider=None):self.director=director;self.context_provider=context_provider
    def run(self, goal: str, use_web: bool = False):
        context=self.context_provider(goal) if self.context_provider else None
        report=self.director.run(goal,request_web=bool(use_web),context=context)
        return report.as_dict()
    def verify(self, output, **kwargs):
        state=(output or {}).get("state")
        return state=="verified", f"Mission state: {state}"


class DeepResearchAction(Action):
    name="deep_research"; capability="research.deep"
    def __init__(self, corps, context_provider=None):
        self.corps=corps; self.context_provider=context_provider
    def run(self, question: str, depth: str = "standard"):
        context=self.context_provider(question) if self.context_provider else None
        report=self.corps.run(question,depth=depth,context=context)
        if report.state == "blocked":
            raise PermissionError(report.synthesis or "Research Corps blocked")
        if report.state != "verified":
            raise RuntimeError(report.synthesis or f"Research Corps ended as {report.state}")
        return report.as_dict()
    def verify(self, output, **kwargs):
        state=str((output or {}).get("state", ""))
        citations=(output or {}).get("citations") or []
        synthesis=str((output or {}).get("synthesis") or "")
        ok=state=="verified" and bool(citations) and bool(synthesis.strip())
        return ok, f"Research state: {state}; sources={len(citations)}"
