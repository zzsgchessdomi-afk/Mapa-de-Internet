from __future__ import annotations

import base64
import json
import os
from urllib import request, error
from .base import AIProvider


class GeminiProvider(AIProvider):
    """Minimal dependency-free Gemini REST adapter.

    API key is supplied via GEMINI_API_KEY. No secret is persisted by this module.
    """

    def __init__(self, api_key: str | None = None, model: str | None = None, timeout: float = 45.0) -> None:
        self.api_key = api_key or os.getenv("GEMINI_API_KEY")
        self.model = model or os.getenv("JARVIS_GEMINI_MODEL", "gemini-3.8-flash")
        self.timeout = timeout

    @property
    def available(self) -> bool:
        return bool(self.api_key)

    def generate(self, prompt: str, *, system: str | None = None) -> str:
        if not self.api_key:
            raise RuntimeError("Gemini unavailable: GEMINI_API_KEY is not configured")

        url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.model}:generateContent"
        body: dict = {
            "contents": [{"role": "user", "parts": [{"text": prompt}]}],
            "generationConfig": {"temperature": 0.2},
        }
        if system:
            body["system_instruction"] = {"parts": [{"text": system}]}

        req = request.Request(
            url,
            data=json.dumps(body).encode("utf-8"),
            method="POST",
            headers={
                "Content-Type": "application/json",
                "x-goog-api-key": self.api_key,
            },
        )
        try:
            with request.urlopen(req, timeout=self.timeout) as resp:
                payload = json.loads(resp.read().decode("utf-8"))
        except error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"Gemini HTTP {exc.code}: {detail[:500]}") from exc
        except error.URLError as exc:
            raise RuntimeError(f"Gemini network error: {exc.reason}") from exc

        try:
            return "".join(
                part.get("text", "")
                for cand in payload.get("candidates", [])
                for part in cand.get("content", {}).get("parts", [])
            ).strip()
        except Exception as exc:
            raise RuntimeError("Gemini returned an unexpected response") from exc
    def grounded_search(self, prompt: str) -> dict:
        """Research with Gemini Interactions + Google Search grounding.

        The caller is responsible for permission/billing policy. This method only
        performs the provider request and returns text plus source metadata.
        """
        if not self.api_key:
            raise RuntimeError("Gemini unavailable: GEMINI_API_KEY is not configured")
        url = "https://generativelanguage.googleapis.com/v1/interactions"
        body = {"model": self.model, "input": prompt, "tools": [{"type": "google_search"}]}
        req = request.Request(url, data=json.dumps(body).encode("utf-8"), method="POST",
                              headers={"Content-Type": "application/json", "x-goog-api-key": self.api_key})
        try:
            with request.urlopen(req, timeout=self.timeout) as resp:
                payload = json.loads(resp.read().decode("utf-8"))
        except error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"Gemini grounded search HTTP {exc.code}: {detail[:500]}") from exc
        except error.URLError as exc:
            raise RuntimeError(f"Gemini grounded search network error: {exc.reason}") from exc
        chunks=[]; citations=[]; queries=[]
        for step in payload.get("steps", []) or []:
            if not isinstance(step, dict):
                continue
            if step.get("type") == "google_search_call":
                args=step.get("arguments") or {}
                queries.extend(str(x) for x in (args.get("queries") or []) if str(x))
            if step.get("type") == "model_output":
                for part in step.get("content", []) or []:
                    if not isinstance(part, dict):
                        continue
                    if isinstance(part.get("text"), str): chunks.append(part["text"])
                    for ann in part.get("annotations", []) or []:
                        if isinstance(ann, dict) and ann.get("type") == "url_citation" and ann.get("url"):
                            item={"url":str(ann["url"]),"title":str(ann.get("title") or "")}
                            if item not in citations: citations.append(item)
        text="".join(chunks).strip()
        if not text and isinstance(payload.get("output_text"), str): text=payload["output_text"].strip()
        if not text: raise RuntimeError("Gemini grounded search returned no text output")
        return {"text":text,"citations":citations,"queries":queries}

    def analyze_image(self, prompt: str, image_bytes: bytes, *, mime_type: str = "image/png") -> str:
        """Analyze one small inline image with Gemini Interactions API.

        Used only by opt-in screen grounding; this method never executes actions.
        """
        if not self.api_key:
            raise RuntimeError("Gemini unavailable: GEMINI_API_KEY is not configured")
        if len(image_bytes) > 18 * 1024 * 1024:
            raise ValueError("Inline image is too large; keep screen captures below 18 MB")
        url = "https://generativelanguage.googleapis.com/v1/interactions"
        body = {
            "model": self.model,
            "input": [
                {"type": "text", "text": prompt},
                {"type": "image", "data": base64.b64encode(image_bytes).decode("ascii"), "mime_type": mime_type},
            ],
            "response_format": {"type": "text", "mime_type": "application/json"},
        }
        req = request.Request(
            url, data=json.dumps(body).encode("utf-8"), method="POST",
            headers={"Content-Type": "application/json", "x-goog-api-key": self.api_key},
        )
        try:
            with request.urlopen(req, timeout=self.timeout) as resp:
                payload = json.loads(resp.read().decode("utf-8"))
        except error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"Gemini image HTTP {exc.code}: {detail[:500]}") from exc
        except error.URLError as exc:
            raise RuntimeError(f"Gemini image network error: {exc.reason}") from exc
        # Interactions responses expose output text in structured output items. Keep
        # tolerant parsing because the endpoint can add metadata around text items.
        if isinstance(payload.get("output_text"), str):
            return payload["output_text"].strip()
        chunks=[]
        for step in payload.get("steps", []) or []:
            if isinstance(step, dict) and step.get("type") == "model_output":
                for part in step.get("content", []) or []:
                    if isinstance(part, dict) and isinstance(part.get("text"), str): chunks.append(part["text"])
        for item in payload.get("outputs", payload.get("output", [])) or []:
            if isinstance(item, dict):
                if isinstance(item.get("text"), str): chunks.append(item["text"])
                content=item.get("content")
                if isinstance(content, list):
                    for part in content:
                        if isinstance(part, dict) and isinstance(part.get("text"), str): chunks.append(part["text"])
        result="".join(chunks).strip()
        if not result:
            raise RuntimeError("Gemini image analysis returned no text output")
        return result

