from __future__ import annotations

from .base import AIProvider
from .gemini import GeminiProvider


class ProviderRegistry:
    def __init__(self) -> None:
        self._providers: dict[str, AIProvider] = {"gemini": GeminiProvider()}
        self._active = "gemini"

    def register(self, name: str, provider: AIProvider) -> None:
        self._providers[name] = provider

    def set_active(self, name: str) -> None:
        if name not in self._providers:
            raise KeyError(name)
        self._active = name

    @property
    def active(self) -> AIProvider:
        return self._providers[self._active]

    @property
    def active_name(self) -> str:
        return self._active
