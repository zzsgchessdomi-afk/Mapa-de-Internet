from __future__ import annotations

from abc import ABC, abstractmethod


class AIProvider(ABC):
    @property
    @abstractmethod
    def available(self) -> bool: ...

    @abstractmethod
    def generate(self, prompt: str, *, system: str | None = None) -> str: ...
