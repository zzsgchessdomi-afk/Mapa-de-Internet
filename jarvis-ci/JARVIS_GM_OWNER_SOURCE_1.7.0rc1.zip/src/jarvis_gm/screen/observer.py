from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from typing import Any

from jarvis_gm.control.windows_backend import DesktopBackend
from .accessibility import AccessibilityScanner, NullAccessibilityScanner
from .capture import ScreenCapture, NullScreenCapture
from .models import EffectVerification, Rect, ScreenElement, ScreenSnapshot


@dataclass(slots=True)
class ObserverConfig:
    max_elements: int = 600
    include_image: bool = True


class ScreenObserver:
    def __init__(self, backend: DesktopBackend, accessibility: AccessibilityScanner | None = None,
                 capture: ScreenCapture | None = None, config: ObserverConfig | None = None) -> None:
        self.backend = backend
        self.accessibility = accessibility or NullAccessibilityScanner()
        self.capture = capture or NullScreenCapture()
        self.config = config or ObserverConfig()

    @staticmethod
    def _structural_fingerprint(elements: list[ScreenElement]) -> str:
        rows = [
            (x.name, x.control_type, x.automation_id, x.rect.left, x.rect.top, x.rect.right, x.rect.bottom, x.enabled)
            for x in elements if x.visible
        ]
        raw = json.dumps(rows, ensure_ascii=False, separators=(",", ":"), sort_keys=False)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def snapshot(self, include_image: bool | None = None) -> ScreenSnapshot:
        active = None
        width = height = 0
        try: active = self.backend.active_window()
        except Exception: pass
        try: width, height = self.backend.screen_size()
        except Exception: pass
        errors: list[str] = []
        elements: list[ScreenElement] = []
        uia_ok = False
        try:
            elements = self.accessibility.scan_active_window(self.backend, self.config.max_elements)
            uia_ok = bool(elements)
        except Exception as exc:
            errors.append(str(exc))

        image_png = None; visual_fp = None; capture_ok = False
        use_image = self.config.include_image if include_image is None else include_image
        if use_image:
            try:
                frame = self.capture.capture()
                image_png = frame.png; visual_fp = frame.fingerprint; capture_ok = True
            except Exception as exc:
                errors.append(str(exc))

        structural = self._structural_fingerprint(elements)
        # Prefix structure into visual fingerprint so verification can work even without Pillow.
        combined = hashlib.sha256(f"{structural}|{visual_fp or ''}".encode()).hexdigest()
        return ScreenSnapshot.create(
            active_handle=active.handle if active else None,
            active_title=active.title if active else "",
            screen_width=int(width), screen_height=int(height), elements=elements,
            image_png=image_png, visual_fingerprint=combined, uia_available=uia_ok,
            capture_available=capture_ok, error="; ".join(errors) if errors else None,
        )

    def element_at(self, snapshot: ScreenSnapshot, x: int, y: int) -> list[ScreenElement]:
        hits = [e for e in snapshot.elements if e.visible and e.enabled and e.rect.contains(x, y)]
        # Smallest controls are normally the most specific child in nested accessibility trees.
        return sorted(hits, key=lambda e: (not e.interactive, e.rect.area, -len(e.name)))


    @staticmethod
    def region_ahash(image_png: bytes | None, rect: Rect, size: int = 8) -> str | None:
        if not image_png:
            return None
        try:
            from PIL import Image  # type: ignore
            from io import BytesIO
            image = Image.open(BytesIO(image_png)).convert("L")
            box=(max(0,rect.left),max(0,rect.top),min(image.width,rect.right),min(image.height,rect.bottom))
            if box[2] <= box[0] or box[3] <= box[1]: return None
            crop=image.crop(box).resize((size,size))
            pixels=list(crop.get_flattened_data() if hasattr(crop, "get_flattened_data") else crop.getdata()); mean=sum(pixels)/len(pixels)
            bits=0
            for i,pixel in enumerate(pixels):
                if pixel >= mean: bits |= 1 << i
            return f"{bits:0{size*size//4}x}"
        except Exception:
            return None

    @staticmethod
    def hash_distance(a: str | None, b: str | None) -> int | None:
        if not a or not b or len(a) != len(b): return None
        try: return (int(a,16) ^ int(b,16)).bit_count()
        except Exception: return None

    @staticmethod
    def _rect_visual_difference(before_png: bytes | None, after_png: bytes | None, rect: Rect | None = None) -> float | None:
        if not before_png or not after_png:
            return None
        try:
            from PIL import Image, ImageChops, ImageStat  # type: ignore
            from io import BytesIO
            a = Image.open(BytesIO(before_png)).convert("RGB")
            b = Image.open(BytesIO(after_png)).convert("RGB")
            if a.size != b.size:
                return 1.0
            if rect is not None:
                box = (max(0, rect.left), max(0, rect.top), min(a.width, rect.right), min(a.height, rect.bottom))
                if box[2] > box[0] and box[3] > box[1]:
                    a = a.crop(box); b = b.crop(box)
            # Normalize mean absolute RGB difference to 0..1.
            stat = ImageStat.Stat(ImageChops.difference(a, b))
            return min(1.0, sum(stat.mean) / (3.0 * 255.0))
        except Exception:
            return None

    def verify_effect(self, before: ScreenSnapshot, after: ScreenSnapshot, target_rect: Rect | None = None,
                      min_visual_change: float = 0.006) -> EffectVerification:
        before_structure = self._structural_fingerprint(before.elements)
        after_structure = self._structural_fingerprint(after.elements)
        structural = before_structure != after_structure
        visual = self._rect_visual_difference(before.image_png, after.image_png, target_rect)
        visual_changed = visual is not None and visual >= min_visual_change
        active_changed = before.active_handle != after.active_handle or before.active_title != after.active_title
        observed = structural or visual_changed or active_changed
        confidence = 0.95 if structural or active_changed else (min(0.9, 0.55 + (visual or 0.0) * 8) if visual_changed else 0.2)
        reasons=[]
        if structural: reasons.append("UI Automation tree changed")
        if active_changed: reasons.append("active window changed")
        if visual_changed: reasons.append(f"target pixels changed ({visual:.3f})")
        if not reasons: reasons.append("no post-action effect was observable")
        return EffectVerification(observed, confidence, "; ".join(reasons), before.visual_fingerprint,
                                  after.visual_fingerprint, structural, visual)
