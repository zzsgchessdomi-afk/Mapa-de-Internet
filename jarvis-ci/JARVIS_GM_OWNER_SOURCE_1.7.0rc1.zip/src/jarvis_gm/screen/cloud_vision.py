from __future__ import annotations

from dataclasses import dataclass
import json
import re
from typing import Any

from jarvis_gm.providers.base import AIProvider
from .models import Rect, ScreenElement, ScreenSnapshot


@dataclass(slots=True)
class CloudGroundingResult:
    element: ScreenElement | None
    reason: str


class GeminiScreenGrounder:
    """Optional fallback for canvases/custom UI that do not expose Windows UI Automation.

    It is observation-only. The model can propose a rectangle; the local intent and
    permission systems still decide whether any action can happen.
    """

    def __init__(self, provider: AIProvider) -> None:
        self.provider = provider

    @staticmethod
    def _extract_json(text: str) -> dict[str, Any]:
        raw = text.strip()
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            m = re.search(r"\{.*\}", raw, re.S)
            if not m:
                raise ValueError("vision model did not return JSON")
            return json.loads(m.group(0))

    def ground(self, snapshot: ScreenSnapshot, nx: float, ny: float, voice_text: str | None = None) -> CloudGroundingResult:
        if not snapshot.image_png:
            return CloudGroundingResult(None, "no screenshot is available for cloud fallback")
        analyze = getattr(self.provider, "analyze_image", None)
        if not callable(analyze) or not self.provider.available:
            return CloudGroundingResult(None, "active AI provider does not support image analysis")
        prompt = f"""
You are the screen grounding module of a desktop assistant. Analyze ONLY the visible screenshot.
The user is pointing at normalized coordinate x={float(nx):.4f}, y={float(ny):.4f}.
Spoken reference: {voice_text or '(none)'}
Return JSON only with this exact schema:
{{"found":true|false,"label":"short visible object name","kind":"button|link|field|menu|tab|canvas_object|other","bbox":[left,top,right,bottom],"confidence":0.0,"reason":"brief evidence"}}
Coordinates in bbox MUST be normalized 0..1 relative to the screenshot. The pointed coordinate must lie inside or extremely near the bbox.
If the object is unclear, overlapping, occluded, or you cannot identify a specific target, return found=false and confidence <= 0.5. Do not invent hidden controls.
""".strip()
        text = analyze(prompt, snapshot.image_png, mime_type="image/png")
        data = self._extract_json(text)
        if not data.get("found"):
            return CloudGroundingResult(None, str(data.get("reason", "cloud vision could not resolve target")))
        bbox = data.get("bbox")
        if not isinstance(bbox, list) or len(bbox) != 4:
            return CloudGroundingResult(None, "vision model returned an invalid bbox")
        vals = [max(0.0, min(1.0, float(x))) for x in bbox]
        left = round(vals[0] * snapshot.screen_width); top = round(vals[1] * snapshot.screen_height)
        right = round(vals[2] * snapshot.screen_width); bottom = round(vals[3] * snapshot.screen_height)
        rect = Rect(left, top, right, bottom)
        if rect.area <= 0:
            return CloudGroundingResult(None, "vision model returned an empty bbox")
        px = round(float(nx) * max(1, snapshot.screen_width - 1)); py = round(float(ny) * max(1, snapshot.screen_height - 1))
        if not rect.contains(px, py, padding=24):
            return CloudGroundingResult(None, "vision proposal does not agree with the pointing coordinate")
        conf = max(0.0, min(0.90, float(data.get("confidence", 0.0))))
        if conf < 0.72:
            return CloudGroundingResult(None, f"cloud target confidence is too low ({conf:.2f})")
        label = str(data.get("label", "visual target")).strip()[:160]
        kind = str(data.get("kind", "other")).strip()[:80]
        element = ScreenElement(
            id=f"cloud-{snapshot.id[:8]}-{left}-{top}-{right}-{bottom}", name=label, control_type=kind,
            rect=rect, enabled=True, visible=True, interactive=kind in {"button","link","field","menu","tab"},
            source="gemini_vision", confidence=conf, metadata={"reason": str(data.get("reason", ""))[:300]},
        )
        return CloudGroundingResult(element, str(data.get("reason", "cloud visual grounding")))
