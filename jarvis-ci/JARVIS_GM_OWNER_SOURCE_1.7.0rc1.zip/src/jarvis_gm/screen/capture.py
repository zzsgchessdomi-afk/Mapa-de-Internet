from __future__ import annotations

from dataclasses import dataclass
from io import BytesIO
from typing import Protocol
import hashlib
import os

from .models import Rect


@dataclass(slots=True)
class CaptureFrame:
    png: bytes
    width: int
    height: int
    fingerprint: str


class ScreenCapture(Protocol):
    def capture(self, rect: Rect | None = None, window_handle: int | None = None) -> CaptureFrame: ...


class PillowScreenCapture:
    """Local-only screen capture. No image leaves the machine in this class."""

    def __init__(self) -> None:
        try:
            from PIL import ImageGrab  # type: ignore
        except ImportError as exc:
            raise RuntimeError("Pillow is required for local screen capture") from exc
        self.ImageGrab = ImageGrab

    @staticmethod
    def _fingerprint(image) -> str:
        # A small grayscale thumbnail is stable enough for post-action change detection.
        thumb = image.convert("L").resize((64, 36))
        return hashlib.sha256(thumb.tobytes()).hexdigest()

    def capture(self, rect: Rect | None = None, window_handle: int | None = None) -> CaptureFrame:
        if os.name != "nt":
            raise RuntimeError("Screen capture for JARVIS Phase 5 is currently Windows-only")
        bbox = None if rect is None else (rect.left, rect.top, rect.right, rect.bottom)
        # Phase 5 pointer coordinates use the primary Windows virtual surface exposed by
        # DesktopBackend.screen_size(). Capture the same coordinate space.
        image = self.ImageGrab.grab(bbox=bbox, all_screens=False)
        out = BytesIO(); image.save(out, format="PNG")
        return CaptureFrame(out.getvalue(), int(image.width), int(image.height), self._fingerprint(image))


class NullScreenCapture:
    def capture(self, rect: Rect | None = None, window_handle: int | None = None) -> CaptureFrame:
        raise RuntimeError("Local screen capture is unavailable")
