from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol
import hashlib
import os

from jarvis_gm.control.windows_backend import DesktopBackend
from .models import Rect, ScreenElement


INTERACTIVE_TYPES = {
    "Button", "CheckBox", "ComboBox", "Edit", "Hyperlink", "ListItem", "MenuItem",
    "RadioButton", "ScrollBar", "Slider", "Spinner", "SplitButton", "TabItem", "TreeItem",
}
INTERACTIVE_PATTERNS = {"Invoke", "SelectionItem", "Toggle", "ExpandCollapse", "Value", "RangeValue", "ScrollItem"}


class AccessibilityScanner(Protocol):
    def scan_active_window(self, backend: DesktopBackend, max_elements: int = 600) -> list[ScreenElement]: ...


def _stable_id(handle: int | None, automation_id: str, control_type: str, name: str, rect: Rect, index: int) -> str:
    raw = f"{handle}|{automation_id}|{control_type}|{name}|{rect.left},{rect.top},{rect.right},{rect.bottom}|{index}"
    return hashlib.sha1(raw.encode("utf-8", errors="replace")).hexdigest()[:20]


class PywinautoAccessibilityScanner:
    """Reads Windows UI Automation metadata without clicking anything."""

    def __init__(self) -> None:
        if os.name != "nt":
            raise RuntimeError("UI Automation scanner requires Windows")
        try:
            from pywinauto import Desktop  # type: ignore
        except ImportError as exc:
            raise RuntimeError("pywinauto is required for UI Automation screen understanding") from exc
        self.Desktop = Desktop

    @staticmethod
    def _patterns(wrapper) -> tuple[str, ...]:
        # pywinauto does not expose one cross-version convenience API for all supported patterns.
        # We safely infer common patterns from wrapper methods and control type.
        found: list[str] = []
        probes = {
            "Invoke": ("invoke", "click"),
            "SelectionItem": ("select",),
            "Toggle": ("toggle",),
            "ExpandCollapse": ("expand", "collapse"),
            "Value": ("set_edit_text", "set_text"),
            "RangeValue": ("set_value",),
            "ScrollItem": ("scroll_into_view",),
        }
        for pattern, attrs in probes.items():
            if any(callable(getattr(wrapper, a, None)) for a in attrs):
                found.append(pattern)
        return tuple(found)

    def scan_active_window(self, backend: DesktopBackend, max_elements: int = 600) -> list[ScreenElement]:
        active = backend.active_window()
        if active is None:
            return []
        desktop = self.Desktop(backend="uia")
        try:
            root = desktop.window(handle=int(active.handle))
            wrappers = [root.wrapper_object()] + list(root.descendants())
        except Exception as exc:
            raise RuntimeError(f"UI Automation could not inspect active window: {exc}") from exc

        out: list[ScreenElement] = []
        for index, wrapper in enumerate(wrappers[:max_elements]):
            try:
                info = wrapper.element_info
                r = wrapper.rectangle()
                rect = Rect(int(r.left), int(r.top), int(r.right), int(r.bottom))
                if rect.area <= 0:
                    continue
                name = str(getattr(info, "name", "") or "")
                control_type = str(getattr(info, "control_type", "") or "Custom")
                automation_id = str(getattr(info, "automation_id", "") or "")
                class_name = str(getattr(info, "class_name", "") or "")
                enabled = bool(getattr(info, "enabled", True))
                visible = bool(getattr(info, "visible", True))
                patterns = self._patterns(wrapper)
                interactive = control_type in INTERACTIVE_TYPES or bool(set(patterns) & INTERACTIVE_PATTERNS)
                out.append(ScreenElement(
                    id=_stable_id(active.handle, automation_id, control_type, name, rect, index),
                    name=name,
                    control_type=control_type,
                    rect=rect,
                    automation_id=automation_id,
                    class_name=class_name,
                    enabled=enabled,
                    visible=visible,
                    interactive=interactive,
                    patterns=patterns,
                    source="uia",
                    confidence=1.0,
                    metadata={"handle": int(active.handle), "depth_index": index},
                ))
            except Exception:
                continue
        return out


class NullAccessibilityScanner:
    def scan_active_window(self, backend: DesktopBackend, max_elements: int = 600) -> list[ScreenElement]:
        return []
