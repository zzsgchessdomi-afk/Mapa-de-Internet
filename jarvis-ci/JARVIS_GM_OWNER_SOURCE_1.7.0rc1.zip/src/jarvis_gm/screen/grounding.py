from __future__ import annotations

from dataclasses import dataclass
import math
import re
import time
import uuid

from .models import (
    GroundedTarget, GroundingCandidate, GroundingResult, GroundingStatus, Rect, ScreenElement, ScreenSnapshot,
)
from .observer import ScreenObserver
from .cloud_vision import GeminiScreenGrounder


@dataclass(slots=True)
class GroundingConfig:
    min_confidence: float = 0.72
    ambiguity_margin: float = 0.08
    target_ttl_s: float = 3.0
    point_padding_px: int = 6
    max_nearby_px: int = 80


class TargetRegistry:
    def __init__(self) -> None:
        self._targets: dict[str, GroundedTarget] = {}

    def put(self, target: GroundedTarget) -> str:
        self._targets[target.id] = target
        self.prune()
        return target.id

    def get(self, target_id: str) -> GroundedTarget:
        self.prune()
        target = self._targets.get(target_id)
        if target is None or target.expired:
            raise KeyError("Grounded target is missing or stale")
        return target

    def prune(self) -> None:
        now = time.time()
        self._targets = {k:v for k,v in self._targets.items() if now - v.created_at <= v.ttl_s}


class GroundingEngine:
    """Resolves deictic language and pointing into a concrete, inspectable UI target."""

    STOP_WORDS = {
        "haz", "click", "clic", "ahi", "ahí", "aqui", "aquí", "alli", "allí", "ese", "esa", "eso", "esto",
        "el", "la", "los", "las", "en", "sobre", "por", "favor", "there", "this", "that", "the", "on",
    }

    def __init__(self, observer: ScreenObserver, registry: TargetRegistry | None = None,
                 config: GroundingConfig | None = None, cloud: GeminiScreenGrounder | None = None,
                 cloud_allowed=None, observe_allowed=None) -> None:
        self.observer = observer
        self.registry = registry or TargetRegistry()
        self.cfg = config or GroundingConfig()
        self.cloud = cloud
        self.cloud_allowed = cloud_allowed or (lambda: False)
        self.observe_allowed = observe_allowed or (lambda: True)

    @staticmethod
    def _norm(text: str) -> str:
        return re.sub(r"\s+", " ", (text or "").casefold()).strip()

    def _query_terms(self, text: str | None) -> set[str]:
        if not text: return set()
        return {x for x in re.findall(r"[\wáéíóúüñ]+", self._norm(text)) if len(x) > 1 and x not in self.STOP_WORDS}

    def _score(self, e: ScreenElement, x: int, y: int, terms: set[str]) -> tuple[float, str]:
        contains = e.rect.contains(x, y, self.cfg.point_padding_px)
        distance = e.rect.distance_to(x, y)
        if not contains and distance > self.cfg.max_nearby_px:
            return 0.0, "too far from pointing coordinate"
        score = 0.46 if contains else max(0.05, 0.30 * (1 - distance / self.cfg.max_nearby_px))
        reasons = ["pointer inside control" if contains else f"near pointer ({distance:.0f}px)"]
        if e.interactive:
            score += 0.28; reasons.append("interactive control")
        if e.name.strip():
            score += 0.08; reasons.append("named control")
        if e.automation_id.strip(): score += 0.03
        if e.enabled and e.visible: score += 0.04
        if e.control_type in {"Button", "Hyperlink", "MenuItem", "TabItem", "ListItem"}: score += 0.05
        if terms:
            hay = self._norm(f"{e.name} {e.automation_id} {e.control_type}")
            matched = sum(1 for t in terms if t in hay)
            if matched:
                score += min(0.24, 0.10 * matched); reasons.append(f"matches {matched} spoken term(s)")
            else:
                score -= 0.08; reasons.append("does not match spoken object description")
        # Nested parent panes must not outrank a specific child simply because they contain the point.
        if e.rect.area > 800_000 and not e.interactive: score -= 0.12
        return max(0.0, min(0.99, score * e.confidence)), "; ".join(reasons)

    def ground_point(self, nx: float, ny: float, *, voice_text: str | None = None,
                     snapshot: ScreenSnapshot | None = None, point_confidence: float = 1.0) -> GroundingResult:
        if not bool(self.observe_allowed()):
            snap = snapshot or ScreenSnapshot.create(active_handle=None, active_title="", screen_width=0, screen_height=0)
            return GroundingResult(GroundingStatus.UNRESOLVED, "local screen understanding is disabled by user policy", snap.id)
        snap = snapshot or self.observer.snapshot(include_image=True)
        if snap.screen_width <= 0 or snap.screen_height <= 0:
            return GroundingResult(GroundingStatus.UNRESOLVED, "screen dimensions are unavailable", snap.id)
        x = max(0, min(snap.screen_width - 1, round(float(nx) * (snap.screen_width - 1))))
        y = max(0, min(snap.screen_height - 1, round(float(ny) * (snap.screen_height - 1))))
        terms = self._query_terms(voice_text)
        candidates=[]
        for e in self.observer.element_at(snap, x, y):
            score, reason = self._score(e, x, y, terms)
            score *= max(0.0, min(1.0, point_confidence))
            if score > 0: candidates.append(GroundingCandidate(e, score, reason))
        candidates.sort(key=lambda c: c.score, reverse=True)
        if not candidates or candidates[0].score < self.cfg.min_confidence:
            # Custom-rendered canvases often expose little or no UIA structure. Cloud vision is an
            # explicit opt-in fallback and can only propose a target; it cannot execute anything.
            if self.cloud is not None and bool(self.cloud_allowed()) and snap.image_png:
                try:
                    cloud = self.cloud.ground(snap, nx, ny, voice_text)
                except Exception as exc:
                    cloud = None
                    cloud_error = str(exc)
                else:
                    cloud_error = cloud.reason
                if cloud is not None and cloud.element is not None:
                    e = cloud.element
                    score = min(0.90, e.confidence * max(0.0, min(1.0, point_confidence)))
                    if score >= self.cfg.min_confidence:
                        cx, cy = e.center
                        target = GroundedTarget(
                            id=uuid.uuid4().hex, snapshot_id=snap.id, element_id=e.id, label=e.label, rect=e.rect,
                            x=cx, y=cy, confidence=score, source=e.source, reason=cloud.reason,
                            active_handle=snap.active_handle, ttl_s=self.cfg.target_ttl_s,
                            metadata={"control_type": e.control_type, "cloud_observation": True,
                                      "point": {"x": x, "y": y},
                                      "visual_patch": self.observer.region_ahash(snap.image_png, e.rect)},
                        )
                        self.registry.put(target)
                        return GroundingResult(GroundingStatus.GROUNDED, f"cloud visual fallback: {cloud.reason}", snap.id,
                                               target, [GroundingCandidate(e, score, cloud.reason)])
            if not candidates:
                reason = "no accessible UI element could be grounded under the pointing coordinate"
            else:
                reason = f"best grounded control confidence {candidates[0].score:.2f} is below {self.cfg.min_confidence:.2f}"
            if self.cloud is not None and bool(self.cloud_allowed()):
                reason += f"; cloud fallback unresolved: {locals().get('cloud_error', 'no visual target')}"
            return GroundingResult(GroundingStatus.UNRESOLVED, reason, snap.id, candidates=candidates[:5])
        top = candidates[0]
        if len(candidates) > 1 and top.score - candidates[1].score < self.cfg.ambiguity_margin:
            return GroundingResult(GroundingStatus.AMBIGUOUS,
                                   f"two screen targets are too close ({top.score:.2f} vs {candidates[1].score:.2f})",
                                   snap.id, candidates=candidates[:5])
        cx, cy = top.element.center
        target = GroundedTarget(
            id=uuid.uuid4().hex, snapshot_id=snap.id, element_id=top.element.id, label=top.element.label,
            rect=top.element.rect, x=cx, y=cy, confidence=top.score, source=top.element.source,
            reason=top.reason, active_handle=snap.active_handle, ttl_s=self.cfg.target_ttl_s,
            metadata={"control_type": top.element.control_type, "automation_id": top.element.automation_id,
                      "patterns": list(top.element.patterns), "point": {"x": x, "y": y},
                      "visual_patch": self.observer.region_ahash(snap.image_png, top.element.rect)},
        )
        self.registry.put(target)
        return GroundingResult(GroundingStatus.GROUNDED, top.reason, snap.id, target, candidates[:5])

    def revalidate(self, target: GroundedTarget) -> tuple[bool, str, ScreenSnapshot]:
        if target.expired:
            snap = self.observer.snapshot(include_image=False)
            return False, "grounded target expired before execution", snap
        need_image = target.source == "gemini_vision"
        snap = self.observer.snapshot(include_image=need_image)
        if target.active_handle is not None and snap.active_handle != target.active_handle:
            return False, "active window changed after grounding", snap
        hits = self.observer.element_at(snap, target.x, target.y)
        if target.source == "gemini_vision":
            before_hash = target.metadata.get("visual_patch")
            now_hash = self.observer.region_ahash(snap.image_png, target.rect)
            distance = self.observer.hash_distance(before_hash, now_hash)
            if distance is not None and distance > 18:
                return False, f"visual target changed too much before execution (hash distance {distance}/64)", snap
            if before_hash and now_hash:
                return True, f"fresh visual target remains stable (hash distance {distance}/64)", snap
            return False, "visual target could not be re-observed before execution", snap
        if target.element_id:
            exact = next((e for e in hits if e.id == target.element_id), None)
            if exact:
                return True, "same UI Automation element remains under target", snap
            # Dynamic web UIs may reconstruct IDs. Fall back to semantic identity + overlap at same point.
            want_name = self._norm(target.label)
            control_type = str(target.metadata.get("control_type", ""))
            similar = [e for e in hits if self._norm(e.label) == want_name and (not control_type or e.control_type == control_type)]
            if similar:
                return True, "semantically equivalent control remains under target", snap
            return False, "target control moved or disappeared after grounding", snap
        return bool(hits), "target coordinate still maps to an accessible control" if hits else "target no longer maps to a control", snap
