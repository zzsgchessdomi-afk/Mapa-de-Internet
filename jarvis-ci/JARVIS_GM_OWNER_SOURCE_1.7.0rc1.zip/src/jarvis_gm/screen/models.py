from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any
import math
import time
import uuid


@dataclass(frozen=True, slots=True)
class Rect:
    left: int
    top: int
    right: int
    bottom: int

    @property
    def width(self) -> int:
        return max(0, self.right - self.left)

    @property
    def height(self) -> int:
        return max(0, self.bottom - self.top)

    @property
    def area(self) -> int:
        return self.width * self.height

    @property
    def center(self) -> tuple[int, int]:
        return (self.left + self.width // 2, self.top + self.height // 2)

    def contains(self, x: int, y: int, padding: int = 0) -> bool:
        return self.left - padding <= x < self.right + padding and self.top - padding <= y < self.bottom + padding

    def distance_to(self, x: int, y: int) -> float:
        cx, cy = self.center
        return math.hypot(cx - x, cy - y)

    def as_dict(self) -> dict[str, int]:
        return asdict(self)


@dataclass(slots=True)
class ScreenElement:
    id: str
    name: str
    control_type: str
    rect: Rect
    automation_id: str = ""
    class_name: str = ""
    enabled: bool = True
    visible: bool = True
    interactive: bool = False
    patterns: tuple[str, ...] = ()
    source: str = "uia"
    confidence: float = 1.0
    parent_id: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def label(self) -> str:
        return self.name.strip() or self.automation_id.strip() or self.control_type

    @property
    def center(self) -> tuple[int, int]:
        return self.rect.center

    def as_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["rect"] = self.rect.as_dict()
        return data


@dataclass(slots=True)
class ScreenSnapshot:
    id: str
    timestamp: float
    active_handle: int | None
    active_title: str
    screen_width: int
    screen_height: int
    elements: list[ScreenElement] = field(default_factory=list)
    image_png: bytes | None = None
    visual_fingerprint: str | None = None
    uia_available: bool = False
    capture_available: bool = False
    error: str | None = None

    @classmethod
    def create(cls, **kwargs: Any) -> "ScreenSnapshot":
        return cls(id=uuid.uuid4().hex, timestamp=time.time(), **kwargs)

    def element(self, element_id: str) -> ScreenElement | None:
        return next((x for x in self.elements if x.id == element_id), None)

    def compact(self, limit: int = 80) -> dict[str, Any]:
        return {
            "id": self.id,
            "timestamp": self.timestamp,
            "active_handle": self.active_handle,
            "active_title": self.active_title,
            "screen": {"width": self.screen_width, "height": self.screen_height},
            "uia_available": self.uia_available,
            "capture_available": self.capture_available,
            "visual_fingerprint": self.visual_fingerprint,
            "elements": [x.as_dict() for x in self.elements[:limit]],
            "error": self.error,
        }


class GroundingStatus(str, Enum):
    GROUNDED = "grounded"
    AMBIGUOUS = "ambiguous"
    UNRESOLVED = "unresolved"


@dataclass(slots=True)
class GroundedTarget:
    id: str
    snapshot_id: str
    element_id: str | None
    label: str
    rect: Rect
    x: int
    y: int
    confidence: float
    source: str
    reason: str
    active_handle: int | None
    created_at: float = field(default_factory=time.time)
    ttl_s: float = 3.0
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def expired(self) -> bool:
        return time.time() - self.created_at > self.ttl_s

    def as_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["rect"] = self.rect.as_dict()
        data["expired"] = self.expired
        return data


@dataclass(slots=True)
class GroundingCandidate:
    element: ScreenElement
    score: float
    reason: str

    def as_dict(self) -> dict[str, Any]:
        return {"element": self.element.as_dict(), "score": self.score, "reason": self.reason}


@dataclass(slots=True)
class GroundingResult:
    status: GroundingStatus
    reason: str
    snapshot_id: str
    target: GroundedTarget | None = None
    candidates: list[GroundingCandidate] = field(default_factory=list)

    def as_dict(self) -> dict[str, Any]:
        return {
            "status": self.status.value,
            "reason": self.reason,
            "snapshot_id": self.snapshot_id,
            "target": self.target.as_dict() if self.target else None,
            "candidates": [x.as_dict() for x in self.candidates],
        }


@dataclass(slots=True)
class EffectVerification:
    observed: bool
    confidence: float
    reason: str
    before_fingerprint: str | None = None
    after_fingerprint: str | None = None
    structural_change: bool = False
    visual_change: float | None = None

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)
