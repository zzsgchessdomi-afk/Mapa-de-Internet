from __future__ import annotations

from pathlib import Path
from io import BytesIO
import tempfile
import time

from .runtime import build_phase4_runtime, build_phase5_runtime, build_phase6_runtime, build_phase7_runtime, build_phase8_runtime, build_infinity1_runtime, build_infinity2_runtime, build_infinity3_runtime, build_infinity4_runtime, build_infinity5_runtime, build_infinity6_runtime, build_infinity7_runtime
from .control.simulated_backend import SimulatedDesktopBackend
from .control.windows_backend import WindowInfo
from .core.models import GoalState, ActionRequest
from .intent.context import ContextClassifier, ContextProvider
from .intent.engine import IntentEngine
from .intent.models import DecisionStatus
from .perception.bus import PerceptionBus
from .perception.events import PerceptionEvent
from .perception.voice.wake_gate import WakeGate
from .screen.capture import CaptureFrame
from .screen.models import Rect, ScreenElement
from .screen.observer import ScreenObserver
from .perception.vision.gesture_engine import GestureConfig, GestureEngine
from .perception.vision.models import HandObservation, Point3, VisionFrame



class _FixedScanner:
    def __init__(self, elements): self.elements = list(elements)
    def scan_active_window(self, backend, max_elements=600): return list(self.elements)[:max_elements]


class _SequenceCapture:
    def __init__(self, variants): self.variants=list(variants); self.i=0
    def capture(self, rect=None, window_handle=None):
        try:
            from PIL import Image, ImageDraw
        except ImportError as exc:
            raise RuntimeError("Pillow missing from Phase 5 install") from exc
        value=self.variants[min(self.i, len(self.variants)-1)]; self.i+=1
        image=Image.new("RGB", (1920,1080), "white")
        if value:
            ImageDraw.Draw(image).rectangle((280,250,430,330), fill="black")
        out=BytesIO(); image.save(out, format="PNG")
        return CaptureFrame(out.getvalue(), 1920,1080, f"selftest-{value}")


def _screen_button():
    return ScreenElement("save", "Guardar", "Button", Rect(300,250,420,310), automation_id="save",
                         interactive=True, patterns=("Invoke",))

def _hand(gesture: str = "Open_Palm", pinch: bool = False) -> HandObservation:
    pts = [Point3(0.5, 0.8) for _ in range(21)]
    pts[0] = Point3(0.5, 0.8); pts[4] = Point3(0.505, 0.305) if pinch else Point3(0.20, 0.35)
    pts[5] = Point3(0.42, 0.58); pts[6] = Point3(0.47, 0.52); pts[8] = Point3(0.50, 0.30)
    pts[10] = Point3(0.52, 0.52); pts[12] = Point3(0.52, 0.25); pts[14] = Point3(0.57, 0.54)
    pts[16] = Point3(0.57, 0.28); pts[17] = Point3(0.62, 0.60); pts[18] = Point3(0.62, 0.56); pts[20] = Point3(0.62, 0.31)
    return HandObservation("Right", tuple(pts), gesture, 0.95)


def _event(kind: str, payload=None, confidence=1.0, ts=None) -> PerceptionEvent:
    return PerceptionEvent(kind, "vision.hand" if kind.startswith("gesture.") else "voice", payload or {}, confidence, ts or time.time())


def _wait(fn, timeout=1.0) -> bool:
    end = time.time() + timeout
    while time.time() < end:
        if fn(): return True
        time.sleep(.01)
    return fn()


def run_self_test() -> tuple[bool, list[str]]:
    checks=[]
    with tempfile.TemporaryDirectory() as d:
        root=Path(d); backend=SimulatedDesktopBackend(); rt=build_phase4_runtime(root, backend)
        g=rt.orchestrator.run("estado"); checks.append(f"core_status={'PASS' if g.state==GoalState.VERIFIED else 'FAIL'}")
        g=rt.orchestrator.run("recuerda: selftest = persisted"); checks.append(f"memory={'PASS' if g.state==GoalState.VERIFIED and rt.orchestrator.memory.recall('selftest')=='persisted' else 'FAIL'}")
        g=rt.orchestrator.run("nota selftest: verified content"); checks.append(f"workspace={'PASS' if g.state==GoalState.VERIFIED and (root/'workspace'/'selftest.txt').exists() else 'FAIL'}")
        denied=rt.orchestrator.run("mueve el cursor a 10, 20"); checks.append(f"operator_default_deny={'PASS' if denied.state!=GoalState.VERIFIED and backend.cursor==(0,0) else 'FAIL'}")
        rt.policy.set("input.control",True); moved=rt.orchestrator.run("mueve el cursor a 10, 20"); checks.append(f"operator_cursor={'PASS' if moved.state==GoalState.VERIFIED and backend.cursor==(10,20) else 'FAIL'}")
        rt.kill_switch.engage(); blocked=rt.orchestrator.run("mueve el cursor a 20, 30").state!=GoalState.VERIFIED; rt.kill_switch.reset(); checks.append(f"kill_switch={'PASS' if blocked and backend.cursor==(10,20) else 'FAIL'}")
        rt.policy.set("app.launch",True); opened=rt.orchestrator.run("abre notepad"); checks.append(f"app_registry={'PASS' if opened.state==GoalState.VERIFIED and backend.opened_apps else 'FAIL'}")
        rt.policy.set("browser.open",True); browsed=rt.orchestrator.run("abre https://example.com"); checks.append(f"browser={'PASS' if browsed.state==GoalState.VERIFIED and backend.opened_urls else 'FAIL'}")
        rt.policy.set("filesystem.write",True); rt.policy.set("filesystem.read",True); folder=root/'workspace'/'phase4'; made=rt.orchestrator.run(f"crea carpeta: {folder}"); checks.append(f"file_scope={'PASS' if made.state==GoalState.VERIFIED and folder.is_dir() else 'FAIL'}")
        bus=PerceptionBus(); seen=[]; bus.subscribe(seen.append); bus.publish(PerceptionEvent("selftest","selftest")); checks.append(f"perception_bus={'PASS' if len(seen)==1 else 'FAIL'}")
        ge=GestureEngine(GestureConfig(arm_dwell_s=0.1)); ge.process(VisionFrame((_hand(),),1.0)); ev=ge.process(VisionFrame((_hand(),),1.2)); checks.append(f"gesture_arm={'PASS' if ge.armed and any(x.type=='gesture.armed' for x in ev) else 'FAIL'}")
        ev=ge.process(VisionFrame((_hand('None',pinch=True),),1.3)); checks.append(f"gesture_pinch={'PASS' if any(x.type=='gesture.pinch_start' for x in ev) else 'FAIL'}")
        gate=WakeGate(("jarvis",)); wake=gate.process("Jarvis estado",5.0); checks.append(f"wake_gate={'PASS' if wake.kind=='command' and wake.text=='estado' else 'FAIL'}")

        labels=ContextClassifier().classify_title("YouTube - Google Chrome")
        checks.append(f"context_multilabel={'PASS' if labels.get('browser',0)>.9 and labels.get('media',0)>.9 else 'FAIL'}")
        backend.windows[0]=WindowInfo(1,"YouTube - Google Chrome",100,100,900,700)
        engine=IntentEngine(ContextProvider(backend)); engine.gesture_armed=True
        amb=engine.process(_event("gesture.swipe_right", {"dx":.3,"duration":.2}, .98))
        checks.append(f"ambiguity_hold={'PASS' if amb.status==DecisionStatus.AMBIGUOUS else 'FAIL'}")
        engine.process(_event("voice.command", {"text":"modo medios"}))
        resolved=engine.process(_event("gesture.swipe_right", {"dx":.3,"duration":.2}, .98))
        checks.append(f"context_override={'PASS' if resolved.status==DecisionStatus.EXECUTE and resolved.selected and resolved.selected.name=='media.seek_right' else 'FAIL'}")
        no_target=engine.process(_event("voice.command", {"text":"haz clic ahí"}))
        checks.append(f"deictic_without_target={'PASS' if no_target.status==DecisionStatus.AMBIGUOUS else 'FAIL'}")

        # Bridge-level multimodal fusion and audited execution.
        backend.windows[0]=WindowInfo(1,"JARVIS Test Window",100,100,900,700)
        rt.start_bridge(); t=time.time()
        rt.perception.bus.publish(_event("gesture.armed", ts=t))
        rt.perception.bus.publish(_event("gesture.point", {"x":.5,"y":.25}, .98, t+.02))
        rt.perception.bus.publish(_event("voice.command", {"text":"haz clic ahí"}, .99, t+.15))
        fused=_wait(lambda: abs(backend.cursor[0]-960)<=1 and abs(backend.cursor[1]-270)<=1)
        checks.append(f"multimodal_fusion={'PASS' if fused and not backend.buttons else 'FAIL'}")

        # Voice goals still go through normal planner/executor/verifier, not around Intent Core.
        rt.perception.bus.publish(_event("voice.command", {"text":"mueve el cursor a 123, 234"}))
        voice_ok=_wait(lambda: backend.cursor==(123,234)); checks.append(f"voice_to_action={'PASS' if voice_ok else 'FAIL'}")
        rt.bridge.stop()
        audit=rt.orchestrator.memory.recent_events(50)
        checks.append(f"intent_audit={'PASS' if any(x['event_type'].startswith('intent.') for x in audit) else 'FAIL'}")
        checks.append(f"intent_config_owned={'PASS' if (root/'intent_config.json').exists() else 'FAIL'}")

        # Phase 5: semantic screen grounding and verified click.
        phase5_root=root/"phase5"; b5=SimulatedDesktopBackend()
        obs=ScreenObserver(b5, _FixedScanner([_screen_button()]), _SequenceCapture([0,0,0,1]))
        rt5=build_phase5_runtime(phase5_root, b5, obs)
        checks.append(f"screen_local_default={'PASS' if rt5.policy.is_allowed('screen.observe') else 'FAIL'}")
        checks.append(f"screen_cloud_default_off={'PASS' if not rt5.policy.is_allowed('screen.cloud') else 'FAIL'}")
        grounded=rt5.grounding.ground_point(360/1919,280/1079,voice_text='haz clic en ese botón guardar',point_confidence=.99)
        checks.append(f"screen_grounding={'PASS' if grounded.target and grounded.target.label=='Guardar' else 'FAIL'}")
        rt5.policy.set('input.control',True); rt5.start_bridge(); t5=time.time()
        rt5.perception.bus.publish(_event('gesture.armed',ts=t5))
        rt5.perception.bus.publish(_event('gesture.point',{'x':360/1919,'y':280/1079},.99,t5+.01))
        rt5.perception.bus.publish(_event('voice.command',{'text':'haz clic en ese botón guardar'},.99,t5+.10))
        click_ok=_wait(lambda: any(x['event_type']=='interaction.verified' and x['payload'].get('action')=='grounded_click' and x['payload'].get('ok') for x in rt5.orchestrator.memory.recent_events(60)))
        checks.append(f"grounded_click_effect={'PASS' if click_ok else 'FAIL'}")
        rt5.bridge.stop()

        # Phase 6: structured continuity, project scope and explicit user control.
        phase6_root=root/"phase6"; b6=SimulatedDesktopBackend(); rt6=build_phase6_runtime(phase6_root,b6)
        created=rt6.orchestrator.run("nuevo proyecto Jarvis")
        checks.append(f"project_create={'PASS' if created.state==GoalState.VERIFIED and rt6.memory_manager.active_project and rt6.memory_manager.active_project.name=='Jarvis' else 'FAIL'}")
        task=rt6.orchestrator.run("tarea: probar instalador en Windows")
        checks.append(f"task_memory={'PASS' if task.state==GoalState.VERIFIED and rt6.memory_manager.store.pending_tasks(rt6.memory_manager.active_project.id) else 'FAIL'}")
        decision=rt6.orchestrator.run("decisión: mantener los datos bajo control del usuario")
        checks.append(f"decision_memory={'PASS' if decision.state==GoalState.VERIFIED and rt6.memory_manager.resume().decisions else 'FAIL'}")
        remembered=rt6.orchestrator.run("recuerda: el núcleo debe seguir funcionando sin membresía de ChatGPT")
        searched=rt6.orchestrator.run("qué recuerdas de membresía ChatGPT?")
        found=bool(searched.results and any("membresía" in x.get("content","") for x in searched.results[0].output))
        checks.append(f"structured_retrieval={'PASS' if remembered.state==GoalState.VERIFIED and searched.state==GoalState.VERIFIED and found else 'FAIL'}")
        resumed=rt6.orchestrator.run("continúa lo de ayer")
        rdata=resumed.results[0].output if resumed.results else {}
        checks.append(f"resume_snapshot={'PASS' if resumed.state==GoalState.VERIFIED and rdata.get('project',{}).get('name')=='Jarvis' and rdata.get('pending_tasks') else 'FAIL'}")
        from .memory.models import MemoryKind
        episodes=rt6.memory_manager.store.recent_memories(project_id=rt6.memory_manager.active_project.id,kind=MemoryKind.EPISODE,limit=20,include_global=False)
        checks.append(f"automatic_episode={'PASS' if any('Goal:' in x.content for x in episodes) else 'FAIL'}")
        cp=rt6.memory_manager.store.latest_checkpoint(rt6.memory_manager.active_project.id)
        checks.append(f"checkpoint={'PASS' if cp and cp.get('state',{}).get('goal_id') else 'FAIL'}")
        original=rt6.memory_manager.remember("build number one",title="Build")
        corrected=rt6.memory_manager.store.correct_memory(original.id,"build number two")
        checks.append(f"memory_correction={'PASS' if rt6.memory_manager.store.get_memory(original.id) is None and corrected.parent_id==original.id else 'FAIL'}")
        forgotten=rt6.memory_manager.remember("temporary secret",title="Temporary")
        rt6.memory_manager.store.forget_memory(forgotten.id)
        checks.append(f"memory_forget={'PASS' if rt6.memory_manager.store.get_memory(forgotten.id) is None else 'FAIL'}")
        before=len(rt6.memory_manager.store.recent_memories(kind=MemoryKind.EPISODE,limit=100))
        rt6.policy.set("memory.write",False); rt6.orchestrator.run("estado")
        after=len(rt6.memory_manager.store.recent_memories(kind=MemoryKind.EPISODE,limit=100))
        checks.append(f"memory_write_off={'PASS' if before==after else 'FAIL'}")
        rt6.policy.set("memory.write",True); rt6.policy.set("memory.read",False); noctx=rt6.orchestrator.run("estado")
        noctx_events=[x for x in rt6.orchestrator.memory.recent_events(30) if x['goal_id']==noctx.id]
        checks.append(f"memory_read_off={'PASS' if not any(x['event_type']=='memory.context' for x in noctx_events) else 'FAIL'}")
        checks.append(f"memory_manage_default_deny={'PASS' if not rt6.policy.is_allowed('memory.manage') else 'FAIL'}")

        # Phase 7: bounded specialists + constrained reusable skills.
        class _Phase7Provider:
            available=True
            def generate(self,prompt,*,system=None):
                import json
                if prompt.startswith("Decompose the user's mission"):
                    return json.dumps({"tasks":[
                        {"id":"t1","role":"planner","objective":"plan","depends_on":[],"web_research":False},
                        {"id":"t2","role":"reviewer","objective":"review","depends_on":["t1"],"web_research":False}]})
                if "Create a compact research plan" in prompt:
                    return json.dumps({"queries":["official docs selftest"]})
                if "Analyze the evidence" in prompt:
                    return json.dumps({"claims":[{"claim":"supported","support_urls":["https://example.com/docs"],"confidence":.9,"status":"supported"}],"gaps":[]})
                if "Act as a skeptical reviewer" in prompt:
                    return json.dumps({"contradictions":[],"gaps":[]})
                if "Synthesize a concise research report" in prompt:
                    return "verified synthesis (https://example.com/docs)"
                if "Design ONE reusable JARVIS skill" in prompt:
                    return json.dumps({"name":"Selftest Note","description":"write a note","inputs":{"filename":{"type":"string"},"content":{"type":"string"}},
                                       "steps":[{"action":"create_note","args":{"filename":"{{filename}}","content":"{{content}}"}}],"confidence":.95})
                if prompt.startswith("Synthesize the mission work"): return "synthesis"
                return "work product"
            def grounded_search(self,prompt):
                return {"text":"evidence","queries":["official docs"],"citations":[{"title":"Official","url":"https://example.com/docs"}]}

        phase7_root=root/"phase7"; b7=SimulatedDesktopBackend(); rt7=build_phase7_runtime(phase7_root,b7)
        fake=_Phase7Provider(); rt7.providers.register("selftest",fake); rt7.providers.set_active("selftest")
        caps=("agent.run","research.web","research.deep","skill.learn","skill.manage","skill.execute")
        checks.append(f"phase7_default_deny={'PASS' if all(not rt7.policy.is_allowed(x) for x in caps) else 'FAIL'}")
        rt7.policy.set("skill.learn",True); learned=rt7.orchestrator.run("aprende: crear nota")
        learned_skill=rt7.skill_store.get("Selftest Note")
        checks.append(f"skill_compile={'PASS' if learned.state==GoalState.VERIFIED and learned_skill and learned_skill.status.value=='validated' else 'FAIL'}")
        rt7.policy.set("skill.manage",True); enabled=rt7.orchestrator.run("habilita skill Selftest Note")
        rt7.policy.set("skill.execute",True); ran=rt7.orchestrator.run('ejecuta skill Selftest Note: {"filename":"phase7.txt","content":"ok"}')
        checks.append(f"skill_owner_enable={'PASS' if enabled.state==GoalState.VERIFIED and ran.state==GoalState.VERIFIED and (phase7_root/'workspace'/'phase7.txt').exists() else 'FAIL'}")
        forged=rt7.skill_store.get("Selftest Note"); forged.required_capabilities=("safe.read",); rt7.skill_store.save(forged)
        validation=rt7.skill_forge.validate_existing("Selftest Note")
        checks.append(f"skill_live_capabilities={'PASS' if validation.required_capabilities==('workspace.write',) and validation.warnings else 'FAIL'}")
        rt7.policy.set("agent.run",True); before=(list(b7.opened_apps),list(b7.opened_urls),b7.cursor); mission=rt7.orchestrator.run("misión: revisar arquitectura")
        after=(list(b7.opened_apps),list(b7.opened_urls),b7.cursor)
        checks.append(f"agent_bounded={'PASS' if mission.state==GoalState.VERIFIED and before==after else 'FAIL'}")
        logs=list((phase7_root/'mission_runs').glob('mission_*.json'))
        checks.append(f"mission_audit={'PASS' if logs else 'FAIL'}")
        rt7.policy.set("research.web",True); rt7.policy.set("research.deep",True)
        research_before=(list(b7.opened_apps),list(b7.opened_urls),b7.cursor)
        research=rt7.orchestrator.run("investiga: procedimiento de selftest")
        research_after=(list(b7.opened_apps),list(b7.opened_urls),b7.cursor)
        research_out=research.results[0].output if research.results else {}
        checks.append(f"research_corps={'PASS' if research.state==GoalState.VERIFIED and research_out.get('citations') and research_before==research_after else 'FAIL'}")
        checks.append(f"research_provenance={'PASS' if research_out.get('claims') and research_out['claims'][0].get('support_urls')==['https://example.com/docs'] else 'FAIL'}")
        preflight=rt7.skill_forge.preflight(rt7.skill_store.get("Selftest Note"))
        checks.append(f"skill_preflight={'PASS' if preflight.get('ok') and all(not x.get('executes') for x in preflight.get('steps',[])) else 'FAIL'}")

        # Phase 8: recovery, owner backups, diagnostics and clean shutdown.
        phase8_root=root/"phase8"; b8=SimulatedDesktopBackend(); rt8=build_phase8_runtime(phase8_root,b8)
        checks.append(f"phase8_safe_first_start={'PASS' if not rt8.recovery_state.safe_mode else 'FAIL'}")
        rt8.policy.set("input.control",True)
        backup_path=root/"phase8-owner.jarvisbackup"; rt8.backup.create(backup_path)
        backup_validation=rt8.backup.validate(backup_path)
        checks.append(f"backup_integrity={'PASS' if backup_validation.ok and backup_validation.files>0 else 'FAIL'}")
        diag=rt8.diagnostics.run(rt8)
        hw=diag.get("hardware_acceptance",{})
        checks.append(f"hardware_truthfulness={'PASS' if hw.get('status')=='pending_physical_windows_test' and hw.get('camera')=='not_claimed' else 'FAIL'}")

        # RC5 Mobile Sovereignty: owner-paired phone bridge, anti-theft telemetry and system-owned auth.
        mobile_caps=("mobile.read","mobile.location","mobile.control","mobile.security","mobile.messaging","mobile.contacts","mobile.relay")
        checks.append(f"mobile_default_deny={'PASS' if all(not rt8.policy.is_allowed(x) for x in mobile_caps) else 'FAIL'}")
        checks.append(f"mobile_relay_manual_start={'PASS' if not rt8.mobile.relay_running else 'FAIL'}")
        dev,secret=rt8.mobile.manager.devices.pair("Selftest Phone",device_id="selftest-phone",relay_url="https://127.0.0.1:8765",cert_fingerprint="00"*32)
        registry=(phase8_root/'mobile'/'devices.json').read_text(encoding='utf-8')
        checks.append(f"mobile_secret_not_plaintext={'PASS' if secret not in registry and rt8.mobile.manager.devices.secret(dev.id)==secret else 'FAIL'}")
        from .mobile.models import MobileHeartbeat, MobileCommandKind
        rt8.mobile.manager.commands.record_heartbeat(MobileHeartbeat(dev.id,time.time(),battery_percent=73,network="selftest",latitude=1.25,longitude=2.5,accuracy_m=4.0,anti_theft_enabled=True))
        loc=rt8.mobile.manager.last_location(dev.id)
        checks.append(f"mobile_owner_location={'PASS' if loc.get('available') and loc.get('device_id')==dev.id and loc.get('latitude')==1.25 else 'FAIL'}")
        auth_cmd=rt8.mobile.manager.queue(dev.id,MobileCommandKind.REQUEST_AUTH,{})
        auth_payload=str(auth_cmd.as_dict()).lower()
        checks.append(f"mobile_system_auth_only={'PASS' if auth_cmd.kind==MobileCommandKind.REQUEST_AUTH and 'pin' not in auth_payload and 'password' not in auth_payload else 'FAIL'}")
        from .mobile.actions import _mobile_command_verify
        checks.append(f"mobile_requires_phone_confirmation={'PASS' if not _mobile_command_verify(auth_cmd.as_dict())[0] else 'FAIL'}")

        # RC5 three jumps: continuous local perception, multimodal fusion and shadow-world skill practice.
        checks.append(f"sentinel_default_off={'PASS' if not rt8.policy.is_allowed('perception.continuous') and not rt8.sentinel.running else 'FAIL'}")
        rt8.policy.set('perception.continuous',True); scene=rt8.sentinel.poll_once()
        checks.append(f"sentinel_local_scene={'PASS' if scene is not None and scene.fingerprint and not hasattr(scene,'image_png') else 'FAIL'}")
        rt8.perception.bus.publish(PerceptionEvent('voice.command','voice',{'text':'haz clic ahí'},timestamp=time.time()))
        fused=rt8.fusion.resolve()
        checks.append(f"fusion_ambiguity_guard={'PASS' if fused.ambiguous and 'deictic_voice_without_fresh_point' in fused.contradictions else 'FAIL'}")
        checks.append(f"fusion_cloud_default_off={'PASS' if rt8.fusion.cloud_summary() is None else 'FAIL'}")
        from .skills.models import SkillDefinition, SkillStep
        practice_skill=SkillDefinition('Selftest Shadow','shadow only',steps=[SkillStep('status',{})])
        practice=rt8.skill_lab.practice(practice_skill)
        checks.append(f"skill_lab_shadow={'PASS' if practice.ok and len(practice.trials)==3 else 'FAIL'}")
        checks.append(f"skill_lab_no_real_authority={'PASS' if all(t.ok for t in practice.trials) and not b8.opened_apps and not b8.opened_urls else 'FAIL'}")
        rt8.clean_shutdown()
        import json as _json
        runtime_state=_json.loads((phase8_root/'runtime_state.json').read_text(encoding='utf-8'))
        checks.append(f"clean_shutdown_marker={'PASS' if runtime_state.get('status')=='clean' else 'FAIL'}")
        # Simulate a crash: start, grant dangerous permission, omit clean shutdown, then restart.
        rt8a=build_phase8_runtime(phase8_root,b8); rt8a.policy.set("input.control",True); rt8a.stop_all(); rt8a.instance_lock.release()
        rt8b=build_phase8_runtime(phase8_root,b8)
        checks.append(f"crash_safe_mode={'PASS' if rt8b.recovery_state.safe_mode and not rt8b.policy.is_allowed('input.control') else 'FAIL'}")
        rt8b.clean_shutdown()

        # Advanced autonomy regression: closed-loop action -> verification -> evidence.
        class _AutonomyProvider:
            available=True
            def __init__(self): self.calls=0
            def generate(self,prompt,*,system=None):
                import json
                if "CLOSED-LOOP desktop mission" in prompt:
                    self.calls += 1
                    if self.calls == 1:
                        return json.dumps({"decision":"done","evidence":[],"reason":"unsupported claim"})
                    if self.calls == 2:
                        return json.dumps({"decision":"act","action":"create_note","args":{"filename":"autopilot.txt","content":"verified"},"rationale":"produce artifact","expected_effect":"note exists"})
                    return json.dumps({"decision":"done","evidence":["step:1"],"reason":"verified artifact"})
                return "{}"
        auto_root=root/"autonomy"; ba=SimulatedDesktopBackend(); rta=build_phase8_runtime(auto_root,ba)
        ap=_AutonomyProvider();rta.providers.register("autonomy-selftest",ap);rta.providers.set_active("autonomy-selftest")
        checks.append(f"autonomy_default_deny={'PASS' if not rta.policy.is_allowed('autonomy.run') else 'FAIL'}")
        rta.policy.set("autonomy.run",True); auto=rta.orchestrator.run("autonomía: crea evidencia")
        checks.append(f"autonomy_closed_loop={'PASS' if auto.state==GoalState.VERIFIED and (auto_root/'workspace'/'autopilot.txt').exists() and ap.calls==3 else 'FAIL'}")
        reports=rta.autonomy_store.list(); saved=rta.autonomy_store.load(reports[0]['id']) if reports else None
        checks.append(f"autonomy_evidence_ledger={'PASS' if saved and saved.state.value=='verified' and saved.steps and saved.steps[0].state.value=='verified' else 'FAIL'}")
        rta.clean_shutdown()

        class _AutoLearnProvider(_Phase7Provider):
            def __init__(self): self.decisions=[]
            def generate(self,prompt,*,system=None):
                import json
                if "CLOSED-LOOP desktop mission" in prompt:
                    return json.dumps(self.decisions.pop(0) if self.decisions else {"decision":"blocked","reason":"no decision"})
                return super().generate(prompt,system=system)
        learn_root=root/"autolearn"; bl=SimulatedDesktopBackend(); rtl=build_phase8_runtime(learn_root,bl)
        alp=_AutoLearnProvider();rtl.providers.register("autolearn-selftest",alp);rtl.providers.set_active("autolearn-selftest")
        for cap in ("autonomy.run","skill.learn","skill.execute","research.web"): rtl.policy.set(cap,True)
        alp.decisions=[{"decision":"learn","goal":"create reusable note","use_web":True}]
        first=rtl.orchestrator.run("autonomía: aprende y crea una nota")
        lm=rtl.autonomy_store.load(rtl.autonomy_store.list()[0]['id']); pending=rtl.skill_store.get(lm.pending_skill) if lm.pending_skill else None
        checks.append(f"autonomy_skill_pause={'PASS' if first.state==GoalState.BLOCKED and lm.state.value=='awaiting_approval' and pending and pending.status.value=='validated' and not lm.verified_evidence_ids() else 'FAIL'}")
        if pending:
            from .skills.models import SkillStatus
            rtl.skill_store.set_status(pending.name,SkillStatus.ENABLED)
            alp.decisions=[{"decision":"skill","skill":pending.name,"inputs":{"filename":"autolearn.txt","content":"ok"}}, {"decision":"done","evidence":["step:2"],"reason":"verified"}]
            resumed=rtl.orchestrator.run(f"reanuda misión autónoma {lm.id}")
        else: resumed=None
        checks.append(f"autonomy_skill_resume={'PASS' if resumed and resumed.state==GoalState.VERIFIED and (learn_root/'workspace'/'autolearn.txt').exists() else 'FAIL'}")
        rtl.clean_shutdown()

        # Infinity 1: persistent World Model + model-independent Guardian.
        inf_root=root/"infinity1"; bi=SimulatedDesktopBackend(); inf=build_infinity1_runtime(inf_root,bi)
        checks.append(f"world_defaults={'PASS' if inf.policy.is_allowed('world.read') and inf.policy.is_allowed('world.write') and not inf.policy.is_allowed('world.cloud') else 'FAIL'}")
        inf.perception.bus.publish(PerceptionEvent('environment.changed','selftest',{'active_handle':11,'active_title':'Infinity Editor','fingerprint':'inf-a','element_count':3,'changed':True},timestamp=time.time()))
        world_ctx=inf.world_model.context_for_goal('continue')
        checks.append(f"world_scene_graph={'PASS' if any(e.get('kind')=='window' and e.get('label')=='Infinity Editor' for e in world_ctx.get('entities',[])) and any(r.get('predicate')=='foreground_window' for r in world_ctx.get('relations',[])) else 'FAIL'}")
        inf.policy.set('world.cloud',True)
        projected=inf.world_model.cloud_context_for_goal('x',allow_screen=False,allow_perception=False,allow_memory=False)
        checks.append(f"world_cloud_boundaries={'PASS' if 'Infinity Editor' not in str(projected) else 'FAIL'}")
        inf.policy.set('mobile.security',True)
        blocked=inf.orchestrator.executor.execute(ActionRequest('mobile_request_auth',{},'mobile.security'))
        checks.append(f"guardian_owner_lease={'PASS' if blocked.blocked and 'owner lease' in (blocked.error or '').lower() else 'FAIL'}")
        inf.guardian.grant_action('mobile_request_auth',ttl_s=60,uses=1)
        attempted=inf.orchestrator.executor.execute(ActionRequest('mobile_request_auth',{},'mobile.security'))
        checks.append(f"guardian_lease_consumed={'PASS' if not attempted.blocked else 'FAIL'}")
        audit=inf.guardian.store.recent_audit(10)
        checks.append(f"guardian_audit={'PASS' if any(x.get('decision')=='block' and x.get('rule')=='owner_lease_required' for x in audit) else 'FAIL'}")
        inf.clean_shutdown()

        # Infinity 2: Personal AI OS resource namespace + capability-aware routing.
        os_root=root/"infinity2"; bo=SimulatedDesktopBackend(); osrt=build_infinity2_runtime(os_root,bo)
        os_rows=osrt.personal_os.resources()
        checks.append(f"personal_os_namespace={'PASS' if any(x.get('kind')=='device' for x in os_rows) and any(x.get('kind')=='app' for x in os_rows) else 'FAIL'}")
        checks.append(f"personal_os_default_deny={'PASS' if osrt.policy.is_allowed('os.read') and not osrt.policy.is_allowed('os.route') and not osrt.policy.is_allowed('os.handoff') and not osrt.policy.is_allowed('os.manage') else 'FAIL'}")
        osrt.policy.set('os.manage',True); pinned=osrt.personal_os.register_url('https://example.com',alias='selftest-url')
        route=osrt.personal_os.plan('open',resource_ref=pinned.id,destination_ref='pc')
        checks.append(f"personal_os_route_plan={'PASS' if route.supported and route.action=='open_url' and bo.opened_urls==[] else 'FAIL'}")
        osrt.policy.set('os.route',True); osrt.policy.set('browser.open',True)
        opened=osrt.personal_os.execute('open',resource_ref='selftest-url',destination_ref='pc')
        checks.append(f"personal_os_nested_authority={'PASS' if opened.get('verified') and bo.opened_urls==['https://example.com'] else 'FAIL'}")
        osrt.mobile.manager.devices.pair('Selftest Android',device_id='os-phone'); osrt.policy.set('mobile.read',True); osrt.personal_os.sync()
        handoff_plan=osrt.personal_os.plan('handoff',resource_ref='selftest-url',destination_ref='mi celular')
        checks.append(f"personal_os_cross_device_plan={'PASS' if handoff_plan.supported and handoff_plan.cross_device and 'os.handoff' in handoff_plan.required_capabilities else 'FAIL'}")
        file=(os_root/'workspace'/'no-fake-transfer.txt');file.parent.mkdir(exist_ok=True);file.write_text('x',encoding='utf-8');osrt.policy.set('filesystem.read',True)
        fr=osrt.personal_os.register_file(str(file)); unsupported=osrt.personal_os.plan('handoff',resource_ref=fr.id,destination_ref='mi celular')
        checks.append(f"personal_os_no_fake_transport={'PASS' if not unsupported.supported else 'FAIL'}")
        osrt.clean_shutdown()

        # Infinity 3: persistent Autonomous Workbench with a single guarded execution lane.
        wb_root=root/"infinity3"; bw=SimulatedDesktopBackend(); wbrt=build_infinity3_runtime(wb_root,bw)
        checks.append(f"workbench_defaults={'PASS' if wbrt.policy.is_allowed('workbench.read') and not wbrt.policy.is_allowed('workbench.run') and not wbrt.policy.is_allowed('workbench.manage') and not wbrt.policy.is_allowed('workbench.cloud') else 'FAIL'}")
        wbrt.policy.set('workbench.manage',True)
        blocked_manage=False
        try:wbrt.workbench.create('selftest work')
        except PermissionError:blocked_manage=True
        checks.append(f"workbench_guardian_manage={'PASS' if blocked_manage else 'FAIL'}")
        wbrt.guardian.grant_action('workbench_manage',ttl_s=60,uses=1); wi=wbrt.workbench.create('selftest work',priority=70,step_budget=5,quantum=2)
        checks.append(f"workbench_persistence={'PASS' if wbrt.workbench.store.get(wi.id) and wbrt.workbench.store.get(wi.id).priority==70 else 'FAIL'}")
        wbrt.personal_os.sync(); work_resources=wbrt.personal_os.resources(kind='work')
        checks.append(f"workbench_aios_resource={'PASS' if any(x.get('locator',{}).get('work_id')==wi.id for x in work_resources) else 'FAIL'}")
        wbrt.policy.set('os.cloud',True)
        checks.append(f"workbench_cloud_default_private={'PASS' if 'selftest work' not in str(wbrt.personal_os.cloud_context()) else 'FAIL'}")
        diag=wbrt.diagnostics.run(wbrt)
        checks.append(f"workbench_diagnostics={'PASS' if diag.get('version')=='1.3.0a3' and diag.get('storage',{}).get('workbench_sqlite',{}).get('status')=='ok' else 'FAIL'}")
        wbrt.clean_shutdown()
        # Infinity 4: dynamically composed Cognitive Swarm with no direct tool authority.
        import json as _json
        class _SwarmProvider:
            available=True
            def generate(self,prompt,*,system=None):
                if "Design a 3-8 member temporary expert team" in prompt:
                    return _json.dumps({"members":[
                        {"id":"architect","specialty":"systems architect","mandate":"design","perspective":"builder","depends_on":[]},
                        {"id":"critic","specialty":"failure analyst","mandate":"challenge","perspective":"critic","depends_on":["architect"]},
                        {"id":"verifier","specialty":"verification engineer","mandate":"verify","perspective":"verifier","depends_on":["architect"]},
                        {"id":"synth","specialty":"chief integrator","mandate":"synthesize","perspective":"synthesizer","depends_on":["architect","critic","verifier"]},
                    ]})
                if "PERSPECTIVE=synthesizer" in prompt:return "integrated result"
                if "PERSPECTIVE=critic" in prompt:return "Risk: unsupported assumption"
                return "bounded specialist work"
        sw_root=root/"infinity4";bs=SimulatedDesktopBackend();swrt=build_infinity4_runtime(sw_root,bs)
        sp=_SwarmProvider();swrt.providers.register("swarm-selftest",sp);swrt.providers.set_active("swarm-selftest")
        blocked=swrt.swarm.run("compose a team")
        checks.append(f"swarm_default_deny={'PASS' if blocked.state.value=='blocked' else 'FAIL'}")
        swrt.policy.set("swarm.run",True);swrt.policy.set("swarm.cloud",True);sr=swrt.swarm.run("compose a team")
        checks.append(f"swarm_dynamic_team={'PASS' if sr.state.value=='completed' and len(sr.members)==4 and sr.members[-1].perspective=='synthesizer' else 'FAIL'}")
        checks.append(f"swarm_adversarial_review={'PASS' if bool(sr.dissent) else 'FAIL'}")
        checks.append(f"swarm_persistence={'PASS' if swrt.swarm.store.load(sr.id).get('state')=='completed' else 'FAIL'}")
        swrt.clean_shutdown()

        # Infinity 5: Self-Evolution proposes/benchmarks revisions but never self-enables them.
        from .skills.models import SkillDefinition,SkillStep,SkillStatus
        class _EvolutionProvider:
            available=True
            def generate(self,prompt,*,system=None):
                if "Propose a safer/more reliable revision" in prompt:
                    return _json.dumps({"description":"Reliable note","inputs":{"filename":{"type":"string"},"content":{"type":"string"}},"steps":[{"action":"create_note","args":{"filename":"{{filename}}","content":"{{content}}"}}],"confidence":0.95,"rationale":"deterministic"})
                return "{}"
        ev_root=root/"infinity5";be=SimulatedDesktopBackend();evrt=build_infinity5_runtime(ev_root,be)
        skill=SkillDefinition("Reliable Note","Create note",inputs={"filename":{"type":"string"},"content":{"type":"string"}},steps=[SkillStep("create_note",{"filename":"{{filename}}","content":"{{content}}"})],status=SkillStatus.ENABLED)
        evrt.skill_store.save(skill);evrt.skill_store.set_status(skill.name,SkillStatus.ENABLED);base_skill=evrt.skill_store.get(skill.name)
        bench=evrt.evolution.benchmark(base_skill)
        checks.append(f"evolution_local_benchmark={'PASS' if bench.passed and bench.score>=90 else 'FAIL'}")
        scan=evrt.evolution.scan()
        checks.append(f"evolution_local_scan={'PASS' if scan and scan[0].get('skill')=='Reliable Note' and scan[0].get('passed') else 'FAIL'}")
        ep=_EvolutionProvider();evrt.providers.register("evo-selftest",ep);evrt.providers.set_active("evo-selftest");evrt.policy.set("evolution.run",True);evrt.policy.set("evolution.cloud",True)
        cand=evrt.evolution.propose(skill.name)
        current=evrt.skill_store.get(skill.name)
        checks.append(f"evolution_no_auto_install={'PASS' if cand.state.value=='benchmarked' and current.version==base_skill.version and current.status.value=='enabled' else 'FAIL'}")
        evrt.policy.set("evolution.manage",True);owner_blocked=False
        try:evrt.evolution.promote(cand.id)
        except PermissionError:owner_blocked=True
        checks.append(f"evolution_owner_lease={'PASS' if owner_blocked else 'FAIL'}")
        evrt.guardian.grant_action("evolution_promote",ttl_s=60,uses=1);promoted=evrt.evolution.promote(cand.id)
        checks.append(f"evolution_promotes_validated={'PASS' if promoted.status.value=='validated' and promoted.version==base_skill.version+1 else 'FAIL'}")
        evrt.guardian.grant_action("evolution_rollback",ttl_s=60,uses=1);rolled=evrt.evolution.rollback(cand.id)
        checks.append(f"evolution_rollback={'PASS' if rolled.status.value=='validated' and rolled.version==promoted.version+1 else 'FAIL'}")
        diag=evrt.diagnostics.run(evrt)
        checks.append(f"infinity5_diagnostics={'PASS' if diag.get('version')=='1.5.0a5' and diag.get('storage',{}).get('swarm_sqlite',{}).get('status')=='ok' and diag.get('storage',{}).get('evolution_sqlite',{}).get('status')=='ok' else 'FAIL'}")
        evrt.clean_shutdown()

        # Infinity 6: Reality Bridge is owner-enrolled, read-only by default and verified after actuation.
        from .reality.models import DeviceState, DeviceRisk
        class _RealityAdapter:
            name="selftest"
            def __init__(self): self.state_value="off"
            def available(self): return True,"ready"
            def state(self,device): return DeviceState(device.id,self.state_value,{},time.time(),self.name)
            def command(self,device,command,args):
                if command=="on": self.state_value="on"
                elif command=="off": self.state_value="off"
                elif command=="toggle": self.state_value="off" if self.state_value=="on" else "on"
                else: raise PermissionError(command)
                return {"ok":True}
        rroot=root/"infinity6"; br=SimulatedDesktopBackend(); rrt=build_infinity6_runtime(rroot,br)
        checks.append(f"reality_defaults={'PASS' if rrt.policy.is_allowed('reality.read') and not rrt.policy.is_allowed('reality.control') and not rrt.policy.is_allowed('reality.manage') and not rrt.policy.is_allowed('reality.cloud') else 'FAIL'}")
        ra=_RealityAdapter();rrt.reality.add_adapter(ra);rrt.policy.set('reality.manage',True);rrt.guardian.grant_action('reality_enroll',ttl_s=60,uses=1)
        rd=rrt.reality.enroll(adapter='selftest',native_id='light.selftest',label='Selftest Light',kind='light',capabilities=('on','off','toggle'),risk=DeviceRisk.LOW)
        blocked=False
        try:rrt.reality.command(rd.id,'on')
        except PermissionError:blocked=True
        checks.append(f"reality_control_default_deny={'PASS' if blocked else 'FAIL'}")
        rrt.policy.set('reality.control',True);result=rrt.reality.command(rd.id,'on')
        checks.append(f"reality_verified_control={'PASS' if result.ok and result.after and result.after.state=='on' else 'FAIL'}")
        rrt.personal_os.sync(); phys=rrt.personal_os.resources(kind='physical')
        checks.append(f"reality_aios_namespace={'PASS' if any(x.get('label')=='Selftest Light' for x in phys) else 'FAIL'}")
        rrt.policy.set('os.cloud',True); rrt.policy.set('world.cloud',True)
        checks.append(f"reality_cloud_default_private={'PASS' if 'Selftest Light' not in str(rrt.personal_os.cloud_context()) and 'Selftest Light' not in str(rrt.world_model.cloud_context_for_goal('x',allow_reality=False)) else 'FAIL'}")
        diag=rrt.diagnostics.run(rrt)
        checks.append(f"infinity6_diagnostics={'PASS' if diag.get('version')=='1.6.0a6' and diag.get('storage',{}).get('reality_sqlite',{}).get('status')=='ok' else 'FAIL'}")
        rrt.clean_shutdown()

        # Infinity 7: final release candidate infrastructure remains truthful about physical acceptance.
        i7root=root/"infinity7"; i7=build_infinity7_runtime(i7root,SimulatedDesktopBackend())
        gate=i7.release_gate.evaluate(i7)
        checks.append(f"infinity7_release_gate={'PASS' if gate.get('status')=='physical-pending' and gate.get('automated_ready') and not gate.get('physical_ready') else 'FAIL'}")
        health=i7.health.sample(i7)
        checks.append(f"infinity7_health={'PASS' if health.overall in {'ok','guarded','degraded'} and i7.health.running else 'FAIL'}")
        checks.append(f"infinity7_sensitive_defaults={'PASS' if not i7.policy.is_allowed('support.export') and not i7.policy.is_allowed('release.manage') else 'FAIL'}")
        i7.policy.set('support.export',True); i7.guardian.grant_action('support_export',ttl_s=60,uses=1)
        support=i7.export_support(i7root/'support.zip')
        checks.append(f"infinity7_support_bundle={'PASS' if support.exists() else 'FAIL'}")
        diag7=i7.diagnostics.run(i7)
        checks.append(f"infinity7_diagnostics={'PASS' if diag7.get('version')=='1.7.0rc1' and diag7.get('release_gate',{}).get('status')=='physical-pending' else 'FAIL'}")
        i7.clean_shutdown()
    return all(x.endswith("PASS") for x in checks), checks


def main() -> int:
    ok,checks=run_self_test(); print("JARVIS GM Infinity 7 self-test")
    for item in checks: print(" -",item)
    print("RESULT=PASS" if ok else "RESULT=FAIL"); return 0 if ok else 1


if __name__=="__main__": raise SystemExit(main())
