from __future__ import annotations
from dataclasses import dataclass,field,asdict
from enum import Enum
from typing import Any
import time,uuid

class CandidateState(str,Enum):
    PROPOSED="proposed";BENCHMARKED="benchmarked";REJECTED="rejected";PROMOTED="promoted";ROLLED_BACK="rolled_back"

@dataclass(slots=True)
class BenchmarkReport:
    skill_name:str
    score:float
    passed:bool
    metrics:dict[str,Any]=field(default_factory=dict)
    trials:list[dict[str,Any]]=field(default_factory=list)
    created_at:float=field(default_factory=time.time)
    def as_dict(self):return asdict(self)

@dataclass(slots=True)
class EvolutionCandidate:
    base_skill:str
    objective:str
    candidate_skill:dict[str,Any]
    base_snapshot:dict[str,Any]
    baseline:dict[str,Any]
    benchmark:dict[str,Any]
    rationale:str=""
    id:str=field(default_factory=lambda:"evo_"+uuid.uuid4().hex[:16])
    state:CandidateState=CandidateState.PROPOSED
    created_at:float=field(default_factory=time.time)
    updated_at:float=field(default_factory=time.time)
    def as_dict(self):
        d=asdict(self);d["state"]=self.state.value;return d
