from __future__ import annotations
from jarvis_gm.actions.base import Action

class EvolutionListAction(Action):
    name="evolution_list";capability="evolution.read"
    def __init__(self,store):self.store=store
    def run(self,limit:int=50,**kwargs):return self.store.list(limit)
class EvolutionScanAction(Action):
    name="evolution_scan";capability="evolution.read"
    def __init__(self,engine):self.engine=engine
    def run(self,**kwargs):return self.engine.scan()

class EvolutionBenchmarkAction(Action):
    name="evolution_benchmark";capability="evolution.read"
    def __init__(self,engine,skills):self.engine=engine;self.skills=skills
    def run(self,skill:str,**kwargs):
        s=self.skills.get(skill)
        if s is None:raise KeyError(skill)
        return self.engine.benchmark(s).as_dict()
class EvolutionProposeAction(Action):
    name="evolution_propose";capability="evolution.run"
    def __init__(self,engine):self.engine=engine
    def run(self,skill:str,objective:str="Improve reliability while preserving intent",**kwargs):return self.engine.propose(skill,objective).as_dict()
    def verify(self,output,**kwargs):return str((output or {}).get("state"))=="benchmarked","Candidate must pass benchmark"
class EvolutionPromoteAction(Action):
    name="evolution_promote";capability="evolution.manage"
    def __init__(self,engine):self.engine=engine
    def run(self,candidate_id:str,**kwargs):return self.engine.promote(candidate_id).as_dict()
class EvolutionRejectAction(Action):
    name="evolution_reject";capability="evolution.manage"
    def __init__(self,engine):self.engine=engine
    def run(self,candidate_id:str,**kwargs):return self.engine.reject(candidate_id).as_dict()

class EvolutionRollbackAction(Action):
    name="evolution_rollback";capability="evolution.manage"
    def __init__(self,engine):self.engine=engine
    def run(self,candidate_id:str,**kwargs):return self.engine.rollback(candidate_id).as_dict()
