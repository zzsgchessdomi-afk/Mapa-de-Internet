from __future__ import annotations
import json,re,copy
from typing import Any,Callable
from jarvis_gm.skills.models import SkillDefinition,SkillStep,SkillStatus
from .models import BenchmarkReport,EvolutionCandidate,CandidateState

class SelfEvolutionEngine:
    """Proposes and benchmarks constrained skill revisions. It never self-enables them."""
    MAX_STEPS=24
    def __init__(self,store,skill_store,skill_lab,compiler,provider_resolver:Callable[[],Any],actions:dict[str,Any],*,read_allowed:Callable[[],bool],run_allowed:Callable[[],bool],manage_allowed:Callable[[],bool],cloud_allowed:Callable[[],bool],authorize:Callable[[str,dict],None]|None=None,swarm=None,swarm_allowed:Callable[[],bool]|None=None)->None:
        self.store=store;self.skill_store=skill_store;self.lab=skill_lab;self.compiler=compiler;self.provider_resolver=provider_resolver;self.actions=actions;self.read_allowed=read_allowed;self.run_allowed=run_allowed;self.manage_allowed=manage_allowed;self.cloud_allowed=cloud_allowed;self.authorize=authorize;self.swarm=swarm;self.swarm_allowed=swarm_allowed or (lambda:False)
    def benchmark(self,skill:SkillDefinition)->BenchmarkReport:
        if not self.read_allowed():raise PermissionError("Capability blocked by policy: evolution.read")
        validation=self.compiler.validate(skill);practice=self.lab.practice(skill) if self.lab else None
        trials=[];compile_ok=bool(validation.ok);practice_ok=bool(practice.ok) if practice else True
        if practice:trials=[x.as_dict() for x in practice.trials]
        caps=set(validation.required_capabilities);high=len(caps & {"system.control","security.sensitive","external.send","mobile.security","mobile.messaging"})
        step_count=len(skill.steps);input_count=len(skill.inputs)
        score=100.0
        if not compile_ok:score-=55
        if not practice_ok:score-=35
        score-=min(15,max(0,step_count-8)*1.5);score-=min(20,high*10)
        if input_count and all(isinstance(x,dict) and x.get("type") for x in skill.inputs.values()):score+=3
        score=max(0.0,min(100.0,score))
        metrics={"compile_ok":compile_ok,"practice_ok":practice_ok,"steps":step_count,"inputs":input_count,"required_capabilities":sorted(caps),"high_risk_capabilities":high,"validation_errors":list(validation.errors),"validation_warnings":list(validation.warnings)}
        return BenchmarkReport(skill.name,round(score,2),compile_ok and practice_ok,metrics,trials)
    def scan(self)->list[dict[str,Any]]:
        if not self.read_allowed():raise PermissionError("Capability blocked by policy: evolution.read")
        rows=[]
        for skill in self.skill_store.list(include_retired=False):
            report=self.benchmark(skill)
            rows.append({"skill":skill.name,"version":skill.version,"status":skill.status.value,"score":report.score,"passed":report.passed,"review_recommended":(not report.passed or report.score<90.0),"metrics":report.metrics})
        rows.sort(key=lambda x:(x["passed"],x["score"],x["skill"].casefold()))
        return rows

    def propose(self,skill_name:str,objective:str="Improve reliability while preserving intent")->EvolutionCandidate:
        if not self.run_allowed():raise PermissionError("Capability blocked by policy: evolution.run")
        if not self.cloud_allowed():raise PermissionError("Capability blocked by policy: evolution.cloud")
        self._gate("evolution_propose",{"skill":skill_name})
        base=self.skill_store.get(skill_name)
        if base is None:raise KeyError(skill_name)
        baseline=self.benchmark(base)
        provider=self.provider_resolver()
        if not getattr(provider,"available",False):raise RuntimeError("Self-Evolution requires a configured cloud AI provider")
        available={name:{"capability":str(a.capability)} for name,a in sorted(self.actions.items())}
        critique=""
        if self.swarm is not None and self.swarm_allowed():
            sr=self.swarm.run(f"Critique this JARVIS skill for failure modes and safe reliability improvements. Skill={json.dumps(base.as_dict(),ensure_ascii=False)}")
            if sr.state.value=="completed":critique=sr.synthesis[:12000]
        schema={"description":"...","inputs":{},"steps":[{"action":"...","args":{},"description":"..."}],"confidence":0.0,"rationale":"..."}
        raw=provider.generate("Propose a safer/more reliable revision of the existing constrained skill. Preserve the skill's user intent. Use ONLY AVAILABLE_ACTIONS. Do not add shell/code execution. Keep <=24 steps. Return JSON only.\nSCHEMA="+json.dumps(schema)+"\nOBJECTIVE="+objective+"\nBASE="+json.dumps(base.as_dict(),ensure_ascii=False)+"\nBASELINE="+json.dumps(baseline.as_dict(),ensure_ascii=False)+"\nSWARM_CRITIQUE="+critique+"\nAVAILABLE_ACTIONS="+json.dumps(available,ensure_ascii=False),system="You are JARVIS Skill Evolution Engineer. Reliability, least authority and verifiability outrank novelty.")
        data=_json(raw);steps=[SkillStep(str(x.get("action") or ""),dict(x.get("args") or {}),str(x.get("description") or "")) for x in data.get("steps",[]) if isinstance(x,dict)]
        if not steps or len(steps)>self.MAX_STEPS:raise RuntimeError("Evolution candidate has invalid step count")
        candidate=SkillDefinition(name=base.name,description=str(data.get("description") or base.description),version=base.version+1,inputs=dict(data.get("inputs") or base.inputs),steps=steps,source="self-evolution",source_urls=base.source_urls,provenance_id=base.provenance_id,confidence=max(0.0,min(1.0,float(data.get("confidence",base.confidence)))),status=SkillStatus.DRAFT)
        validation=self.compiler.validate(candidate)
        candidate.required_capabilities=validation.required_capabilities
        report=self.benchmark(candidate)
        base_caps=set(self.compiler.validate(base).required_capabilities)
        candidate_caps=set(validation.required_capabilities)
        widened=sorted(candidate_caps-base_caps)
        base_actions={x.action for x in base.steps}
        candidate_actions={x.action for x in candidate.steps}
        removed_actions=sorted(base_actions-candidate_actions)
        base_inputs={k:str(v.get("type","any")).casefold() for k,v in base.inputs.items()}
        candidate_inputs={k:str(v.get("type","any")).casefold() for k,v in candidate.inputs.items()}
        contract_changed=base_inputs!=candidate_inputs
        if widened:
            report.passed=False;report.metrics["authority_widening"]=widened;report.score=min(report.score,49.0)
        if removed_actions:
            report.passed=False;report.metrics["removed_anchor_actions"]=removed_actions;report.score=min(report.score,49.0)
        if contract_changed:
            report.passed=False;report.metrics["input_contract_changed"]={"base":base_inputs,"candidate":candidate_inputs};report.score=min(report.score,49.0)
        state=CandidateState.BENCHMARKED if report.passed else CandidateState.REJECTED
        record=EvolutionCandidate(base_skill=base.name,objective=str(objective),candidate_skill=candidate.as_dict(),base_snapshot=base.as_dict(),baseline=baseline.as_dict(),benchmark=report.as_dict(),rationale=str(data.get("rationale") or ""),state=state)
        self.store.save(record);return record
    def promote(self,candidate_id:str)->SkillDefinition:
        if not self.manage_allowed():raise PermissionError("Capability blocked by policy: evolution.manage")
        self._gate("evolution_promote",{"candidate_id":candidate_id})
        c=self.store.load(candidate_id)
        if c.state!=CandidateState.BENCHMARKED:raise RuntimeError("Only a passed benchmark candidate can be promoted")
        if not bool(c.benchmark.get("passed")):raise RuntimeError("Candidate benchmark did not pass")
        if float(c.benchmark.get("score",0)) < float(c.baseline.get("score",0)):raise RuntimeError("Candidate score is below baseline")
        skill=_skill(c.candidate_skill);skill.status=SkillStatus.VALIDATED
        saved=self.skill_store.save(skill)
        c.state=CandidateState.PROMOTED;self.store.save(c);return saved
    def reject(self,candidate_id:str)->EvolutionCandidate:
        if not self.manage_allowed():raise PermissionError("Capability blocked by policy: evolution.manage")
        self._gate("evolution_manage",{"operation":"reject","candidate_id":candidate_id})
        c=self.store.load(candidate_id);c.state=CandidateState.REJECTED;self.store.save(c);return c
    def rollback(self,candidate_id:str)->SkillDefinition:
        if not self.manage_allowed():raise PermissionError("Capability blocked by policy: evolution.manage")
        self._gate("evolution_rollback",{"candidate_id":candidate_id})
        c=self.store.load(candidate_id)
        if c.state!=CandidateState.PROMOTED:raise RuntimeError("Only a promoted candidate can be rolled back")
        if not c.base_snapshot:raise RuntimeError("Candidate has no base snapshot for rollback")
        prior=_skill(c.base_snapshot);prior.status=SkillStatus.VALIDATED
        restored=self.skill_store.save(prior);c.state=CandidateState.ROLLED_BACK;self.store.save(c);return restored
    def _gate(self,name,args):
        if self.authorize is not None:self.authorize(name,args)

def _skill(raw:dict[str,Any])->SkillDefinition:
    return SkillDefinition(name=str(raw["name"]),description=str(raw.get("description") or ""),version=int(raw.get("version",1)),inputs=dict(raw.get("inputs") or {}),steps=[SkillStep(str(x["action"]),dict(x.get("args") or {}),str(x.get("description") or "")) for x in raw.get("steps",[])],required_capabilities=tuple(str(x) for x in raw.get("required_capabilities",[])),source=str(raw.get("source") or "self-evolution"),source_urls=tuple(str(x) for x in raw.get("source_urls",[])),provenance_id=str(raw.get("provenance_id") or ""),confidence=float(raw.get("confidence",.5)),status=SkillStatus(raw.get("status","draft")),created_at=float(raw.get("created_at",0) or 0),updated_at=float(raw.get("updated_at",0) or 0))
def _json(raw:str)->dict:
    text=str(raw).strip();text=re.sub(r"^```(?:json)?\s*|\s*```$","",text,flags=re.I)
    try:v=json.loads(text)
    except json.JSONDecodeError:
        a,b=text.find("{"),text.rfind("}")
        if a<0 or b<=a:raise RuntimeError("Evolution provider did not return JSON")
        v=json.loads(text[a:b+1])
    if not isinstance(v,dict):raise RuntimeError("Evolution JSON must be an object")
    return v
