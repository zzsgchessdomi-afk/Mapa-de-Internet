from __future__ import annotations

from dataclasses import asdict
from typing import TYPE_CHECKING

from .models import Goal, GoalState
from .planner import Planner
from .executor import Executor
from .verifier import Verifier
from .memory import MemoryStore

if TYPE_CHECKING:
    from jarvis_gm.memory.manager import MemoryManager


class Orchestrator:
    def __init__(self, planner: Planner, executor: Executor, verifier: Verifier, memory: MemoryStore,
                 continuity: "MemoryManager | None" = None, world_model=None) -> None:
        self.planner=planner; self.executor=executor; self.verifier=verifier; self.memory=memory; self.continuity=continuity; self.world_model=world_model; self.personal_os=None

    def run(self, text: str) -> Goal:
        goal=Goal(text=text); self.memory.record_event(goal.id,"goal.received",{"text":text})
        if self.world_model is not None and self.executor.policy.is_allowed("world.write"):
            try: self.world_model.goal_started(goal.id,text)
            except Exception as exc: self.memory.record_event(goal.id,"world.error",{"stage":"goal_started","error":str(exc)})
        actions=self.executor.actions; capabilities={name:action.capability for name,action in actions.items()}
        try:
            memory_context=self.continuity.context_for_goal(text) if self.continuity and self.executor.policy.is_allowed("memory.read") and self.executor.policy.is_allowed("memory.cloud") else None
            world_context=self.world_model.cloud_context_for_goal(text, allow_screen=self.executor.policy.is_allowed("screen.cloud"), allow_perception=self.executor.policy.is_allowed("perception.cloud"), allow_memory=self.executor.policy.is_allowed("memory.cloud"), allow_reality=self.executor.policy.is_allowed("reality.cloud")) if self.world_model is not None and self.executor.policy.is_allowed("world.read") and self.executor.policy.is_allowed("world.cloud") else None
            os_context=self.personal_os.cloud_context() if self.personal_os is not None and self.executor.policy.is_allowed("os.cloud") else None
            context=None
            if memory_context is not None or world_context is not None or os_context is not None:
                context={"memory":memory_context,"world":world_context,"personal_os":os_context}
            if memory_context: self.memory.record_event(goal.id,"memory.context",memory_context)
            if world_context: self.memory.record_event(goal.id,"world.context",world_context)
            goal.plan=self.planner.plan(text,capabilities,memory_context=context)
            goal.state=GoalState.PLANNED; self.memory.record_event(goal.id,"goal.planned",{"plan":[asdict(x) for x in goal.plan]})
            goal.state=GoalState.RUNNING
            for req in goal.plan:
                result=self.executor.execute(req); goal.results.append(result); self.memory.record_event(goal.id,"action.result",asdict(result))
                ok,detail=self.verifier.verify(req,result); self.memory.record_event(goal.id,"action.verified",{"action":req.name,"ok":ok,"detail":detail})
                if self.world_model is not None and self.executor.policy.is_allowed("world.write"):
                    try: self.world_model.action_observed(goal.id,req,result,ok,detail)
                    except Exception as exc: self.memory.record_event(goal.id,"world.error",{"stage":"action","error":str(exc)})
                if not ok:
                    goal.state=GoalState.BLOCKED if result.blocked or not result.error else GoalState.FAILED; goal.verification=detail; break
            else:
                goal.state=GoalState.VERIFIED; goal.verification="All planned actions completed and verified"
                self.memory.record_event(goal.id,"goal.verified",{"verification":goal.verification})
        except PermissionError as exc:
            goal.state=GoalState.BLOCKED; goal.verification=str(exc)
        except Exception as exc:
            goal.state=GoalState.FAILED; goal.verification=str(exc)
        if goal.state != GoalState.VERIFIED:
            self.memory.record_event(goal.id,"goal.ended",{"state":goal.state.value,"detail":goal.verification})
        if self.world_model is not None and self.executor.policy.is_allowed("world.write"):
            try: self.world_model.goal_finished(goal)
            except Exception as exc: self.memory.record_event(goal.id,"world.error",{"stage":"goal_finished","error":str(exc)})
        if self.continuity and self.executor.policy.is_allowed("memory.write"):
            try:
                self.continuity.capture_goal_outcome(goal)
                self.memory.record_event(goal.id,"memory.episode_captured",{"state":goal.state.value})
            except Exception as exc:
                self.memory.record_event(goal.id,"memory.capture_error",{"error":str(exc)})
        return goal
