from __future__ import annotations

from pathlib import Path
import threading


class KillSwitch:
    def __init__(self, sentinel: Path | None = None) -> None:
        self._event = threading.Event()
        self.sentinel = sentinel

    @property
    def engaged(self) -> bool:
        return self._event.is_set() or bool(self.sentinel and self.sentinel.exists())

    def engage(self) -> None:
        self._event.set()
        if self.sentinel:
            self.sentinel.parent.mkdir(parents=True, exist_ok=True)
            self.sentinel.write_text("STOP\n", encoding="utf-8")

    def reset(self) -> None:
        self._event.clear()
        if self.sentinel and self.sentinel.exists():
            self.sentinel.unlink()

    def check(self) -> None:
        if self.engaged:
            raise RuntimeError("JARVIS kill switch is engaged")
