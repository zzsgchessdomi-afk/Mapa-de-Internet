from __future__ import annotations

from pathlib import Path
import json
from .sqlite import sqlite_session
import time


class MemoryStore:
    def __init__(self, db_path: Path) -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _connect(self):
        return sqlite_session(self.db_path)

    def _init_db(self) -> None:
        with self._connect() as con:
            con.executescript(
                """
                CREATE TABLE IF NOT EXISTS memories (
                    key TEXT PRIMARY KEY,
                    value_json TEXT NOT NULL,
                    updated_at REAL NOT NULL
                );
                CREATE TABLE IF NOT EXISTS events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    goal_id TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    created_at REAL NOT NULL
                );
                """
            )

    def remember(self, key: str, value: object) -> None:
        payload = json.dumps(value, ensure_ascii=False)
        with self._connect() as con:
            con.execute(
                "INSERT INTO memories(key,value_json,updated_at) VALUES(?,?,?) "
                "ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json, updated_at=excluded.updated_at",
                (key, payload, time.time()),
            )

    def recall(self, key: str, default=None):
        with self._connect() as con:
            row = con.execute("SELECT value_json FROM memories WHERE key=?", (key,)).fetchone()
        return default if row is None else json.loads(row["value_json"])

    def record_event(self, goal_id: str, event_type: str, payload: object) -> None:
        with self._connect() as con:
            con.execute(
                "INSERT INTO events(goal_id,event_type,payload_json,created_at) VALUES(?,?,?,?)",
                (goal_id, event_type, json.dumps(payload, ensure_ascii=False), time.time()),
            )

    def recent_events(self, limit: int = 50) -> list[dict]:
        with self._connect() as con:
            rows = con.execute(
                "SELECT goal_id,event_type,payload_json,created_at FROM events ORDER BY id DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [
            {
                "goal_id": r["goal_id"],
                "event_type": r["event_type"],
                "payload": json.loads(r["payload_json"]),
                "created_at": r["created_at"],
            }
            for r in rows
        ]
