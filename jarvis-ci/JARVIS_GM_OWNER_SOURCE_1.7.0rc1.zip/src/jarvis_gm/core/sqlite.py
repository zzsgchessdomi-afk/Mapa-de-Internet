from __future__ import annotations

from contextlib import contextmanager
from pathlib import Path
from typing import Iterable, Iterator
import sqlite3


@contextmanager
def sqlite_session(path: Path, *, timeout: float = 5.0, row_factory: bool = True, pragmas: Iterable[str] = ()) -> Iterator[sqlite3.Connection]:
    """Transaction context that ALWAYS closes the SQLite handle.

    sqlite3.Connection.__exit__ commits/rolls back but does not close the
    connection. That is easy to miss on POSIX because an open database file can
    still be unlinked; Windows correctly keeps the file locked. This helper
    preserves transaction semantics and closes in finally on every platform.
    """
    con = sqlite3.connect(Path(path), timeout=float(timeout))
    if row_factory:
        con.row_factory = sqlite3.Row
    try:
        for pragma in pragmas:
            con.execute(pragma)
        yield con
        con.commit()
    except BaseException:
        try:
            con.rollback()
        finally:
            con.close()
        raise
    else:
        con.close()
