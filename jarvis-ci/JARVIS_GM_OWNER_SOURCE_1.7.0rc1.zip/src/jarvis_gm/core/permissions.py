from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import json


DEFAULT_POLICY = {
    "safe.read": True,
    "screen.observe": True,
    "screen.cloud": False,
    "perception.continuous": False,
    "perception.cloud": False,
    "memory.read": True,
    "memory.write": True,
    "memory.cloud": False,
    "memory.manage": False,
    "workspace.write": True,
    "system.control": False,
    "input.control": False,
    "window.control": False,
    "app.launch": False,
    "browser.open": False,
    "filesystem.read": False,
    "filesystem.write": False,
    "external.send": False,
    "security.sensitive": False,
    "agent.run": False,
    "research.web": False,
    "research.deep": False,
    "skill.learn": False,
    "skill.manage": False,
    "skill.execute": False,
    "autonomy.run": False,
    "mobile.read": False,
    "mobile.location": False,
    "mobile.control": False,
    "mobile.security": False,
    "mobile.messaging": False,
    "mobile.contacts": False,
    "mobile.relay": False,
    "world.read": True,
    "world.write": True,
    "world.cloud": False,
    "guardian.enforce": True,
    "os.read": True,
    "os.cloud": False,
    "os.route": False,
    "os.handoff": False,
    "os.manage": False,
    "workbench.read": True,
    "workbench.run": False,
    "workbench.manage": False,
    "workbench.cloud": False,
    "swarm.read": True,
    "swarm.run": False,
    "swarm.cloud": False,
    "evolution.read": True,
    "evolution.run": False,
    "evolution.manage": False,
    "evolution.cloud": False,
    "reality.read": True,
    "reality.continuous": False,
    "reality.control": False,
    "reality.manage": False,
    "reality.security": False,
    "reality.cloud": False,
    "health.read": True,
    "health.monitor": True,
    "support.export": False,
    "release.manage": False,
}


@dataclass
class PermissionPolicy:
    rules: dict[str, bool] = field(default_factory=lambda: dict(DEFAULT_POLICY))
    path: Path | None = None

    def __post_init__(self) -> None:
        if self.path is not None:
            self.path = Path(self.path)
            self._load_or_initialize()

    def _load_or_initialize(self) -> None:
        assert self.path is not None
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if self.path.exists():
            try:
                raw = json.loads(self.path.read_text(encoding="utf-8"))
                if not isinstance(raw, dict):
                    raise ValueError("permission file must contain an object")
                merged = dict(DEFAULT_POLICY)
                for key, value in raw.items():
                    if isinstance(key, str) and isinstance(value, bool):
                        merged[key] = value
                self.rules = merged
            except (OSError, json.JSONDecodeError, ValueError):
                # Fail safe: use defaults, where sensitive capabilities are denied.
                self.rules = dict(DEFAULT_POLICY)
                self._save()
        else:
            self._save()

    def _save(self) -> None:
        if self.path is None:
            return
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(self.rules, indent=2, sort_keys=True), encoding="utf-8")
        tmp.replace(self.path)

    def is_allowed(self, capability: str) -> bool:
        return bool(self.rules.get(capability, False))

    def set(self, capability: str, allowed: bool) -> None:
        self.rules[capability] = bool(allowed)
        self._save()

    def require(self, capability: str) -> None:
        if not self.is_allowed(capability):
            raise PermissionError(f"Capability blocked by policy: {capability}")
