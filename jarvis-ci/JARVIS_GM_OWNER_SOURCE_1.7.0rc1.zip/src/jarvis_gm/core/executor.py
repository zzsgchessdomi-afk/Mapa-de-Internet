from __future__ import annotations

from jarvis_gm.actions.base import Action
from .kill_switch import KillSwitch
from .models import ActionRequest, ActionResult
from .permissions import PermissionPolicy


class Executor:
    def __init__(self, actions: dict[str, Action], policy: PermissionPolicy, kill_switch: KillSwitch, guardian=None) -> None:
        self.actions = actions
        self.policy = policy
        self.kill_switch = kill_switch
        self.guardian = guardian

    def execute(self, req: ActionRequest) -> ActionResult:
        try:
            if self.kill_switch.engaged:
                return ActionResult(False, req.name, error="JARVIS kill switch is engaged", blocked=True)
            self.kill_switch.check()
            action = self.actions[req.name]
            if req.capability != action.capability:
                raise RuntimeError("Capability mismatch between plan and registered action")
            self.policy.require(action.capability)
            if self.guardian is not None:
                try:
                    decision = self.guardian.authorize(req)
                except Exception as exc:
                    return ActionResult(False, req.name, error=f"Guardian failed closed: {exc}", blocked=True)
                if not decision.allowed:
                    return ActionResult(False, req.name, error=decision.reason, blocked=True)
            output = action.run(**req.args)
            result = ActionResult(True, req.name, output=output)
            if self.guardian is not None:
                try: self.guardian.observe_result(req, result)
                except Exception: pass
            return result
        except PermissionError as exc:
            return ActionResult(False, req.name, error=str(exc), blocked=True)
        except Exception as exc:
            return ActionResult(False, req.name, error=str(exc))
