from __future__ import annotations

from jarvis_gm.actions.base import Action
from .models import ActionRequest, ActionResult


class Verifier:
    def __init__(self, actions: dict[str, Action]) -> None:
        self.actions = actions

    def verify(self, req: ActionRequest, result: ActionResult) -> tuple[bool, str]:
        if not result.ok:
            return False, result.error or "Action failed"
        action = self.actions[req.name]
        try:
            return action.verify(result.output, **req.args)
        except Exception as exc:
            return False, f"Verifier error: {exc}"
