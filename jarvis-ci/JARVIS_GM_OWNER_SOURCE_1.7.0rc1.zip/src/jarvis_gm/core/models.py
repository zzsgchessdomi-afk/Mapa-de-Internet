from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any
import time
import uuid


class GoalState(str, Enum):
    RECEIVED = "received"
    PLANNED = "planned"
    RUNNING = "running"
    BLOCKED = "blocked"
    VERIFIED = "verified"
    FAILED = "failed"


@dataclass(slots=True)
class ActionRequest:
    name: str
    args: dict[str, Any] = field(default_factory=dict)
    capability: str = "safe.read"


@dataclass(slots=True)
class ActionResult:
    ok: bool
    action: str
    output: Any = None
    error: str | None = None
    blocked: bool = False


@dataclass(slots=True)
class Goal:
    text: str
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    state: GoalState = GoalState.RECEIVED
    created_at: float = field(default_factory=time.time)
    plan: list[ActionRequest] = field(default_factory=list)
    results: list[ActionResult] = field(default_factory=list)
    verification: str | None = None
