from __future__ import annotations

from pathlib import Path
import shutil
from typing import Any

from .base import Action
from jarvis_gm.control.config import AppRegistry, FileScope, validate_url
from jarvis_gm.control.windows_backend import DesktopBackend


class DesktopAction(Action):
    def __init__(self, backend: DesktopBackend) -> None:
        self.backend = backend


class ScreenInfoAction(DesktopAction):
    name = "screen_info"; capability = "safe.read"
    def run(self, **kwargs: Any) -> Any:
        width, height = self.backend.screen_size()
        x, y = self.backend.cursor_position()
        return {"width": width, "height": height, "cursor": {"x": x, "y": y}}


class MoveCursorAction(DesktopAction):
    name = "move_cursor"; capability = "input.control"
    def run(self, **kwargs: Any) -> Any:
        x, y = self.backend.move_cursor(int(kwargs["x"]), int(kwargs["y"]))
        return {"x": x, "y": y}
    def verify(self, output: Any, **kwargs: Any) -> tuple[bool, str]:
        x, y = self.backend.cursor_position(); tx, ty = int(kwargs["x"]), int(kwargs["y"])
        ok = abs(x - tx) <= 2 and abs(y - ty) <= 2
        return ok, "Cursor position verified" if ok else f"Cursor mismatch: {(x, y)} != {(tx, ty)}"


class MoveCursorNormalizedAction(DesktopAction):
    name = "move_cursor_normalized"; capability = "input.control"
    def run(self, **kwargs: Any) -> Any:
        nx = max(0.0, min(1.0, float(kwargs["x"])))
        ny = max(0.0, min(1.0, float(kwargs["y"])))
        w, h = self.backend.screen_size()
        x, y = self.backend.move_cursor(round(nx * (w - 1)), round(ny * (h - 1)))
        return {"x": x, "y": y, "normalized": {"x": nx, "y": ny}}
    def verify(self, output: Any, **kwargs: Any) -> tuple[bool, str]:
        x, y = self.backend.cursor_position()
        ok = x == int(output["x"]) and y == int(output["y"])
        return ok, "Normalized pointer verified" if ok else "Pointer verification failed"


class MouseButtonAction(DesktopAction):
    name = "mouse_button"; capability = "input.control"
    def run(self, **kwargs: Any) -> Any:
        button = str(kwargs.get("button", "left")); state = str(kwargs.get("state", "click")).lower()
        if state == "down": self.backend.mouse_down(button)
        elif state == "up": self.backend.mouse_up(button)
        elif state == "click": self.backend.click(button)
        else: raise ValueError("state must be down, up or click")
        return {"button": button, "state": state, "accepted": True}
    def verify(self, output: Any, **kwargs: Any) -> tuple[bool, str]:
        # Windows does not provide a general semantic proof of what a click changed.
        return bool(output.get("accepted")), "Input event was accepted by Windows" if output.get("accepted") else "Input event failed"


class HotkeyAction(DesktopAction):
    name = "hotkey"; capability = "input.control"
    def run(self, **kwargs: Any) -> Any:
        keys = kwargs.get("keys")
        if isinstance(keys, str): keys = [x.strip() for x in keys.split("+") if x.strip()]
        if not isinstance(keys, list): raise ValueError("keys must be a list or '+' separated string")
        self.backend.hotkey([str(x) for x in keys])
        return {"keys": keys, "accepted": True}
    def verify(self, output: Any, **kwargs: Any) -> tuple[bool, str]:
        return bool(output.get("accepted")), "Hotkey sent" if output.get("accepted") else "Hotkey failed"


class TypeTextAction(DesktopAction):
    name = "type_text"; capability = "input.control"
    def run(self, **kwargs: Any) -> Any:
        text = str(kwargs.get("text", ""))
        if len(text) > 20000: raise ValueError("Text is too large for one input action")
        self.backend.type_text(text)
        return {"chars": len(text), "accepted": True}
    def verify(self, output: Any, **kwargs: Any) -> tuple[bool, str]:
        return bool(output.get("accepted")), "Text paste event sent" if output.get("accepted") else "Text input failed"


class ListWindowsAction(DesktopAction):
    name = "list_windows"; capability = "safe.read"
    def run(self, **kwargs: Any) -> Any:
        return [w.as_dict() for w in self.backend.list_windows()]


class FocusWindowAction(DesktopAction):
    name = "focus_window"; capability = "window.control"
    def run(self, **kwargs: Any) -> Any:
        return self.backend.focus_window(str(kwargs["title"])).as_dict()
    def verify(self, output: Any, **kwargs: Any) -> tuple[bool, str]:
        win = self.backend.active_window(); ok = win is not None and win.handle == int(output["handle"])
        return ok, "Foreground window verified" if ok else "Window focus verification failed"


class MoveWindowAction(DesktopAction):
    name = "move_window"; capability = "window.control"
    def run(self, **kwargs: Any) -> Any:
        return self.backend.move_active_window(int(kwargs["left"]), int(kwargs["top"]), int(kwargs["width"]), int(kwargs["height"])).as_dict()
    def verify(self, output: Any, **kwargs: Any) -> tuple[bool, str]:
        win = self.backend.active_window()
        if win is None: return False, "No active window after move"
        expected = (int(kwargs["left"]), int(kwargs["top"]), int(kwargs["width"]), int(kwargs["height"]))
        actual = (win.left, win.top, win.width, win.height)
        ok = all(abs(a-b) <= 4 for a,b in zip(actual, expected))
        return ok, "Window geometry verified" if ok else f"Window geometry mismatch: {actual} != {expected}"


class ResizeWindowAction(DesktopAction):
    name = "resize_active_window"; capability = "window.control"
    def run(self, **kwargs: Any) -> Any:
        return self.backend.resize_active_window(float(kwargs["scale"]), kwargs.get("center_x"), kwargs.get("center_y")).as_dict()
    def verify(self, output: Any, **kwargs: Any) -> tuple[bool, str]:
        win = self.backend.active_window(); ok = win is not None and win.handle == int(output["handle"]) and win.width > 0 and win.height > 0
        return ok, "Window resize observed" if ok else "Window resize verification failed"


class MaximizeWindowAction(DesktopAction):
    name = "maximize_window"; capability = "window.control"
    def run(self, **kwargs: Any) -> Any: return self.backend.maximize_active_window().as_dict()
    def verify(self, output: Any, **kwargs: Any) -> tuple[bool, str]:
        win = self.backend.active_window(); ok = win is not None and bool(win.maximized)
        return ok, "Window maximized" if ok else "Maximize verification failed"


class MinimizeWindowAction(DesktopAction):
    name = "minimize_window"; capability = "window.control"
    def run(self, **kwargs: Any) -> Any:
        before = self.backend.active_window(); self.backend.minimize_active_window()
        return {"handle": before.handle if before else None, "accepted": True}
    def verify(self, output: Any, **kwargs: Any) -> tuple[bool, str]:
        handle = output.get("handle")
        if handle is None: return False, "No window was active"
        matches = [w for w in self.backend.list_windows() if w.handle == int(handle)]
        ok = not matches or matches[0].minimized
        return ok, "Window minimize observed" if ok else "Minimize verification failed"


class OpenAppAction(DesktopAction):
    name = "open_app"; capability = "app.launch"
    def __init__(self, backend: DesktopBackend, registry: AppRegistry) -> None:
        super().__init__(backend); self.registry = registry
    def run(self, **kwargs: Any) -> Any:
        alias = str(kwargs["app"]); exe = self.registry.resolve(alias)
        return self.backend.open_app(exe, [str(x) for x in kwargs.get("args", [])])
    def verify(self, output: Any, **kwargs: Any) -> tuple[bool, str]:
        ok = int(output.get("pid", 0)) > 0
        return ok, "Application process launch accepted" if ok else "Application launch failed"


class OpenUrlAction(DesktopAction):
    name = "open_url"; capability = "browser.open"
    def run(self, **kwargs: Any) -> Any:
        return self.backend.open_url(validate_url(str(kwargs["url"])))
    def verify(self, output: Any, **kwargs: Any) -> tuple[bool, str]:
        # We can verify that Windows/default browser accepted the request, not that a page finished loading.
        ok = bool(output.get("request_accepted"))
        return ok, "Browser accepted URL request (page load not claimed)" if ok else "Browser rejected URL request"


class ListDirectoryAction(Action):
    name = "list_directory"; capability = "filesystem.read"
    def __init__(self, scope: FileScope) -> None: self.scope = scope
    def run(self, **kwargs: Any) -> Any:
        path = self.scope.require(Path(str(kwargs["path"])), must_exist=True)
        if not path.is_dir(): raise NotADirectoryError(str(path))
        return [{"name": p.name, "path": str(p), "is_dir": p.is_dir(), "size": None if p.is_dir() else p.stat().st_size} for p in sorted(path.iterdir(), key=lambda p: p.name.casefold())]


class CreateFolderAction(Action):
    name = "create_folder"; capability = "filesystem.write"
    def __init__(self, scope: FileScope) -> None: self.scope = scope
    def run(self, **kwargs: Any) -> Any:
        path = self.scope.require(Path(str(kwargs["path"])), must_exist=False); path.mkdir(parents=True, exist_ok=True)
        return {"path": str(path)}
    def verify(self, output: Any, **kwargs: Any) -> tuple[bool, str]:
        p = Path(output["path"]); ok = p.is_dir(); return ok, "Folder exists" if ok else "Folder verification failed"


class CopyFileAction(Action):
    name = "copy_file"; capability = "filesystem.write"
    def __init__(self, scope: FileScope) -> None: self.scope = scope
    def run(self, **kwargs: Any) -> Any:
        src = self.scope.require(Path(str(kwargs["src"])), must_exist=True); dst = self.scope.require(Path(str(kwargs["dst"])), must_exist=False)
        if not src.is_file(): raise FileNotFoundError(str(src))
        dst.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(src, dst)
        return {"src": str(src), "dst": str(dst), "bytes": dst.stat().st_size}
    def verify(self, output: Any, **kwargs: Any) -> tuple[bool, str]:
        src, dst = Path(output["src"]), Path(output["dst"]); ok = dst.is_file() and src.stat().st_size == dst.stat().st_size
        return ok, "Copied file size verified" if ok else "Copy verification failed"


class MoveFileAction(Action):
    name = "move_file"; capability = "filesystem.write"
    def __init__(self, scope: FileScope) -> None: self.scope = scope
    def run(self, **kwargs: Any) -> Any:
        src = self.scope.require(Path(str(kwargs["src"])), must_exist=True); dst = self.scope.require(Path(str(kwargs["dst"])), must_exist=False)
        if not src.is_file(): raise FileNotFoundError(str(src))
        dst.parent.mkdir(parents=True, exist_ok=True); shutil.move(str(src), str(dst))
        return {"src": str(src), "dst": str(dst)}
    def verify(self, output: Any, **kwargs: Any) -> tuple[bool, str]:
        src, dst = Path(output["src"]), Path(output["dst"]); ok = dst.is_file() and not src.exists()
        return ok, "Move verified" if ok else "Move verification failed"
