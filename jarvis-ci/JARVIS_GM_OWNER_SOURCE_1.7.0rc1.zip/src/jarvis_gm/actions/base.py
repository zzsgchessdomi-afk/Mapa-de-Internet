from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class Action(ABC):
    name: str
    capability: str

    @abstractmethod
    def run(self, **kwargs: Any) -> Any: ...

    def verify(self, output: Any, **kwargs: Any) -> tuple[bool, str]:
        return True, "Action returned without error"
