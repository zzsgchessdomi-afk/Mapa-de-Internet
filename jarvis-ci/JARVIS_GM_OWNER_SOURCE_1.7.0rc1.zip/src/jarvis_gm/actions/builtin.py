from __future__ import annotations

from pathlib import Path
import platform
from typing import Any

from .base import Action
from jarvis_gm.core.memory import MemoryStore


class RememberAction(Action):
    name = "remember"
    capability = "memory.write"

    def __init__(self, memory: MemoryStore) -> None:
        self.memory = memory

    def run(self, **kwargs: Any) -> Any:
        key = str(kwargs["key"]).strip()
        if not key:
            raise ValueError("Memory key cannot be empty")
        value = kwargs.get("value")
        self.memory.remember(key, value)
        return {"key": key, "value": value}

    def verify(self, output: Any, **kwargs: Any) -> tuple[bool, str]:
        actual = self.memory.recall(str(kwargs["key"]).strip(), object())
        ok = actual == kwargs.get("value")
        return ok, "Memory persisted" if ok else "Memory verification failed"


class CreateNoteAction(Action):
    name = "create_note"
    capability = "workspace.write"

    def __init__(self, workspace: Path) -> None:
        self.workspace = Path(workspace)
        self.workspace.mkdir(parents=True, exist_ok=True)

    def _safe_path(self, filename: str) -> Path:
        name = Path(filename).name
        if not name.endswith(".txt"):
            name += ".txt"
        return self.workspace / name

    def run(self, **kwargs: Any) -> Any:
        path = self._safe_path(str(kwargs["filename"]))
        content = str(kwargs.get("content", ""))
        path.write_text(content, encoding="utf-8")
        return {"path": str(path), "bytes": len(content.encode("utf-8"))}

    def verify(self, output: Any, **kwargs: Any) -> tuple[bool, str]:
        path = self._safe_path(str(kwargs["filename"]))
        expected = str(kwargs.get("content", ""))
        ok = path.exists() and path.read_text(encoding="utf-8") == expected
        return ok, "Note exists and content matches" if ok else "Note verification failed"


class ReadNoteAction(Action):
    name = "read_note"
    capability = "safe.read"

    def __init__(self, workspace: Path) -> None:
        self.workspace = Path(workspace)

    def run(self, **kwargs: Any) -> Any:
        name = Path(str(kwargs["filename"])).name
        if not name.endswith(".txt"):
            name += ".txt"
        path = self.workspace / name
        return path.read_text(encoding="utf-8")


class StatusAction(Action):
    name = "status"
    capability = "safe.read"

    def __init__(self, phase: int = 1) -> None:
        self.phase = int(phase)

    def run(self, **kwargs: Any) -> Any:
        return {
            "platform": platform.platform(),
            "python": platform.python_version(),
            "phase": self.phase,
            "core": "ready",
        }
