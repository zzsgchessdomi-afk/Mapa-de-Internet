from __future__ import annotations

from threading import Lock
import time
from typing import Any

from .base import Action
from jarvis_gm.control.windows_backend import DesktopBackend
from jarvis_gm.screen.grounding import GroundingEngine, TargetRegistry
from jarvis_gm.screen.observer import ScreenObserver


class ScreenSnapshotAction(Action):
    name = "screen_snapshot"
    capability = "screen.observe"

    def __init__(self, observer: ScreenObserver) -> None:
        self.observer = observer

    def run(self, **kwargs: Any) -> Any:
        snap = self.observer.snapshot(include_image=False)
        return snap.compact(limit=int(kwargs.get("limit", 80)))

    def verify(self, output: Any, **kwargs: Any) -> tuple[bool, str]:
        ok = isinstance(output, dict) and bool(output.get("id"))
        return ok, "Screen structure captured" if ok else "Screen snapshot failed"


class GroundedClickAction(Action):
    """Executes only a fresh target produced by Screen Grounding, then observes its effect."""
    name = "grounded_click"
    capability = "input.control"

    def __init__(self, backend: DesktopBackend, observer: ScreenObserver, grounding: GroundingEngine,
                 registry: TargetRegistry) -> None:
        self.backend = backend; self.observer = observer; self.grounding = grounding; self.registry = registry
        self._before: dict[str, Any] = {}; self._lock = Lock()

    def run(self, **kwargs: Any) -> Any:
        target_id = str(kwargs["target_id"])
        target = self.registry.get(target_id)
        valid, reason, _ = self.grounding.revalidate(target)
        if not valid:
            raise RuntimeError(f"Grounded target failed revalidation: {reason}")
        before = self.observer.snapshot(include_image=True)
        self.backend.move_cursor(target.x, target.y)
        self.backend.click(str(kwargs.get("button", "left")))
        with self._lock:
            self._before[target_id] = before
        return {
            "target_id": target_id, "label": target.label, "x": target.x, "y": target.y,
            "confidence": target.confidence, "source": target.source, "accepted": True,
            "grounding_reason": target.reason,
        }

    def verify(self, output: Any, **kwargs: Any) -> tuple[bool, str]:
        target_id = str(output.get("target_id", ""))
        try: target = self.registry.get(target_id)
        except Exception as exc: return False, f"Target disappeared before verification: {exc}"
        with self._lock:
            before = self._before.pop(target_id, None)
        if before is None:
            return False, "No pre-action screen snapshot exists"
        time.sleep(0.10)
        after = self.observer.snapshot(include_image=True)
        effect = self.observer.verify_effect(before, after, target.rect)
        # We deliberately do not equate an accepted mouse event with semantic success.
        if effect.observed:
            return True, f"Grounded click verified on '{target.label}': {effect.reason}"
        return False, f"Click was sent to '{target.label}', but semantic effect is unverified: {effect.reason}"
