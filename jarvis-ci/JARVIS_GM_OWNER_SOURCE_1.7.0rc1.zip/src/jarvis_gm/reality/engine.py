from __future__ import annotations

import time
import threading
from typing import Any

from jarvis_gm.core.models import ActionRequest
from .models import CommandResult, DeviceRisk
from .store import RealityStore
from .config import RealityConfig
from .adapters.home_assistant import HomeAssistantAdapter, HomeAssistantConfig


class RealityBridge:
    """Owner-enrolled physical device bridge with fail-closed actuation."""
    def __init__(self, store: RealityStore, *, policy, guardian, kill_switch, world=None, credentials=None, config_path=None, verify_timeout_s: float = 1.5, verify_interval_s: float = 0.15) -> None:
        self.store=store; self.policy=policy; self.guardian=guardian; self.kill_switch=kill_switch; self.world=world; self.credentials=credentials
        self.verify_timeout_s=max(0.0,float(verify_timeout_s)); self.verify_interval_s=max(0.01,float(verify_interval_s))
        self.adapters: dict[str,Any] = {}
        self._last_command: dict[str,float] = {}
        self._monitor_stop=threading.Event(); self._monitor_thread: threading.Thread | None=None
        self.config = RealityConfig(config_path or (self.store.path.parent / "reality_config.json"))
        self._load_configured_adapters()

    def _load_configured_adapters(self) -> None:
        cfg=self.config.load(); ha=cfg.get("home_assistant") if isinstance(cfg,dict) else None
        if isinstance(ha,dict) and ha.get("base_url"):
            try:
                self.add_adapter(HomeAssistantAdapter(HomeAssistantConfig(str(ha["base_url"]), lambda: self.credentials.get("JARVIS_HOME_ASSISTANT_TOKEN") if self.credentials else None)))
            except Exception:
                pass

    def configure_home_assistant(self, base_url: str, token: str) -> dict:
        self.policy.require("reality.manage")
        decision=self.guardian.authorize(ActionRequest("reality_configure",{"adapter":"home_assistant"},"reality.manage"))
        if not decision.allowed: raise PermissionError(decision.reason)
        if self.credentials is None or not getattr(self.credentials,"available",False):
            raise RuntimeError("A secure OS credential store is required; JARVIS refuses to save the token in plaintext")
        adapter=HomeAssistantAdapter(HomeAssistantConfig(base_url, lambda: self.credentials.get("JARVIS_HOME_ASSISTANT_TOKEN")))
        # Validate URL before persisting anything. Connectivity itself may be offline now.
        self.credentials.set("JARVIS_HOME_ASSISTANT_TOKEN",token)
        self.config.save({"home_assistant":{"base_url":adapter.base_url}})
        self.add_adapter(adapter)
        return {"adapter":"home_assistant","base_url":adapter.base_url,"configured":True}


    @property
    def monitoring(self) -> bool:
        return bool(self._monitor_thread and self._monitor_thread.is_alive())

    def start_monitor(self, interval_s: float = 5.0) -> None:
        self.policy.require("reality.continuous")
        if self.monitoring: return
        interval=max(1.0,float(interval_s)); self._monitor_stop.clear()
        def loop():
            next_poll=time.monotonic()
            while not self._monitor_stop.is_set():
                if self.kill_switch.engaged or not self.policy.is_allowed("reality.continuous"):
                    break
                now=time.monotonic()
                if now < next_poll:
                    self._monitor_stop.wait(min(0.20,next_poll-now)); continue
                next_poll=now+interval
                for d in self.store.list():
                    if self._monitor_stop.is_set() or self.kill_switch.engaged: break
                    try:self.observe(d.id)
                    except Exception as exc:self.store.event(d.id,"monitor_error",{"error":str(exc)[:300]})
            self._monitor_stop.set()
        self._monitor_thread=threading.Thread(target=loop,name="jarvis-reality-monitor",daemon=True);self._monitor_thread.start()

    def stop_monitor(self) -> None:
        self._monitor_stop.set(); t=self._monitor_thread
        if t and t.is_alive() and t is not threading.current_thread(): t.join(timeout=2.0)
        self._monitor_thread=None

    def add_adapter(self, adapter) -> None:
        self.adapters[str(adapter.name)] = adapter

    def adapter(self, name: str):
        try: return self.adapters[name]
        except KeyError: raise RuntimeError(f"Reality adapter is not configured: {name}")

    def list_devices(self) -> list[dict]:
        self.policy.require("reality.read")
        return [{"id":d.id,"adapter":d.adapter,"native_id":d.native_id,"label":d.label,"kind":d.kind,"capabilities":list(d.capabilities),"risk":d.risk.value,"enabled":d.enabled} for d in self.store.list()]

    def observe(self, ref: str) -> dict:
        self.policy.require("reality.read"); self.kill_switch.check()
        d=self.store.find(ref); state=self.adapter(d.adapter).state(d)
        payload={"device_id":d.id,"label":d.label,"state":state.state,"attributes":state.attributes,"observed_at":state.observed_at,"source":state.source}
        self.store.event(d.id,"observe",payload)
        if self.world is not None and self.policy.is_allowed("world.write"):
            ent=self.world.store.upsert_entity(kind="physical_device",key=d.id,label=d.label,attributes={"kind":d.kind,"state":state.state,"adapter":d.adapter},source="reality",confidence=1.0,ttl_s=120.0)
            self.world.store.observe("reality.state",{"entity_id":ent.id,"device_id":d.id,"state":state.state},source="reality",confidence=1.0)
        return payload

    def command(self, ref: str, command: str, args: dict | None = None) -> CommandResult:
        self.policy.require("reality.control"); self.kill_switch.check()
        d=self.store.find(ref)
        if not d.enabled: raise PermissionError("Reality device is disabled")
        if command not in d.capabilities: raise PermissionError(f"Command not enrolled for this device: {command}")
        now=time.monotonic(); last=self._last_command.get(d.id,0.0)
        if now-last < 0.35: raise RuntimeError("Reality command cooldown is active")
        capability = "reality.security" if d.risk in {DeviceRisk.HIGH,DeviceRisk.CRITICAL} else "reality.control"
        self.policy.require(capability)
        req=ActionRequest("reality_device_command",{"device_id":d.id,"command":command},capability)
        decision=self.guardian.authorize(req)
        if not decision.allowed: raise PermissionError(decision.reason)
        before=self.adapter(d.adapter).state(d)
        cmd_args=dict(args or {})
        self.adapter(d.adapter).command(d,command,cmd_args)
        self._last_command[d.id]=time.monotonic()
        deadline=time.monotonic()+self.verify_timeout_s
        after=self.adapter(d.adapter).state(d)
        ok=self._command_verified(command,cmd_args,before,after)
        while not ok and time.monotonic()<deadline and not self.kill_switch.engaged:
            time.sleep(self.verify_interval_s)
            after=self.adapter(d.adapter).state(d)
            ok=self._command_verified(command,cmd_args,before,after)
        detail = f"verified state={after.state}" if ok else f"command transport returned but expected state change was not verified (state={after.state})"
        result=CommandResult(ok,d.id,command,before,after,detail)
        self.store.event(d.id,"command",{"command":command,"ok":ok,"before":before.state,"after":after.state})
        if self.world is not None and self.policy.is_allowed("world.write"):
            self.world.store.observe("reality.command_result",{"device_id":d.id,"command":command,"ok":ok,"state":after.state},source="reality",confidence=1.0)
        return result

    @staticmethod
    def _command_verified(command: str, args: dict, before, after) -> bool:
        cmd=str(command).casefold()
        if cmd=="on": return str(after.state).casefold()=="on"
        if cmd=="off": return str(after.state).casefold()=="off"
        if cmd in {"toggle","play_pause"}: return str(after.state)!=str(before.state)
        if cmd=="volume":
            try:return abs(float(after.attributes.get("volume_level"))-float(args.get("level")))<=0.03
            except Exception:return False
        if cmd=="play": return str(after.state).casefold() in {"playing","on"}
        if cmd=="pause": return str(after.state).casefold() in {"paused","idle","off"}
        return False

    def enroll(self, **kwargs):
        self.policy.require("reality.manage")
        decision=self.guardian.authorize(ActionRequest("reality_enroll",{"adapter":str(kwargs.get("adapter") or ""),"native_id":str(kwargs.get("native_id") or "")},"reality.manage"))
        if not decision.allowed: raise PermissionError(decision.reason)
        device=self.store.enroll(**kwargs)
        self.store.event(device.id,"enroll",{"label":device.label,"adapter":device.adapter,"native_id":device.native_id})
        return device

    def status(self) -> dict:
        out={"store":self.store.stats(),"adapters":{}}
        for name,adapter in self.adapters.items():
            try: ok,detail=adapter.available()
            except Exception as exc: ok,detail=False,str(exc)
            out["adapters"][name]={"available":bool(ok),"detail":detail}
        return out
