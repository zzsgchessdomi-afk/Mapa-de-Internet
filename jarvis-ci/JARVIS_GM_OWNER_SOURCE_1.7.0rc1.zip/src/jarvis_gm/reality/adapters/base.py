from __future__ import annotations

from abc import ABC, abstractmethod
from jarvis_gm.reality.models import RealityDevice, DeviceState


class RealityAdapter(ABC):
    name: str

    @abstractmethod
    def available(self) -> tuple[bool,str]: ...

    @abstractmethod
    def state(self, device: RealityDevice) -> DeviceState: ...

    @abstractmethod
    def command(self, device: RealityDevice, command: str, args: dict) -> dict: ...
