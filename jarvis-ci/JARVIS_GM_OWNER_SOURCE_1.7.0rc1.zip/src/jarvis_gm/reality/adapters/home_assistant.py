from __future__ import annotations

from dataclasses import dataclass
from ipaddress import ip_address
import json
import socket
import time
from urllib import request, error
from urllib.parse import urlparse

from .base import RealityAdapter
from jarvis_gm.reality.models import RealityDevice, DeviceState


SAFE_COMMANDS = {
    "light": {"on": "turn_on", "off": "turn_off", "toggle": "toggle"},
    "media_player": {"play": "media_play", "pause": "media_pause", "play_pause": "media_play_pause", "volume": "volume_set"},
}


@dataclass(slots=True)
class HomeAssistantConfig:
    base_url: str
    token_getter: callable
    timeout_s: float = 8.0


class HomeAssistantAdapter(RealityAdapter):
    name = "home_assistant"

    def __init__(self, config: HomeAssistantConfig) -> None:
        self.config = config
        self.base_url = self._validate_base(config.base_url)

    @staticmethod
    def _validate_base(value: str) -> str:
        raw = value.strip().rstrip("/")
        parsed = urlparse(raw)
        if parsed.scheme not in {"http","https"} or not parsed.hostname:
            raise ValueError("Home Assistant URL must be http(s)://host[:port]")
        if parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise ValueError("Home Assistant URL may not contain credentials/query/fragment")
        if parsed.scheme == "http":
            host = parsed.hostname
            private = host in {"localhost"} or host.endswith(".local")
            try: private = private or ip_address(host).is_private or ip_address(host).is_loopback
            except ValueError:
                try:
                    ips={x[4][0] for x in socket.getaddrinfo(host,parsed.port or 80,type=socket.SOCK_STREAM)}
                    private = private or bool(ips) and all(ip_address(x).is_private or ip_address(x).is_loopback for x in ips)
                except Exception: pass
            if not private:
                raise ValueError("Plain HTTP is only allowed for private/local Home Assistant hosts; use HTTPS otherwise")
        return raw

    def _token(self) -> str:
        token = str(self.config.token_getter() or "").strip()
        if not token: raise RuntimeError("Home Assistant credential is not configured")
        return token

    def _json(self, method: str, path: str, payload: dict | None = None):
        data = None if payload is None else json.dumps(payload).encode("utf-8")
        req = request.Request(self.base_url + path, data=data, method=method,
                              headers={"Authorization":f"Bearer {self._token()}","Content-Type":"application/json"})
        try:
            with request.urlopen(req, timeout=float(self.config.timeout_s)) as resp:
                body = resp.read()
                return json.loads(body.decode("utf-8")) if body else {}
        except error.HTTPError as exc:
            raise RuntimeError(f"Home Assistant HTTP {exc.code}") from exc
        except error.URLError as exc:
            raise RuntimeError(f"Home Assistant unavailable: {exc.reason}") from exc

    def available(self) -> tuple[bool,str]:
        try:
            payload = self._json("GET","/api/")
            return True, str(payload.get("message") or "connected")
        except Exception as exc:
            return False, str(exc)

    def state(self, device: RealityDevice) -> DeviceState:
        raw = self._json("GET", f"/api/states/{device.native_id}")
        return DeviceState(device.id, str(raw.get("state") or "unknown"), dict(raw.get("attributes") or {}), time.time(), self.name)

    def command(self, device: RealityDevice, command: str, args: dict) -> dict:
        domain = device.native_id.split(".",1)[0]
        mapping = SAFE_COMMANDS.get(domain, {})
        service = mapping.get(command)
        if not service:
            raise PermissionError(f"Reality Bridge does not allow command '{command}' for domain '{domain}'")
        payload = {"entity_id": device.native_id}
        if domain == "media_player" and command == "volume":
            level = float(args.get("level"))
            if not 0.0 <= level <= 1.0: raise ValueError("volume level must be between 0 and 1")
            payload["volume_level"] = level
        return self._json("POST", f"/api/services/{domain}/{service}", payload)
