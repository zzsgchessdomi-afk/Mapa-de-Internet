from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class DeviceRisk(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass(slots=True)
class RealityDevice:
    id: str
    adapter: str
    native_id: str
    label: str
    kind: str
    capabilities: tuple[str, ...] = ()
    risk: DeviceRisk = DeviceRisk.LOW
    enabled: bool = True
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class DeviceState:
    device_id: str
    state: str
    attributes: dict[str, Any]
    observed_at: float
    source: str


@dataclass(slots=True)
class CommandResult:
    ok: bool
    device_id: str
    command: str
    before: DeviceState | None = None
    after: DeviceState | None = None
    detail: str = ""
