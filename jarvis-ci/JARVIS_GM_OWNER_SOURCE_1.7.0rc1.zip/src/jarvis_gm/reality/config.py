from __future__ import annotations
from pathlib import Path
import json


class RealityConfig:
    def __init__(self, path: Path) -> None:
        self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True)

    def load(self) -> dict:
        if not self.path.exists(): return {}
        try:
            raw=json.loads(self.path.read_text(encoding='utf-8'))
            return raw if isinstance(raw,dict) else {}
        except Exception: return {}

    def save(self, payload: dict) -> None:
        safe=dict(payload)
        # Secrets are forbidden in this file by contract.
        for key in tuple(safe):
            if any(x in key.casefold() for x in ('token','secret','password','pin','key')):
                safe.pop(key,None)
        tmp=self.path.with_suffix(self.path.suffix+'.tmp')
        tmp.write_text(json.dumps(safe,ensure_ascii=False,indent=2,sort_keys=True),encoding='utf-8')
        tmp.replace(self.path)
