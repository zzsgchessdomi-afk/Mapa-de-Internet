from __future__ import annotations

from typing import Any
from jarvis_gm.actions.base import Action
from .models import DeviceRisk


class RealityListAction(Action):
    name="reality_list_devices"; capability="reality.read"
    def __init__(self,bridge): self.bridge=bridge
    def run(self,**kwargs): return self.bridge.list_devices()

class RealityObserveAction(Action):
    name="reality_observe"; capability="reality.read"
    def __init__(self,bridge): self.bridge=bridge
    def run(self,**kwargs): return self.bridge.observe(str(kwargs["device"]))

class RealityCommandAction(Action):
    name="reality_command"; capability="reality.control"
    def __init__(self,bridge): self.bridge=bridge
    def run(self,**kwargs):
        res=self.bridge.command(str(kwargs["device"]),str(kwargs["command"]),dict(kwargs.get("args") or {}))
        return {"ok":res.ok,"device_id":res.device_id,"command":res.command,"before":res.before.state if res.before else None,"after":res.after.state if res.after else None,"detail":res.detail}
    def verify(self,output,**kwargs): return bool(output and output.get("ok")), str((output or {}).get("detail") or "Reality command not verified")

class RealityEnrollAction(Action):
    name="reality_enroll"; capability="reality.manage"
    def __init__(self,bridge): self.bridge=bridge
    def run(self,**kwargs):
        risk=DeviceRisk(str(kwargs.get("risk") or "low"))
        d=self.bridge.enroll(adapter=str(kwargs["adapter"]),native_id=str(kwargs["native_id"]),label=str(kwargs["label"]),kind=str(kwargs.get("kind") or "device"),capabilities=tuple(str(x) for x in kwargs.get("capabilities",[])),risk=risk,metadata=dict(kwargs.get("metadata") or {}))
        return {"id":d.id,"label":d.label,"risk":d.risk.value}
