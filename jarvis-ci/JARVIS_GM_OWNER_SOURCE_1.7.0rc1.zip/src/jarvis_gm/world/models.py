from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any
import time


@dataclass(slots=True)
class WorldEntity:
    id: str
    kind: str
    label: str
    attributes: dict[str, Any] = field(default_factory=dict)
    source: str = "system"
    confidence: float = 1.0
    first_seen: float = field(default_factory=time.time)
    last_seen: float = field(default_factory=time.time)
    expires_at: float | None = None
    status: str = "active"

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class WorldRelation:
    id: str
    subject_id: str
    predicate: str
    object_id: str
    attributes: dict[str, Any] = field(default_factory=dict)
    source: str = "system"
    confidence: float = 1.0
    first_seen: float = field(default_factory=time.time)
    last_seen: float = field(default_factory=time.time)
    expires_at: float | None = None
    status: str = "active"

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)
