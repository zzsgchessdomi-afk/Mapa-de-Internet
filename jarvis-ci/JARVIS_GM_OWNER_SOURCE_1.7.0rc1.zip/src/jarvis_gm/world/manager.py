from __future__ import annotations

from typing import Any
import time

from .store import WorldModelStore


class WorldModelManager:
    """Maintains a compact, owner-local model of the current situation."""

    OWNER_ID = WorldModelStore.stable_id("person", "owner")
    PC_ID = WorldModelStore.stable_id("device", "local_pc")

    def __init__(self, store: WorldModelStore, *, memory_manager=None, mobile=None, fusion=None, write_allowed=None, memory_allowed=None, mobile_allowed=None) -> None:
        self.store = store
        self.memory_manager = memory_manager
        self.mobile = mobile
        self.fusion = fusion
        self.write_allowed = write_allowed or (lambda: True)
        self.memory_allowed = memory_allowed or (lambda: True)
        self.mobile_allowed = mobile_allowed or (lambda: True)
        self._ensure_baseline()

    def _ensure_baseline(self) -> None:
        if not self.write_allowed(): return
        self.store.upsert_entity(kind="person", key="owner", label="Owner", source="system.identity", confidence=1.0)
        self.store.upsert_entity(kind="device", key="local_pc", label="Local PC", source="system.runtime", confidence=1.0)
        self.store.relate(self.OWNER_ID, "owns", self.PC_ID, source="system.identity", confidence=1.0)

    def ingest_perception(self, event) -> None:
        if not self.write_allowed(): return
        self._ensure_baseline()
        payload = dict(getattr(event, "payload", {}) or {})
        event_type = str(getattr(event, "type", "unknown"))
        source = str(getattr(event, "source", "perception"))
        confidence = float(getattr(event, "confidence", 1.0))
        observed_at = float(getattr(event, "timestamp", time.time()))
        self.store.observe(event_type, payload, source=source, confidence=confidence, observed_at=observed_at)
        if event_type == "environment.changed":
            title = str(payload.get("active_title") or "").strip()
            handle = payload.get("active_handle")
            key = str(handle) if handle is not None else (title or "unknown")
            win = self.store.upsert_entity(
                kind="window", key=key, label=title or "Active window",
                attributes={"handle": handle, "fingerprint": str(payload.get("fingerprint") or ""), "element_count": int(payload.get("element_count") or 0)},
                source="sentinel", confidence=confidence, ttl_s=8.0, now=observed_at,
            )
            self.store.relate(self.PC_ID, "foreground_window", win.id, source="sentinel", confidence=confidence, ttl_s=8.0, now=observed_at)
        elif event_type == "voice.command":
            text = str(payload.get("text") or "").strip()
            if text:
                utterance = self.store.upsert_entity(kind="utterance", key=f"{observed_at:.6f}:{text}", label=text[:120], attributes={"text": text}, source=source, confidence=confidence, ttl_s=20.0, now=observed_at)
                self.store.relate(self.OWNER_ID, "said", utterance.id, source=source, confidence=confidence, ttl_s=20.0, now=observed_at)

    def sync(self) -> None:
        if not self.write_allowed(): return
        self._ensure_baseline()
        now = time.time()
        if self.memory_manager is not None and self.memory_allowed():
            project = self.memory_manager.active_project
            if project is not None:
                p = self.store.upsert_entity(kind="project", key=project.id, label=project.name, attributes={"summary": project.summary}, source="memory.project", confidence=1.0)
                self.store.relate(self.OWNER_ID, "working_on", p.id, source="memory.project", confidence=1.0, ttl_s=300.0)
        if self.mobile is not None and self.mobile_allowed():
            try:
                devices = [x.as_dict() if hasattr(x,"as_dict") else x for x in self.mobile.manager.devices.list()]
            except Exception:
                devices = []
            for row in devices:
                if not isinstance(row, dict):
                    continue
                did = str(row.get("device_id") or row.get("id") or "").strip()
                if not did:
                    continue
                dev = self.store.upsert_entity(kind="device", key=f"mobile:{did}", label=str(row.get("name") or did), attributes={k: row.get(k) for k in ("online","last_seen","model") if k in row}, source="mobile", confidence=1.0, ttl_s=180.0, now=now)
                self.store.relate(self.OWNER_ID, "owns", dev.id, source="mobile", confidence=1.0)
        self.store.purge_expired(now)

    def goal_started(self, goal_id: str, text: str) -> None:
        if not self.write_allowed(): return
        self._ensure_baseline()
        g = self.store.upsert_entity(kind="goal", key=goal_id, label=text[:160], attributes={"text": text, "state": "received"}, source="core.goal", confidence=1.0, ttl_s=86400.0)
        self.store.relate(self.OWNER_ID, "pursues", g.id, source="core.goal", confidence=1.0, ttl_s=86400.0)
        if self.memory_manager is not None and self.memory_allowed() and self.memory_manager.active_project is not None:
            p = self.memory_manager.active_project
            pid = self.store.stable_id("project", p.id)
            self.store.relate(pid, "contains_goal", g.id, source="core.goal", confidence=1.0, ttl_s=86400.0)

    def goal_finished(self, goal) -> None:
        if not self.write_allowed(): return
        self._ensure_baseline()
        self.store.upsert_entity(kind="goal", key=goal.id, label=goal.text[:160], attributes={"text": goal.text, "state": goal.state.value, "verification": goal.verification, "actions": [r.action for r in goal.results]}, source="core.goal", confidence=1.0, ttl_s=86400.0)
        self.store.observe("goal.finished", {"goal_id": goal.id, "state": goal.state.value, "verification": goal.verification}, source="core", confidence=1.0)

    def action_observed(self, goal_id: str, req, result, verified: bool | None = None, detail: str | None = None) -> None:
        if not self.write_allowed(): return
        payload = {"goal_id": goal_id, "action": req.name, "capability": req.capability, "ok": result.ok, "blocked": result.blocked, "error": result.error, "verified": verified, "detail": detail}
        self.store.observe("action.result", payload, source="core.executor", confidence=1.0)

    def context_for_goal(self, goal: str = "") -> dict[str, Any]:
        self.sync()
        fusion = None
        if self.fusion is not None:
            try:
                fusion = self.fusion.resolve().as_dict()
            except Exception as exc:
                fusion = {"error": str(exc)}
        entities = self.store.entities(kinds=("project","device","window","goal"), limit=20)
        relations = self.store.relations(limit=30)
        observations = self.store.recent_observations(limit=12)
        return {
            "query": goal,
            "active_project": None if self.memory_manager is None or not self.memory_allowed() or self.memory_manager.active_project is None else self.memory_manager.active_project.name,
            "entities": [{"id": e["id"], "kind": e["kind"], "label": e["label"], "attributes": e["attributes"], "confidence": e["confidence"], "last_seen": e["last_seen"]} for e in entities],
            "relations": [{"subject": r["subject_id"], "predicate": r["predicate"], "object": r["object_id"], "confidence": r["confidence"], "last_seen": r["last_seen"]} for r in relations],
            "recent_observations": observations,
            "multimodal": fusion,
            "stats": self.store.stats(),
        }

    def cloud_context_for_goal(self, goal: str = "", *, allow_screen: bool = False, allow_perception: bool = False, allow_memory: bool = False, allow_reality: bool = False) -> dict[str, Any]:
        """Privacy-projected world state for a cloud planner.

        `world.cloud` is necessary but intentionally not sufficient to export data
        that originated behind other privacy boundaries. Screen-, perception- and
        memory-derived fields are independently stripped unless their own cloud
        permission is enabled.
        """
        data = self.context_for_goal(goal)
        entities = list(data.get("entities") or [])
        blocked_ids=set()
        if not allow_screen:
            for e in entities:
                if e.get("kind") == "window": blocked_ids.add(str(e.get("id")))
            entities=[e for e in entities if e.get("kind") != "window"]
        if not allow_perception:
            for e in entities:
                if e.get("kind") == "utterance": blocked_ids.add(str(e.get("id")))
            entities=[e for e in entities if e.get("kind") != "utterance"]
        if not allow_memory:
            for e in entities:
                if e.get("kind") == "project": blocked_ids.add(str(e.get("id")))
            entities=[e for e in entities if e.get("kind") != "project"]
        if not allow_reality:
            for e in entities:
                if e.get("kind") == "physical_device": blocked_ids.add(str(e.get("id")))
            entities=[e for e in entities if e.get("kind") != "physical_device"]
        data["entities"]=entities
        data["relations"]=[r for r in (data.get("relations") or [])
                           if str(r.get("subject")) not in blocked_ids and str(r.get("object")) not in blocked_ids
                           and (allow_screen or r.get("predicate") != "foreground_window")
                           and (allow_perception or r.get("predicate") != "said")]
        observations=[]
        for row in data.get("recent_observations") or []:
            et=str(row.get("event_type") or "")
            if not allow_screen and (et.startswith("environment.") or et.startswith("screen.") or et.startswith("interaction.")):
                continue
            if not allow_perception and (et.startswith("voice.") or et.startswith("gesture.") or et.startswith("sensor.")):
                continue
            if not allow_memory and et.startswith("memory."):
                continue
            if not allow_reality and et.startswith("reality."):
                continue
            observations.append(row)
        data["recent_observations"]=observations
        mm=data.get("multimodal")
        if isinstance(mm,dict):
            mm=dict(mm)
            mm.pop("scene_fingerprint",None)
            if not allow_screen:
                mm["active_title"]=""
                mm["sources"]=[x for x in mm.get("sources",[]) if x!="scene"]
            if not allow_perception:
                mm["voice_text"]=""; mm["gesture"]=""; mm["point"]=None
                mm["sources"]=[x for x in mm.get("sources",[]) if x not in {"voice","gesture","point"}]
            data["multimodal"]=mm
        if not allow_memory:
            data["active_project"] = None
        return data

