from __future__ import annotations

from typing import Any
from jarvis_gm.actions.base import Action


class WorldStatusAction(Action):
    name = "world_status"; capability = "world.read"
    def __init__(self, world) -> None: self.world = world
    def run(self, **kwargs: Any) -> Any: return self.world.context_for_goal(str(kwargs.get("query") or ""))


class WorldEntitiesAction(Action):
    name = "world_entities"; capability = "world.read"
    def __init__(self, world) -> None: self.world = world
    def run(self, **kwargs: Any) -> Any:
        kinds = kwargs.get("kinds")
        kinds_tuple = tuple(str(x) for x in kinds) if isinstance(kinds, list) else None
        return self.world.store.entities(kinds=kinds_tuple, limit=min(100, int(kwargs.get("limit", 30))))
