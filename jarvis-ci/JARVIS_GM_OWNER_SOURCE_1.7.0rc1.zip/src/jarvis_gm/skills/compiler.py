from __future__ import annotations

import inspect
import re
from typing import Any

from .models import SkillDefinition, SkillValidation

_VAR = re.compile(r"\{\{\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*\}\}")
_DENIED_META_ACTIONS = {
    "run_skill", "learn_skill", "enable_skill", "run_mission", "deep_research",
    "run_autonomous_mission", "resume_autonomous_mission",
    "workbench_create", "workbench_run_cycle", "workbench_pause", "workbench_resume", "workbench_cancel",
    "swarm_run", "evolution_propose", "evolution_promote", "evolution_reject", "evolution_rollback",
}
_REQUIRED_KWARG = re.compile(r"kwargs\[\s*['\"]([^'\"]+)['\"]\s*\]")
_OPTIONAL_KWARG = re.compile(r"kwargs\.get\(\s*['\"]([^'\"]+)['\"]")


class SkillCompiler:
    """Validate a persisted skill against the live action registry."""

    def __init__(self, actions: dict[str, Any]) -> None:
        self.actions = actions

    def validate(self, skill: SkillDefinition) -> SkillValidation:
        errors: list[str] = []
        warnings: list[str] = []
        capabilities: list[str] = []
        declared_inputs = set(skill.inputs)

        if not skill.name.strip():
            errors.append("Skill has no name")
        if not skill.steps:
            errors.append("Skill has no steps")

        for index, step in enumerate(skill.steps, 1):
            if step.action in _DENIED_META_ACTIONS:
                errors.append(f"Step {index}: meta-action {step.action!r} is forbidden inside skills")
                continue

            action = self.actions.get(step.action)
            if action is None:
                errors.append(f"Step {index}: unknown action {step.action!r}")
                continue

            capability = str(action.capability)
            if capability not in capabilities:
                capabilities.append(capability)

            required_args, optional_args, accepts_any = _action_contract(action)
            if not accepts_any:
                unknown = sorted(set(step.args) - required_args - optional_args)
                if unknown:
                    errors.append(f"Step {index}: unsupported args for {step.action}: {', '.join(unknown)}")
            missing = sorted(required_args - set(step.args))
            if missing:
                errors.append(f"Step {index}: missing required args for {step.action}: {', '.join(missing)}")

            for value in _walk_values(step.args):
                if not isinstance(value, str):
                    continue
                for variable in _VAR.findall(value):
                    if variable not in declared_inputs:
                        errors.append(f"Step {index}: undeclared input {{{{{variable}}}}}")

        if skill.required_capabilities and set(skill.required_capabilities) != set(capabilities):
            warnings.append("Stored capability list differs from live action registry; live registry wins")
        return SkillValidation(not errors, errors, warnings, tuple(capabilities))

    def render(self, skill: SkillDefinition, inputs: dict[str, Any]) -> list[tuple[str, dict[str, Any]]]:
        missing = [name for name, spec in skill.inputs.items() if name not in inputs and "default" not in spec]
        if missing:
            raise ValueError(f"Missing skill inputs: {', '.join(missing)}")

        extra = sorted(set(inputs) - set(skill.inputs))
        if extra:
            raise ValueError("Unknown skill inputs: " + ", ".join(extra))

        values = {name: inputs[name] if name in inputs else spec.get("default") for name, spec in skill.inputs.items()}
        for name, spec in skill.inputs.items():
            _validate_input_type(name, values.get(name), str(spec.get("type", "any")))

        return [(step.action, _render_value(step.args, values)) for step in skill.steps]


def _action_contract(action: Any) -> tuple[set[str], set[str], bool]:
    """Infer a conservative keyword contract for Action.run.

    New actions may define required_args / optional_args. Older actions in the
    project mostly use **kwargs, so literal kwargs["x"] accesses are treated as
    required and kwargs.get("x") accesses as optional.
    """
    declared_required = getattr(action, "required_args", None)
    declared_optional = getattr(action, "optional_args", None)
    if declared_required is not None or declared_optional is not None:
        return set(declared_required or ()), set(declared_optional or ()), False

    try:
        signature = inspect.signature(action.run)
    except (TypeError, ValueError):
        return set(), set(), True

    params = {name: param for name, param in signature.parameters.items() if name != "self"}
    required = {
        name
        for name, param in params.items()
        if param.kind in (inspect.Parameter.POSITIONAL_ONLY, inspect.Parameter.POSITIONAL_OR_KEYWORD, inspect.Parameter.KEYWORD_ONLY)
        and param.default is inspect.Parameter.empty
    }
    optional = {
        name
        for name, param in params.items()
        if param.kind in (inspect.Parameter.POSITIONAL_OR_KEYWORD, inspect.Parameter.KEYWORD_ONLY)
        and param.default is not inspect.Parameter.empty
    }
    has_varkw = any(param.kind == inspect.Parameter.VAR_KEYWORD for param in params.values())
    if not has_varkw:
        return required, optional, False

    try:
        source = inspect.getsource(action.run)
    except (OSError, TypeError):
        return required, optional, True

    literal_required = set(_REQUIRED_KWARG.findall(source))
    literal_optional = set(_OPTIONAL_KWARG.findall(source))
    required |= literal_required
    optional |= literal_optional - required
    accepts_any = not bool(required or optional)
    return required, optional, accepts_any


def _walk_values(value: Any):
    if isinstance(value, dict):
        for item in value.values():
            yield from _walk_values(item)
    elif isinstance(value, list):
        for item in value:
            yield from _walk_values(item)
    else:
        yield value


def _render_value(value: Any, inputs: dict[str, Any]) -> Any:
    if isinstance(value, dict):
        return {key: _render_value(item, inputs) for key, item in value.items()}
    if isinstance(value, list):
        return [_render_value(item, inputs) for item in value]
    if isinstance(value, str):
        full = _VAR.fullmatch(value.strip())
        if full:
            return inputs[full.group(1)]
        return _VAR.sub(lambda match: str(inputs[match.group(1)]), value)
    return value


def _validate_input_type(name: str, value: Any, expected: str) -> None:
    expected = expected.lower().strip()
    if expected in {"", "any"}:
        return
    checks = {
        "string": lambda item: isinstance(item, str),
        "integer": lambda item: isinstance(item, int) and not isinstance(item, bool),
        "number": lambda item: isinstance(item, (int, float)) and not isinstance(item, bool),
        "boolean": lambda item: isinstance(item, bool),
        "object": lambda item: isinstance(item, dict),
        "array": lambda item: isinstance(item, list),
    }
    check = checks.get(expected)
    if check is None:
        raise ValueError(f"Unsupported input type for {name}: {expected}")
    if not check(value):
        raise ValueError(f"Skill input {name} must be {expected}")
