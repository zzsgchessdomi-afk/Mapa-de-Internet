from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any

from .compiler import SkillCompiler
from .models import SkillDefinition


@dataclass(slots=True)
class PracticeTrial:
    name: str
    ok: bool
    steps: list[dict[str,Any]]=field(default_factory=list)
    notes: list[str]=field(default_factory=list)
    def as_dict(self): return asdict(self)


@dataclass(slots=True)
class PracticeReport:
    skill: str
    ok: bool
    trials: list[PracticeTrial]=field(default_factory=list)
    error: str=''
    def as_dict(self): return {'skill':self.skill,'ok':self.ok,'trials':[x.as_dict() for x in self.trials],'error':self.error}


class ShadowWorld:
    """In-memory world model for non-executing skill practice."""
    def __init__(self) -> None:
        self.cursor=(0,0); self.window_generation=0; self.input_events=0; self.apps=[]; self.urls=[]
        self.virtual_files=set(); self.virtual_notes=set(); self.memory_events=0

    def apply(self,name:str,args:dict[str,Any],capability:str) -> dict[str,Any]:
        if name in {'move_cursor','move_cursor_normalized'}:
            self.cursor=(args.get('x',0),args.get('y',0))
        elif name in {'mouse_button','hotkey','type_text','grounded_click'}:
            self.input_events+=1
        elif capability=='window.control': self.window_generation+=1
        elif name=='open_app': self.apps.append(str(args.get('app','')))
        elif name=='open_url': self.urls.append(str(args.get('url','')))
        elif name in {'create_note'}: self.virtual_notes.add(str(args.get('filename','note')))
        elif name in {'create_folder','copy_file','move_file'}: self.virtual_files.add(str(args.get('path') or args.get('dst') or 'virtual'))
        elif capability.startswith('memory.') or name=='remember': self.memory_events+=1
        return {'simulated':True,'action':name,'capability':capability}


class SkillLab:
    """Practices skills without invoking the real Executor or OS.

    The lab validates rendered steps against the live action registry, runs them in
    a shadow state model, and performs adversarial checks for capability revocation
    and context drift. It never grants authority and never executes an action.
    """
    HIGH_RISK={'system.control','security.sensitive','external.send','mobile.security','mobile.messaging'}

    def __init__(self,actions:dict[str,Any]) -> None:
        self.actions=actions; self.compiler=SkillCompiler(actions)

    def practice(self,skill:SkillDefinition,inputs:dict[str,Any]|None=None) -> PracticeReport:
        validation=self.compiler.validate(skill)
        if not validation.ok: return PracticeReport(skill.name,False,error='; '.join(validation.errors))
        try: rendered=self.compiler.render(skill,inputs or self._samples(skill))
        except Exception as exc: return PracticeReport(skill.name,False,error=str(exc))
        nominal=PracticeTrial('nominal',True); world=ShadowWorld()
        for name,args in rendered:
            action=self.actions.get(name)
            if action is None:
                nominal.ok=False;nominal.notes.append(f'unknown action: {name}');break
            cap=str(action.capability)
            if cap in self.HIGH_RISK:
                nominal.ok=False;nominal.notes.append(f'high-risk capability requires real owner review: {cap}');break
            effect=world.apply(name,args,cap); nominal.steps.append({'action':name,'args':args,'capability':cap,'effect':effect})
        revoked=PracticeTrial('permission_revocation',True,notes=['Every step remains bound to its underlying capability; owner revocation must block real execution.'])
        for name,args in rendered:
            action=self.actions[name]; revoked.steps.append({'action':name,'capability':str(action.capability),'expected':'BLOCKED when capability is revoked'})
        drift=PracticeTrial('context_drift',True)
        context_sensitive={'grounded_click','focus_window','move_window','resize_active_window','maximize_window','minimize_window','mouse_button','hotkey','type_text'}
        for name,args in rendered:
            if name in context_sensitive:
                drift.steps.append({'action':name,'expected':'requires fresh runtime verification after simulated context change'})
        if not drift.steps: drift.notes.append('No context-sensitive desktop steps in this skill.')
        trials=[nominal,revoked,drift]
        return PracticeReport(skill.name,all(t.ok for t in trials),trials,'' if all(t.ok for t in trials) else 'Skill failed shadow-world practice')

    @staticmethod
    def _samples(skill:SkillDefinition)->dict[str,Any]:
        out={}
        for name,spec in skill.inputs.items():
            if 'default' in spec: out[name]=spec['default']; continue
            kind=str(spec.get('type','string')).lower()
            out[name]={'integer':1,'number':1.0,'boolean':True,'object':{},'array':[]}.get(kind,'__jarvis_lab__')
        return out
