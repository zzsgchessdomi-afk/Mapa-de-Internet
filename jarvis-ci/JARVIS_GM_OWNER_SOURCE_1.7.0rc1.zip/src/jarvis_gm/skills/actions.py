from __future__ import annotations

from jarvis_gm.actions.base import Action
from .models import SkillStatus


class ListSkillsAction(Action):
    name="list_skills"; capability="safe.read"
    def __init__(self, store): self.store=store
    def run(self):
        return [{"name":s.name,"version":s.version,"status":s.status.value,"description":s.description,"required_capabilities":list(s.required_capabilities)} for s in self.store.list()]

class LearnSkillAction(Action):
    name="learn_skill"; capability="skill.learn"
    def __init__(self, forge): self.forge=forge
    def run(self, goal: str, documentation: str = "", use_web: bool = False):
        result=self.forge.learn(goal,documentation=documentation,allow_web=bool(use_web))
        return {"skill":result.skill.as_dict(),"validation":{"ok":result.validation.ok,"errors":result.validation.errors,"warnings":result.validation.warnings},"research":{"citations":result.research.get("citations",[]),"queries":result.research.get("queries",[]),"research_id":result.research.get("research_id")},"preflight":result.preflight,"practice":result.practice}
    def verify(self, output, **kwargs):
        ok=bool(output and output.get("validation",{}).get("ok") and output.get("preflight",{}).get("ok") and output.get("practice",{}).get("ok"))
        return ok, "Skill compiled, preflighted and passed shadow-world practice" if ok else "Skill failed constrained compilation/preflight/practice"

class EnableSkillAction(Action):
    name="enable_skill"; capability="skill.manage"
    def __init__(self, store, forge): self.store=store; self.forge=forge
    def run(self, name: str, enabled: bool = True):
        validation=self.forge.validate_existing(name)
        if enabled and not validation.ok: raise RuntimeError("Skill cannot be enabled: "+"; ".join(validation.errors))
        if enabled:
            practice=self.forge.practice_existing(name)
            if not practice.get("ok"):
                raise RuntimeError("Skill cannot be enabled: shadow-world practice failed: "+str(practice.get("error") or "unsafe simulation"))
        skill=self.store.set_status(name,SkillStatus.ENABLED if enabled else SkillStatus.VALIDATED)
        return {"name":skill.name,"status":skill.status.value}

class RunSkillAction(Action):
    name="run_skill"; capability="skill.execute"
    def __init__(self, store, runner): self.store=store; self.runner=runner
    def run(self, name: str, inputs: dict | None = None, dry_run: bool = False):
        skill=self.store.get(name)
        if not skill: raise KeyError(f"Unknown skill: {name}")
        report=self.runner.run(skill,inputs or {},dry_run=bool(dry_run))
        return {"skill":report.skill,"ok":report.ok,"dry_run":report.dry_run,"steps":report.steps,"error":report.error}
    def verify(self, output, **kwargs):
        ok=bool(output and output.get("ok"))
        return ok, "Skill execution verified" if ok else str(output.get("error") if output else "Skill failed")
