from __future__ import annotations

from dataclasses import asdict
from typing import Any

from jarvis_gm.core.models import ActionRequest
from .compiler import SkillCompiler
from .models import SkillDefinition, SkillRunReport, SkillStatus


class SkillRunner:
    def __init__(self, executor, verifier, audit_memory=None, lab=None) -> None:
        self.executor = executor
        self.verifier = verifier
        self.audit_memory = audit_memory
        self.compiler = SkillCompiler(executor.actions)
        self.lab = lab

    def run(self, skill: SkillDefinition, inputs: dict[str, Any] | None = None, *, dry_run: bool = False) -> SkillRunReport:
        validation = self.compiler.validate(skill)
        if not validation.ok:
            return SkillRunReport(skill.name, False, dry_run, error="; ".join(validation.errors))
        if not dry_run and skill.status != SkillStatus.ENABLED:
            return SkillRunReport(skill.name, False, dry_run, error="Skill is not enabled by the owner")
        if not dry_run and self.lab is not None:
            practice=self.lab.practice(skill)
            if not practice.ok:
                return SkillRunReport(skill.name, False, dry_run, error="Skill Lab rejected execution: "+(practice.error or "shadow-world practice failed"))
        try:
            rendered = self.compiler.render(skill, inputs or {})
        except Exception as exc:
            return SkillRunReport(skill.name, False, dry_run, error=str(exc))
        records: list[dict[str, Any]] = []
        for name, args in rendered:
            action = self.executor.actions[name]
            req = ActionRequest(name, args, action.capability)
            if dry_run:
                records.append({"action": name, "args": args, "capability": action.capability, "would_execute": True})
                continue
            result = self.executor.execute(req)
            ok, detail = self.verifier.verify(req, result)
            row = {"request": {"name": name, "args": args, "capability": action.capability}, "result": asdict(result), "verified": ok, "detail": detail}
            records.append(row)
            if self.audit_memory:
                self.audit_memory.record_event(f"skill:{skill.name}", "skill.step", row)
            if not ok:
                return SkillRunReport(skill.name, False, False, records, detail)
        return SkillRunReport(skill.name, True, dry_run, records)
