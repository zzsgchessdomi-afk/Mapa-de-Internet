from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any
import time


class SkillStatus(str, Enum):
    DRAFT = "draft"
    VALIDATED = "validated"
    ENABLED = "enabled"
    RETIRED = "retired"


@dataclass(slots=True)
class SkillStep:
    action: str
    args: dict[str, Any] = field(default_factory=dict)
    description: str = ""


@dataclass(slots=True)
class SkillDefinition:
    name: str
    description: str
    version: int = 1
    inputs: dict[str, dict[str, Any]] = field(default_factory=dict)
    steps: list[SkillStep] = field(default_factory=list)
    required_capabilities: tuple[str, ...] = ()
    source: str = "user"
    source_urls: tuple[str, ...] = ()
    provenance_id: str = ""
    confidence: float = 1.0
    status: SkillStatus = SkillStatus.DRAFT
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)

    def as_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["status"] = self.status.value
        data["required_capabilities"] = list(self.required_capabilities)
        data["source_urls"] = list(self.source_urls)
        return data


@dataclass(slots=True)
class SkillValidation:
    ok: bool
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    required_capabilities: tuple[str, ...] = ()


@dataclass(slots=True)
class SkillRunReport:
    skill: str
    ok: bool
    dry_run: bool
    steps: list[dict[str, Any]] = field(default_factory=list)
    error: str | None = None
