from __future__ import annotations

from dataclasses import dataclass
import json
import re
from typing import Any, Callable

from .compiler import SkillCompiler
from .models import SkillDefinition, SkillStatus, SkillStep, SkillValidation
from .store import SkillStore


@dataclass(slots=True)
class ForgeResult:
    skill: SkillDefinition
    validation: SkillValidation
    research: dict[str, Any]
    preflight: dict[str, Any]
    practice: dict[str, Any]


class SkillForge:
    def __init__(self, store: SkillStore, actions: dict[str, Any], provider_resolver: Callable[[], Any], *,
                 web_allowed: Callable[[], bool] | None = None,
                 research_callback: Callable[[str], dict[str, Any]] | None = None,
                 research_corps_allowed: Callable[[], bool] | None = None, lab: Any | None = None) -> None:
        self.store = store
        self.actions = actions
        self.provider_resolver = provider_resolver
        self.web_allowed = web_allowed or (lambda: False)
        self.research_callback = research_callback
        self.research_corps_allowed = research_corps_allowed or (lambda: False)
        self.compiler = SkillCompiler(actions)
        self.lab = lab

    def learn(self, goal: str, *, documentation: str = "", allow_web: bool = False) -> ForgeResult:
        goal = " ".join(str(goal).split()).strip()
        if not goal:
            raise ValueError("Learning goal cannot be empty")
        provider = self.provider_resolver()
        if not getattr(provider, "available", False):
            raise RuntimeError("Learning a new skill requires a configured cloud AI provider")
        research: dict[str, Any] = {"text": documentation.strip(), "citations": [], "queries": []}
        if allow_web:
            if not self.web_allowed():
                raise PermissionError("Capability blocked by policy: research.web")
            if self.research_callback is not None and self.research_corps_allowed():
                research = self.research_callback(goal)
            else:
                method = getattr(provider, "grounded_search", None)
                if method is None:
                    raise RuntimeError("Active provider does not support grounded web research")
                research = method(
                    "Research a reliable, current procedure for this task. Prefer primary/official documentation. "
                    "Focus on operational steps and constraints, not marketing. Task: " + goal
                )
        evidence = (documentation.strip() + "\n" + str(research.get("text", "")).strip()).strip()
        available = [{"name": name, "capability": action.capability} for name, action in sorted(self.actions.items()) if name not in {"run_skill","learn_skill","enable_skill","run_mission","run_autonomous_mission","resume_autonomous_mission"}]
        prompt = (
            "Design ONE reusable JARVIS skill for the user's task. You may ONLY use actions listed in AVAILABLE_ACTIONS. "
            "Do not invent shell/terminal actions. A skill is a deterministic recipe, not prose. "
            "Use {{input_name}} templates for values the user must supply. Return JSON only with keys: "
            "name, description, inputs(object of input_name -> {type, description, optional default}), steps(array of {action,args,description}), confidence(number 0..1). "
            "If the available actions cannot safely accomplish the task, return {\"name\":\"UNSUPPORTED\",\"description\":\"...\",\"inputs\":{},\"steps\":[],\"confidence\":0}.\n"
            f"AVAILABLE_ACTIONS={json.dumps(available, ensure_ascii=False)}\n"
            f"EVIDENCE={evidence[:30000]}\nTASK={goal}"
        )
        raw = provider.generate(prompt, system="You compile evidence into constrained desktop-agent skills. Never invent tools.")
        data = _parse_json_object(raw)
        if str(data.get("name", "")).upper() == "UNSUPPORTED" or not data.get("steps"):
            raise RuntimeError(str(data.get("description") or "Current registered actions cannot safely implement this skill"))
        steps = [SkillStep(str(x.get("action", "")), dict(x.get("args") or {}), str(x.get("description") or "")) for x in data.get("steps", [])]
        skill = SkillDefinition(
            name=str(data.get("name") or goal)[:96], description=str(data.get("description") or goal),
            inputs=dict(data.get("inputs") or {}), steps=steps, source="research-corps+ai" if research.get("research_id") else ("web+ai" if allow_web else "docs+ai"),
            source_urls=tuple(str(x.get("url")) for x in research.get("citations", []) if isinstance(x, dict) and x.get("url")),
            provenance_id=str(research.get("research_id") or ""),
            confidence=max(0.0, min(1.0, float(data.get("confidence", .5)))), status=SkillStatus.DRAFT,
        )
        validation = self.compiler.validate(skill)
        skill.required_capabilities = validation.required_capabilities
        preflight = self.preflight(skill) if validation.ok else {"ok": False, "error": "Compilation failed", "steps": []}
        practice = self.practice(skill) if validation.ok and preflight.get("ok") else {"ok": False, "error": "Preflight failed", "trials": []}
        if validation.ok and preflight.get("ok") and practice.get("ok"):
            skill.status = SkillStatus.VALIDATED
        self.store.save(skill)
        return ForgeResult(skill, validation, research, preflight, practice)

    def preflight(self, skill: SkillDefinition) -> dict[str, Any]:
        """Render a skill with inert sample inputs and inspect its live action contract.

        This never executes an action. It catches template/type/registry drift before
        the owner is asked to enable the skill.
        """
        validation = self.compiler.validate(skill)
        if not validation.ok:
            return {"ok": False, "error": "; ".join(validation.errors), "steps": []}
        samples = {name: _sample_value(spec) for name, spec in skill.inputs.items()}
        try:
            rendered = self.compiler.render(skill, samples)
        except Exception as exc:
            return {"ok": False, "error": str(exc), "steps": []}
        rows=[]
        for name,args in rendered:
            action=self.actions.get(name)
            if action is None:
                return {"ok": False, "error": f"Unknown live action during preflight: {name}", "steps": rows}
            rows.append({"action":name,"args":args,"capability":str(action.capability),"executes":False})
        return {"ok": True, "error": "", "steps": rows, "sample_inputs": samples}


    def practice(self, skill: SkillDefinition) -> dict[str, Any]:
        if self.lab is None:
            return {"ok": True, "skipped": True, "reason": "Skill Lab is not configured", "trials": []}
        return self.lab.practice(skill).as_dict()

    def practice_existing(self, name: str) -> dict[str, Any]:
        skill = self.store.get(name)
        if not skill:
            raise KeyError(name)
        return self.practice(skill)

    def validate_existing(self, name: str) -> SkillValidation:
        skill = self.store.get(name)
        if not skill:
            raise KeyError(name)
        return self.compiler.validate(skill)


def _sample_value(spec: dict[str, Any]) -> Any:
    if "default" in spec:
        return spec.get("default")
    kind=str(spec.get("type","any")).lower().strip()
    return {
        "string":"__jarvis_preflight__",
        "integer":1,
        "number":1.0,
        "boolean":True,
        "object":{},
        "array":[],
        "any":"__jarvis_preflight__",
        "":"__jarvis_preflight__",
    }.get(kind,"__jarvis_preflight__")


def _parse_json_object(raw: str) -> dict[str, Any]:
    text = raw.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.I)
        text = re.sub(r"\s*```$", "", text)
    try:
        value = json.loads(text)
    except json.JSONDecodeError:
        start, end = text.find("{"), text.rfind("}")
        if start < 0 or end <= start:
            raise RuntimeError("Skill Forge did not return valid JSON")
        try:
            value = json.loads(text[start:end+1])
        except json.JSONDecodeError as exc:
            raise RuntimeError("Skill Forge did not return valid JSON") from exc
    if not isinstance(value, dict):
        raise RuntimeError("Skill Forge output must be a JSON object")
    return value
