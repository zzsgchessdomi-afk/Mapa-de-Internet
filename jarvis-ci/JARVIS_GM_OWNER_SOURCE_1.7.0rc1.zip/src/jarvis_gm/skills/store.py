from __future__ import annotations

from pathlib import Path
import json
import re
import time

from .models import SkillDefinition, SkillStatus, SkillStep


def _slug(name: str) -> str:
    value = re.sub(r"[^a-zA-Z0-9._-]+", "-", name.strip().lower()).strip("-.")
    if not value:
        raise ValueError("Skill name must contain letters or numbers")
    return value[:96]


class SkillStore:
    def __init__(self, root: Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def _path(self, name: str) -> Path:
        return self.root / f"{_slug(name)}.json"

    def save(self, skill: SkillDefinition) -> SkillDefinition:
        existing = self.get(skill.name)
        if existing and existing.version >= skill.version:
            skill.version = existing.version + 1
        skill.updated_at = time.time()
        path = self._path(skill.name)
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(skill.as_dict(), ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")
        tmp.replace(path)
        return skill

    def get(self, name: str) -> SkillDefinition | None:
        path = self._path(name)
        if not path.exists():
            # also allow lookup by display name across a small local collection
            for candidate in self.root.glob("*.json"):
                try:
                    raw = json.loads(candidate.read_text(encoding="utf-8"))
                except Exception:
                    continue
                if str(raw.get("name", "")).casefold() == name.strip().casefold():
                    return self._decode(raw)
            return None
        try:
            return self._decode(json.loads(path.read_text(encoding="utf-8")))
        except (OSError, json.JSONDecodeError, TypeError, ValueError):
            return None

    def list(self, include_retired: bool = False) -> list[SkillDefinition]:
        result: list[SkillDefinition] = []
        for path in sorted(self.root.glob("*.json")):
            try:
                skill = self._decode(json.loads(path.read_text(encoding="utf-8")))
            except Exception:
                continue
            if include_retired or skill.status != SkillStatus.RETIRED:
                result.append(skill)
        result.sort(key=lambda s: (s.status.value, s.name.casefold()))
        return result

    def set_status(self, name: str, status: SkillStatus | str) -> SkillDefinition:
        skill = self.get(name)
        if not skill:
            raise KeyError(f"Unknown skill: {name}")
        skill.status = SkillStatus(status)
        # status changes are not content revisions
        skill.updated_at = time.time()
        path = self._path(skill.name)
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(skill.as_dict(), ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")
        tmp.replace(path)
        return skill

    @staticmethod
    def _decode(raw: dict) -> SkillDefinition:
        steps = [SkillStep(str(x["action"]), dict(x.get("args") or {}), str(x.get("description") or "")) for x in raw.get("steps", [])]
        return SkillDefinition(
            name=str(raw["name"]), description=str(raw.get("description") or ""), version=int(raw.get("version", 1)),
            inputs=dict(raw.get("inputs") or {}), steps=steps,
            required_capabilities=tuple(str(x) for x in raw.get("required_capabilities", [])),
            source=str(raw.get("source") or "unknown"), source_urls=tuple(str(x) for x in raw.get("source_urls", [])),
            provenance_id=str(raw.get("provenance_id") or ""), confidence=float(raw.get("confidence", 1.0)), status=SkillStatus(raw.get("status", "draft")),
            created_at=float(raw.get("created_at", time.time())), updated_at=float(raw.get("updated_at", time.time())),
        )
