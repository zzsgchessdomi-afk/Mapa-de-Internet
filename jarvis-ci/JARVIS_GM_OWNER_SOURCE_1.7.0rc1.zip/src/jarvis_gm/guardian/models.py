from __future__ import annotations

from dataclasses import dataclass, asdict, field
from enum import IntEnum
from typing import Any
import time


class RiskLevel(IntEnum):
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4


@dataclass(slots=True)
class GuardianDecision:
    allowed: bool
    risk: RiskLevel
    reason: str
    rule: str
    requires_lease: bool = False
    lease_id: str | None = None
    timestamp: float = field(default_factory=time.time)

    def as_dict(self) -> dict[str, Any]:
        data = asdict(self); data["risk"] = self.risk.name.lower(); return data
