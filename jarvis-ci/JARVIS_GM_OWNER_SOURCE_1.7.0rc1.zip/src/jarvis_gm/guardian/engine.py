from __future__ import annotations

from dataclasses import dataclass
from typing import Any
import re

from .models import GuardianDecision, RiskLevel
from .store import GuardianStore


@dataclass(slots=True)
class GuardianConfig:
    require_lease_at: RiskLevel = RiskLevel.HIGH
    max_text_chars_without_lease: int = 4000


class Guardian:
    """Local, model-independent action supervisor.

    PermissionPolicy answers "may this capability ever be used?". Guardian answers
    "is this particular action safe to execute *now*?" and adds short-lived owner
    leases for high-risk actions. A cloud model cannot grant those leases.
    """

    HIGH_CAPS = {"external.send","security.sensitive","mobile.security","mobile.messaging","system.control","memory.manage","skill.manage","os.handoff","os.manage","evolution.manage","reality.manage","reality.security","release.manage","support.export"}
    MEDIUM_CAPS = {"input.control","window.control","app.launch","browser.open","filesystem.read","filesystem.write","mobile.read","mobile.location","mobile.contacts","mobile.control","skill.execute","autonomy.run","os.route","workbench.run","workbench.manage","swarm.run","evolution.run","reality.control"}
    CRITICAL_ACTIONS = {"mobile_lock"}
    HIGH_ACTIONS = {"mobile_compose_message","workbench_run","workbench_manage","evolution_promote","evolution_rollback","reality_enroll","release_stage","support_export"}
    SAFE_URL = re.compile(r"^https?://", re.I)

    def __init__(self, store: GuardianStore, *, policy, kill_switch, world=None, config: GuardianConfig | None = None) -> None:
        self.store=store; self.policy=policy; self.kill_switch=kill_switch; self.world=world; self.config=config or GuardianConfig()
        # Owner leases are session authority, never durable authority. Audit persists; grants do not.
        self.store.revoke_all()

    def classify(self, req) -> RiskLevel:
        if req.name in self.CRITICAL_ACTIONS: return RiskLevel.CRITICAL
        if req.name in self.HIGH_ACTIONS or req.capability in self.HIGH_CAPS: return RiskLevel.HIGH
        if req.name == "os_execute" and str((req.args if isinstance(req.args,dict) else {}).get("operation") or "").casefold() in {"handoff","continue_on","message","compose_message"}: return RiskLevel.HIGH
        args=req.args if isinstance(req.args,dict) else {}
        if req.name == "mouse_button" and str(args.get("state") or "click").lower() == "down": return RiskLevel.HIGH
        if req.name == "type_text" and len(str(args.get("text") or "")) > self.config.max_text_chars_without_lease: return RiskLevel.HIGH
        if req.capability in self.MEDIUM_CAPS: return RiskLevel.MEDIUM
        return RiskLevel.LOW

    def authorize(self, req) -> GuardianDecision:
        risk=self.classify(req)
        if self.kill_switch.engaged:
            return self._finish(req,risk,False,"kill_switch","Global STOP is engaged")
        if not self.policy.is_allowed("guardian.enforce"):
            return self._finish(req,risk,True,"guardian_disabled_by_owner","Guardian enforcement is disabled by owner policy")
        anomaly=self._anomaly(req,risk)
        if anomaly is not None:
            return self._finish(req,risk,False,anomaly[0],anomaly[1])
        if risk >= self.config.require_lease_at:
            lease=self.store.consume(action=req.name,capability=req.capability,risk=risk.name.lower())
            if lease is None:
                return self._finish(req,risk,False,"owner_lease_required",f"Guardian requires a short-lived owner lease for {risk.name.lower()}-risk action '{req.name}'",requires_lease=True)
            return self._finish(req,risk,True,"owner_lease",f"Authorized by owner lease {lease}",lease_id=lease)
        return self._finish(req,risk,True,"risk_policy","Action risk is within current automatic Guardian threshold")

    def observe_result(self, req, result) -> None:
        if self.world is not None and self.policy.is_allowed("world.write"):
            try:
                self.world.store.observe("guardian.action_result",{"action":req.name,"capability":req.capability,"ok":result.ok,"blocked":result.blocked,"error":result.error},source="guardian",confidence=1.0)
            except Exception:
                pass

    def grant_action(self, action: str, *, ttl_s: float = 120.0, uses: int | None = 1) -> str:
        return self.store.grant("action",str(action),ttl_s=ttl_s,uses=uses)

    def grant_capability(self, capability: str, *, ttl_s: float = 120.0, uses: int | None = 1) -> str:
        return self.store.grant("capability",str(capability),ttl_s=ttl_s,uses=uses)

    def revoke_all(self) -> None: self.store.revoke_all()

    def _anomaly(self, req, risk: RiskLevel) -> tuple[str,str] | None:
        args=req.args if isinstance(req.args,dict) else {}
        if req.name == "open_url":
            url=str(args.get("url") or "")
            if not self.SAFE_URL.match(url): return ("unsafe_url_scheme","Guardian blocks non-HTTP(S) URLs")
        return None

    def _finish(self,req,risk,allowed,rule,reason,requires_lease=False,lease_id=None):
        self.store.audit(action=req.name,capability=req.capability,risk=risk.name.lower(),decision="allow" if allowed else "block",rule=rule,reason=reason,args=req.args)
        return GuardianDecision(bool(allowed),risk,reason,rule,bool(requires_lease),lease_id)
