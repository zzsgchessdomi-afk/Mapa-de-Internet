from __future__ import annotations
import json,re,time
from typing import Any, Callable
from .models import SwarmReport,SwarmState,SwarmMember,SwarmContribution

class CognitiveSwarm:
    """Dynamically composes bounded cloud specialists with no direct tool authority."""
    MAX_MEMBERS=8
    VALID_PERSPECTIVES={"builder","critic","verifier","synthesizer","analyst","planner"}
    def __init__(self,provider_resolver:Callable[[],Any],store,*,run_allowed:Callable[[],bool],cloud_allowed:Callable[[],bool],research_allowed:Callable[[],bool],research_corps=None,stop_check:Callable[[],None]|None=None,authorize:Callable[[str,dict],None]|None=None)->None:
        self.provider_resolver=provider_resolver;self.store=store;self.run_allowed=run_allowed;self.cloud_allowed=cloud_allowed;self.research_allowed=research_allowed;self.research_corps=research_corps;self.stop_check=stop_check or (lambda:None);self.authorize=authorize
    def plan(self,goal:str,*,context:dict[str,Any]|None=None)->list[SwarmMember]:
        self._gate("swarm_run",{"operation":"plan"});self._require()
        p=self.provider_resolver(); self._provider(p)
        schema={"members":[{"id":"m1","specialty":"domain expert","mandate":"...","perspective":"builder|critic|verifier|synthesizer|analyst|planner","depends_on":[],"use_research":False}]}
        raw=p.generate("Design a 3-8 member temporary expert team for this goal. Create specialties specific to the problem, not generic personas. Include at least one critic/verifier and exactly one final synthesizer. Members have no computer/tool access. JSON only.\nSCHEMA="+json.dumps(schema)+"\nGOAL="+goal+"\nCONTEXT="+json.dumps(context or {},ensure_ascii=False)[:8000],system="You are JARVIS Cognitive Swarm architect. Diversity of expertise and adversarial review matter.")
        data=_json(raw);rows=data.get("members",[]) if isinstance(data,dict) else []
        if not isinstance(rows,list) or not 3<=len(rows)<=self.MAX_MEMBERS: raise RuntimeError("Swarm returned an invalid team size")
        out=[];seen=set();synth=0;challenge=0
        for i,row in enumerate(rows,1):
            if not isinstance(row,dict): raise RuntimeError("Invalid swarm member")
            mid=_slug(str(row.get("id") or f"m{i}"),32)
            if mid in seen: raise RuntimeError("Duplicate swarm member id")
            deps=tuple(_slug(str(x),32) for x in row.get("depends_on",[]) if str(x))
            if any(x not in seen for x in deps): raise RuntimeError(f"Swarm member {mid} depends on future/unknown member")
            perspective=str(row.get("perspective") or "analyst").casefold()
            if perspective not in self.VALID_PERSPECTIVES: perspective="analyst"
            if perspective=="synthesizer": synth+=1
            if perspective in {"critic","verifier"}: challenge+=1
            specialty=" ".join(str(row.get("specialty") or "specialist").split())[:96]
            mandate=" ".join(str(row.get("mandate") or "Analyze the assigned aspect").split())[:800]
            use_research=bool(row.get("use_research",False))
            out.append(SwarmMember(mid,specialty,mandate,perspective,deps,use_research));seen.add(mid)
        if synth!=1: raise RuntimeError("Swarm requires exactly one final synthesizer")
        if challenge<1: raise RuntimeError("Swarm requires a critic or verifier")
        if out[-1].perspective!="synthesizer": raise RuntimeError("Final swarm member must be synthesizer")
        if set(out[-1].depends_on) != set(x.id for x in out[:-1]): raise RuntimeError("Final synthesizer must depend on all prior specialists")
        return out
    def run(self,goal:str,*,context:dict[str,Any]|None=None)->SwarmReport:
        goal=" ".join(str(goal).split()).strip()
        if not goal: raise ValueError("Swarm goal cannot be empty")
        report=SwarmReport(goal=goal)
        try:
            report.members=self.plan(goal,context=context);report.state=SwarmState.RUNNING;self.store.save(report)
            p=self.provider_resolver(); done={}
            for member in report.members:
                self.stop_check()
                missing=[x for x in member.depends_on if x not in done or not done[x].ok]
                if missing:
                    c=SwarmContribution(member.id,member.specialty,member.perspective,False,error="Blocked dependencies: "+", ".join(missing));report.contributions.append(c);done[member.id]=c;report.state=SwarmState.BLOCKED;break
                prior={x:done[x].output for x in member.depends_on}
                evidence=[]
                if member.use_research:
                    if not self.research_allowed() or self.research_corps is None: raise PermissionError("Capability blocked by policy: research.deep")
                    rr=self.research_corps.run(member.mandate,depth="focused",context=context)
                    if rr.state!="verified": raise RuntimeError("Research Corps did not verify requested evidence")
                    evidence=list(rr.citations); researched=rr.synthesis
                else: researched=""
                prompt=(f"GOAL={goal}\nSPECIALTY={member.specialty}\nPERSPECTIVE={member.perspective}\nMANDATE={member.mandate}\n"
                        f"DEPENDENCIES={json.dumps(prior,ensure_ascii=False)[:24000]}\nRESEARCH={researched[:16000]}\nCONTEXT={json.dumps(context or {},ensure_ascii=False)[:6000]}\n"
                        "Produce a bounded work product. Challenge unsupported assumptions when appropriate. You have NO direct computer/tool access and must not claim actions were executed.")
                output=str(p.generate(prompt,system=f"You are a temporary JARVIS specialist in {member.specialty}, acting as {member.perspective}."))[:50000]
                c=SwarmContribution(member.id,member.specialty,member.perspective,True,str(output).strip(),evidence);report.contributions.append(c);done[member.id]=c
            if report.state!=SwarmState.BLOCKED:
                final=report.members[-1];final_c=done.get(final.id)
                report.synthesis=final_c.output if final_c else ""
                critics=[x.output for x in report.contributions if x.ok and x.perspective in {"critic","verifier"}]
                report.dissent=[x[:1200] for x in critics if _has_dissent(x)][:10]
                report.state=SwarmState.COMPLETED if report.synthesis else SwarmState.FAILED
        except PermissionError as exc:
            report.state=SwarmState.BLOCKED;report.synthesis=str(exc)
        except Exception as exc:
            if "kill switch" in str(exc).casefold() or "stop global" in str(exc).casefold():
                report.state=SwarmState.BLOCKED;report.synthesis="Swarm stopped by owner safety control"
            else:
                report.state=SwarmState.FAILED;report.synthesis=str(exc)
        report.updated_at=time.time();self.store.save(report);return report
    def _require(self):
        if not self.run_allowed(): raise PermissionError("Capability blocked by policy: swarm.run")
        if not self.cloud_allowed(): raise PermissionError("Capability blocked by policy: swarm.cloud")
    def _provider(self,p):
        if not getattr(p,"available",False): raise RuntimeError("Cognitive Swarm requires a configured cloud AI provider")
    def _gate(self,name,args):
        if self.authorize is not None:self.authorize(name,args)

def _has_dissent(text:str)->bool:
    s=text.casefold();return any(x in s for x in ("risk","weak","unsupported","uncertain","disagree","contradiction","failure"))
def _slug(s:str,n:int)->str:
    out=re.sub(r"[^a-zA-Z0-9_-]+","-",s.strip()).strip("-").lower();return (out or "member")[:n]
def _json(raw:str)->dict:
    text=str(raw).strip();text=re.sub(r"^```(?:json)?\s*|\s*```$","",text,flags=re.I)
    try:v=json.loads(text)
    except json.JSONDecodeError:
        a,b=text.find("{"),text.rfind("}")
        if a<0 or b<=a: raise RuntimeError("Swarm planner did not return JSON")
        v=json.loads(text[a:b+1])
    if not isinstance(v,dict):raise RuntimeError("Swarm planner JSON must be an object")
    return v
