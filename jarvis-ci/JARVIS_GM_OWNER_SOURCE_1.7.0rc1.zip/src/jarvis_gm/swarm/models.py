from __future__ import annotations
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any
import time, uuid

class SwarmState(str, Enum):
    PLANNED="planned"; RUNNING="running"; COMPLETED="completed"; BLOCKED="blocked"; FAILED="failed"

@dataclass(slots=True)
class SwarmMember:
    id: str
    specialty: str
    mandate: str
    perspective: str = "builder"
    depends_on: tuple[str,...] = ()
    use_research: bool = False

@dataclass(slots=True)
class SwarmContribution:
    member_id: str
    specialty: str
    perspective: str
    ok: bool
    output: str = ""
    evidence: list[dict[str,Any]] = field(default_factory=list)
    error: str = ""

@dataclass(slots=True)
class SwarmReport:
    goal: str
    id: str = field(default_factory=lambda:"swarm_"+uuid.uuid4().hex[:16])
    state: SwarmState = SwarmState.PLANNED
    members: list[SwarmMember] = field(default_factory=list)
    contributions: list[SwarmContribution] = field(default_factory=list)
    synthesis: str = ""
    dissent: list[str] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    def as_dict(self)->dict[str,Any]:
        data=asdict(self); data["state"]=self.state.value; return data
