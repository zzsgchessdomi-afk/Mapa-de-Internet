from __future__ import annotations
from jarvis_gm.actions.base import Action

class SwarmRunAction(Action):
    name="swarm_run";capability="swarm.run"
    def __init__(self,swarm,context_provider=None):self.swarm=swarm;self.context_provider=context_provider
    def run(self,goal:str,**kwargs):
        ctx=self.context_provider(goal) if self.context_provider else None
        return self.swarm.run(goal,context=ctx).as_dict()
    def verify(self,output,**kwargs):
        state=str((output or {}).get("state") or "");return state=="completed",f"Swarm state: {state}"
class SwarmListAction(Action):
    name="swarm_list";capability="swarm.read"
    def __init__(self,store):self.store=store
    def run(self,limit:int=50,**kwargs):return self.store.list(limit)
