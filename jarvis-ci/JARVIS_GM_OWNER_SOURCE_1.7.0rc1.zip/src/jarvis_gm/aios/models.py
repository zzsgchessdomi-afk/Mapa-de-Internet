from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any
import time


class ResourceKind(str, Enum):
    DEVICE = "device"
    APP = "app"
    FILE = "file"
    FOLDER = "folder"
    URL = "url"
    WINDOW = "window"
    PROJECT = "project"
    CONTACT = "contact"
    MISSION = "mission"
    WORK = "work"
    PHYSICAL = "physical"


@dataclass(slots=True)
class Resource:
    id: str
    kind: ResourceKind
    key: str
    label: str
    locator: dict[str, Any] = field(default_factory=dict)
    device_id: str | None = None
    capabilities: tuple[str, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)
    source: str = "system"
    confidence: float = 1.0
    last_seen: float = field(default_factory=time.time)
    expires_at: float | None = None
    status: str = "active"

    def as_dict(self) -> dict[str, Any]:
        out = asdict(self)
        out["kind"] = self.kind.value
        out["capabilities"] = list(self.capabilities)
        return out


@dataclass(slots=True)
class RoutePlan:
    operation: str
    resource_id: str | None
    destination_id: str | None
    action: str | None
    args: dict[str, Any] = field(default_factory=dict)
    required_capabilities: tuple[str, ...] = ()
    supported: bool = False
    reason: str = ""
    cross_device: bool = False
    destructive: bool = False

    def as_dict(self) -> dict[str, Any]:
        out = asdict(self)
        out["required_capabilities"] = list(self.required_capabilities)
        return out


@dataclass(slots=True)
class HandoffRecord:
    id: str
    resource_id: str
    destination_id: str
    operation: str
    state: str
    created_at: float
    updated_at: float
    action: str | None = None
    verification: str | None = None
    error: str | None = None

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)
