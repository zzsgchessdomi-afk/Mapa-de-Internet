from __future__ import annotations

from typing import Any
from jarvis_gm.actions.base import Action
from .models import ResourceKind


class OSResourcesAction(Action):
    name="os_resources"; capability="os.read"
    def __init__(self,kernel): self.kernel=kernel
    def run(self, **kwargs: Any): return self.kernel.resources(kind=kwargs.get("kind"),limit=int(kwargs.get("limit",100)))

class OSResolveAction(Action):
    name="os_resolve"; capability="os.read"
    def __init__(self,kernel): self.kernel=kernel
    def run(self, ref: str, **kwargs: Any): return self.kernel.resolve(ref).as_dict()

class OSPlanAction(Action):
    name="os_plan"; capability="os.read"
    def __init__(self,kernel): self.kernel=kernel
    def run(self, operation: str, resource: str | None=None, destination: str | None=None, payload: dict[str,Any] | None=None, **kwargs: Any):
        return self.kernel.plan(operation,resource_ref=resource,destination_ref=destination,payload=payload).as_dict()

class OSExecuteAction(Action):
    name="os_execute"; capability="os.route"
    def __init__(self,kernel): self.kernel=kernel
    def run(self, operation: str, resource: str | None=None, destination: str | None=None, payload: dict[str,Any] | None=None, **kwargs: Any):
        return self.kernel.execute(operation,resource_ref=resource,destination_ref=destination,payload=payload,outer_guardian_checked=True)
    def verify(self, output: Any, **kwargs: Any):
        return bool(output.get("verified")), str(output.get("verification") or "Personal AI OS route was not verified")

class OSPinURLAction(Action):
    name="os_pin_url"; capability="os.manage"
    def __init__(self,kernel): self.kernel=kernel
    def run(self, url: str, label: str | None=None, alias: str | None=None, **kwargs: Any): return self.kernel.register_url(url,label=label,alias=alias).as_dict()

class OSPinFileAction(Action):
    name="os_pin_file"; capability="os.manage"
    def __init__(self,kernel): self.kernel=kernel
    def run(self, path: str, alias: str | None=None, **kwargs: Any): return self.kernel.register_file(path,alias=alias).as_dict()

class OSPinContactAction(Action):
    name="os_pin_contact"; capability="os.manage"
    def __init__(self,kernel): self.kernel=kernel
    def run(self, label: str, alias: str | None=None, device: str | None=None, **kwargs: Any): return self.kernel.register_contact(label,alias=alias,device_ref=device).as_dict()

class OSHandoffsAction(Action):
    name="os_handoffs"; capability="os.read"
    def __init__(self,kernel): self.kernel=kernel
    def run(self, **kwargs: Any): return self.kernel.store.handoffs(limit=int(kwargs.get("limit",50)))
