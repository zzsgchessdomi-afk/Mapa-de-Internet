from __future__ import annotations

from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from jarvis_gm.core.models import ActionRequest
from .models import Resource, ResourceKind, RoutePlan
from .store import ResourceStore


LOCAL_DEVICE_KEY = "local-desktop"
RESERVED_ALIASES = {"pc","este pc","computadora","celular","telefono","teléfono","mi celular","mi telefono","mi teléfono"}


class PersonalAIOS:
    """Resource namespace + capability-aware router across JARVIS surfaces.

    It never executes arbitrary commands. Routing compiles a generic resource
    operation into an already-registered JARVIS action, which then traverses the
    existing PermissionPolicy, Guardian, Executor and Verifier.
    """

    def __init__(self, store: ResourceStore, *, executor, verifier, policy, apps, file_scope,
                 backend, mobile, memory_manager, autonomy_store=None, world=None, guardian=None, workbench_store=None, reality=None) -> None:
        self.store=store; self.executor=executor; self.verifier=verifier; self.policy=policy
        self.apps=apps; self.file_scope=file_scope; self.backend=backend; self.mobile=mobile
        self.memory_manager=memory_manager; self.autonomy_store=autonomy_store; self.world=world; self.guardian=guardian; self.workbench_store=workbench_store; self.reality=reality

    @property
    def local_device_id(self) -> str:
        return ResourceStore.stable_id(ResourceKind.DEVICE, LOCAL_DEVICE_KEY)

    def sync(self) -> dict[str, int]:
        counts: dict[str,int] = {}
        local = self.store.upsert(kind=ResourceKind.DEVICE,key=LOCAL_DEVICE_KEY,label="Este PC",locator={"platform":"windows"},
                                  capabilities=("desktop","windows","browser","filesystem"),source="aios.desktop")
        self.store.bind_alias("pc", local.id); self.store.bind_alias("este pc", local.id); self.store.bind_alias("computadora", local.id)
        counts["devices"] = 1

        mobile_ids=set()
        if self.policy.is_allowed("mobile.read"):
            for dev in self.mobile.manager.devices.list():
                if not dev.enabled: continue
                r=self.store.upsert(kind=ResourceKind.DEVICE,key=f"mobile:{dev.id}",label=dev.name,locator={"platform":dev.platform,"device_id":dev.id},
                                    device_id=dev.id,capabilities=tuple(dev.capabilities) + ("mobile",),source="aios.mobile")
                mobile_ids.add(r.id); counts["devices"] += 1
                if len([x for x in self.mobile.manager.devices.list() if x.enabled]) == 1:
                    for alias in ("celular","telefono","teléfono","mi celular","mi telefono","mi teléfono"): self.store.bind_alias(alias,r.id)
        self.store.expire_missing(source_prefix="aios.mobile",active_ids=mobile_ids)

        app_ids=set()
        for alias, exe in sorted(self.apps.apps.items()):
            r=self.store.upsert(kind=ResourceKind.APP,key=f"desktop:{alias}",label=alias,locator={"app":alias,"executable":exe},device_id=local.id,
                                capabilities=("open",),source="aios.apps")
            app_ids.add(r.id)
        self.store.expire_missing(source_prefix="aios.apps",active_ids=app_ids); counts["apps"]=len(app_ids)

        root_ids=set()
        if self.policy.is_allowed("filesystem.read"):
            for p in self.file_scope.roots:
                rp=Path(p)
                r=self.store.upsert(kind=ResourceKind.FOLDER,key=str(rp),label=rp.name or str(rp),locator={"path":str(rp)},device_id=local.id,
                                    capabilities=("list","read","write"),source="aios.files")
                root_ids.add(r.id)
        self.store.expire_missing(source_prefix="aios.files",active_ids=root_ids); counts["folders"]=len(root_ids)

        project_ids=set()
        if self.policy.is_allowed("memory.read") and self.memory_manager is not None:
            for p in self.memory_manager.store.list_projects():
                key=getattr(p,"id",None) or p.name
                r=self.store.upsert(kind=ResourceKind.PROJECT,key=str(key),label=p.name,locator={"project":p.name},capabilities=("activate","resume"),source="aios.projects")
                project_ids.add(r.id)
        self.store.expire_missing(source_prefix="aios.projects",active_ids=project_ids); counts["projects"]=len(project_ids)

        mission_ids=set()
        if self.autonomy_store is not None:
            try:
                for row in self.autonomy_store.list(limit=100):
                    mid=str(row.get("id") or "")
                    if not mid: continue
                    r=self.store.upsert(kind=ResourceKind.MISSION,key=mid,label=str(row.get("goal") or mid)[:160],locator={"mission_id":mid},
                                        capabilities=("inspect","resume"),source="aios.missions")
                    mission_ids.add(r.id)
            except Exception:
                pass
        self.store.expire_missing(source_prefix="aios.missions",active_ids=mission_ids); counts["missions"]=len(mission_ids)

        work_ids=set()
        if self.workbench_store is not None and self.policy.is_allowed("workbench.read"):
            try:
                for item in self.workbench_store.list(200):
                    r=self.store.upsert(kind=ResourceKind.WORK,key=item.id,label=item.goal[:160],locator={"work_id":item.id,"state":item.state.value},
                                        capabilities=("inspect","resume"),source="aios.workbench",metadata={"priority":item.priority})
                    work_ids.add(r.id)
            except Exception:
                pass
        self.store.expire_missing(source_prefix="aios.workbench",active_ids=work_ids); counts["work_items"]=len(work_ids)

        physical_ids=set()
        if self.reality is not None and self.policy.is_allowed("reality.read"):
            try:
                for d in self.reality.store.list():
                    r=self.store.upsert(kind=ResourceKind.PHYSICAL,key=d.id,label=d.label,locator={"reality_device_id":d.id},
                                        capabilities=tuple(d.capabilities)+("observe",),source="aios.reality",metadata={"kind":d.kind,"risk":d.risk.value})
                    physical_ids.add(r.id)
            except Exception:
                pass
        self.store.expire_missing(source_prefix="aios.reality",active_ids=physical_ids); counts["physical_devices"]=len(physical_ids)
        self._publish_world()
        return counts

    def _publish_world(self) -> None:
        if self.world is None or not self.policy.is_allowed("world.write"): return
        try:
            for r in self.store.list(limit=120):
                e=self.world.store.upsert_entity(kind="resource",key=r.id,label=r.label,attributes={"resource_id":r.id,"kind":r.kind.value,"device_id":r.device_id,"capabilities":list(r.capabilities)},source="aios",confidence=r.confidence,ttl_s=600)
                if r.device_id:
                    did = r.device_id if str(r.device_id).startswith("res:") else ResourceStore.stable_id(ResourceKind.DEVICE,f"mobile:{r.device_id}")
                    self.world.store.relate(e.id,"available_on",self.world.store.stable_id("resource",did),source="aios",confidence=1.0,ttl_s=600)
        except Exception:
            pass

    def resources(self, *, kind: str | None = None, limit: int = 100) -> list[dict[str,Any]]:
        self.policy.require("os.read")
        self.sync()
        rk = ResourceKind(kind) if kind else None
        return [r.as_dict() for r in self.store.list(kind=rk,limit=limit)]

    def resolve(self, ref: str, *, kinds: tuple[ResourceKind,...] | None = None) -> Resource:
        self.policy.require("os.read")
        self.sync(); return self.store.resolve(ref,kinds=kinds)

    @staticmethod
    def _user_alias(alias: str | None) -> str | None:
        if alias is None: return None
        value=str(alias).strip()
        if not value: return None
        if value.casefold() in RESERVED_ALIASES:
            raise ValueError("Alias is reserved for a system device")
        return value

    def register_url(self, url: str, *, label: str | None = None, alias: str | None = None) -> Resource:
        self.policy.require("os.manage")
        parsed=urlparse(url)
        if parsed.scheme not in {"http","https"} or not parsed.netloc: raise ValueError("Only http/https URLs are resources")
        alias=self._user_alias(alias)
        r=self.store.upsert(kind=ResourceKind.URL,key=url,label=label or parsed.netloc,locator={"url":url},capabilities=("open","handoff"),source="user.resource")
        if alias: self.store.bind_alias(alias,r.id)
        return r

    def register_file(self, path: str, *, alias: str | None = None) -> Resource:
        self.policy.require("os.manage")
        alias=self._user_alias(alias)
        p=self.file_scope.require(Path(path),must_exist=True)
        kind=ResourceKind.FOLDER if p.is_dir() else ResourceKind.FILE
        r=self.store.upsert(kind=kind,key=str(p),label=p.name or str(p),locator={"path":str(p)},device_id=self.local_device_id,
                            capabilities=(("list","read") if p.is_dir() else ("read","open")),source="user.resource")
        if alias:self.store.bind_alias(alias,r.id)
        return r

    def register_contact(self, label: str, *, alias: str | None = None, device_ref: str | None = None) -> Resource:
        self.policy.require("os.manage")
        alias=self._user_alias(alias)
        dest=self.resolve(device_ref or "mi celular",kinds=(ResourceKind.DEVICE,))
        if dest.locator.get("platform") != "android": raise ValueError("Contact resources currently belong to a paired Android device")
        key=f"{dest.id}:{label.casefold().strip()}"
        r=self.store.upsert(kind=ResourceKind.CONTACT,key=key,label=label.strip(),locator={"query":label.strip()},device_id=dest.id,
                            capabilities=("resolve","message"),source="user.contact")
        if alias:self.store.bind_alias(alias,r.id)
        return r

    def cloud_context(self) -> dict[str, Any] | None:
        if not self.policy.is_allowed("os.read") or not self.policy.is_allowed("os.cloud"):
            return None
        self.sync()
        rows=[]
        allow_memory=self.policy.is_allowed("memory.cloud")
        for r in self.store.list(limit=160):
            if r.kind == ResourceKind.CONTACT:
                continue  # contact labels stay local
            if r.kind == ResourceKind.WORK and not self.policy.is_allowed("workbench.cloud"):
                continue
            if r.kind == ResourceKind.PHYSICAL and not self.policy.is_allowed("reality.cloud"):
                continue
            if r.kind in {ResourceKind.PROJECT, ResourceKind.MISSION} and not allow_memory:
                continue
            item={"id":r.id,"kind":r.kind.value,"label":r.label,"capabilities":list(r.capabilities)}
            if r.kind == ResourceKind.DEVICE:
                item["platform"]=r.locator.get("platform")
            elif r.kind == ResourceKind.URL:
                item["url"]=r.locator.get("url")
            # File/folder paths and executable paths are intentionally not exported.
            rows.append(item)
        return {"resources":rows,"count":len(rows)}

    def plan(self, operation: str, *, resource_ref: str | None = None, destination_ref: str | None = None,
             payload: dict[str,Any] | None = None) -> RoutePlan:
        op=str(operation).strip().casefold(); payload=dict(payload or {})
        resource=self.resolve(resource_ref) if resource_ref else None
        destination=self.resolve(destination_ref,kinds=(ResourceKind.DEVICE,)) if destination_ref else None
        local_id=self.local_device_id
        if destination is None and resource is not None and resource.device_id:
            try: destination=self.store.get(resource.device_id)
            except Exception: destination=None

        def plan(action,args,caps,reason,cross=False,destructive=False):
            return RoutePlan(op,resource.id if resource else None,destination.id if destination else None,action,args,tuple(caps),True,reason,cross,destructive)
        def unsupported(reason):
            return RoutePlan(op,resource.id if resource else None,destination.id if destination else None,None,{},(),False,reason,False,False)

        if op in {"open","show"}:
            if resource is None: return unsupported("An explicit resource is required")
            if destination is None or destination.id == local_id:
                if resource.kind == ResourceKind.URL: return plan("open_url",{"url":resource.locator["url"]},("browser.open",),"Open URL on local desktop")
                if resource.kind == ResourceKind.APP: return plan("open_app",{"app":resource.locator["app"]},("app.launch",),"Launch registered desktop app")
                if resource.kind == ResourceKind.FOLDER: return plan("list_directory",{"path":resource.locator["path"]},("filesystem.read",),"Inspect authorized folder")
                if resource.kind == ResourceKind.PROJECT: return plan("project_activate",{"project":resource.locator["project"]},("memory.write",),"Activate project context")
                return unsupported(f"Open is not implemented for local {resource.kind.value} resources")
            if destination.locator.get("platform") == "android":
                device_id=destination.locator.get("device_id")
                if resource.kind == ResourceKind.URL: return plan("mobile_open_url",{"device_id":device_id,"url":resource.locator["url"]},("mobile.control",),"Open URL on paired Android",True)
                return unsupported(f"Android open route is not available for {resource.kind.value}; JARVIS will not fake a transfer")
            return unsupported("Destination platform is unsupported")

        if op in {"handoff","continue_on"}:
            if resource is None or destination is None: return unsupported("Handoff requires a resource and destination device")
            if destination.id == local_id:
                return self.plan("open",resource_ref=resource.id,destination_ref=local_id,payload=payload)
            if resource.kind == ResourceKind.URL and destination.locator.get("platform") == "android":
                return plan("mobile_open_url",{"device_id":destination.locator.get("device_id"),"url":resource.locator["url"]},("os.handoff","mobile.control"),"Handoff URL to paired Android",True)
            return unsupported("This resource cannot be transferred with a verified transport yet")

        if op in {"message","compose_message"}:
            if resource is None or resource.kind != ResourceKind.CONTACT: return unsupported("Message operation requires a contact resource")
            text=str(payload.get("text") or "").strip()
            if not text: return unsupported("Message text is required")
            dest=self.store.get(resource.device_id or "")
            if dest is None or dest.locator.get("platform") != "android": return unsupported("Contact's Android device is unavailable")
            return plan("mobile_compose_message",{"device_id":dest.locator.get("device_id"),"channel":str(payload.get("channel") or "whatsapp"),"recipient":resource.locator["query"],"text":text},
                        ("os.handoff","mobile.messaging"),"Compose message on contact's paired Android",True)

        if op in {"observe","read_state"}:
            if resource is None or resource.kind != ResourceKind.PHYSICAL: return unsupported("Observe requires an enrolled physical resource")
            return plan("reality_observe",{"device":resource.locator["reality_device_id"]},("reality.read",),"Observe enrolled physical device")

        if op in {"control","command"}:
            if resource is None or resource.kind != ResourceKind.PHYSICAL: return unsupported("Control requires an enrolled physical resource")
            command=str(payload.get("command") or "").strip()
            if not command: return unsupported("Physical control requires payload.command")
            if command not in resource.capabilities: return unsupported("Command is not enrolled for this physical resource")
            args=dict(payload.get("args") or {})
            return plan("reality_command",{"device":resource.locator["reality_device_id"],"command":command,"args":args},("reality.control",),"Control enrolled physical device")

        if op == "resume":
            if resource is None: return unsupported("Resume requires a resource")
            if resource.kind == ResourceKind.PROJECT: return plan("project_activate",{"project":resource.locator["project"]},("memory.write",),"Activate the selected project so subsequent planning resumes in its context")
            if resource.kind == ResourceKind.MISSION: return plan("resume_autonomous_mission",{"mission_id":resource.locator["mission_id"]},("autonomy.run",),"Resume autonomous mission")
            return unsupported("Resume is only valid for project or mission resources")

        return unsupported(f"Unknown Personal AI OS operation: {operation}")

    def execute(self, operation: str, *, resource_ref: str | None = None, destination_ref: str | None = None,
                payload: dict[str,Any] | None = None, outer_guardian_checked: bool = False) -> dict[str,Any]:
        route=self.plan(operation,resource_ref=resource_ref,destination_ref=destination_ref,payload=payload)
        if not route.supported or not route.action:
            raise ValueError(route.reason)
        self.policy.require("os.route")
        if route.cross_device:self.policy.require("os.handoff")
        if self.guardian is not None and not outer_guardian_checked:
            pseudo = ActionRequest("os_execute", {"operation":operation,"resource":resource_ref,"destination":destination_ref,"payload":dict(payload or {})}, "os.route")
            decision = self.guardian.authorize(pseudo)
            if not decision.allowed:
                return {"route":route.as_dict(),"result":{"ok":False,"blocked":True,"error":decision.reason,"action":"os_execute"},"verified":False,"verification":decision.reason,"handoff_id":None}
        action=self.executor.actions.get(route.action)
        if action is None: raise KeyError(f"Routed action is not registered: {route.action}")
        handoff=None
        if route.cross_device and route.resource_id and route.destination_id:
            handoff=self.store.create_handoff(route.resource_id,route.destination_id,route.operation)
        req=ActionRequest(route.action,route.args,action.capability)
        result=self.executor.execute(req)
        if not result.ok:
            if handoff:self.store.update_handoff(handoff.id,state="blocked" if result.blocked else "failed",action=route.action,error=result.error)
            return {"route":route.as_dict(),"result":{"ok":result.ok,"blocked":result.blocked,"error":result.error,"action":result.action},"verified":False,"verification":result.error or "Execution failed","handoff_id":handoff.id if handoff else None}
        ok,detail=self.verifier.verify(req,result)
        if handoff:self.store.update_handoff(handoff.id,state="verified" if ok else "unverified",action=route.action,verification=detail,error=None if ok else detail)
        if self.world is not None and self.policy.is_allowed("world.write"):
            try:self.world.store.observe("aios.route",{"operation":operation,"resource_id":route.resource_id,"destination_id":route.destination_id,"action":route.action,"verified":ok},source="aios",confidence=1.0)
            except Exception:pass
        return {"route":route.as_dict(),"result":{"ok":result.ok,"blocked":result.blocked,"error":result.error,"action":result.action,"output":result.output},"verified":bool(ok),"verification":detail,"handoff_id":handoff.id if handoff else None}
