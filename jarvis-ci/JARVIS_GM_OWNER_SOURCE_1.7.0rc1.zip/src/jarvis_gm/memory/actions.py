from __future__ import annotations

from typing import Any

from jarvis_gm.actions.base import Action
from .manager import MemoryManager
from .models import MemoryKind


class CreateProjectAction(Action):
    name="project_create"; capability="memory.write"
    def __init__(self,memory:MemoryManager): self.memory=memory
    def run(self,**kwargs:Any)->Any:
        p=self.memory.create_project(str(kwargs["name"]),str(kwargs.get("summary","")),activate=bool(kwargs.get("activate",True)))
        return {"id":p.id,"name":p.name,"summary":p.summary,"active":bool(self.memory.active_project and self.memory.active_project.id==p.id)}

class ActivateProjectAction(Action):
    name="project_activate"; capability="memory.write"
    def __init__(self,memory:MemoryManager): self.memory=memory
    def run(self,**kwargs:Any)->Any:
        p=self.memory.activate_project(str(kwargs["project"]))
        return {"id":p.id,"name":p.name,"summary":p.summary}

class ListProjectsAction(Action):
    name="project_list"; capability="memory.read"
    def __init__(self,memory:MemoryManager): self.memory=memory
    def run(self,**kwargs:Any)->Any:
        active=self.memory.active_project
        return [{"id":p.id,"name":p.name,"summary":p.summary,"active":bool(active and active.id==p.id)} for p in self.memory.store.list_projects()]

class StructuredRememberAction(Action):
    name="memory_add"; capability="memory.write"
    def __init__(self,memory:MemoryManager): self.memory=memory
    def run(self,**kwargs:Any)->Any:
        rec=self.memory.remember(str(kwargs["content"]),kind=MemoryKind(str(kwargs.get("kind","fact"))),title=str(kwargs.get("title","")),
                                 source="user.explicit",importance=float(kwargs.get("importance",.7)),tags=tuple(kwargs.get("tags",())))
        return {"id":rec.id,"kind":rec.kind.value,"title":rec.title,"content":rec.content,"project_id":rec.project_id}

class MemorySearchAction(Action):
    name="memory_search"; capability="memory.read"
    def __init__(self,memory:MemoryManager): self.memory=memory
    def run(self,**kwargs:Any)->Any:
        rows=self.memory.retrieve(str(kwargs["query"]),int(kwargs.get("limit",8)))
        return [{"id":x.id,"kind":x.kind.value,"title":x.title,"content":x.content,"source":x.source,"score":x.score,"project_id":x.project_id} for x in rows]

class CorrectMemoryAction(Action):
    name="memory_correct"; capability="memory.manage"
    def __init__(self,memory:MemoryManager): self.memory=memory
    def run(self,**kwargs:Any)->Any:
        rec=self.memory.store.correct_memory(str(kwargs["memory_id"]),str(kwargs["content"]),source="user.correction")
        return {"id":rec.id,"parent_id":rec.parent_id,"content":rec.content}

class ForgetMemoryAction(Action):
    name="memory_forget"; capability="memory.manage"
    def __init__(self,memory:MemoryManager): self.memory=memory
    def run(self,**kwargs:Any)->Any:
        mid=str(kwargs["memory_id"]); return {"memory_id":mid,"forgotten":self.memory.store.forget_memory(mid)}

class AddTaskAction(Action):
    name="task_add"; capability="memory.write"
    def __init__(self,memory:MemoryManager): self.memory=memory
    def run(self,**kwargs:Any)->Any:
        t=self.memory.add_task(str(kwargs["title"]),str(kwargs.get("details","")),int(kwargs.get("priority",2)))
        return {"id":t.id,"title":t.title,"details":t.details,"priority":t.priority,"status":t.status,"project_id":t.project_id}

class CompleteTaskAction(Action):
    name="task_complete"; capability="memory.write"
    def __init__(self,memory:MemoryManager): self.memory=memory
    def run(self,**kwargs:Any)->Any:
        tid=str(kwargs["task_id"]); return {"task_id":tid,"done":self.memory.store.set_task_status(tid,"done")}

class RecordDecisionAction(Action):
    name="decision_add"; capability="memory.write"
    def __init__(self,memory:MemoryManager): self.memory=memory
    def run(self,**kwargs:Any)->Any:
        r=self.memory.record_decision(str(kwargs["content"]),str(kwargs.get("title","Decision")))
        return {"id":r.id,"title":r.title,"content":r.content,"project_id":r.project_id}

class ResumeContextAction(Action):
    name="resume_context"; capability="memory.read"
    def __init__(self,memory:MemoryManager): self.memory=memory
    def run(self,**kwargs:Any)->Any: return self.memory.resume(str(kwargs.get("query",""))).compact()
