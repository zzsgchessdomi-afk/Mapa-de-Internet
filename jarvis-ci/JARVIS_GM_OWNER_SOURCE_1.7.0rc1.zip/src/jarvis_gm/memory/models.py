from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class MemoryKind(str, Enum):
    FACT = "fact"
    PREFERENCE = "preference"
    DECISION = "decision"
    PROCEDURE = "procedure"
    EPISODE = "episode"
    NOTE = "note"


@dataclass(slots=True)
class ProjectRecord:
    id: str
    name: str
    summary: str
    status: str
    created_at: float
    updated_at: float
    last_active_at: float


@dataclass(slots=True)
class MemoryRecord:
    id: str
    kind: MemoryKind
    title: str
    content: str
    source: str
    confidence: float
    importance: float
    project_id: str | None
    tags: tuple[str, ...] = ()
    status: str = "active"
    parent_id: str | None = None
    created_at: float = 0.0
    updated_at: float = 0.0
    score: float = 0.0


@dataclass(slots=True)
class TaskRecord:
    id: str
    project_id: str | None
    title: str
    details: str
    status: str
    priority: int
    created_at: float
    updated_at: float


@dataclass(slots=True)
class ResumeSnapshot:
    project: ProjectRecord | None
    pending_tasks: list[TaskRecord] = field(default_factory=list)
    decisions: list[MemoryRecord] = field(default_factory=list)
    relevant_memories: list[MemoryRecord] = field(default_factory=list)
    recent_episodes: list[MemoryRecord] = field(default_factory=list)
    latest_checkpoint: dict[str, Any] | None = None
    current_session_id: str | None = None

    def compact(self) -> dict[str, Any]:
        return {
            "project": None if self.project is None else {
                "id": self.project.id,
                "name": self.project.name,
                "summary": self.project.summary,
                "status": self.project.status,
            },
            "pending_tasks": [
                {"id": x.id, "title": x.title, "details": x.details, "priority": x.priority}
                for x in self.pending_tasks
            ],
            "decisions": [
                {"id": x.id, "title": x.title, "content": x.content, "source": x.source}
                for x in self.decisions
            ],
            "relevant_memories": [
                {"id": x.id, "kind": x.kind.value, "title": x.title, "content": x.content, "score": x.score}
                for x in self.relevant_memories
            ],
            "recent_episodes": [
                {"id": x.id, "title": x.title, "content": x.content}
                for x in self.recent_episodes
            ],
            "latest_checkpoint": self.latest_checkpoint,
            "current_session_id": self.current_session_id,
        }
