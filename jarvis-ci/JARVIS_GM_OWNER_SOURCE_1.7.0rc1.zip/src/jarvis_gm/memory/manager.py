from __future__ import annotations

from dataclasses import asdict
from typing import Any
import time

from .models import MemoryKind, ResumeSnapshot
from .store import ContinuityStore


class MemoryManager:
    def __init__(self, store: ContinuityStore) -> None:
        self.store = store
        if not self.store.current_session_id():
            active = self.store.active_project()
            self.store.start_session(active.id if active else None)

    @property
    def active_project(self):
        return self.store.active_project()

    def create_project(self, name: str, summary: str = "", *, activate: bool = True):
        project=self.store.create_project(name,summary)
        if activate: self.activate_project(project.id)
        return project

    def activate_project(self, name_or_id: str):
        project=self.store.activate_project(name_or_id)
        self.store.start_session(project.id)
        return project

    def remember(self, content: str, *, kind: MemoryKind | str = MemoryKind.FACT, title: str = "",
                 source: str = "user.explicit", confidence: float = 1.0, importance: float = 0.7,
                 tags=(), global_scope: bool = False):
        project=None if global_scope else self.active_project
        return self.store.add_memory(kind=kind,title=title,content=content,source=source,
                                     project_id=project.id if project else None,confidence=confidence,
                                     importance=importance,tags=tags)

    def record_decision(self, content: str, title: str = "Decision"):
        return self.remember(content,kind=MemoryKind.DECISION,title=title,importance=.9,tags=("decision",))

    def add_task(self, title: str, details: str = "", priority: int = 2):
        project=self.active_project
        return self.store.add_task(title,details=details,project_id=project.id if project else None,priority=priority)

    def retrieve(self, query: str, limit: int = 8):
        project=self.active_project
        return self.store.search_memories(query,project_id=project.id if project else None,limit=limit,include_global=True)

    def context_for_goal(self, goal: str, limit: int = 6) -> dict[str, Any]:
        project=self.active_project
        memories=self.store.search_memories(goal,project_id=project.id if project else None,limit=limit,include_global=True)
        tasks=self.store.pending_tasks(project.id if project else None,limit=8)
        checkpoint=self.store.latest_checkpoint(project.id if project else None)
        return {
            "active_project": None if project is None else {"id":project.id,"name":project.name,"summary":project.summary},
            "relevant_memories":[{"id":x.id,"kind":x.kind.value,"title":x.title,"content":x.content,"source":x.source,"confidence":x.confidence} for x in memories],
            "pending_tasks":[{"id":x.id,"title":x.title,"details":x.details,"priority":x.priority} for x in tasks],
            "latest_checkpoint": checkpoint,
        }

    def capture_goal_outcome(self, goal) -> None:
        project=self.active_project
        actions=[{"name":x.action,"ok":x.ok,"error":x.error} for x in goal.results]
        content=f"Goal: {goal.text}\nState: {goal.state.value}\nVerification: {goal.verification or ''}\nActions: {actions}"
        self.store.add_memory(kind=MemoryKind.EPISODE,title=goal.text[:100],content=content,source="system.goal",
                              project_id=project.id if project else None,confidence=1.0,
                              importance=.35 if goal.state.value=="verified" else .55,tags=("goal",goal.state.value))
        self.store.add_checkpoint(project_id=project.id if project else None,session_id=self.store.current_session_id(),
                                  label=f"goal:{goal.state.value}",state={"goal_id":goal.id,"text":goal.text,"state":goal.state.value,
                                  "verification":goal.verification,"actions":actions,"captured_at":time.time()})

    def resume(self, query: str = "") -> ResumeSnapshot:
        project=self.active_project
        pid=project.id if project else None
        decisions=self.store.recent_memories(project_id=pid,kind=MemoryKind.DECISION,limit=6,include_global=True)
        episodes=self.store.recent_memories(project_id=pid,kind=MemoryKind.EPISODE,limit=5,include_global=False)
        relevant=self.store.search_memories(query or (project.name if project else "recent work"),project_id=pid,limit=8,include_global=True)
        return ResumeSnapshot(project=project,pending_tasks=self.store.pending_tasks(pid,limit=12),decisions=decisions,
                              relevant_memories=relevant,recent_episodes=episodes,
                              latest_checkpoint=self.store.latest_checkpoint(pid),current_session_id=self.store.current_session_id())

    def end_session(self, summary: str = "") -> None:
        self.store.end_session(summary)
