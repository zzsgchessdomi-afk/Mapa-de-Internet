from pathlib import Path
import tempfile
import unittest

from jarvis_gm.runtime import build_runtime
from jarvis_gm.core.models import GoalState


class CoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.runtime, self.policy, self.kill, self.providers = build_runtime(self.root)

    def tearDown(self):
        self.tmp.cleanup()

    def test_status_is_verified(self):
        goal = self.runtime.run("estado")
        self.assertEqual(goal.state, GoalState.VERIFIED)
        self.assertTrue(goal.results[0].ok)

    def test_memory_persists(self):
        goal = self.runtime.run("recuerda: proyecto = JARVIS")
        self.assertEqual(goal.state, GoalState.VERIFIED)
        self.assertEqual(self.runtime.memory.recall("proyecto"), "JARVIS")

    def test_create_note_and_read(self):
        goal = self.runtime.run("nota prueba: contenido real")
        self.assertEqual(goal.state, GoalState.VERIFIED)
        read = self.runtime.run("leer nota prueba")
        self.assertEqual(read.state, GoalState.VERIFIED)
        self.assertEqual(read.results[0].output, "contenido real")

    def test_permission_block(self):
        self.policy.set("workspace.write", False)
        goal = self.runtime.run("nota bloqueada: no debe crearse")
        self.assertNotEqual(goal.state, GoalState.VERIFIED)
        self.assertFalse((self.root / "workspace" / "bloqueada.txt").exists())

    def test_kill_switch_blocks_execution(self):
        self.kill.engage()
        goal = self.runtime.run("estado")
        self.assertNotEqual(goal.state, GoalState.VERIFIED)
        self.kill.reset()
        goal2 = self.runtime.run("estado")
        self.assertEqual(goal2.state, GoalState.VERIFIED)

    def test_unknown_goal_without_ai_is_honest_failure(self):
        goal = self.runtime.run("haz una presentación compleja")
        self.assertEqual(goal.state, GoalState.FAILED)
        self.assertIn("no cloud AI provider", goal.verification)

    def test_event_audit_trail_exists(self):
        goal = self.runtime.run("estado")
        events = self.runtime.memory.recent_events()
        self.assertTrue(any(e["goal_id"] == goal.id and e["event_type"] == "goal.verified" for e in events))

    def test_permissions_persist(self):
        self.policy.set("workspace.write", False)
        _, policy2, _, _ = build_runtime(self.root)
        self.assertFalse(policy2.is_allowed("workspace.write"))


if __name__ == "__main__":
    unittest.main()
