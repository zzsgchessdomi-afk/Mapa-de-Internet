from __future__ import annotations

from pathlib import Path
import time

import pytest

from jarvis_gm.actions.base import Action
from jarvis_gm.control.simulated_backend import SimulatedDesktopBackend
from jarvis_gm.perception.bus import PerceptionBus
from jarvis_gm.perception.events import PerceptionEvent
from jarvis_gm.perception.fusion import FusionCore
from jarvis_gm.perception.sentinel import PerceptionSentinel, SentinelConfig
from jarvis_gm.screen.models import ScreenSnapshot
from jarvis_gm.skills.lab import SkillLab
from jarvis_gm.skills.models import SkillDefinition, SkillStep, SkillStatus
from jarvis_gm.runtime import build_phase8_runtime


class SequenceObserver:
    def __init__(self):
        self.i = 0
    def snapshot(self, include_image=False):
        self.i += 1
        fp = "A" if self.i < 3 else "B"
        title = "Editor" if fp == "A" else "Browser"
        return ScreenSnapshot.create(active_handle=1, active_title=title, screen_width=100, screen_height=100,
                                     elements=[], image_png=None, visual_fingerprint=fp,
                                     uia_available=True, capture_available=False, error=None)


def test_sentinel_is_owner_gated():
    bus=PerceptionBus(); observer=SequenceObserver()
    sentinel=PerceptionSentinel(observer,bus,allowed=lambda:False)
    with pytest.raises(PermissionError): sentinel.start()
    assert sentinel.poll_once() is None


def test_sentinel_publishes_only_compact_scene_changes():
    bus=PerceptionBus(); seen=[]; bus.subscribe(seen.append); observer=SequenceObserver()
    sentinel=PerceptionSentinel(observer,bus,allowed=lambda:True,config=SentinelConfig(max_observations_per_minute=10))
    a=sentinel.poll_once(1.0); b=sentinel.poll_once(1.1); c=sentinel.poll_once(1.2)
    assert a and a.changed
    assert b and not b.changed
    assert c and c.changed
    changed=[x for x in seen if x.type=='environment.changed']
    assert len(changed)==2
    assert all('image' not in x.payload and 'png' not in x.payload for x in changed)


def test_sentinel_budget_limits_observations():
    bus=PerceptionBus(); observer=SequenceObserver()
    sentinel=PerceptionSentinel(observer,bus,allowed=lambda:True,config=SentinelConfig(max_observations_per_minute=2))
    assert sentinel.poll_once(10.0) is not None
    assert sentinel.poll_once(10.1) is not None
    assert sentinel.poll_once(10.2) is None


def test_fusion_marks_deictic_without_point_ambiguous():
    bus=PerceptionBus(); fusion=FusionCore(bus)
    now=time.time(); bus.publish(PerceptionEvent('voice.command','voice',{'text':'haz clic ahí'},timestamp=now))
    ctx=fusion.resolve(now+.1)
    assert ctx.ambiguous
    assert 'deictic_voice_without_fresh_point' in ctx.contradictions
    fusion.close()


def test_fusion_rejects_point_when_scene_changed_after_it():
    bus=PerceptionBus(); fusion=FusionCore(bus)
    now=time.time()
    bus.publish(PerceptionEvent('gesture.point','vision.hand',{'x':.4,'y':.5},.99,now))
    bus.publish(PerceptionEvent('environment.changed','sentinel',{'active_title':'Other','fingerprint':'B','changed':True},timestamp=now+.2))
    bus.publish(PerceptionEvent('voice.command','voice',{'text':'haz clic ahí'},.99,now+.3))
    ctx=fusion.resolve(now+.35)
    assert ctx.ambiguous and 'scene_changed_after_point' in ctx.contradictions
    fusion.close()


def test_fusion_cloud_export_separate_permission():
    bus=PerceptionBus(); allow=False; fusion=FusionCore(bus,cloud_allowed=lambda:allow)
    bus.publish(PerceptionEvent('voice.command','voice',{'text':'estado'}))
    assert fusion.cloud_summary() is None
    allow=True
    summary=fusion.cloud_summary()
    assert summary and summary['voice_text']=='estado'
    assert 'scene_fingerprint' not in summary
    fusion.close()


class DangerousAction(Action):
    name='danger'; capability='system.control'
    def run(self): raise AssertionError('must never execute in Skill Lab')


class MarkerAction(Action):
    name='marker'; capability='workspace.write'
    def __init__(self): self.called=0
    def run(self, value='x'):
        self.called += 1
        return {'value':value}


def test_skill_lab_practices_without_executing_real_action():
    action=MarkerAction(); lab=SkillLab({'marker':action})
    skill=SkillDefinition('mark','test',steps=[SkillStep('marker',{'value':'x'})],status=SkillStatus.VALIDATED)
    report=lab.practice(skill)
    assert report.ok
    assert action.called==0
    assert {t.name for t in report.trials}=={'nominal','permission_revocation','context_drift'}


def test_skill_lab_rejects_high_risk_capability():
    action=DangerousAction(); lab=SkillLab({'danger':action})
    skill=SkillDefinition('dangerous','test',steps=[SkillStep('danger',{})])
    report=lab.practice(skill)
    assert not report.ok
    assert action.run.__self__.name == 'danger' if hasattr(action.run,'__self__') else True


def test_phase8_runtime_has_three_advanced_jumps(tmp_path: Path):
    rt=build_phase8_runtime(tmp_path,SimulatedDesktopBackend())
    assert not rt.policy.is_allowed('perception.continuous')
    assert not rt.policy.is_allowed('perception.cloud')
    assert rt.sentinel is not None and rt.fusion is not None and rt.skill_lab is not None
    rt.policy.set('perception.continuous',True)
    rec=rt.sentinel.poll_once()
    assert rec is not None
    rt.clean_shutdown()


def test_skill_forge_in_phase8_requires_shadow_practice_for_enable(tmp_path: Path):
    rt=build_phase8_runtime(tmp_path,SimulatedDesktopBackend())
    # Build a safe skill directly to test the owner-enable gate without cloud AI.
    skill=SkillDefinition('safe_marker','safe simulated skill',steps=[SkillStep('status',{})],status=SkillStatus.VALIDATED)
    validation=rt.skill_forge.compiler.validate(skill); skill.required_capabilities=validation.required_capabilities
    rt.skill_store.save(skill)
    practice=rt.skill_forge.practice_existing(skill.name)
    assert practice['ok']
    rt.policy.set('skill.manage',True)
    req=rt.orchestrator.run('habilita skill safe_marker')
    # Natural planner support may vary, so inspect the persisted gate directly too.
    enabled=rt.skill_store.get('safe_marker')
    assert enabled is not None
    rt.clean_shutdown()

def test_skill_runner_rechecks_shadow_practice_even_if_status_was_manually_enabled(tmp_path: Path):
    rt=build_phase8_runtime(tmp_path,SimulatedDesktopBackend())
    # mobile_lock is intentionally high-risk in Skill Lab. A hand-edited ENABLED state must not bypass the lab.
    skill=SkillDefinition('manual_bypass','must be blocked',steps=[SkillStep('mobile_lock',{'device_id':'fake'})],status=SkillStatus.ENABLED)
    validation=rt.skill_forge.compiler.validate(skill); skill.required_capabilities=validation.required_capabilities
    rt.skill_store.save(skill)
    report=rt.skill_runner.run(skill,{})
    assert not report.ok
    assert 'Skill Lab rejected execution' in (report.error or '')
    rt.clean_shutdown()

def test_sentinel_thread_stops_on_global_stop():
    bus=PerceptionBus(); observer=SequenceObserver(); killed={'value':False}
    def stop_check():
        if killed['value']: raise RuntimeError('JARVIS kill switch is engaged')
    sentinel=PerceptionSentinel(observer,bus,allowed=lambda:True,stop_check=stop_check,config=SentinelConfig(interval_s=.02,max_observations_per_minute=1000))
    sentinel.start(); time.sleep(.04); killed['value']=True
    end=time.time()+.5
    while sentinel.running and time.time()<end: time.sleep(.01)
    assert not sentinel.running

def test_autopilot_receives_multimodal_context_only_with_owner_cloud_permission(tmp_path: Path):
    from jarvis_gm.autonomy.models import AutonomousMission
    rt=build_phase8_runtime(tmp_path,SimulatedDesktopBackend())
    class P:
        available=True
        def __init__(self): self.prompt=''
        def generate(self,prompt,*,system=None): self.prompt=prompt; return '{"decision":"blocked","reason":"test"}'
    p=P(); now=time.time()
    rt.perception.bus.publish(PerceptionEvent('voice.command','voice',{'text':'abre eso'},timestamp=now))
    mission=AutonomousMission(goal='test')
    rt.autonomy_engine._decide(p,mission)
    assert 'MULTIMODAL=null' in p.prompt
    rt.policy.set('perception.cloud',True)
    rt.autonomy_engine._decide(p,mission)
    assert '"voice_text": "abre eso"' in p.prompt
    rt.clean_shutdown()

def test_fusion_keeps_screen_cloud_boundary_separate():
    bus=PerceptionBus(); screen=False
    fusion=FusionCore(bus,cloud_allowed=lambda:True,screen_cloud_allowed=lambda:screen)
    now=time.time()
    bus.publish(PerceptionEvent('environment.changed','sentinel',{'active_title':'Secret Document','fingerprint':'x','changed':True},timestamp=now))
    bus.publish(PerceptionEvent('voice.command','voice',{'text':'estado'},timestamp=now+.01))
    hidden=fusion.cloud_summary(); assert hidden and hidden['voice_text']=='estado' and hidden['active_title']=='' and 'scene' not in hidden['sources']
    screen=True
    shown=fusion.cloud_summary(); assert shown and shown['active_title']=='Secret Document' and 'scene' in shown['sources']
    fusion.close()
