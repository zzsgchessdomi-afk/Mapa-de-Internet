from __future__ import annotations

from pathlib import Path
import tempfile
import time

from jarvis_gm.control.simulated_backend import SimulatedDesktopBackend
from jarvis_gm.control.windows_backend import WindowInfo
from jarvis_gm.intent.context import ContextClassifier, ContextProvider
from jarvis_gm.intent.engine import IntentConfig, IntentEngine
from jarvis_gm.intent.models import DecisionStatus
from jarvis_gm.perception.events import PerceptionEvent
from jarvis_gm.runtime import build_phase4_runtime


def _event(kind: str, payload=None, confidence=1.0, ts=None):
    return PerceptionEvent(kind, "vision.hand" if kind.startswith("gesture.") else "voice", payload or {}, confidence, ts or time.time())


def _wait_until(fn, timeout=1.0):
    end = time.time() + timeout
    while time.time() < end:
        if fn(): return True
        time.sleep(0.01)
    return fn()


def test_context_classifier_keeps_mixed_browser_media_context():
    labels = ContextClassifier().classify_title("YouTube - Google Chrome")
    assert labels["browser"] > 0.9 and labels["media"] > 0.9


def test_mixed_context_swipe_is_ambiguous_instead_of_guessing():
    b = SimulatedDesktopBackend(); b.windows[0] = WindowInfo(1, "YouTube - Google Chrome", 0,0,900,700)
    e = IntentEngine(ContextProvider(b)); e.gesture_armed = True
    d = e.process(_event("gesture.swipe_right", {"dx": .3, "duration": .2}, .98))
    assert d.status == DecisionStatus.AMBIGUOUS
    assert {c.context_label for c in d.candidates[:2]} == {"browser", "media"}


def test_explicit_media_mode_resolves_mixed_context():
    b = SimulatedDesktopBackend(); b.windows[0] = WindowInfo(1, "YouTube - Google Chrome", 0,0,900,700)
    e = IntentEngine(ContextProvider(b)); e.gesture_armed = True
    mode = e.process(_event("voice.command", {"text": "modo medios"}))
    assert mode.status == DecisionStatus.HOLD and e.context_override == "media"
    d = e.process(_event("gesture.swipe_right", {"dx": .3, "duration": .2}, .98))
    assert d.status == DecisionStatus.EXECUTE
    assert d.selected and d.selected.name == "media.seek_right"


def test_default_jarvis_context_maps_swipe_to_window_switch():
    b = SimulatedDesktopBackend(); e = IntentEngine(ContextProvider(b)); e.gesture_armed = True
    d = e.process(_event("gesture.swipe_right", {}, .98))
    assert d.status == DecisionStatus.EXECUTE
    assert d.selected and d.selected.name == "window.switch_right"


def test_low_confidence_pointer_is_held():
    b = SimulatedDesktopBackend(); e = IntentEngine(ContextProvider(b)); e.gesture_armed = True
    d = e.process(_event("gesture.point", {"x": .4, "y": .4}, .35))
    assert d.status == DecisionStatus.HOLD


def test_gesture_without_arm_signal_is_held():
    b = SimulatedDesktopBackend(); e = IntentEngine(ContextProvider(b))
    d = e.process(_event("gesture.pinch_start", {"x": .4, "y": .4}, .99))
    assert d.status == DecisionStatus.HOLD and not e.drag_active


def test_deictic_click_requires_recent_pointing_target():
    b = SimulatedDesktopBackend(); e = IntentEngine(ContextProvider(b)); e.gesture_armed = True
    missing = e.process(_event("voice.command", {"text": "haz clic ahí"}))
    assert missing.status == DecisionStatus.AMBIGUOUS
    t = time.time()
    point = e.process(_event("gesture.point", {"x": .25, "y": .5}, .96, t))
    assert point.status == DecisionStatus.EXECUTE
    click = e.process(_event("voice.command", {"text": "haz clic ahí"}, .98, t + .3))
    assert click.status == DecisionStatus.EXECUTE
    assert click.selected and click.selected.name == "multimodal.deictic_click"
    assert len(click.selected.actions) == 2


def test_unresolved_deictic_voice_does_not_fall_through_to_ai_planner():
    b = SimulatedDesktopBackend(); e = IntentEngine(ContextProvider(b))
    d = e.process(_event("voice.command", {"text": "mueve eso a la derecha"}))
    assert d.status == DecisionStatus.AMBIGUOUS


def test_phase4_bridge_blocks_ambiguous_mixed_context():
    with tempfile.TemporaryDirectory() as d:
        b = SimulatedDesktopBackend(); b.windows[0] = WindowInfo(1, "YouTube - Google Chrome", 0,0,900,700)
        rt = build_phase4_runtime(Path(d), b); rt.policy.set("input.control", True); rt.policy.set("window.control", True); rt.start_bridge()
        rt.perception.bus.publish(_event("gesture.armed"))
        rt.perception.bus.publish(_event("gesture.swipe_right", {"dx": .3, "duration": .2}, .98))
        time.sleep(.1); rt.bridge.stop()
        assert not b.hotkeys
        events = rt.orchestrator.memory.recent_events(20)
        assert any(x["event_type"] == "intent.ambiguous" for x in events)


def test_phase4_bridge_executes_after_user_context_lock():
    with tempfile.TemporaryDirectory() as d:
        b = SimulatedDesktopBackend(); b.windows[0] = WindowInfo(1, "YouTube - Google Chrome", 0,0,900,700)
        rt = build_phase4_runtime(Path(d), b); rt.policy.set("input.control", True); rt.start_bridge()
        rt.perception.bus.publish(_event("voice.command", {"text": "modo medios"}))
        rt.perception.bus.publish(_event("gesture.armed"))
        rt.perception.bus.publish(_event("gesture.swipe_right", {"dx": .3, "duration": .2}, .98))
        assert _wait_until(lambda: ("right",) in b.hotkeys)
        rt.bridge.stop()


def test_phase4_multimodal_point_plus_voice_click_executes_through_gateway():
    with tempfile.TemporaryDirectory() as d:
        b = SimulatedDesktopBackend(); rt = build_phase4_runtime(Path(d), b); rt.policy.set("input.control", True); rt.start_bridge()
        t = time.time(); rt.perception.bus.publish(_event("gesture.armed", ts=t))
        rt.perception.bus.publish(_event("gesture.point", {"x": .5, "y": .25}, .98, t+.02))
        rt.perception.bus.publish(_event("voice.command", {"text": "haz clic ahí"}, .99, t+.2))
        assert _wait_until(lambda: abs(b.cursor[0]-960) <= 1 and abs(b.cursor[1]-270) <= 1)
        rt.bridge.stop(); assert not b.buttons


def test_pinch_lifecycle_requires_arm_and_never_leaves_button_held():
    with tempfile.TemporaryDirectory() as d:
        b = SimulatedDesktopBackend(); rt = build_phase4_runtime(Path(d), b); rt.policy.set("input.control", True); rt.start_bridge()
        rt.perception.bus.publish(_event("gesture.pinch_start", {"x": .3, "y": .3}, .99)); time.sleep(.05)
        assert not b.buttons
        rt.perception.bus.publish(_event("gesture.armed")); rt.perception.bus.publish(_event("gesture.pinch_start", {"x": .3, "y": .3}, .99))
        assert _wait_until(lambda: "left" in b.buttons)
        rt.perception.bus.publish(_event("gesture.pinch_end", {"x": .4, "y": .4}, .99))
        assert _wait_until(lambda: "left" not in b.buttons)
        rt.bridge.stop()


def test_intent_config_is_user_owned_and_persisted():
    with tempfile.TemporaryDirectory() as d:
        p = Path(d)/"intent_config.json"
        cfg = IntentConfig.load(p); assert p.exists()
        cfg.min_confidence = .77; cfg.save(p)
        assert IntentConfig.load(p).min_confidence == .77


def test_context_override_expires():
    b = SimulatedDesktopBackend(); cfg = IntentConfig(context_override_ttl_s=.01); e = IntentEngine(ContextProvider(b), cfg)
    e.process(_event("voice.command", {"text": "modo navegador"}))
    assert e.context_override == "browser"
    time.sleep(.02)
    assert e.context_override is None
