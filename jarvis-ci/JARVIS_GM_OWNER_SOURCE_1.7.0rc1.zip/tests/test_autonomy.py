from __future__ import annotations

import json
import tempfile
from pathlib import Path

from jarvis_gm.control.simulated_backend import SimulatedDesktopBackend
from jarvis_gm.core.models import GoalState
from jarvis_gm.runtime import build_phase8_runtime


class SequenceProvider:
    available=True
    def __init__(self, decisions):
        self.decisions=list(decisions); self.calls=0
    def generate(self,prompt,*,system=None):
        if "CLOSED-LOOP desktop mission" in prompt:
            self.calls += 1
            if not self.decisions: return json.dumps({"decision":"blocked","reason":"no decision"})
            return json.dumps(self.decisions.pop(0))
        return "{}"


def _rt(root: Path, provider):
    rt=build_phase8_runtime(root,SimulatedDesktopBackend())
    rt.providers.register("auto-test",provider);rt.providers.set_active("auto-test")
    return rt


def test_autonomy_default_off_and_list_is_read_only():
    with tempfile.TemporaryDirectory() as d:
        rt=_rt(Path(d),SequenceProvider([]))
        try:
            assert rt.policy.is_allowed("autonomy.run") is False
            blocked=rt.orchestrator.run("autonomía: crea una nota")
            assert blocked.state==GoalState.BLOCKED
            listed=rt.orchestrator.run("misiones autónomas")
            assert listed.state==GoalState.VERIFIED and listed.results[0].output==[]
        finally: rt.clean_shutdown()


def test_closed_loop_requires_local_verified_evidence_before_done():
    decisions=[
        {"decision":"done","evidence":[],"reason":"trust me"},
        {"decision":"act","action":"create_note","args":{"filename":"proof.txt","content":"ok"},"rationale":"create artifact","expected_effect":"file exists"},
        {"decision":"done","evidence":["step:1"],"reason":"verified artifact exists"},
    ]
    with tempfile.TemporaryDirectory() as d:
        root=Path(d);rt=_rt(root,SequenceProvider(decisions));rt.policy.set("autonomy.run",True)
        try:
            goal=rt.orchestrator.run("autonomía: crea una nota de prueba")
            assert goal.state==GoalState.VERIFIED
            assert (root/"workspace"/"proof.txt").read_text()=="ok"
            rows=rt.autonomy_store.list();assert rows and rows[0]["state"]=="verified"
            report=rt.autonomy_store.load(rows[0]["id"])
            assert len(report.steps)==1 and report.steps[0].state.value=="verified"
        finally: rt.clean_shutdown()


def test_autonomy_cannot_bypass_underlying_permission():
    decisions=[{"decision":"act","action":"open_app","args":{"app":"notepad"},"rationale":"open app","expected_effect":"app opens"}]
    with tempfile.TemporaryDirectory() as d:
        rt=_rt(Path(d),SequenceProvider(decisions));rt.policy.set("autonomy.run",True)
        try:
            goal=rt.orchestrator.run("autonomía: abre notepad")
            assert goal.state==GoalState.BLOCKED
            assert rt.backend.opened_apps==[]
            rows=rt.autonomy_store.list();report=rt.autonomy_store.load(rows[0]["id"])
            assert report.state.value=="blocked" and report.steps[0].state.value=="blocked"
        finally: rt.clean_shutdown()


def test_autonomy_loop_guard_stops_repeated_actions():
    decisions=[
        {"decision":"act","action":"status","args":{},"rationale":"check","expected_effect":"status"},
        {"decision":"act","action":"status","args":{},"rationale":"check again","expected_effect":"status"},
        {"decision":"act","action":"status","args":{},"rationale":"again","expected_effect":"status"},
    ]
    with tempfile.TemporaryDirectory() as d:
        rt=_rt(Path(d),SequenceProvider(decisions));rt.policy.set("autonomy.run",True)
        try:
            goal=rt.orchestrator.run("autonomía: loop")
            assert goal.state==GoalState.BLOCKED
            rows=rt.autonomy_store.list();report=rt.autonomy_store.load(rows[0]["id"])
            assert "Loop guard" in report.blocked_reason and len(report.steps)==2
        finally: rt.clean_shutdown()


def test_autonomy_replans_after_action_failure_then_completes():
    decisions=[
        {"decision":"act","action":"read_note","args":{"filename":"missing.txt"},"rationale":"inspect","expected_effect":"read file"},
        {"decision":"act","action":"create_note","args":{"filename":"fixed.txt","content":"recovered"},"rationale":"recover","expected_effect":"file exists"},
        {"decision":"done","evidence":["step:2"],"reason":"recovery verified"},
    ]
    with tempfile.TemporaryDirectory() as d:
        root=Path(d);rt=_rt(root,SequenceProvider(decisions));rt.policy.set("autonomy.run",True)
        try:
            goal=rt.orchestrator.run("autonomía: recupera la tarea")
            assert goal.state==GoalState.VERIFIED and (root/"workspace"/"fixed.txt").exists()
            report=rt.autonomy_store.load(rt.autonomy_store.list()[0]["id"])
            assert report.steps[0].state.value=="failed" and report.steps[1].state.value=="verified" and report.replans>=1
        finally: rt.clean_shutdown()

class CapturePromptProvider:
    available=True
    def __init__(self): self.prompts=[]
    def generate(self,prompt,*,system=None):
        self.prompts.append(prompt)
        return json.dumps({"decision":"blocked","reason":"privacy probe"})


def test_autonomy_does_not_send_screen_or_memory_context_without_cloud_permissions():
    with tempfile.TemporaryDirectory() as d:
        root=Path(d); provider=CapturePromptProvider(); rt=_rt(root,provider); rt.policy.set("autonomy.run",True)
        try:
            rt.memory_manager.remember("TOP SECRET MEMORY TOKEN",source="test")
            rt.autonomy_engine.run("privacy probe",max_steps=1)
            prompt=provider.prompts[-1]
            assert "TOP SECRET MEMORY TOKEN" not in prompt
            assert '"elements":' not in prompt
            assert rt.policy.is_allowed("memory.cloud") is False and rt.policy.is_allowed("screen.cloud") is False
        finally: rt.clean_shutdown()


def test_autonomy_cloud_context_is_explicit_opt_in():
    with tempfile.TemporaryDirectory() as d:
        root=Path(d); provider=CapturePromptProvider(); rt=_rt(root,provider); rt.policy.set("autonomy.run",True)
        try:
            rt.memory_manager.remember("CLOUD OPT IN TOKEN",source="test")
            rt.policy.set("memory.cloud",True)
            rt.policy.set("screen.cloud",True)
            rt.autonomy_engine.run("CLOUD OPT IN TOKEN",max_steps=1)
            prompt=provider.prompts[-1]
            assert "CLOUD OPT IN TOKEN" in prompt
            assert '"screen"' in prompt.lower() or 'SCREEN=' in prompt
        finally: rt.clean_shutdown()

class InvalidProvider:
    available=True
    def generate(self,prompt,*,system=None): return "not-json"


def test_autonomy_runtime_errors_are_persisted_not_left_running():
    with tempfile.TemporaryDirectory() as d:
        rt=_rt(Path(d),InvalidProvider());rt.policy.set("autonomy.run",True)
        try:
            goal=rt.orchestrator.run("autonomía: malformed provider")
            assert goal.state==GoalState.FAILED
            row=rt.autonomy_store.list()[0];report=rt.autonomy_store.load(row["id"])
            assert report.state.value=="failed" and "Autonomy runtime error" in report.conclusion
        finally:rt.clean_shutdown()


def test_kill_switch_prevents_autonomy_from_starting():
    with tempfile.TemporaryDirectory() as d:
        rt=_rt(Path(d),SequenceProvider([]));rt.policy.set("autonomy.run",True);rt.kill_switch.engage()
        try:
            goal=rt.orchestrator.run("autonomía: should stop")
            assert goal.state==GoalState.BLOCKED and rt.autonomy_store.list()==[]
        finally:
            rt.kill_switch.reset();rt.clean_shutdown()


class MidMissionStopProvider:
    available=True
    def __init__(self): self.stop=None
    def generate(self,prompt,*,system=None):
        if self.stop:self.stop()
        return json.dumps({"decision":"act","action":"status","args":{},"rationale":"probe","expected_effect":"status"})


def test_mid_mission_stop_is_persisted_as_blocked():
    with tempfile.TemporaryDirectory() as d:
        provider=MidMissionStopProvider();rt=_rt(Path(d),provider);provider.stop=rt.kill_switch.engage;rt.policy.set("autonomy.run",True)
        try:
            goal=rt.orchestrator.run("autonomía: should stop mid mission")
            assert goal.state==GoalState.BLOCKED
            report=rt.autonomy_store.load(rt.autonomy_store.list()[0]["id"])
            assert report.state.value=="blocked" and report.steps and report.steps[0].state.value=="blocked"
        finally:
            rt.kill_switch.reset();rt.clean_shutdown()
