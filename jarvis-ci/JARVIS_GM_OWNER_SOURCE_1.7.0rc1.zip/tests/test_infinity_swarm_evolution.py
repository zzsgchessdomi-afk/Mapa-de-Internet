from __future__ import annotations
import json
import pytest
from jarvis_gm.control.simulated_backend import SimulatedDesktopBackend
from jarvis_gm.runtime import build_infinity4_runtime, build_infinity5_runtime
from jarvis_gm.skills.models import SkillDefinition, SkillStep, SkillStatus

class SwarmProvider:
    available=True
    def __init__(self): self.prompts=[]
    def generate(self,prompt,*,system=None):
        self.prompts.append(prompt)
        if "Design a 3-8 member temporary expert team" in prompt:
            return json.dumps({"members":[
                {"id":"architect","specialty":"systems architect","mandate":"Design solution","perspective":"builder","depends_on":[],"use_research":False},
                {"id":"critic","specialty":"failure analyst","mandate":"Challenge design","perspective":"critic","depends_on":["architect"],"use_research":False},
                {"id":"verifier","specialty":"verification engineer","mandate":"Check assumptions","perspective":"verifier","depends_on":["architect"],"use_research":False},
                {"id":"synth","specialty":"chief integrator","mandate":"Synthesize","perspective":"synthesizer","depends_on":["architect","critic","verifier"],"use_research":False},
            ]})
        if "PERSPECTIVE=synthesizer" in prompt: return "Integrated answer with residual uncertainty noted."
        if "PERSPECTIVE=critic" in prompt: return "Risk: one unsupported assumption should be tested."
        if "PERSPECTIVE=verifier" in prompt: return "Verification checklist and evidence requirements."
        return "Architecture proposal."

class EvolutionProvider:
    available=True
    def generate(self,prompt,*,system=None):
        if "Propose a safer/more reliable revision" in prompt:
            return json.dumps({
                "description":"Create a note reliably",
                "inputs":{"filename":{"type":"string"},"content":{"type":"string"}},
                "steps":[{"action":"create_note","args":{"filename":"{{filename}}","content":"{{content}}"},"description":"write note"}],
                "confidence":0.95,
                "rationale":"Keep a single deterministic verified action"
            })
        return "{}"

def test_infinity4_swarm_defaults_and_dynamic_team(tmp_path):
    rt=build_infinity4_runtime(tmp_path,SimulatedDesktopBackend())
    assert rt.policy.is_allowed("swarm.read")
    assert not rt.policy.is_allowed("swarm.run")
    assert not rt.policy.is_allowed("swarm.cloud")
    p=SwarmProvider();rt.providers.register("swarm-test",p);rt.providers.set_active("swarm-test")
    blocked=rt.swarm.run("design a reliable subsystem")
    assert blocked.state.value=="blocked"
    rt.policy.set("swarm.run",True);rt.policy.set("swarm.cloud",True)
    report=rt.swarm.run("design a reliable subsystem")
    assert report.state.value=="completed"
    assert len(report.members)==4
    assert report.members[-1].perspective=="synthesizer"
    assert set(report.members[-1].depends_on)=={"architect","critic","verifier"}
    assert report.synthesis.startswith("Integrated answer")
    assert report.dissent
    assert rt.swarm.store.load(report.id)["state"]=="completed"
    rt.clean_shutdown()

def test_infinity4_cloud_context_respects_existing_cloud_boundaries(tmp_path):
    rt=build_infinity4_runtime(tmp_path,SimulatedDesktopBackend())
    p=SwarmProvider();rt.providers.register("swarm-test",p);rt.providers.set_active("swarm-test")
    rt.policy.set("swarm.run",True);rt.policy.set("swarm.cloud",True)
    # Populate a local project memory, but keep memory.cloud/world.cloud/os.cloud OFF.
    rt.memory_manager.create_project("SECRET PROJECT")
    action=rt.orchestrator.executor.actions["swarm_run"]
    out=action.run(goal="plan next step")
    assert out["state"]=="completed"
    joined="\n".join(p.prompts)
    assert "SECRET PROJECT" not in joined
    rt.clean_shutdown()

def _seed_skill(rt):
    skill=SkillDefinition(
        name="Reliable Note",description="Create a note",inputs={"filename":{"type":"string"},"content":{"type":"string"}},
        steps=[SkillStep("create_note",{"filename":"{{filename}}","content":"{{content}}"})],status=SkillStatus.ENABLED,
    )
    rt.skill_store.save(skill);rt.skill_store.set_status(skill.name,SkillStatus.ENABLED)
    return rt.skill_store.get(skill.name)

def test_infinity5_benchmark_propose_and_owner_promotion(tmp_path):
    rt=build_infinity5_runtime(tmp_path,SimulatedDesktopBackend())
    base=_seed_skill(rt)
    assert rt.policy.is_allowed("evolution.read")
    assert not rt.policy.is_allowed("evolution.run")
    baseline=rt.evolution.benchmark(base)
    assert baseline.passed and baseline.score>=90
    p=EvolutionProvider();rt.providers.register("evo-test",p);rt.providers.set_active("evo-test")
    rt.policy.set("evolution.run",True);rt.policy.set("evolution.cloud",True)
    candidate=rt.evolution.propose(base.name,"reduce failure risk")
    assert candidate.state.value=="benchmarked"
    assert candidate.benchmark["passed"] is True
    # Candidate is not installed/enabled merely because the model proposed it.
    current=rt.skill_store.get(base.name)
    assert current.version==base.version and current.status==SkillStatus.ENABLED
    with pytest.raises(PermissionError): rt.evolution.promote(candidate.id)
    rt.policy.set("evolution.manage",True)
    with pytest.raises(PermissionError): rt.evolution.promote(candidate.id)  # Guardian owner lease still required.
    rt.guardian.grant_action("evolution_promote",ttl_s=60,uses=1)
    promoted=rt.evolution.promote(candidate.id)
    assert promoted.version==base.version+1
    assert promoted.status==SkillStatus.VALIDATED  # never auto-enabled
    assert rt.evolution.store.load(candidate.id).state.value=="promoted"
    rt.clean_shutdown()

def test_infinity5_rejects_candidate_below_baseline(tmp_path):
    rt=build_infinity5_runtime(tmp_path,SimulatedDesktopBackend());base=_seed_skill(rt)
    p=EvolutionProvider();rt.providers.register("evo-test",p);rt.providers.set_active("evo-test")
    rt.policy.set("evolution.run",True);rt.policy.set("evolution.cloud",True);rt.policy.set("evolution.manage",True)
    c=rt.evolution.propose(base.name)
    c.benchmark["score"]=0.0;rt.evolution.store.save(c)
    rt.guardian.grant_action("evolution_promote",ttl_s=60,uses=1)
    with pytest.raises(RuntimeError): rt.evolution.promote(c.id)
    rt.clean_shutdown()

class BadTeamProvider(SwarmProvider):
    def generate(self,prompt,*,system=None):
        if "Design a 3-8 member temporary expert team" in prompt:
            return json.dumps({"members":[
                {"id":"a","specialty":"a","mandate":"a","perspective":"builder","depends_on":[]},
                {"id":"b","specialty":"b","mandate":"b","perspective":"builder","depends_on":["a"]},
                {"id":"s","specialty":"s","mandate":"s","perspective":"synthesizer","depends_on":["a","b"]},
            ]})
        return "x"

class MetaEvolutionProvider:
    available=True
    def __init__(self, action="workbench_run_cycle"): self.action=action
    def generate(self,prompt,*,system=None):
        if "Propose a safer/more reliable revision" in prompt:
            return json.dumps({"description":"bad meta candidate","inputs":{},"steps":[{"action":self.action,"args":{}}],"confidence":0.9,"rationale":"bad"})
        return "{}"

class WidenEvolutionProvider:
    available=True
    def generate(self,prompt,*,system=None):
        if "Propose a safer/more reliable revision" in prompt:
            return json.dumps({"description":"widen authority","inputs":{"url":{"type":"string"}},"steps":[{"action":"open_url","args":{"url":"{{url}}"}}],"confidence":0.9,"rationale":"widen"})
        return "{}"

def test_infinity4_requires_adversarial_member(tmp_path):
    rt=build_infinity4_runtime(tmp_path,SimulatedDesktopBackend());p=BadTeamProvider();rt.providers.register("bad",p);rt.providers.set_active("bad")
    rt.policy.set("swarm.run",True);rt.policy.set("swarm.cloud",True)
    report=rt.swarm.run("test")
    assert report.state.value=="failed" and "critic or verifier" in report.synthesis
    rt.clean_shutdown()

def test_infinity4_stop_blocks_swarm_and_persists_state(tmp_path):
    rt=build_infinity4_runtime(tmp_path,SimulatedDesktopBackend());p=SwarmProvider();rt.providers.register("s",p);rt.providers.set_active("s")
    rt.policy.set("swarm.run",True);rt.policy.set("swarm.cloud",True);rt.kill_switch.engage()
    report=rt.swarm.run("should stop")
    assert report.state.value=="blocked"
    assert rt.swarm.store.load(report.id)["state"]=="blocked"
    rt.kill_switch.reset();rt.clean_shutdown()

def test_infinity4_backup_diagnostics_and_safe_mode_caps(tmp_path):
    import zipfile, json as _json
    from jarvis_gm.product.recovery import SAFE_MODE_CAPABILITIES
    rt=build_infinity4_runtime(tmp_path,SimulatedDesktopBackend());p=SwarmProvider();rt.providers.register("s",p);rt.providers.set_active("s")
    rt.policy.set("swarm.run",True);rt.policy.set("swarm.cloud",True);rt.swarm.run("persist me")
    archive=rt.backup.create(tmp_path/"x.jarvisbackup")
    with zipfile.ZipFile(archive) as zf:
        manifest=_json.loads(zf.read("backup_manifest.json")); paths={x["path"] for x in manifest["files"]}
    assert "swarm.sqlite3" in paths
    diag=rt.diagnostics.run(rt)
    assert diag["version"]=="1.4.0a4" and diag["storage"]["swarm_sqlite"]["status"]=="ok"
    assert "swarm.run" in SAFE_MODE_CAPABILITIES and "swarm.cloud" in SAFE_MODE_CAPABILITIES
    rt.clean_shutdown()

def test_infinity5_meta_actions_are_forbidden_inside_evolved_skills(tmp_path):
    rt=build_infinity5_runtime(tmp_path,SimulatedDesktopBackend());base=_seed_skill(rt)
    p=MetaEvolutionProvider();rt.providers.register("meta",p);rt.providers.set_active("meta")
    rt.policy.set("evolution.run",True);rt.policy.set("evolution.cloud",True)
    c=rt.evolution.propose(base.name)
    assert c.state.value=="rejected"
    assert c.benchmark["passed"] is False
    assert any("meta-action" in x for x in c.benchmark["metrics"]["validation_errors"])
    rt.clean_shutdown()

def test_infinity5_cannot_widen_skill_authority(tmp_path):
    rt=build_infinity5_runtime(tmp_path,SimulatedDesktopBackend());base=_seed_skill(rt)
    p=WidenEvolutionProvider();rt.providers.register("wide",p);rt.providers.set_active("wide")
    rt.policy.set("evolution.run",True);rt.policy.set("evolution.cloud",True)
    c=rt.evolution.propose(base.name)
    assert c.state.value=="rejected"
    assert c.benchmark["metrics"]["authority_widening"]==["browser.open"]
    rt.clean_shutdown()

def test_infinity5_backup_diagnostics_and_safe_mode_caps(tmp_path):
    import zipfile, json as _json
    from jarvis_gm.product.recovery import SAFE_MODE_CAPABILITIES
    rt=build_infinity5_runtime(tmp_path,SimulatedDesktopBackend());base=_seed_skill(rt)
    p=EvolutionProvider();rt.providers.register("e",p);rt.providers.set_active("e");rt.policy.set("evolution.run",True);rt.policy.set("evolution.cloud",True)
    rt.evolution.propose(base.name)
    archive=rt.backup.create(tmp_path/"e.jarvisbackup")
    with zipfile.ZipFile(archive) as zf:
        manifest=_json.loads(zf.read("backup_manifest.json")); paths={x["path"] for x in manifest["files"]}
    assert "evolution.sqlite3" in paths and "swarm.sqlite3" in paths
    diag=rt.diagnostics.run(rt)
    assert diag["version"]=="1.5.0a5" and diag["storage"]["evolution_sqlite"]["status"]=="ok"
    assert {"evolution.run","evolution.manage","evolution.cloud"}.issubset(SAFE_MODE_CAPABILITIES)
    rt.clean_shutdown()

class DriftEvolutionProvider:
    available=True
    def generate(self,prompt,*,system=None):
        if "Propose a safer/more reliable revision" in prompt:
            return json.dumps({"description":"semantic drift","inputs":{"filename":{"type":"string"}},"steps":[{"action":"status","args":{}}],"confidence":0.99,"rationale":"does nothing useful"})
        return "{}"

def test_infinity5_rejects_semantic_contract_drift(tmp_path):
    rt=build_infinity5_runtime(tmp_path,SimulatedDesktopBackend());base=_seed_skill(rt)
    p=DriftEvolutionProvider();rt.providers.register("drift",p);rt.providers.set_active("drift")
    rt.policy.set("evolution.run",True);rt.policy.set("evolution.cloud",True)
    c=rt.evolution.propose(base.name)
    assert c.state.value=="rejected"
    assert "create_note" in c.benchmark["metrics"]["removed_anchor_actions"]
    assert "input_contract_changed" in c.benchmark["metrics"]
    rt.clean_shutdown()

def test_infinity5_owner_can_rollback_promoted_revision(tmp_path):
    rt=build_infinity5_runtime(tmp_path,SimulatedDesktopBackend());base=_seed_skill(rt)
    p=EvolutionProvider();rt.providers.register("e",p);rt.providers.set_active("e")
    rt.policy.set("evolution.run",True);rt.policy.set("evolution.cloud",True);rt.policy.set("evolution.manage",True)
    c=rt.evolution.propose(base.name)
    rt.guardian.grant_action("evolution_promote",ttl_s=60,uses=1);promoted=rt.evolution.promote(c.id)
    assert promoted.status==SkillStatus.VALIDATED
    with pytest.raises(PermissionError):rt.evolution.rollback(c.id)
    rt.guardian.grant_action("evolution_rollback",ttl_s=60,uses=1);restored=rt.evolution.rollback(c.id)
    assert restored.version==promoted.version+1
    assert restored.status==SkillStatus.VALIDATED
    assert restored.description==base.description
    assert rt.evolution.store.load(c.id).state.value=="rolled_back"
    rt.clean_shutdown()

def test_autopilot_cannot_reenter_workbench_or_promote_evolution():
    from jarvis_gm.autonomy.engine import AutonomyEngine
    assert "workbench_run_cycle" in AutonomyEngine.META_ACTIONS
    assert "workbench_create" in AutonomyEngine.META_ACTIONS
    assert "evolution_promote" in AutonomyEngine.META_ACTIONS
    assert "evolution_rollback" in AutonomyEngine.META_ACTIONS
    assert "swarm_run" not in AutonomyEngine.META_ACTIONS  # advisory specialists are safe to call


def test_infinity5_scan_benchmarks_local_skills_without_cloud(tmp_path):
    rt=build_infinity5_runtime(tmp_path,SimulatedDesktopBackend());_seed_skill(rt)
    rows=rt.evolution.scan()
    assert rows and rows[0]["skill"]=="Reliable Note"
    assert rows[0]["passed"] is True
    assert not rt.policy.is_allowed("evolution.cloud")
    rt.clean_shutdown()
