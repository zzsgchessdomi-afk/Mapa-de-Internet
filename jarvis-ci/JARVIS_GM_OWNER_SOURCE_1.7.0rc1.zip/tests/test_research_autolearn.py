from __future__ import annotations

from pathlib import Path
import json
import tempfile

from jarvis_gm.control.simulated_backend import SimulatedDesktopBackend
from jarvis_gm.core.models import GoalState
from jarvis_gm.runtime import build_phase8_runtime
from jarvis_gm.skills.models import SkillStatus


class ResearchProvider:
    available=True
    def __init__(self):
        self.search_calls=[]
        self.auto_decisions=[]
    def generate(self,prompt: str,*,system=None):
        if "Create a compact research plan" in prompt:
            return json.dumps({"queries":["official docs procedure","known limitations contradiction"]})
        if "Analyze the evidence" in prompt:
            return json.dumps({"claims":[
                {"claim":"Procedure is supported by official docs","support_urls":["https://official.example/docs","https://invented.invalid"],"confidence":0.9,"status":"supported"}
            ],"gaps":["Hardware-specific behavior remains untested"]})
        if "Act as a skeptical reviewer" in prompt:
            return json.dumps({"contradictions":[{"issue":"One environment may differ","claim_indexes":[0],"severity":"medium"}],"gaps":[]})
        if "Synthesize a concise research report" in prompt:
            return "Supported procedure with explicit uncertainty (https://official.example/docs)"
        if "Design ONE reusable JARVIS skill" in prompt:
            return json.dumps({
                "name":"Create Auto Note","description":"Create a note from supplied content",
                "inputs":{"filename":{"type":"string"},"content":{"type":"string"}},
                "steps":[{"action":"create_note","args":{"filename":"{{filename}}","content":"{{content}}"},"description":"write note"}],
                "confidence":0.94,
            })
        if "You control a CLOSED-LOOP desktop mission" in prompt:
            if not self.auto_decisions:
                return json.dumps({"decision":"blocked","reason":"no decision queued"})
            return json.dumps(self.auto_decisions.pop(0))
        if prompt.startswith("Synthesize the mission work"):
            return "mission synthesis"
        if prompt.startswith("Decompose the user's mission"):
            return json.dumps({"tasks":[{"id":"t1","role":"reviewer","objective":"review","depends_on":[],"web_research":False}]})
        return "specialist output"
    def grounded_search(self,prompt: str):
        self.search_calls.append(prompt)
        return {"text":"Official procedural evidence.","queries":["official"],"citations":[{"title":"Official Docs","url":"https://official.example/docs"}]}


def _rt(root: Path, provider: ResearchProvider):
    rt=build_phase8_runtime(root,SimulatedDesktopBackend())
    rt.providers.register("research-test",provider);rt.providers.set_active("research-test")
    return rt


def test_research_corps_permissions_default_off():
    with tempfile.TemporaryDirectory() as d:
        provider=ResearchProvider();rt=_rt(Path(d),provider)
        try:
            assert rt.policy.is_allowed("research.deep") is False
            assert rt.policy.is_allowed("research.web") is False
            g=rt.orchestrator.run("investiga: procedimiento actual")
            assert g.state==GoalState.BLOCKED and provider.search_calls==[]
        finally:rt.clean_shutdown()


def test_research_corps_runs_bounded_pipeline_and_keeps_provenance():
    with tempfile.TemporaryDirectory() as d:
        provider=ResearchProvider();rt=_rt(Path(d),provider)
        try:
            rt.policy.set("research.deep",True);rt.policy.set("research.web",True)
            before=(list(rt.backend.opened_apps),list(rt.backend.opened_urls),rt.backend.cursor)
            g=rt.orchestrator.run("investiga: cómo realizar una tarea verificable")
            after=(list(rt.backend.opened_apps),list(rt.backend.opened_urls),rt.backend.cursor)
            assert g.state==GoalState.VERIFIED and before==after
            output=g.results[0].output
            assert output["state"]=="verified" and len(output["queries"])==2
            assert output["citations"]==[{"url":"https://official.example/docs","title":"Official Docs"}]
            assert output["claims"][0]["support_urls"]==["https://official.example/docs"]
            roles={x["role"] for x in output["traces"]}
            assert {"source_scout","evidence_analyst","skeptic","synthesizer"}.issubset(roles)
            assert list((Path(d)/"research_runs").glob("research_*.json"))
        finally:rt.clean_shutdown()


def test_skill_forge_web_uses_research_corps_and_preflight_without_execution():
    with tempfile.TemporaryDirectory() as d:
        root=Path(d);provider=ResearchProvider();rt=_rt(root,provider)
        try:
            rt.policy.set("skill.learn",True);rt.policy.set("research.web",True);rt.policy.set("research.deep",True)
            g=rt.orchestrator.run("aprende web: crear nota reusable")
            assert g.state==GoalState.VERIFIED
            skill=rt.skill_store.get("Create Auto Note")
            assert skill and skill.status==SkillStatus.VALIDATED and skill.source=="research-corps+ai"
            assert skill.source_urls==("https://official.example/docs",)
            out=g.results[0].output
            assert out["preflight"]["ok"] is True and all(not x["executes"] for x in out["preflight"]["steps"])
            assert not (root/"workspace"/"__jarvis_preflight__").exists()
            assert list((root/"research_runs").glob("research_*.json"))
        finally:rt.clean_shutdown()


def test_autopilot_learns_pauses_for_owner_then_resumes_with_enabled_skill():
    with tempfile.TemporaryDirectory() as d:
        root=Path(d);provider=ResearchProvider();rt=_rt(root,provider)
        try:
            for cap in ("autonomy.run","skill.learn","skill.execute","research.web","research.deep"):
                rt.policy.set(cap,True)
            provider.auto_decisions=[
                {"decision":"learn","goal":"create a reusable project note","use_web":True,"rationale":"missing procedure"},
            ]
            first=rt.orchestrator.run("autonomía: crea una nota usando una skill que puedas aprender")
            assert first.state==GoalState.BLOCKED
            row=rt.autonomy_store.list()[0];mission=rt.autonomy_store.load(row["id"])
            assert mission.state.value=="awaiting_approval" and mission.pending_skill=="Create Auto Note"
            assert mission.steps[0].action=="learn_skill" and mission.steps[0].evidence_kind=="capability"
            assert mission.steps[0].state.value=="verified"
            assert not (root/"workspace"/"auto.txt").exists()
            skill=rt.skill_store.get("Create Auto Note");assert skill and skill.status==SkillStatus.VALIDATED

            # Explicit owner approval. Autopilot itself never performs this transition.
            rt.skill_store.set_status("Create Auto Note",SkillStatus.ENABLED)
            provider.auto_decisions=[
                {"decision":"skill","skill":"Create Auto Note","inputs":{"filename":"auto.txt","content":"learned and verified"},"rationale":"use owner-approved skill","expected_effect":"note exists"},
                {"decision":"done","evidence":["step:2"],"reason":"owner-approved skill produced verified artifact"},
            ]
            resumed=rt.orchestrator.run(f"reanuda misión autónoma {mission.id}")
            assert resumed.state==GoalState.VERIFIED
            final=rt.autonomy_store.load(mission.id)
            assert final.state.value=="verified" and final.pending_skill==""
            assert final.steps[1].action=="run_skill" and final.steps[1].state.value=="verified"
            assert (root/"workspace"/"auto.txt").read_text()=="learned and verified"
        finally:rt.clean_shutdown()


def test_learning_step_cannot_be_used_as_task_completion_evidence():
    with tempfile.TemporaryDirectory() as d:
        root=Path(d);provider=ResearchProvider();rt=_rt(root,provider)
        try:
            for cap in ("autonomy.run","skill.learn","research.web"):
                rt.policy.set(cap,True)
            provider.auto_decisions=[{"decision":"learn","goal":"create a reusable project note","use_web":True}]
            rt.orchestrator.run("autonomía: complete task")
            mission=rt.autonomy_store.load(rt.autonomy_store.list()[0]["id"])
            assert mission.verified_evidence_ids()==()
        finally:rt.clean_shutdown()

class StopDuringResearchProvider(ResearchProvider):
    def __init__(self, stop):
        super().__init__(); self.stop=stop; self.count=0
    def grounded_search(self,prompt: str):
        self.count+=1
        result=super().grounded_search(prompt)
        if self.count==1:self.stop()
        return result


def test_stop_global_interrupts_research_between_stages():
    with tempfile.TemporaryDirectory() as d:
        root=Path(d); holder={}
        rt=build_phase8_runtime(root,SimulatedDesktopBackend())
        provider=StopDuringResearchProvider(rt.kill_switch.engage);rt.providers.register("stop-research",provider);rt.providers.set_active("stop-research")
        try:
            rt.policy.set("research.deep",True);rt.policy.set("research.web",True)
            g=rt.orchestrator.run("investiga: stop test")
            assert g.state==GoalState.BLOCKED
            rows=rt.research_corps.list();assert rows and rows[0]["state"]=="blocked"
            assert provider.count==1
        finally:
            rt.kill_switch.reset();rt.clean_shutdown()

def test_deep_research_requires_web_even_when_corps_permission_is_on():
    with tempfile.TemporaryDirectory() as d:
        provider=ResearchProvider();rt=_rt(Path(d),provider)
        try:
            rt.policy.set("research.deep",True)
            g=rt.orchestrator.run("investiga: current docs")
            assert g.state==GoalState.BLOCKED and provider.search_calls==[]
        finally:rt.clean_shutdown()


def test_web_skill_learning_does_not_silently_use_corps_without_corps_permission():
    with tempfile.TemporaryDirectory() as d:
        root=Path(d);provider=ResearchProvider();rt=_rt(root,provider)
        try:
            rt.policy.set("skill.learn",True);rt.policy.set("research.web",True)
            g=rt.orchestrator.run("aprende web: crear nota reusable")
            assert g.state==GoalState.VERIFIED
            skill=rt.skill_store.get("Create Auto Note")
            assert skill and skill.source=="web+ai" and skill.provenance_id==""
            assert not list((root/"research_runs").glob("research_*.json"))
        finally:rt.clean_shutdown()


class FailingResearchProvider(ResearchProvider):
    def grounded_search(self,prompt: str):
        raise RuntimeError("provider research outage")


def test_research_provider_failure_is_persisted_and_reported_failed():
    with tempfile.TemporaryDirectory() as d:
        root=Path(d);provider=FailingResearchProvider();rt=_rt(root,provider)
        try:
            rt.policy.set("research.deep",True);rt.policy.set("research.web",True)
            g=rt.orchestrator.run("investiga: outage test")
            assert g.state==GoalState.FAILED
            rows=rt.research_corps.list();assert rows and rows[0]["state"]=="failed"
            saved=rt.research_corps.load(rows[0]["id"]);assert "outage" in saved["synthesis"]
        finally:rt.clean_shutdown()


def test_research_memory_context_is_cloud_opt_in_only():
    with tempfile.TemporaryDirectory() as d:
        root=Path(d);provider=ResearchProvider();provider.prompts=[]
        original_generate=provider.generate
        def capture(prompt,*,system=None):
            provider.prompts.append(prompt);return original_generate(prompt,system=system)
        provider.generate=capture
        rt=_rt(root,provider)
        try:
            rt.policy.set("research.deep",True);rt.policy.set("research.web",True)
            rt.memory_manager.context_for_goal=lambda goal: {"private":"RESEARCH_MEMORY_SECRET"}
            rt.orchestrator.run("investiga: privacy test one")
            assert all("RESEARCH_MEMORY_SECRET" not in p for p in provider.prompts)
            provider.prompts.clear();rt.policy.set("memory.cloud",True)
            rt.orchestrator.run("investiga: privacy test two")
            assert any("RESEARCH_MEMORY_SECRET" in p for p in provider.prompts)
        finally:rt.clean_shutdown()


def test_resume_missing_pending_skill_fails_closed():
    with tempfile.TemporaryDirectory() as d:
        root=Path(d);provider=ResearchProvider();rt=_rt(root,provider)
        try:
            for cap in ("autonomy.run","skill.learn","research.web"):
                rt.policy.set(cap,True)
            provider.auto_decisions=[{"decision":"learn","goal":"create a reusable project note","use_web":False}]
            rt.orchestrator.run("autonomía: learn then wait")
            mission=rt.autonomy_store.load(rt.autonomy_store.list()[0]["id"])
            skill=rt.skill_store.get(mission.pending_skill);assert skill
            # Simulate corruption/removal before resume.
            for path in (root/"skills").glob("*.json"):path.unlink()
            resumed=rt.autonomy_engine.resume(mission.id)
            assert resumed.state.value=="failed" and "disappeared" in resumed.conclusion
        finally:rt.clean_shutdown()


def test_enabled_skill_still_cannot_bypass_revoked_underlying_permission():
    with tempfile.TemporaryDirectory() as d:
        root=Path(d);provider=ResearchProvider();rt=_rt(root,provider)
        try:
            for cap in ("autonomy.run","skill.learn","skill.execute"):
                rt.policy.set(cap,True)
            provider.auto_decisions=[{"decision":"learn","goal":"create a reusable project note","use_web":False}]
            rt.orchestrator.run("autonomía: create note eventually")
            mission=rt.autonomy_store.load(rt.autonomy_store.list()[0]["id"])
            rt.skill_store.set_status(mission.pending_skill,SkillStatus.ENABLED)
            rt.policy.set("workspace.write",False)
            provider.auto_decisions=[{"decision":"skill","skill":mission.pending_skill,"inputs":{"filename":"blocked.txt","content":"no"}}]
            resumed=rt.autonomy_engine.resume(mission.id,max_steps=1)
            assert resumed.state.value=="blocked" and not (root/"workspace"/"blocked.txt").exists()
        finally:rt.clean_shutdown()
