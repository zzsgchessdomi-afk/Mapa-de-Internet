from __future__ import annotations

import json
import ssl
import time
import urllib.error
import urllib.request
from pathlib import Path

import pytest

from jarvis_gm.mobile.actions import _mobile_command_verify
from jarvis_gm.mobile.manager import MobileManager
from jarvis_gm.mobile.models import MobileCommandKind, MobileHeartbeat
from jarvis_gm.mobile.relay import MobileRelayServer, ensure_tls_identity
from jarvis_gm.mobile.security import MemorySecretVault, ReplayGuard, command_auth_message, request_auth_message, sign_text, verify_text_signature
from jarvis_gm.mobile.store import MobileDeviceStore, MobileCommandStore
from jarvis_gm.core.permissions import PermissionPolicy


def _client_request(base: str, method: str, path: str, device_id: str, secret: str, body: dict | None = None, *, nonce: str = "0123456789abcdef"):
    raw = b"" if body is None else json.dumps(body, separators=(",", ":")).encode()
    ts = int(time.time() * 1000)
    sig = sign_text(secret, request_auth_message(method, path.split("?", 1)[0], device_id, ts, nonce, raw))
    req = urllib.request.Request(base + path, data=raw if method == "POST" else None, method=method)
    req.add_header("X-Jarvis-Device", device_id); req.add_header("X-Jarvis-Timestamp", str(ts)); req.add_header("X-Jarvis-Nonce", nonce); req.add_header("X-Jarvis-Signature", sig)
    if body is not None: req.add_header("Content-Type", "application/json")
    opener = urllib.request.build_opener(urllib.request.HTTPSHandler(context=ssl._create_unverified_context()))
    try:
        with opener.open(req, timeout=5) as res:
            return res.status, res.read().decode()
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read().decode()


def test_pairing_secret_never_written_to_registry(tmp_path: Path):
    vault = MemorySecretVault(); store = MobileDeviceStore(tmp_path / "devices.json", vault)
    _, secret = store.pair("My phone", device_id="phone-1", relay_url="https://127.0.0.1:1", cert_fingerprint="AA")
    raw = (tmp_path / "devices.json").read_text()
    assert secret not in raw
    assert store.secret("phone-1") == secret


def test_replay_guard_rejects_duplicate():
    g = ReplayGuard(max_skew_seconds=60); now = time.time(); g.check("0123456789abcdef", now, now=now)
    with pytest.raises(PermissionError): g.check("0123456789abcdef", now, now=now)


def test_signed_text_roundtrip():
    secret = "x" * 48; msg = request_auth_message("POST", "/v1/heartbeat", "d", 123, "nonce-123456789", b"{}")
    sig = sign_text(secret, msg)
    assert verify_text_signature(secret, msg, sig)
    assert not verify_text_signature(secret, msg + "x", sig)


def test_command_store_is_at_most_once_delivery(tmp_path: Path):
    store = MobileCommandStore(tmp_path / "mobile.sqlite3")
    from jarvis_gm.mobile.models import MobileCommand
    cmd = store.enqueue(MobileCommand(device_id="d", kind=MobileCommandKind.RING, expires_at=time.time()+100))
    first = store.next_for_device("d", retry_after=30); assert first and first.id == cmd.id
    assert store.next_for_device("d", retry_after=0) is None
    with store._connect() as con: con.execute("UPDATE commands SET delivered_at=? WHERE id=?", (time.time()-400, cmd.id))
    assert store.next_for_device("d", retry_after=0) is None


def test_command_completion_is_final_and_cannot_flip(tmp_path: Path):
    store = MobileCommandStore(tmp_path / "mobile.sqlite3")
    from jarvis_gm.mobile.models import MobileCommand
    cmd = store.enqueue(MobileCommand(device_id="d", kind=MobileCommandKind.LOCK, expires_at=time.time()+100))
    with pytest.raises(ValueError): store.complete(cmd.id, ok=True, result={"bad":"premature"})
    store.next_for_device("d")
    failed=store.complete(cmd.id, ok=False, error="phone denied")
    assert failed.state.value=="failed"
    unchanged=store.complete(cmd.id, ok=True, result={"late":True})
    assert unchanged.state.value=="failed" and unchanged.error=="phone denied"


def test_relay_signed_roundtrip_and_location(tmp_path: Path):
    vault=MemorySecretVault(); devices=MobileDeviceStore(tmp_path/"devices.json",vault); commands=MobileCommandStore(tmp_path/"mobile.sqlite3")
    _,secret=devices.pair("Phone",device_id="phone",relay_url="https://127.0.0.1",cert_fingerprint="pending")
    cert,key,_=ensure_tls_identity(tmp_path/"tls"); relay=MobileRelayServer(devices,commands,cert,key,host="127.0.0.1",port=0); _,port=relay.start(); base=f"https://127.0.0.1:{port}"
    try:
        hb={"device_id":"phone","timestamp":time.time(),"battery_percent":75,"charging":False,"network":"wifi","latitude":-2.17,"longitude":-79.9,"accuracy_m":7.0,"anti_theft_enabled":True,"device_locked":True}
        code,_=_client_request(base,"POST","/v1/heartbeat","phone",secret,hb); assert code==200
        assert commands.latest_heartbeat("phone").latitude == pytest.approx(-2.17)
        manager=MobileManager(devices,commands); queued=manager.queue("phone",MobileCommandKind.RING,{"seconds":5})
        code,body=_client_request(base,"GET","/v1/poll?device_id=phone","phone",secret,nonce="abcdefghijklmnop"); assert code==200
        payload=json.loads(body); sig=payload.pop("signature")
        msg=command_auth_message(payload["id"],payload["device_id"],payload["kind"],payload["expires_at_ms"],payload["payload"])
        assert verify_text_signature(secret,msg,sig)
        response={"device_id":"phone","command_id":queued.id,"ok":True,"result":{"ringing":True}}
        code,_=_client_request(base,"POST","/v1/response","phone",secret,response,nonce="qrstuvwxyzABCDEF"); assert code==200
        assert commands.get(queued.id).state.value=="verified"
    finally: relay.stop()


def test_relay_rejects_bad_signature(tmp_path: Path):
    vault=MemorySecretVault(); devices=MobileDeviceStore(tmp_path/"devices.json",vault); commands=MobileCommandStore(tmp_path/"mobile.sqlite3")
    devices.pair("Phone",device_id="phone",secret="good"*12)
    cert,key,_=ensure_tls_identity(tmp_path/"tls"); relay=MobileRelayServer(devices,commands,cert,key,host="127.0.0.1",port=0); _,port=relay.start()
    try:
        code,_=_client_request(f"https://127.0.0.1:{port}","GET","/v1/poll?device_id=phone","phone","bad"*12)
        assert code==401
    finally: relay.stop()


def test_mobile_permissions_default_deny():
    p=PermissionPolicy()
    for cap in ("mobile.read","mobile.location","mobile.control","mobile.security","mobile.messaging","mobile.contacts","mobile.relay"):
        assert not p.is_allowed(cap)


def test_mobile_command_not_claimed_complete_until_phone_confirms():
    assert _mobile_command_verify({"state":"queued"})[0] is False
    assert _mobile_command_verify({"state":"delivered"})[0] is False
    assert _mobile_command_verify({"state":"verified"})[0] is True


def test_last_location_is_device_telemetry_only(tmp_path: Path):
    m=MobileManager(MobileDeviceStore(tmp_path/"devices.json",MemorySecretVault()),MobileCommandStore(tmp_path/"mobile.sqlite3"))
    m.devices.pair("Phone",device_id="phone")
    m.commands.record_heartbeat(MobileHeartbeat("phone",time.time(),latitude=1.2,longitude=3.4,accuracy_m=5,anti_theft_enabled=True))
    loc=m.last_location("phone"); assert loc["available"] and loc["device_id"]=="phone" and "person" not in loc


def test_android_companion_has_no_accessibility_or_camera_and_no_pin_storage():
    root=Path(__file__).parents[1]/"android_companion"; manifest=(root/"app/src/main/AndroidManifest.xml").read_text()
    assert "AccessibilityService" not in manifest
    assert "android.permission.CAMERA" not in manifest
    assert 'android:usesCleartextTraffic="false"' in manifest
    source="\n".join(p.read_text() for p in (root/"app/src/main/java/com/jarvisgm/mobile").glob("*.java"))
    assert "shared_secret" in source
    assert "putString(\"pin\"" not in source.lower()
    assert "device.request_auth" in source


def test_android_antitheft_declares_background_location_and_device_admin():
    root=Path(__file__).parents[1]/"android_companion"; manifest=(root/"app/src/main/AndroidManifest.xml").read_text()
    assert "ACCESS_BACKGROUND_LOCATION" in manifest
    assert "FOREGROUND_SERVICE_LOCATION" in manifest
    assert "BIND_DEVICE_ADMIN" in manifest
    assert "JarvisDeviceAdminReceiver" in manifest
    assert "FOREGROUND_SERVICE_CONNECTED_DEVICE" in manifest
    assert 'android:foregroundServiceType="connectedDevice|location"' in manifest
    assert '<receiver android:name=".BootReceiver" android:exported="false">' in manifest


def test_unlock_language_maps_only_to_system_auth_action():
    from jarvis_gm.core.planner import Planner
    allowed={"mobile_request_auth":"mobile.security"}
    reqs=Planner().plan("desbloquea móvil phone-1",allowed)
    assert len(reqs)==1
    assert reqs[0].name=="mobile_request_auth"
    assert reqs[0].args=={"device_id":"phone-1"}
    assert "pin" not in json.dumps(reqs[0].args).lower()


def test_recovery_safe_mode_covers_mobile_and_autonomy_capabilities(tmp_path: Path):
    from jarvis_gm.product.recovery import RecoveryManager
    policy=PermissionPolicy(path=tmp_path/"permissions.json")
    risky=("autonomy.run","research.deep","memory.cloud","memory.manage","mobile.location","mobile.control","mobile.security","mobile.messaging","mobile.contacts","mobile.relay")
    for cap in risky: policy.set(cap,True)
    RecoveryManager(tmp_path).begin(policy)
    policy2=PermissionPolicy(path=tmp_path/"permissions.json")
    state=RecoveryManager(tmp_path).begin(policy2)
    assert state.safe_mode
    assert all(not policy2.is_allowed(cap) for cap in risky)


def test_heartbeat_uses_server_time_and_validates_coordinates():
    from jarvis_gm.mobile.relay import _heartbeat_from_payload
    now=time.time()
    hb=_heartbeat_from_payload("phone",{"device_id":"phone","timestamp":now+10_000_000,"latitude":-2.17,"longitude":-79.9,"accuracy_m":7,"battery_percent":80})
    assert abs(hb.timestamp-now)<2
    with pytest.raises(ValueError): _heartbeat_from_payload("phone",{"latitude":100,"longitude":0})
    with pytest.raises(ValueError): _heartbeat_from_payload("phone",{"latitude":0,"longitude":181})


def test_android_message_resolution_stays_on_phone_and_does_not_claim_send():
    root=Path(__file__).parents[1]/"android_companion/app/src/main/java/com/jarvisgm/mobile"
    source=(root/"DeviceActions.java").read_text()
    assert "resolveRecipientNumber" in source
    assert 'out.put("sent",false)' in source
    assert 'out.put("resolved_locally",resolvedLocally)' in source
    assert 'out.put("recipient_label",recipient)' in source
    assert 'out.put("recipient",recipient)' not in source


def test_single_paired_phone_can_be_resolved_without_device_id(tmp_path: Path):
    m=MobileManager(MobileDeviceStore(tmp_path/"devices.json",MemorySecretVault()),MobileCommandStore(tmp_path/"mobile.sqlite3"))
    m.devices.pair("My phone",device_id="phone")
    assert m.resolve_device_id()=="phone"
    m.devices.pair("Second",device_id="phone2")
    with pytest.raises(ValueError, match="More than one"): m.resolve_device_id()


def test_natural_phone_commands_do_not_need_id_and_unlock_is_system_auth():
    from jarvis_gm.core.planner import Planner
    allowed={"mobile_request_location":"mobile.location","mobile_ring":"mobile.control","mobile_lock":"mobile.security",
             "mobile_request_auth":"mobile.security","mobile_compose_message":"mobile.messaging"}
    p=Planner()
    assert p.plan("localiza mi celular",allowed)[0].name=="mobile_request_location"
    assert p.plan("haz sonar mi celular",allowed)[0].name=="mobile_ring"
    assert p.plan("bloquea mi celular",allowed)[0].name=="mobile_lock"
    unlock=p.plan("desbloquea mi celular",allowed)[0]
    assert unlock.name=="mobile_request_auth" and not unlock.args
    msg=p.plan("manda WhatsApp a mamá: llego a las siete",allowed)[0]
    assert msg.name=="mobile_compose_message" and msg.args["recipient"]=="mamá" and "device_id" not in msg.args


def test_android_pairing_parser_rejects_weak_relay_shape_by_contract():
    source=(Path(__file__).parents[1]/"android_companion/app/src/main/java/com/jarvisgm/mobile/PairingConfig.java").read_text()
    assert '"https".equalsIgnoreCase(relayUri.getScheme())' in source
    assert 'relayUri.getUserInfo()!=null' in source
    assert 'fpHex.matches("[0-9A-Fa-f]{64}")' in source
    assert 'secret.matches("[A-Za-z0-9_-]{40,128}")' in source


def test_android_boot_restart_degrades_without_background_location_instead_of_dropping_bridge():
    root=Path(__file__).parents[1]/"android_companion/app/src/main/java/com/jarvisgm/mobile"
    relay=(root/"RelayService.java").read_text(); boot=(root/"BootReceiver.java").read_text()
    assert "EXTRA_FROM_BOOT" in relay and "EXTRA_FROM_BOOT" in boot
    assert "!fromBoot||hasBackground" in relay
    assert "FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE" in relay
