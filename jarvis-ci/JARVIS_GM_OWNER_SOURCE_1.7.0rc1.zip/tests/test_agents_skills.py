from __future__ import annotations

from pathlib import Path
import json
import tempfile

import pytest

from jarvis_gm.agents.director import AgentDirector
from jarvis_gm.control.simulated_backend import SimulatedDesktopBackend
from jarvis_gm.core.models import GoalState
from jarvis_gm.runtime import build_phase7_runtime
from jarvis_gm.skills.compiler import SkillCompiler
from jarvis_gm.skills.models import SkillDefinition, SkillStatus, SkillStep
from jarvis_gm.skills.store import SkillStore


class FakeProvider:
    available = True
    def __init__(self):
        self.calls=[]
        self.search_calls=[]
    def generate(self, prompt: str, *, system: str | None = None) -> str:
        self.calls.append((prompt,system))
        if prompt.startswith("Decompose the user's mission"):
            return json.dumps({"tasks":[
                {"id":"t1","role":"planner","objective":"make plan","depends_on":[],"web_research":False},
                {"id":"t2","role":"reviewer","objective":"review plan","depends_on":["t1"],"web_research":False},
            ]})
        if "Design ONE reusable JARVIS skill" in prompt:
            return json.dumps({
                "name":"Create Project Note","description":"Create a reusable note in the JARVIS workspace",
                "inputs":{"filename":{"type":"string","description":"note filename"},"content":{"type":"string","description":"note body"}},
                "steps":[{"action":"create_note","args":{"filename":"{{filename}}","content":"{{content}}"},"description":"write the note"}],
                "confidence":0.93,
            })
        if prompt.startswith("Synthesize the mission work"):
            return "Final synthesis"
        return "Specialist work product"
    def grounded_search(self, prompt: str) -> dict:
        self.search_calls.append(prompt)
        return {"text":"Official procedure evidence","queries":["official procedure"],"citations":[{"title":"Official Docs","url":"https://example.com/docs"}]}


class WebMissionProvider(FakeProvider):
    def generate(self, prompt: str, *, system: str | None = None) -> str:
        self.calls.append((prompt,system))
        if prompt.startswith("Decompose the user's mission"):
            return json.dumps({"tasks":[
                {"id":"t1","role":"researcher","objective":"research current docs","depends_on":[],"web_research":True},
                {"id":"t2","role":"reviewer","objective":"review evidence","depends_on":["t1"],"web_research":False},
            ]})
        if prompt.startswith("Synthesize the mission work"):
            return "Grounded final"
        return "Review complete"


def _runtime(root: Path, provider=None):
    backend=SimulatedDesktopBackend(); rt=build_phase7_runtime(root,backend)
    if provider is not None:
        rt.providers.register("fake",provider); rt.providers.set_active("fake")
    return rt,backend


def test_phase7_sensitive_capabilities_default_off():
    with tempfile.TemporaryDirectory() as d:
        rt,_=_runtime(Path(d))
        for cap in ("agent.run","research.web","skill.learn","skill.manage","skill.execute"):
            assert rt.policy.is_allowed(cap) is False


def test_status_reports_phase7():
    with tempfile.TemporaryDirectory() as d:
        rt,_=_runtime(Path(d))
        g=rt.orchestrator.run("estado")
        assert g.state==GoalState.VERIFIED and g.results[0].output["phase"]==7


def test_skill_store_versions_content_revisions():
    with tempfile.TemporaryDirectory() as d:
        store=SkillStore(Path(d)/"skills")
        a=store.save(SkillDefinition("Demo","one",steps=[SkillStep("status")]))
        b=store.save(SkillDefinition("Demo","two",steps=[SkillStep("status")]))
        assert a.version==1 and b.version==2 and store.get("Demo").description=="two"


def test_skill_compiler_rejects_unknown_and_meta_actions():
    with tempfile.TemporaryDirectory() as d:
        rt,_=_runtime(Path(d)); c=SkillCompiler(rt.orchestrator.executor.actions)
        unknown=c.validate(SkillDefinition("Bad","",steps=[SkillStep("totally_fake")]))
        recursive=c.validate(SkillDefinition("Loop","",steps=[SkillStep("run_skill",{"name":"Loop"})]))
        assert not unknown.ok and "unknown action" in unknown.errors[0]
        assert not recursive.ok and "forbidden" in recursive.errors[0]


def test_skill_compiler_checks_action_signature_and_inputs():
    with tempfile.TemporaryDirectory() as d:
        rt,_=_runtime(Path(d)); c=SkillCompiler(rt.orchestrator.executor.actions)
        bad=c.validate(SkillDefinition("BadArgs","",steps=[SkillStep("move_cursor",{"x":1})]))
        undeclared=c.validate(SkillDefinition("BadTemplate","",steps=[SkillStep("create_note",{"filename":"{{name}}","content":"x"})]))
        assert not bad.ok and any("missing required args" in x for x in bad.errors)
        assert not undeclared.ok and any("undeclared input" in x for x in undeclared.errors)


def test_learning_requires_explicit_permission_and_never_auto_enables():
    with tempfile.TemporaryDirectory() as d:
        provider=FakeProvider(); rt,_=_runtime(Path(d),provider)
        blocked=rt.orchestrator.run("aprende: crear una nota reusable")
        assert blocked.state==GoalState.BLOCKED and rt.skill_store.list()==[]
        rt.policy.set("skill.learn",True)
        learned=rt.orchestrator.run("aprende: crear una nota reusable")
        assert learned.state==GoalState.VERIFIED
        skill=rt.skill_store.get("Create Project Note")
        assert skill and skill.status==SkillStatus.VALIDATED and skill.required_capabilities==("workspace.write",)


def test_web_learning_requires_separate_research_permission():
    with tempfile.TemporaryDirectory() as d:
        provider=FakeProvider(); rt,_=_runtime(Path(d),provider); rt.policy.set("skill.learn",True)
        blocked=rt.orchestrator.run("aprende web: crear una nota reusable")
        assert blocked.state!=GoalState.VERIFIED and not provider.search_calls
        rt.policy.set("research.web",True)
        learned=rt.orchestrator.run("aprende web: crear una nota reusable")
        assert learned.state==GoalState.VERIFIED and provider.search_calls
        skill=rt.skill_store.get("Create Project Note")
        assert skill and skill.source_urls==("https://example.com/docs",)


def test_enable_skill_action_requires_management_permission():
    with tempfile.TemporaryDirectory() as d:
        provider=FakeProvider(); rt,_=_runtime(Path(d),provider); rt.policy.set("skill.learn",True)
        assert rt.orchestrator.run("aprende: crear nota").state==GoalState.VERIFIED
        blocked=rt.orchestrator.run("habilita skill Create Project Note")
        assert blocked.state==GoalState.BLOCKED
        rt.policy.set("skill.manage",True)
        ok=rt.orchestrator.run("habilita skill Create Project Note")
        assert ok.state==GoalState.VERIFIED and rt.skill_store.get("Create Project Note").status==SkillStatus.ENABLED


def test_running_skill_requires_execute_permission_and_underlying_capability():
    with tempfile.TemporaryDirectory() as d:
        root=Path(d); rt,_=_runtime(root)
        skill=SkillDefinition("Writer","write",inputs={"filename":{"type":"string"},"content":{"type":"string"}},
                              steps=[SkillStep("create_note",{"filename":"{{filename}}","content":"{{content}}"})],
                              required_capabilities=("workspace.write",),status=SkillStatus.ENABLED)
        rt.skill_store.save(skill)
        blocked=rt.orchestrator.run('ejecuta skill Writer: {"filename":"a.txt","content":"hello"}')
        assert blocked.state==GoalState.BLOCKED
        rt.policy.set("skill.execute",True); rt.policy.set("workspace.write",False)
        blocked2=rt.orchestrator.run('ejecuta skill Writer: {"filename":"a.txt","content":"hello"}')
        assert blocked2.state!=GoalState.VERIFIED and not (root/"workspace"/"a.txt").exists()
        rt.policy.set("workspace.write",True)
        ok=rt.orchestrator.run('ejecuta skill Writer: {"filename":"a.txt","content":"hello"}')
        assert ok.state==GoalState.VERIFIED and (root/"workspace"/"a.txt").read_text()=="hello"


def test_skill_input_types_are_enforced():
    with tempfile.TemporaryDirectory() as d:
        rt,_=_runtime(Path(d)); skill=SkillDefinition("Typed","",inputs={"name":{"type":"string"}},steps=[SkillStep("create_note",{"filename":"{{name}}","content":"x"})],status=SkillStatus.ENABLED)
        rt.skill_store.save(skill); rt.policy.set("skill.execute",True)
        g=rt.orchestrator.run('ejecuta skill Typed: {"name": 42}')
        assert g.state!=GoalState.VERIFIED


def test_agent_director_requires_explicit_permission():
    with tempfile.TemporaryDirectory() as d:
        provider=FakeProvider(); rt,_=_runtime(Path(d),provider)
        g=rt.orchestrator.run("misión: organizar este proyecto")
        assert g.state==GoalState.BLOCKED and not list((Path(d)/"mission_runs").glob("*.json"))


def test_agent_mission_runs_bounded_specialists_without_touching_desktop():
    with tempfile.TemporaryDirectory() as d:
        provider=FakeProvider(); rt,backend=_runtime(Path(d),provider); rt.policy.set("agent.run",True)
        before=(list(backend.hotkeys),list(backend.opened_apps),list(backend.opened_urls),backend.cursor)
        g=rt.orchestrator.run("misión: organizar este proyecto")
        after=(list(backend.hotkeys),list(backend.opened_apps),list(backend.opened_urls),backend.cursor)
        assert g.state==GoalState.VERIFIED and before==after
        logs=list((Path(d)/"mission_runs").glob("mission_*.json")); assert len(logs)==1
        saved=json.loads(logs[0].read_text()); assert saved["state"]=="verified" and len(saved["tasks"])>=2


def test_web_mission_requires_research_permission_and_then_keeps_citations():
    with tempfile.TemporaryDirectory() as d:
        provider=WebMissionProvider(); rt,_=_runtime(Path(d),provider); rt.policy.set("agent.run",True)
        blocked=rt.orchestrator.run("misión web: revisa documentación actual")
        assert blocked.state==GoalState.BLOCKED and not provider.search_calls
        rt.policy.set("research.web",True)
        ok=rt.orchestrator.run("misión web: revisa documentación actual")
        assert ok.state==GoalState.VERIFIED and provider.search_calls
        logs=sorted((Path(d)/"mission_runs").glob("mission_*.json"),key=lambda p:p.stat().st_mtime)
        saved=json.loads(logs[-1].read_text()); researcher=next(x for x in saved["results"] if x["role"]=="researcher")
        assert researcher["citations"][0]["url"]=="https://example.com/docs"


def test_director_rejects_future_dependency_graph():
    class BadProvider(FakeProvider):
        def generate(self,prompt,*,system=None):
            if prompt.startswith("Decompose the user's mission"):
                return json.dumps({"tasks":[{"id":"t1","role":"planner","objective":"x","depends_on":["t2"]},{"id":"t2","role":"reviewer","objective":"y","depends_on":[]}]})
            return "x"
    with tempfile.TemporaryDirectory() as d:
        director=AgentDirector(lambda:BadProvider(),Path(d)/"runs",web_allowed=lambda:False)
        with pytest.raises(RuntimeError,match="future/unknown"):
            director.plan("bad graph")


def test_list_skills_is_safe_read_even_when_autonomy_off():
    with tempfile.TemporaryDirectory() as d:
        rt,_=_runtime(Path(d)); rt.skill_store.save(SkillDefinition("ReadOnly","",steps=[SkillStep("status")],status=SkillStatus.VALIDATED))
        g=rt.orchestrator.run("skills")
        assert g.state==GoalState.VERIFIED and g.results[0].output[0]["name"]=="ReadOnly"


def test_skill_cannot_escalate_by_forging_stored_capability_list():
    with tempfile.TemporaryDirectory() as d:
        rt,_=_runtime(Path(d)); skill=SkillDefinition("Forged","",steps=[SkillStep("open_app",{"app":"notepad"})],required_capabilities=("safe.read",),status=SkillStatus.ENABLED)
        rt.skill_store.save(skill); rt.policy.set("skill.execute",True)
        # Live compiler derives app.launch from the registered action and the nested executor enforces it.
        g=rt.orchestrator.run("ejecuta skill Forged")
        assert g.state!=GoalState.VERIFIED
        validation=rt.skill_forge.validate_existing("Forged")
        assert validation.ok and validation.required_capabilities==("app.launch",) and validation.warnings


def test_kill_switch_blocks_skill_before_any_nested_step():
    with tempfile.TemporaryDirectory() as d:
        root=Path(d); rt,_=_runtime(root); rt.skill_store.save(SkillDefinition("Writer","",steps=[SkillStep("create_note",{"filename":"x.txt","content":"x"})],status=SkillStatus.ENABLED))
        rt.policy.set("skill.execute",True); rt.kill_switch.engage()
        g=rt.orchestrator.run("ejecuta skill Writer")
        assert g.state!=GoalState.VERIFIED and not (root/"workspace"/"x.txt").exists()
