from __future__ import annotations

from pathlib import Path

from jarvis_gm.aios.models import ResourceKind
from jarvis_gm.control.simulated_backend import SimulatedDesktopBackend
from jarvis_gm.core.models import ActionRequest
from jarvis_gm.runtime import build_infinity2_runtime


def build(tmp_path: Path):
    return build_infinity2_runtime(tmp_path, SimulatedDesktopBackend())


def action_req(rt, name, **args):
    action=rt.orchestrator.executor.actions[name]
    return ActionRequest(name,args,action.capability)


def test_resource_namespace_has_pc_apps_and_projects(tmp_path):
    rt=build(tmp_path)
    rt.memory_manager.create_project("Atlas")
    rows=rt.personal_os.resources()
    kinds={r["kind"] for r in rows}
    assert "device" in kinds and "app" in kinds and "project" in kinds
    assert rt.personal_os.resolve("pc").kind == ResourceKind.DEVICE
    rt.clean_shutdown()


def test_os_routes_are_denied_by_default(tmp_path):
    rt=build(tmp_path); rt.policy.set("os.manage",True)
    url=rt.personal_os.register_url("https://example.com",alias="example")
    result=rt.orchestrator.executor.execute(action_req(rt,"os_execute",operation="open",resource=url.id,destination="pc"))
    assert not result.ok and result.blocked
    rt.clean_shutdown()


def test_os_plan_is_read_only_and_does_not_open(tmp_path):
    rt=build(tmp_path); backend=rt.backend; rt.policy.set("os.manage",True)
    url=rt.personal_os.register_url("https://example.com",alias="example")
    result=rt.orchestrator.executor.execute(action_req(rt,"os_plan",operation="open",resource=url.id,destination="pc"))
    assert result.ok and result.output["action"] == "open_url"
    assert backend.opened_urls == []
    rt.clean_shutdown()


def test_os_execute_rechecks_underlying_permission(tmp_path):
    rt=build(tmp_path)
    rt.policy.set("os.route",True); rt.policy.set("os.manage",True)
    url=rt.personal_os.register_url("https://example.com",alias="example")
    # browser.open stays false: nested Executor must block.
    out=rt.personal_os.execute("open",resource_ref=url.id,destination_ref="pc")
    assert not out["verified"] and out["result"]["blocked"]
    rt.clean_shutdown()


def test_local_url_open_is_verified_when_both_permissions_enabled(tmp_path):
    rt=build(tmp_path); rt.policy.set("os.route",True); rt.policy.set("browser.open",True); rt.policy.set("os.manage",True)
    url=rt.personal_os.register_url("https://example.com",alias="example")
    out=rt.personal_os.execute("open",resource_ref="example",destination_ref="pc")
    assert out["verified"] and rt.backend.opened_urls == ["https://example.com"]
    rt.clean_shutdown()


def test_file_resource_must_be_inside_authorized_scope(tmp_path):
    rt=build(tmp_path); rt.policy.set("os.manage",True)
    outside=tmp_path.parent / "outside_personal_os.txt"; outside.write_text("x")
    try:
        rt.personal_os.register_file(str(outside))
        assert False, "outside file should have been rejected"
    except PermissionError:
        pass
    finally:
        outside.unlink(missing_ok=True); rt.clean_shutdown()


def test_mobile_handoff_requires_os_handoff_and_guardian_lease(tmp_path):
    rt=build(tmp_path); rt.policy.set("os.manage",True)
    rt.mobile.manager.devices.pair("My phone",device_id="phone-1")
    rt.policy.set("mobile.read",True); rt.personal_os.sync()
    rt.policy.set("os.route",True); rt.policy.set("mobile.control",True)
    url=rt.personal_os.register_url("https://example.com",alias="example")
    # os.handoff is a separate owner boundary.
    try:
        rt.personal_os.execute("handoff",resource_ref=url.id,destination_ref="mi celular")
        assert False, "handoff permission should be required"
    except PermissionError:
        pass
    rt.policy.set("os.handoff",True)
    # os_execute is high risk for a cross-device handoff, so outer Guardian blocks without owner lease.
    result=rt.orchestrator.executor.execute(action_req(rt,"os_execute",operation="handoff",resource=url.id,destination="mi celular"))
    assert not result.ok and result.blocked and "lease" in (result.error or "").lower()
    rt.clean_shutdown()


def test_unsupported_file_to_mobile_handoff_fails_closed(tmp_path):
    rt=build(tmp_path); rt.mobile.manager.devices.pair("Phone",device_id="phone-1"); rt.policy.set("mobile.read",True); rt.policy.set("os.manage",True); rt.personal_os.sync()
    rt.policy.set("filesystem.read",True)
    file=(tmp_path/"workspace"/"report.txt"); file.parent.mkdir(exist_ok=True); file.write_text("hello")
    res=rt.personal_os.register_file(str(file),alias="report")
    plan=rt.personal_os.plan("handoff",resource_ref=res.id,destination_ref="mi celular")
    assert not plan.supported and "cannot be transferred" in plan.reason
    rt.clean_shutdown()


def test_contact_resource_contains_label_not_phone_number(tmp_path):
    rt=build(tmp_path); rt.mobile.manager.devices.pair("Phone",device_id="phone-1"); rt.policy.set("mobile.read",True); rt.policy.set("os.manage",True); rt.personal_os.sync()
    contact=rt.personal_os.register_contact("Mamá",alias="mama")
    assert contact.locator == {"query":"Mamá"}
    assert "phone" not in contact.locator and "number" not in contact.locator
    rt.clean_shutdown()


def test_ambiguous_device_alias_is_not_guessed(tmp_path):
    rt=build(tmp_path); rt.mobile.manager.devices.pair("Phone A",device_id="a"); rt.mobile.manager.devices.pair("Phone B",device_id="b")
    rt.policy.set("mobile.read",True); rt.personal_os.sync()
    try:
        rt.personal_os.resolve("mi celular")
        assert False, "two phones must not get a guessed alias"
    except KeyError:
        pass
    rt.clean_shutdown()


def test_project_resume_routes_through_memory_permission(tmp_path):
    rt=build(tmp_path); rt.memory_manager.create_project("One"); rt.memory_manager.create_project("Two")
    rt.policy.set("os.route",True); rt.policy.set("memory.write",False); rt.personal_os.sync()
    project=[x for x in rt.personal_os.store.list(kind=ResourceKind.PROJECT) if x.label=="One"][0]
    out=rt.personal_os.execute("resume",resource_ref=project.id)
    assert not out["verified"] and out["result"]["blocked"]
    rt.clean_shutdown()


def test_guardian_classifies_cross_device_os_execute_high(tmp_path):
    rt=build(tmp_path)
    req=action_req(rt,"os_execute",operation="handoff",resource="x",destination="y")
    assert rt.guardian.classify(req).name == "HIGH"
    rt.clean_shutdown()


def test_handoff_ledger_is_not_created_for_unsupported_route(tmp_path):
    rt=build(tmp_path); rt.mobile.manager.devices.pair("Phone",device_id="phone-1"); rt.policy.set("mobile.read",True); rt.policy.set("os.manage",True); rt.personal_os.sync()
    rt.policy.set("filesystem.read",True); p=tmp_path/"workspace"/"x.txt"; p.parent.mkdir(exist_ok=True); p.write_text("x")
    r=rt.personal_os.register_file(str(p))
    try: rt.personal_os.execute("handoff",resource_ref=r.id,destination_ref="mi celular")
    except (ValueError,PermissionError): pass
    assert rt.personal_os.store.handoffs() == []
    rt.clean_shutdown()


def test_world_model_receives_resource_entities_only_when_world_write_on(tmp_path):
    rt=build(tmp_path); rt.personal_os.sync()
    assert any(x["kind"]=="resource" for x in rt.world_model.store.entities(kinds=("resource",),limit=200))
    rt.policy.set("world.write",False)
    before=len(rt.world_model.store.recent_observations(limit=100))
    rt.personal_os.sync()
    after=len(rt.world_model.store.recent_observations(limit=100))
    assert after == before
    rt.clean_shutdown()


def test_safe_mode_revokes_personal_os_authority(tmp_path):
    rt=build(tmp_path); rt.policy.set("os.route",True); rt.policy.set("os.handoff",True); rt.policy.set("os.manage",True)
    # Simulate unclean close: release process lock only, do not mark recovery clean.
    rt.instance_lock.release()
    rt2=build(tmp_path)
    assert rt2.recovery_state.safe_mode
    assert not rt2.policy.is_allowed("os.route") and not rt2.policy.is_allowed("os.handoff") and not rt2.policy.is_allowed("os.manage")
    rt2.clean_shutdown()


def test_direct_kernel_cross_device_call_still_hits_guardian(tmp_path):
    rt=build(tmp_path); rt.policy.set("os.manage",True); rt.policy.set("os.route",True); rt.policy.set("os.handoff",True); rt.policy.set("mobile.control",True)
    rt.mobile.manager.devices.pair("Phone",device_id="phone-1"); rt.policy.set("mobile.read",True); rt.personal_os.sync()
    url=rt.personal_os.register_url("https://example.com",alias="example")
    out=rt.personal_os.execute("handoff",resource_ref=url.id,destination_ref="mi celular")
    assert not out["verified"] and out["result"]["blocked"] and "lease" in out["verification"].lower()
    rt.clean_shutdown()


def test_os_cloud_is_separate_and_redacts_contact_and_paths(tmp_path):
    rt=build(tmp_path); rt.policy.set("os.manage",True); rt.policy.set("filesystem.read",True)
    rt.memory_manager.create_project("Secret Project")
    p=tmp_path/"workspace"/"secret-name.txt"; p.parent.mkdir(exist_ok=True); p.write_text("x")
    rt.personal_os.register_file(str(p),alias="secret-file")
    rt.mobile.manager.devices.pair("Phone",device_id="phone-1"); rt.policy.set("mobile.read",True); rt.personal_os.sync()
    rt.personal_os.register_contact("Mamá",alias="mama")
    assert rt.personal_os.cloud_context() is None
    rt.policy.set("os.cloud",True)
    ctx=rt.personal_os.cloud_context(); blob=str(ctx)
    assert "Mamá" not in blob and str(p) not in blob and "Secret Project" not in blob
    rt.policy.set("memory.cloud",True)
    ctx2=rt.personal_os.cloud_context(); assert "Secret Project" in str(ctx2) and "Mamá" not in str(ctx2)
    rt.clean_shutdown()


def test_os_manage_action_denied_by_default(tmp_path):
    rt=build(tmp_path)
    result=rt.orchestrator.executor.execute(action_req(rt,"os_pin_url",url="https://example.com",alias="x"))
    assert not result.ok and result.blocked
    rt.clean_shutdown()


def test_mobile_resource_becomes_unresolvable_after_device_removed(tmp_path):
    rt=build(tmp_path); rt.mobile.manager.devices.pair("Phone",device_id="phone-1"); rt.policy.set("mobile.read",True); rt.personal_os.sync()
    assert rt.personal_os.resolve("mi celular").kind == ResourceKind.DEVICE
    rt.mobile.manager.devices.forget("phone-1"); rt.personal_os.sync()
    try:
        rt.personal_os.resolve("mi celular")
        assert False, "stale phone alias must not resolve"
    except KeyError:
        pass
    rt.clean_shutdown()


def test_handoff_terminal_state_is_immutable(tmp_path):
    rt=build(tmp_path)
    a=rt.personal_os.store.upsert(kind=ResourceKind.URL,key="https://example.com",label="x",locator={"url":"https://example.com"})
    d=rt.personal_os.store.upsert(kind=ResourceKind.DEVICE,key="d",label="d",locator={"platform":"android"})
    h=rt.personal_os.store.create_handoff(a.id,d.id,"handoff")
    rt.personal_os.store.update_handoff(h.id,state="failed",error="first")
    rt.personal_os.store.update_handoff(h.id,state="verified",verification="late")
    row=rt.personal_os.store.handoffs(1)[0]
    assert row["state"] == "failed" and row["error"] == "first" and row["verification"] is None
    rt.clean_shutdown()


def test_backup_restore_preserves_personal_os_registry(tmp_path):
    from jarvis_gm.product.backup import BackupManager
    rt=build(tmp_path); rt.policy.set("os.manage",True)
    r=rt.personal_os.register_url("https://example.com",alias="kept")
    backup=tmp_path/"os.jarvisbackup"; rt.backup.create(backup); rt.clean_shutdown()
    assert BackupManager.validate(backup).ok
    (tmp_path/"personal_os.sqlite3").unlink()
    BackupManager(tmp_path,product_version="1.2.0a2").stage_restore(backup)
    rt2=build(tmp_path)
    assert rt2.personal_os.resolve("kept").id == r.id
    rt2.clean_shutdown()


def test_safe_mode_revokes_os_cloud_too(tmp_path):
    rt=build(tmp_path); rt.policy.set("os.cloud",True); rt.instance_lock.release()
    rt2=build(tmp_path)
    assert rt2.recovery_state.safe_mode and not rt2.policy.is_allowed("os.cloud")
    rt2.clean_shutdown()


def test_user_resource_cannot_shadow_reserved_device_alias(tmp_path):
    rt=build(tmp_path); rt.policy.set("os.manage",True)
    try:
        rt.personal_os.register_url("https://example.com",alias="pc")
        assert False, "system device alias must be reserved"
    except ValueError as exc:
        assert "reserved" in str(exc).lower()
    assert rt.personal_os.resolve("pc").kind == ResourceKind.DEVICE
    rt.clean_shutdown()


def test_diagnostics_reports_personal_os_without_claiming_hardware(tmp_path):
    rt=build(tmp_path)
    report=rt.diagnostics.run(rt)
    assert report["version"] == "1.2.0a2"
    assert report["storage"]["personal_os_sqlite"]["status"] == "ok"
    assert report["personal_os"]["resources"] >= 1
    assert report["hardware_acceptance"]["status"] == "pending_physical_windows_test"
    rt.clean_shutdown()
