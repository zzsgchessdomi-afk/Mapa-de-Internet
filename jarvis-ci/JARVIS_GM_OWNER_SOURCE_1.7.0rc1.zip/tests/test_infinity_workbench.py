from __future__ import annotations

import json
from pathlib import Path
import pytest

from jarvis_gm.autonomy.models import AutonomousMission, AutonomyState, MissionStep, StepState
from jarvis_gm.autonomy.store import MissionStore
from jarvis_gm.control.simulated_backend import SimulatedDesktopBackend
from jarvis_gm.core.models import ActionRequest
from jarvis_gm.runtime import build_infinity3_runtime
from jarvis_gm.workbench.engine import AutonomousWorkbench
from jarvis_gm.workbench.models import WorkState
from jarvis_gm.workbench.store import WorkbenchStore


class FakeAutonomy:
    def __init__(self, root: Path):
        self.store=MissionStore(root/'missions'); self.calls=[]
    def run(self,goal,*,success_criteria=(),max_steps=None,existing=None,pause_on_budget=False):
        m=existing or AutonomousMission(goal=goal,success_criteria=tuple(success_criteria))
        self.calls.append((goal,max_steps,m.id))
        if not m.steps:
            m.steps.append(MissionStep(1,'status',{},'safe.read',state=StepState.VERIFIED,verification='ok'))
            m.state=AutonomyState.PAUSED if pause_on_budget else AutonomyState.FAILED
            m.conclusion='checkpoint'
        else:
            m.steps.append(MissionStep(2,'status',{},'safe.read',state=StepState.VERIFIED,verification='ok'))
            m.state=AutonomyState.VERIFIED; m.conclusion='done'
        self.store.save(m); return m


def unit_wb(tmp_path: Path):
    return AutonomousWorkbench(WorkbenchStore(tmp_path/'work.sqlite3'),FakeAutonomy(tmp_path),kill_switch=type('K',(),{'check':lambda self:None})(),run_allowed=lambda:True,manage_allowed=lambda:True)


def test_workbench_defaults_are_owner_controlled(tmp_path):
    rt=build_infinity3_runtime(tmp_path,SimulatedDesktopBackend())
    assert rt.policy.is_allowed('workbench.read')
    assert not rt.policy.is_allowed('workbench.run')
    assert not rt.policy.is_allowed('workbench.manage')
    assert not rt.policy.is_allowed('workbench.cloud')
    rt.clean_shutdown()


def test_create_requires_guardian_owner_lease_in_runtime(tmp_path):
    rt=build_infinity3_runtime(tmp_path,SimulatedDesktopBackend());rt.policy.set('workbench.manage',True)
    with pytest.raises(PermissionError,match='owner lease'):
        rt.workbench.create('compile report')
    rt.guardian.grant_action('workbench_manage',ttl_s=60,uses=1)
    item=rt.workbench.create('compile report')
    assert item.state==WorkState.QUEUED
    rt.clean_shutdown()


def test_run_requires_both_workbench_and_autonomy_permission(tmp_path):
    rt=build_infinity3_runtime(tmp_path,SimulatedDesktopBackend());rt.policy.set('workbench.run',True)
    rt.guardian.grant_action('workbench_run',ttl_s=60,uses=1)
    with pytest.raises(PermissionError,match='workbench.run'):
        rt.workbench.run_cycle()
    rt.clean_shutdown()


def test_cooperative_checkpoint_then_completion(tmp_path):
    wb=unit_wb(tmp_path); item=wb.create('two cycle job',step_budget=5,quantum=1)
    first=wb.run_cycle(max_jobs=1)[0]
    assert first.state==WorkState.RUNNABLE and first.steps_used==1 and first.checkpoint_seq==1
    second=wb.run_cycle(max_jobs=1)[0]
    assert second.state==WorkState.VERIFIED and second.steps_used==2 and second.checkpoint_seq==2
    cps=wb.store.checkpoints(item.id)
    assert len(cps)==2 and cps[0]['seq']==2 and cps[1]['seq']==1


def test_dependency_waits_for_verified_parent(tmp_path):
    wb=unit_wb(tmp_path); parent=wb.create('parent',priority=20); child=wb.create('child',dependencies=(parent.id,),priority=100)
    rows=wb.run_cycle(max_jobs=5)
    assert [x.id for x in rows]==[parent.id]
    assert wb.store.get(child.id).state==WorkState.QUEUED
    wb.run_cycle(max_jobs=5) # parent verifies
    rows=wb.run_cycle(max_jobs=5)
    assert rows and rows[0].id==child.id


def test_failed_dependency_blocks_dependent(tmp_path):
    wb=unit_wb(tmp_path); parent=wb.create('parent'); child=wb.create('child',dependencies=(parent.id,))
    p=wb.store.get(parent.id);p.state=WorkState.FAILED;p.conclusion='boom';wb.store.save(p)
    assert wb.run_cycle(max_jobs=5)==[]
    c=wb.store.get(child.id)
    assert c.state==WorkState.BLOCKED and 'dependency_failed' in c.blocked_reason


def test_unknown_dependency_is_rejected(tmp_path):
    wb=unit_wb(tmp_path)
    with pytest.raises(ValueError,match='Unknown dependency'):
        wb.create('bad',dependencies=('work_missing',))


def test_owner_pause_resume_cancel(tmp_path):
    wb=unit_wb(tmp_path); item=wb.create('job')
    assert wb.pause(item.id).state==WorkState.PAUSED
    assert wb.run_cycle()==[]
    assert wb.resume(item.id).state==WorkState.QUEUED
    assert wb.cancel(item.id).state==WorkState.CANCELLED
    assert wb.resume(item.id).state==WorkState.CANCELLED


def test_terminal_state_is_immutable_in_store(tmp_path):
    store=WorkbenchStore(tmp_path/'w.sqlite3');item=__import__('jarvis_gm.workbench.models',fromlist=['WorkItem']).WorkItem('x')
    item.state=WorkState.VERIFIED;store.save(item);item.state=WorkState.FAILED
    with pytest.raises(RuntimeError,match='Terminal work item is immutable'):
        store.save(item)


def test_step_budget_fails_closed(tmp_path):
    wb=unit_wb(tmp_path);item=wb.create('budget',step_budget=1,quantum=1)
    one=wb.run_cycle()[0];assert one.state==WorkState.RUNNABLE and one.steps_used==1
    two=wb.run_cycle()[0];assert two.state==WorkState.FAILED and 'budget exhausted' in two.conclusion.lower()


def test_personal_os_exposes_work_item_without_cloud_leak_by_default(tmp_path):
    rt=build_infinity3_runtime(tmp_path,SimulatedDesktopBackend());rt.policy.set('workbench.manage',True);rt.guardian.grant_action('workbench_manage',uses=1)
    item=rt.workbench.create('SECRET WORK GOAL')
    rt.personal_os.sync(); rows=rt.personal_os.resources(kind='work')
    assert any(x['locator']['work_id']==item.id for x in rows)
    rt.policy.set('os.cloud',True)
    assert 'SECRET WORK GOAL' not in str(rt.personal_os.cloud_context())
    rt.policy.set('workbench.cloud',True)
    assert 'SECRET WORK GOAL' in str(rt.personal_os.cloud_context())
    rt.clean_shutdown()


def test_workbench_actions_still_pass_executor_and_guardian(tmp_path):
    rt=build_infinity3_runtime(tmp_path,SimulatedDesktopBackend());rt.policy.set('workbench.manage',True)
    req=ActionRequest('workbench_create',{'goal':'action job'},'workbench.manage')
    blocked=rt.orchestrator.executor.execute(req)
    assert blocked.blocked and 'owner lease' in (blocked.error or '').lower()
    rt.guardian.grant_action('workbench_manage',uses=1)
    ok=rt.orchestrator.executor.execute(req)
    assert ok.ok and ok.output['goal']=='action job'
    rt.clean_shutdown()


class SeqProvider:
    available=True
    def __init__(self): self.n=0
    def generate(self,prompt,*,system=None):
        if 'CLOSED-LOOP desktop mission' not in prompt:return '{}'
        self.n+=1
        if self.n==1:return json.dumps({'decision':'act','action':'create_note','args':{'filename':'wb.txt','content':'ok'},'expected_effect':'note exists'})
        return json.dumps({'decision':'done','evidence':['step:1'],'reason':'verified'})


def test_runtime_workbench_executes_real_autopilot_with_verified_result(tmp_path):
    rt=build_infinity3_runtime(tmp_path,SimulatedDesktopBackend());p=SeqProvider();rt.providers.register('wb',p);rt.providers.set_active('wb')
    rt.policy.set('workbench.manage',True);rt.policy.set('workbench.run',True);rt.policy.set('autonomy.run',True)
    rt.guardian.grant_action('workbench_manage',uses=1);item=rt.workbench.create('create verified note',quantum=3)
    rt.guardian.grant_action('workbench_run',uses=1);out=rt.workbench.run_cycle(max_jobs=1)[0]
    assert out.state==WorkState.VERIFIED and (tmp_path/'workspace'/'wb.txt').read_text()=='ok'
    assert out.mission_id and rt.autonomy_store.load(out.mission_id).state==AutonomyState.VERIFIED
    rt.clean_shutdown()


def test_stop_blocks_workbench_before_scheduler_runs(tmp_path):
    rt=build_infinity3_runtime(tmp_path,SimulatedDesktopBackend());rt.policy.set('workbench.run',True);rt.policy.set('autonomy.run',True)
    rt.guardian.grant_action('workbench_run',uses=1);rt.kill_switch.engage()
    with pytest.raises(Exception): rt.workbench.run_cycle()
    rt.kill_switch.reset();rt.clean_shutdown()


def test_backup_contains_workbench_database(tmp_path):
    import zipfile
    rt=build_infinity3_runtime(tmp_path/'data',SimulatedDesktopBackend());rt.policy.set('workbench.manage',True);rt.guardian.grant_action('workbench_manage',uses=1);rt.workbench.create('backup me')
    archive=tmp_path/'b.jarvisbackup';rt.backup.create(archive)
    with zipfile.ZipFile(archive) as zf: names=set(zf.namelist())
    assert 'payload/workbench.sqlite3' in names
    rt.clean_shutdown()


def test_crash_recovery_pauses_running_work_and_revokes_run(tmp_path):
    backend=SimulatedDesktopBackend();rt=build_infinity3_runtime(tmp_path,backend);rt.policy.set('workbench.manage',True);rt.guardian.grant_action('workbench_manage',uses=1);item=rt.workbench.create('crash job')
    row=rt.workbench.store.get(item.id);row.state=WorkState.RUNNING;rt.workbench.store.save(row)
    rt.policy.set('workbench.run',True);rt.stop_all();rt.base.base.base.instance_lock.release()
    rt2=build_infinity3_runtime(tmp_path,backend)
    recovered=rt2.workbench.store.get(item.id)
    assert rt2.recovery_state.safe_mode and not rt2.policy.is_allowed('workbench.run')
    assert recovered.state==WorkState.PAUSED and 'Recovery pause' in recovered.conclusion
    rt2.clean_shutdown()


def test_diagnostics_reports_workbench_and_version(tmp_path):
    rt=build_infinity3_runtime(tmp_path,SimulatedDesktopBackend());report=rt.diagnostics.run(rt)
    assert report['version']=='1.3.0a3' and report['storage']['workbench_sqlite']['status']=='ok'
    assert report['workbench']['total']==0
    rt.clean_shutdown()

def test_workbench_read_off_removes_jobs_from_personal_os(tmp_path):
    rt=build_infinity3_runtime(tmp_path,SimulatedDesktopBackend());rt.policy.set('workbench.manage',True);rt.guardian.grant_action('workbench_manage',uses=1)
    rt.workbench.create('PRIVATE WORK ITEM');rt.personal_os.sync()
    assert any(x['kind']=='work' for x in rt.personal_os.resources())
    rt.policy.set('workbench.read',False);rt.personal_os.sync()
    assert not any(x.kind.value=='work' and x.status=='active' for x in rt.personal_os.store.list(limit=200))
    rt.policy.set('os.cloud',True);rt.policy.set('workbench.cloud',True)
    assert 'PRIVATE WORK ITEM' not in str(rt.personal_os.cloud_context())
    rt.clean_shutdown()

def test_workbench_goal_cloud_export_requires_os_and_workbench_cloud(tmp_path):
    rt=build_infinity3_runtime(tmp_path,SimulatedDesktopBackend());rt.policy.set('workbench.manage',True);rt.guardian.grant_action('workbench_manage',uses=1);rt.workbench.create('CLOUD BOUNDARY GOAL')
    rt.personal_os.sync(); assert rt.personal_os.cloud_context() is None
    rt.policy.set('os.cloud',True); assert 'CLOUD BOUNDARY GOAL' not in str(rt.personal_os.cloud_context())
    rt.policy.set('workbench.cloud',True); assert 'CLOUD BOUNDARY GOAL' in str(rt.personal_os.cloud_context())
    rt.clean_shutdown()

class FailingAutonomy:
    def __init__(self,root): self.store=MissionStore(root/'m')
    def run(self,*a,**k): raise RuntimeError('provider down')

def test_provider_failure_closes_work_item_not_running(tmp_path):
    wb=AutonomousWorkbench(WorkbenchStore(tmp_path/'w.sqlite3'),FailingAutonomy(tmp_path),kill_switch=type('K',(),{'engaged':False,'check':lambda self:None})(),run_allowed=lambda:True,manage_allowed=lambda:True)
    item=wb.create('fail safely');out=wb.run_cycle()[0]
    assert out.state==WorkState.FAILED and 'provider down' in out.conclusion
    assert wb.store.get(item.id).state==WorkState.FAILED


def test_recovery_does_not_rerun_already_verified_underlying_mission(tmp_path):
    auto=FakeAutonomy(tmp_path);store=WorkbenchStore(tmp_path/'w.sqlite3');wb=AutonomousWorkbench(store,auto,kill_switch=type('K',(),{'check':lambda self:None})(),run_allowed=lambda:True,manage_allowed=lambda:True)
    item=wb.create('already done');mission=AutonomousMission(goal=item.goal,state=AutonomyState.VERIFIED,conclusion='proof already exists')
    mission.steps.append(MissionStep(1,'status',{},'safe.read',state=StepState.VERIFIED,verification='ok'));auto.store.save(mission)
    item.mission_id=mission.id;item.state=WorkState.PAUSED;store.save(item)
    item=wb.resume(item.id);before=len(auto.calls);out=wb.run_cycle()[0]
    assert out.state==WorkState.VERIFIED and len(auto.calls)==before and out.steps_used==1


def test_crash_reconciles_mission_steps_before_budget(tmp_path):
    auto=FakeAutonomy(tmp_path);store=WorkbenchStore(tmp_path/'w.sqlite3');wb=AutonomousWorkbench(store,auto,kill_switch=type('K',(),{'check':lambda self:None})(),run_allowed=lambda:True,manage_allowed=lambda:True)
    item=wb.create('budget after crash',step_budget=1);mission=AutonomousMission(goal=item.goal,state=AutonomyState.PAUSED)
    mission.steps.append(MissionStep(1,'status',{},'safe.read',state=StepState.VERIFIED,verification='ok'));auto.store.save(mission)
    item.mission_id=mission.id;item.state=WorkState.PAUSED;store.save(item);wb.resume(item.id)
    out=wb.run_cycle()[0]
    assert out.state==WorkState.FAILED and out.steps_used==1 and 'budget exhausted' in out.conclusion.lower()

def test_backup_restore_preserves_workbench_rows(tmp_path):
    from jarvis_gm.product.backup import BackupManager
    data=tmp_path/'data';rt=build_infinity3_runtime(data,SimulatedDesktopBackend());rt.policy.set('workbench.manage',True);rt.guardian.grant_action('workbench_manage',uses=1)
    item=rt.workbench.create('RESTORE WORK');archive=tmp_path/'owner.jarvisbackup';rt.backup.create(archive);rt.clean_shutdown()
    (data/'workbench.sqlite3').unlink()
    BackupManager(data,product_version='1.3.0a3').stage_restore(archive)
    rt2=build_infinity3_runtime(data,SimulatedDesktopBackend())
    restored=rt2.workbench.store.get(item.id)
    assert restored is not None and restored.goal=='RESTORE WORK'
    rt2.clean_shutdown()

def test_planner_understands_workbench_commands(tmp_path):
    rt=build_infinity3_runtime(tmp_path,SimulatedDesktopBackend())
    actions={k:v.capability for k,v in rt.orchestrator.executor.actions.items()}
    p=rt.orchestrator.planner
    assert p.plan('trabajos',actions)[0].name=='workbench_list'
    assert p.plan('trabajo: redactar informe',actions)[0].name=='workbench_create'
    assert p.plan('ciclo workbench',actions)[0].name=='workbench_run_cycle'
    rt.clean_shutdown()

def test_package_version_is_current_release():
    import jarvis_gm
    assert jarvis_gm.__version__=='1.7.0rc1'
