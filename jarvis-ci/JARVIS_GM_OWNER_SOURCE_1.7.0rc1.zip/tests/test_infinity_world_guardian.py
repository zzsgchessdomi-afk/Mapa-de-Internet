from __future__ import annotations

from pathlib import Path
import time

from jarvis_gm.control.simulated_backend import SimulatedDesktopBackend
from jarvis_gm.core.models import ActionRequest, GoalState
from jarvis_gm.perception.events import PerceptionEvent
from jarvis_gm.runtime import build_infinity1_runtime
from jarvis_gm.world.store import WorldModelStore


def test_world_model_entities_relations_and_expiry(tmp_path: Path):
    store=WorldModelStore(tmp_path/'world.sqlite3')
    a=store.upsert_entity(kind='window',key='1',label='A',ttl_s=1,now=10)
    b=store.upsert_entity(kind='device',key='pc',label='PC',now=10)
    store.relate(b.id,'foreground_window',a.id,ttl_s=1,now=10)
    assert len(store.entities(now=10.5))==2
    store.purge_expired(now=12)
    assert all(x['id'] != a.id for x in store.entities(now=12))
    assert not store.relations(now=12)


def test_infinity_runtime_world_model_ingests_perception(tmp_path: Path):
    rt=build_infinity1_runtime(tmp_path,SimulatedDesktopBackend())
    now=time.time()
    rt.perception.bus.publish(PerceptionEvent('environment.changed','test',{'active_handle':7,'active_title':'Editor','fingerprint':'abc','element_count':4,'changed':True},timestamp=now))
    ctx=rt.world_model.context_for_goal('continue editing')
    assert any(x['kind']=='window' and x['label']=='Editor' for x in ctx['entities'])
    assert any(x['predicate']=='foreground_window' for x in ctx['relations'])
    rt.clean_shutdown()


def test_world_cloud_is_separate_permission(tmp_path: Path):
    rt=build_infinity1_runtime(tmp_path,SimulatedDesktopBackend())
    class P:
        available=True
        def __init__(self): self.prompt=''
        def generate(self,prompt,*,system=None): self.prompt=prompt; return '{"decision":"blocked","reason":"test"}'
    p=P()
    from jarvis_gm.autonomy.models import AutonomousMission
    rt.autonomy_engine._decide(p,AutonomousMission(goal='test'))
    assert 'WORLD=null' in p.prompt
    rt.policy.set('world.cloud',True)
    rt.autonomy_engine._decide(p,AutonomousMission(goal='test'))
    assert '"stats"' in p.prompt and 'WORLD={' in p.prompt
    rt.clean_shutdown()


def test_guardian_medium_action_uses_normal_policy_without_lease(tmp_path: Path):
    backend=SimulatedDesktopBackend(); rt=build_infinity1_runtime(tmp_path,backend)
    rt.policy.set('app.launch',True)
    rt.apps.register('notes','notepad.exe')
    result=rt.orchestrator.executor.execute(ActionRequest('open_app',{'app':'notes'},'app.launch'))
    assert result.ok and backend.opened_apps
    rt.clean_shutdown()


def test_guardian_high_risk_requires_owner_lease(tmp_path: Path):
    rt=build_infinity1_runtime(tmp_path,SimulatedDesktopBackend())
    rt.policy.set('mobile.security',True)
    req=ActionRequest('mobile_request_auth',{},'mobile.security')
    blocked=rt.orchestrator.executor.execute(req)
    assert blocked.blocked and 'owner lease' in (blocked.error or '').lower()
    audit=rt.guardian.store.recent_audit(1)[0]
    assert audit['decision']=='block' and audit['risk']=='high'
    rt.clean_shutdown()


def test_guardian_lease_is_short_lived_and_consumable(tmp_path: Path):
    rt=build_infinity1_runtime(tmp_path,SimulatedDesktopBackend())
    rt.policy.set('mobile.security',True)
    rt.guardian.grant_action('mobile_request_auth',ttl_s=60,uses=1)
    # The phone is not paired, so Guardian must allow the attempt and underlying action then fails normally.
    result=rt.orchestrator.executor.execute(ActionRequest('mobile_request_auth',{},'mobile.security'))
    assert not result.blocked
    again=rt.orchestrator.executor.execute(ActionRequest('mobile_request_auth',{},'mobile.security'))
    assert again.blocked and 'owner lease' in (again.error or '').lower()
    rt.clean_shutdown()


def test_guardian_redacts_secret_like_arguments_in_audit(tmp_path: Path):
    rt=build_infinity1_runtime(tmp_path,SimulatedDesktopBackend())
    rt.guardian.store.audit(action='x',capability='safe.read',risk='low',decision='allow',rule='test',reason='test',args={'pin':'1234','nested':{'api_key':'secret'},'normal':'ok'})
    row=rt.guardian.store.recent_audit(1)[0]
    assert row['args']['pin']=='<redacted>' and row['args']['nested']['api_key']=='<redacted>' and row['args']['normal']=='ok'
    rt.clean_shutdown()


def test_guardian_blocks_unsafe_url_even_if_policy_enabled(tmp_path: Path):
    rt=build_infinity1_runtime(tmp_path,SimulatedDesktopBackend())
    rt.policy.set('browser.open',True)
    out=rt.orchestrator.executor.execute(ActionRequest('open_url',{'url':'file:///etc/passwd'},'browser.open'))
    assert out.blocked and 'http' in (out.error or '').lower()
    rt.clean_shutdown()


def test_world_model_records_goal_lifecycle(tmp_path: Path):
    rt=build_infinity1_runtime(tmp_path,SimulatedDesktopBackend())
    goal=rt.orchestrator.run('status')
    assert goal.state==GoalState.VERIFIED
    observations=rt.world_model.store.recent_observations(20)
    assert any(x['event_type']=='goal.finished' and x['payload']['goal_id']==goal.id for x in observations)
    goals=rt.world_model.store.entities(kinds=('goal',),limit=10)
    assert any(x['attributes']['state']=='verified' for x in goals)
    rt.clean_shutdown()


def test_guardian_stop_revokes_leases(tmp_path: Path):
    rt=build_infinity1_runtime(tmp_path,SimulatedDesktopBackend())
    rt.guardian.grant_capability('mobile.security',ttl_s=300,uses=10)
    rt.stop_all()
    rt.policy.set('mobile.security',True)
    result=rt.orchestrator.executor.execute(ActionRequest('mobile_request_auth',{},'mobile.security'))
    assert result.blocked
    rt.base.instance_lock.release()

def test_world_cloud_cannot_bypass_screen_perception_memory_boundaries(tmp_path: Path):
    rt=build_infinity1_runtime(tmp_path,SimulatedDesktopBackend())
    rt.memory_manager.create_project('Secret Project', summary='private project summary')
    now=time.time()
    rt.perception.bus.publish(PerceptionEvent('environment.changed','test',{'active_handle':99,'active_title':'Secret Window','fingerprint':'secret-fp','element_count':2,'changed':True},timestamp=now))
    rt.perception.bus.publish(PerceptionEvent('voice.command','voice',{'text':'secret spoken phrase'},timestamp=now+.01))
    projected=rt.world_model.cloud_context_for_goal('goal',allow_screen=False,allow_perception=False,allow_memory=False)
    blob=str(projected)
    assert 'Secret Window' not in blob
    assert 'secret spoken phrase' not in blob
    assert 'Secret Project' not in blob
    assert 'private project summary' not in blob
    full=rt.world_model.cloud_context_for_goal('goal',allow_screen=True,allow_perception=True,allow_memory=True)
    full_blob=str(full)
    assert 'Secret Window' in full_blob and 'Secret Project' in full_blob
    rt.clean_shutdown()


def test_world_write_permission_stops_goal_ingestion(tmp_path: Path):
    rt=build_infinity1_runtime(tmp_path,SimulatedDesktopBackend())
    before=rt.world_model.store.stats()['observations']
    rt.policy.set('world.write',False)
    rt.orchestrator.run('status')
    after=rt.world_model.store.stats()['observations']
    assert after==before
    rt.clean_shutdown()


def test_executor_fails_closed_when_guardian_crashes(tmp_path: Path):
    rt=build_infinity1_runtime(tmp_path,SimulatedDesktopBackend())
    rt.policy.set('browser.open',True)
    class BrokenGuardian:
        def authorize(self,req): raise RuntimeError('broken')
    rt.orchestrator.executor.guardian=BrokenGuardian()
    out=rt.orchestrator.executor.execute(ActionRequest('open_url',{'url':'https://example.com'},'browser.open'))
    assert out.blocked and 'failed closed' in (out.error or '').lower()
    rt.base.instance_lock.release()

def test_world_model_does_not_bypass_memory_read_permission(tmp_path: Path):
    rt=build_infinity1_runtime(tmp_path,SimulatedDesktopBackend())
    rt.memory_manager.create_project('Private Project',summary='secret')
    rt.policy.set('memory.read',False)
    ctx=rt.world_model.context_for_goal('x')
    assert ctx['active_project'] is None
    assert not any(e['kind']=='project' and e['label']=='Private Project' for e in ctx['entities'])
    rt.clean_shutdown()


def test_guardian_leases_do_not_survive_restart(tmp_path: Path):
    rt=build_infinity1_runtime(tmp_path,SimulatedDesktopBackend())
    rt.policy.set('mobile.security',True)
    rt.guardian.grant_action('mobile_request_auth',ttl_s=300,uses=10)
    rt.clean_shutdown()
    rt2=build_infinity1_runtime(tmp_path,SimulatedDesktopBackend())
    rt2.policy.set('mobile.security',True)
    out=rt2.orchestrator.executor.execute(ActionRequest('mobile_request_auth',{},'mobile.security'))
    assert out.blocked and 'owner lease' in (out.error or '').lower()
    rt2.clean_shutdown()

def test_guardian_sensitive_action_audit_redacts_message_body(tmp_path: Path):
    rt=build_infinity1_runtime(tmp_path,SimulatedDesktopBackend())
    rt.guardian.store.audit(action='mobile_compose_message',capability='mobile.messaging',risk='high',decision='block',rule='test',reason='test',args={'recipient':'Mom','text':'private message'})
    row=rt.guardian.store.recent_audit(1)[0]
    assert row['args']['recipient'].startswith('<redacted') and row['args']['text'].startswith('<redacted')
    assert 'private message' not in str(row)
    rt.clean_shutdown()


def test_guardian_mouse_hold_is_high_risk(tmp_path: Path):
    rt=build_infinity1_runtime(tmp_path,SimulatedDesktopBackend())
    rt.policy.set('input.control',True)
    out=rt.orchestrator.executor.execute(ActionRequest('mouse_button',{'button':'left','state':'down'},'input.control'))
    assert out.blocked and 'owner lease' in (out.error or '').lower()
    assert not rt.backend.buttons
    rt.clean_shutdown()

def test_backup_includes_world_and_guardian_state(tmp_path: Path):
    import zipfile, json
    rt=build_infinity1_runtime(tmp_path/'data',SimulatedDesktopBackend())
    rt.orchestrator.run('status')
    archive=tmp_path/'owner.jarvisbackup'
    rt.backup.create(archive)
    validation=rt.backup.validate(archive)
    assert validation.ok
    with zipfile.ZipFile(archive,'r') as zf:
        manifest=json.loads(zf.read('backup_manifest.json'))
    names={x['path'] for x in manifest['files']}
    assert 'world_model.sqlite3' in names and 'guardian.sqlite3' in names
    rt.clean_shutdown()


def test_autopilot_cannot_bypass_guardian_high_risk_lease(tmp_path: Path):
    rt=build_infinity1_runtime(tmp_path,SimulatedDesktopBackend())
    class P:
        available=True
        def generate(self,prompt,*,system=None):
            if 'CLOSED-LOOP desktop mission' in prompt:
                return '{"decision":"act","action":"mobile_lock","args":{},"rationale":"lock","expected_effect":"phone locked"}'
            return '{}'
    rt.providers.register('guardian-autonomy',P());rt.providers.set_active('guardian-autonomy')
    rt.policy.set('autonomy.run',True);rt.policy.set('mobile.security',True)
    mission=rt.autonomy_engine.run('lock my phone',max_steps=1)
    assert mission.state.value=='blocked'
    assert 'owner lease' in (mission.blocked_reason or '').lower()
    rt.clean_shutdown()


def test_world_model_perception_does_not_write_when_disabled(tmp_path: Path):
    rt=build_infinity1_runtime(tmp_path,SimulatedDesktopBackend())
    rt.policy.set('world.write',False)
    before=rt.world_model.store.stats()['observations']
    rt.perception.bus.publish(PerceptionEvent('voice.command','voice',{'text':'do not persist'},timestamp=time.time()))
    assert rt.world_model.store.stats()['observations']==before
    rt.clean_shutdown()

def test_safe_mode_reenables_guardian_after_unclean_shutdown(tmp_path: Path):
    rt=build_infinity1_runtime(tmp_path,SimulatedDesktopBackend())
    rt.policy.set('guardian.enforce',False)
    rt.stop_all(); rt.base.instance_lock.release()  # intentionally omit clean recovery marker
    rt2=build_infinity1_runtime(tmp_path,SimulatedDesktopBackend())
    assert rt2.recovery_state.safe_mode and rt2.policy.is_allowed('guardian.enforce')
    rt2.clean_shutdown()


def test_agent_memory_management_is_high_risk(tmp_path: Path):
    rt=build_infinity1_runtime(tmp_path,SimulatedDesktopBackend())
    rt.policy.set('memory.manage',True)
    decision=rt.guardian.authorize(ActionRequest('forget_memory',{'memory_id':'x'},'memory.manage'))
    assert not decision.allowed and decision.risk.name=='HIGH' and decision.requires_lease
    rt.clean_shutdown()

def test_backup_restore_recovers_world_model_state(tmp_path: Path):
    data=tmp_path/'data'; archive=tmp_path/'owner.jarvisbackup'
    rt=build_infinity1_runtime(data,SimulatedDesktopBackend())
    rt.world_model.store.upsert_entity(kind='device',key='restore-test',label='Before Backup',source='test')
    rt.backup.create(archive)
    rt.world_model.store.upsert_entity(kind='device',key='restore-test',label='After Backup',source='test')
    rt.backup.stage_restore(archive)
    rt.clean_shutdown()
    rt2=build_infinity1_runtime(data,SimulatedDesktopBackend())
    rows=rt2.world_model.store.entities(kinds=('device',),limit=50)
    restored=[x for x in rows if x['id']==rt2.world_model.store.stable_id('device','restore-test')]
    assert restored and restored[0]['label']=='Before Backup'
    rt2.clean_shutdown()


def test_diagnostics_checks_world_and_guardian_databases(tmp_path: Path):
    rt=build_infinity1_runtime(tmp_path,SimulatedDesktopBackend())
    report=rt.diagnostics.run(rt)
    assert report['storage']['world_model_sqlite']['status']=='ok'
    assert report['storage']['guardian_sqlite']['status']=='ok'
    assert 'world_model' in report and 'guardian' in report
    rt.clean_shutdown()
