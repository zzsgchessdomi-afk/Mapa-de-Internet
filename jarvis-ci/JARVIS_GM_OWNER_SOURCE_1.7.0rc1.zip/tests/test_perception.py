from __future__ import annotations

from pathlib import Path
import tempfile
import unittest

from jarvis_gm.perception.bus import PerceptionBus
from jarvis_gm.perception.events import PerceptionEvent
from jarvis_gm.perception.voice.wake_gate import WakeGate
from jarvis_gm.perception.vision.gesture_engine import GestureConfig, GestureEngine
from jarvis_gm.perception.vision.model_manager import ModelManager
from jarvis_gm.perception.vision.models import HandObservation, Point3, VisionFrame


def make_hand(*, gesture="Open_Palm", confidence=0.95, wrist_x=0.5, index=(0.5, 0.3), thumb=(0.2, 0.35), hand="Right"):
    pts = [Point3(0.5, 0.8, 0.0) for _ in range(21)]
    pts[0] = Point3(wrist_x, 0.80)
    pts[4] = Point3(*thumb)
    pts[5] = Point3(0.42, 0.58)
    pts[6] = Point3(0.47, 0.52)
    pts[8] = Point3(*index)
    pts[10] = Point3(0.52, 0.52)
    pts[12] = Point3(0.52, 0.25)
    pts[14] = Point3(0.57, 0.54)
    pts[16] = Point3(0.57, 0.28)
    pts[17] = Point3(0.62, 0.60)
    pts[18] = Point3(0.62, 0.56)
    pts[20] = Point3(0.62, 0.31)
    return HandObservation(hand, tuple(pts), gesture, confidence)


class PerceptionTests(unittest.TestCase):
    def test_bus_delivers_and_keeps_history(self):
        bus = PerceptionBus()
        seen = []
        token = bus.subscribe(seen.append)
        event = PerceptionEvent("x", "test", {"a": 1})
        bus.publish(event)
        self.assertEqual(seen, [event])
        self.assertEqual(bus.recent(1), [event])
        bus.unsubscribe(token)
        bus.publish(PerceptionEvent("y", "test"))
        self.assertEqual(len(seen), 1)

    def test_open_palm_dwell_arms(self):
        engine = GestureEngine(GestureConfig(arm_dwell_s=0.2))
        self.assertFalse(engine.process(VisionFrame((make_hand(),), 10.0)))
        events = engine.process(VisionFrame((make_hand(),), 10.25))
        self.assertTrue(engine.armed)
        self.assertIn("gesture.armed", [e.type for e in events])

    def test_pinch_hysteresis(self):
        engine = GestureEngine(GestureConfig(arm_dwell_s=0.1))
        engine.process(VisionFrame((make_hand(),), 1.0))
        engine.process(VisionFrame((make_hand(),), 1.2))
        close = make_hand(gesture="None", index=(0.50, 0.30), thumb=(0.505, 0.305))
        events = engine.process(VisionFrame((close,), 1.3))
        self.assertIn("gesture.pinch_start", [e.type for e in events])
        far = make_hand(gesture="None", index=(0.55, 0.30), thumb=(0.20, 0.40))
        events = engine.process(VisionFrame((far,), 1.5))
        self.assertIn("gesture.pinch_end", [e.type for e in events])

    def test_no_hands_auto_disarms(self):
        engine = GestureEngine(GestureConfig(arm_dwell_s=0.1, no_hands_disarm_s=0.5))
        engine.process(VisionFrame((make_hand(),), 1.0))
        engine.process(VisionFrame((make_hand(),), 1.2))
        engine.process(VisionFrame(tuple(), 1.4))
        events = engine.process(VisionFrame(tuple(), 1.8))
        self.assertFalse(engine.armed)
        self.assertIn("gesture.disarmed", [e.type for e in events])

    def test_swipe_requires_movement(self):
        cfg = GestureConfig(arm_dwell_s=0.05, swipe_min_dx=0.18, swipe_window_s=0.5)
        engine = GestureEngine(cfg)
        engine.process(VisionFrame((make_hand(wrist_x=0.2),), 1.0))
        engine.process(VisionFrame((make_hand(wrist_x=0.2),), 1.1))
        engine.process(VisionFrame((make_hand(gesture="None", wrist_x=0.22),), 1.2))
        events = engine.process(VisionFrame((make_hand(gesture="None", wrist_x=0.48),), 1.35))
        self.assertIn("gesture.swipe_right", [e.type for e in events])

    def test_two_hand_transform(self):
        engine = GestureEngine(GestureConfig(arm_dwell_s=0.05, transform_throttle_s=0.01))
        engine.process(VisionFrame((make_hand(),), 1.0))
        engine.process(VisionFrame((make_hand(),), 1.1))
        a = make_hand(gesture="None", index=(0.35, 0.35), hand="Left")
        b = make_hand(gesture="None", index=(0.65, 0.35), hand="Right")
        engine.process(VisionFrame((a, b), 1.2))
        b2 = make_hand(gesture="None", index=(0.75, 0.30), hand="Right")
        events = engine.process(VisionFrame((a, b2), 1.3))
        self.assertIn("gesture.transform", [e.type for e in events])

    def test_wake_gate_same_phrase_and_followup(self):
        gate = WakeGate(("jarvis",), command_window_s=5)
        d = gate.process("Jarvis abre el proyecto", now=10)
        self.assertEqual((d.kind, d.text), ("command", "abre el proyecto"))
        d2 = gate.process("y revisa los errores", now=12)
        self.assertEqual(d2.kind, "command")
        self.assertEqual(gate.process("esto no", now=30).kind, "ignored")

    def test_model_manager_does_not_redownload_valid_model(self):
        with tempfile.TemporaryDirectory() as d:
            manager = ModelManager(Path(d))
            manager.gesture_model.write_bytes(b"x" * (1024 * 1024 + 1))
            self.assertEqual(manager.ensure_gesture_model(), manager.gesture_model)


if __name__ == "__main__":
    unittest.main()
