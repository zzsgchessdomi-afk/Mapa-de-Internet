from __future__ import annotations

from pathlib import Path
import json
import zipfile

import pytest

from jarvis_gm.control.simulated_backend import SimulatedDesktopBackend
from jarvis_gm.core.permissions import PermissionPolicy
from jarvis_gm.product.backup import BackupManager, apply_pending_restore
from jarvis_gm.product.diagnostics import DiagnosticsRunner
from jarvis_gm.product.recovery import RecoveryManager, SAFE_MODE_CAPABILITIES
from jarvis_gm.runtime import build_phase8_runtime


def test_recovery_clean_shutdown_does_not_trigger_safe_mode(tmp_path: Path):
    policy = PermissionPolicy(path=tmp_path / "permissions.json")
    policy.set("input.control", True)
    first = RecoveryManager(tmp_path)
    state = first.begin(policy)
    assert not state.safe_mode
    first.mark_clean()

    second = RecoveryManager(tmp_path)
    state2 = second.begin(policy)
    assert not state2.safe_mode
    assert policy.is_allowed("input.control")


def test_recovery_unclean_shutdown_revokes_risky_permissions(tmp_path: Path):
    policy = PermissionPolicy(path=tmp_path / "permissions.json")
    for cap in SAFE_MODE_CAPABILITIES:
        policy.set(cap, True)
    RecoveryManager(tmp_path).begin(policy)  # intentionally no mark_clean

    policy2 = PermissionPolicy(path=tmp_path / "permissions.json")
    state = RecoveryManager(tmp_path).begin(policy2)
    assert state.safe_mode
    assert state.previous_unclean
    assert all(not policy2.is_allowed(cap) for cap in SAFE_MODE_CAPABILITIES)


def test_backup_roundtrip_and_pending_restore(tmp_path: Path):
    root = tmp_path / "data"
    root.mkdir()
    (root / "workspace").mkdir()
    (root / "workspace" / "note.txt").write_text("original", encoding="utf-8")
    (root / "permissions.json").write_text(json.dumps({"safe.read": True}), encoding="utf-8")
    manager = BackupManager(root)
    backup = manager.create(tmp_path / "owner.jarvisbackup")
    validation = manager.validate(backup)
    assert validation.ok and validation.files >= 2

    (root / "workspace" / "note.txt").write_text("changed", encoding="utf-8")
    manager.stage_restore(backup)
    assert apply_pending_restore(root)
    assert (root / "workspace" / "note.txt").read_text(encoding="utf-8") == "original"
    assert not (root / "pending_restore.jarvisbackup").exists()


def test_backup_rejects_hash_tampering(tmp_path: Path):
    root = tmp_path / "data"; root.mkdir(); (root / "workspace").mkdir()
    (root / "workspace" / "a.txt").write_text("safe", encoding="utf-8")
    manager = BackupManager(root)
    backup = manager.create(tmp_path / "good.jarvisbackup")
    tampered = tmp_path / "bad.jarvisbackup"
    with zipfile.ZipFile(backup, "r") as src, zipfile.ZipFile(tampered, "w") as dst:
        for item in src.infolist():
            data = src.read(item.filename)
            if item.filename.endswith("a.txt"):
                data = b"tampered"
            dst.writestr(item, data)
    validation = manager.validate(tampered)
    assert not validation.ok
    assert any("Hash mismatch" in e or "Size mismatch" in e for e in validation.errors)


def test_backup_rejects_path_traversal(tmp_path: Path):
    archive = tmp_path / "evil.jarvisbackup"
    manifest = {"format": 1, "product": "JARVIS GM", "version": "x", "created_at": 0,
                "files": [{"path": "../escape.txt", "sha256": "0" * 64, "size": 1}]}
    with zipfile.ZipFile(archive, "w") as zf:
        zf.writestr("backup_manifest.json", json.dumps(manifest))
        zf.writestr("payload/../escape.txt", b"x")
    validation = BackupManager.validate(archive)
    assert not validation.ok


def test_diagnostics_never_claims_physical_hardware_test(tmp_path: Path):
    report = DiagnosticsRunner(tmp_path).run()
    hw = report["hardware_acceptance"]
    assert hw["status"] == "pending_physical_windows_test"
    assert all(hw[k] == "not_claimed" for k in ("camera", "microphone", "windows_ui_automation", "real_mouse_keyboard"))


def test_phase8_runtime_clean_shutdown(tmp_path: Path):
    rt = build_phase8_runtime(tmp_path, SimulatedDesktopBackend())
    assert rt.recovery_state.safe_mode is False
    report = rt.diagnostics.run(rt)
    assert report["version"] == "1.2.0a2"
    rt.clean_shutdown()
    state = json.loads((tmp_path / "runtime_state.json").read_text(encoding="utf-8"))
    assert state["status"] == "clean"


def test_phase8_unclean_restart_enters_safe_mode(tmp_path: Path):
    rt1 = build_phase8_runtime(tmp_path, SimulatedDesktopBackend())
    rt1.policy.set("input.control", True)
    rt1.stop_all()  # deliberately not clean_shutdown; simulates abrupt process end
    rt1.instance_lock.release()  # the OS would release this automatically if the process died
    rt2 = build_phase8_runtime(tmp_path, SimulatedDesktopBackend())
    assert rt2.recovery_state.safe_mode
    assert not rt2.policy.is_allowed("input.control")
    rt2.clean_shutdown()


def test_provider_settings_persist_without_secret(tmp_path: Path):
    from jarvis_gm.product.settings import ProviderSettings
    settings = ProviderSettings.load(tmp_path / "provider_config.json")
    settings.gemini_model = "gemini-3.8-flash"
    settings.save()
    loaded = ProviderSettings.load(tmp_path / "provider_config.json")
    assert loaded.gemini_model == "gemini-3.8-flash"
    assert "api" not in (tmp_path / "provider_config.json").read_text(encoding="utf-8").casefold()


def test_backup_excludes_runtime_and_secret_material(tmp_path: Path):
    root = tmp_path / "data"; root.mkdir(); (root / "workspace").mkdir()
    (root / "workspace" / "x.txt").write_text("x", encoding="utf-8")
    (root / "runtime_state.json").write_text('{"status":"running"}', encoding="utf-8")
    (root / "STOP").write_text("1", encoding="utf-8")
    (root / "logs").mkdir(); (root / "logs" / "crash.jsonl").write_text("secret-looking-log", encoding="utf-8")
    archive = BackupManager(root).create(tmp_path / "safe.jarvisbackup")
    with zipfile.ZipFile(archive) as zf:
        names = set(zf.namelist())
    assert "payload/runtime_state.json" not in names
    assert "payload/STOP" not in names
    assert not any(name.startswith("payload/logs/") for name in names)


def test_second_instance_is_blocked(tmp_path: Path):
    rt1 = build_phase8_runtime(tmp_path, SimulatedDesktopBackend())
    with pytest.raises(RuntimeError, match="Another JARVIS GM instance"):
        build_phase8_runtime(tmp_path, SimulatedDesktopBackend())
    rt1.clean_shutdown()


def test_backup_rejects_internal_runtime_file_even_with_valid_hash(tmp_path: Path):
    import hashlib
    archive = tmp_path / "evil-runtime.jarvisbackup"
    payload = b'{"status":"clean"}'
    manifest = {"format": 1, "product": "JARVIS GM", "version": "x", "created_at": 0,
                "files": [{"path": "runtime_state.json", "sha256": hashlib.sha256(payload).hexdigest(), "size": len(payload)}]}
    with zipfile.ZipFile(archive, "w") as zf:
        zf.writestr("backup_manifest.json", json.dumps(manifest))
        zf.writestr("payload/runtime_state.json", payload)
    validation = BackupManager.validate(archive)
    assert not validation.ok
    assert any("Disallowed payload path" in e for e in validation.errors)


def test_windows_delivery_is_self_contained_and_build_is_one_click():
    root = Path(__file__).resolve().parents[1]
    ps1 = (root / "BUILD_WINDOWS.ps1").read_text(encoding="utf-8")
    spec = (root / "JarvisGM.spec").read_text(encoding="utf-8")
    iss = (root / "installer" / "JARVIS_GM.iss").read_text(encoding="utf-8")
    entry = (root / "build_tools" / "jarvis_entry.py").read_text(encoding="utf-8")
    assert "winget install --id Python.Python.3.11" in ps1
    assert "winget install --id JRSoftware.InnoSetup" in ps1
    assert 'JARVIS_GM.exe" --self-test' in ps1
    assert "--release-preflight" in ps1 and "JARVIS_GM_INFINITY7_PREFLIGHT.json" in ps1
    assert "console=False" in spec
    assert "--self-test" in entry
    assert "python.exe" not in iss.casefold() and "pip" not in iss.casefold()
    assert "JARVIS_GM_Setup_INFINITY7" in iss


def test_infinity6_backup_contract_includes_reality_files():
    from jarvis_gm.product.backup import BACKUP_ENTRIES
    assert "reality.sqlite3" in BACKUP_ENTRIES
    assert "reality_config.json" in BACKUP_ENTRIES
