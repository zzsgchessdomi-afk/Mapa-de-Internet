from __future__ import annotations

from pathlib import Path
import tempfile

from jarvis_gm.control.simulated_backend import SimulatedDesktopBackend
from jarvis_gm.core.models import GoalState
from jarvis_gm.memory.models import MemoryKind
from jarvis_gm.memory.store import ContinuityStore
from jarvis_gm.memory.manager import MemoryManager
from jarvis_gm.runtime import build_phase6_runtime


def test_projects_persist_and_activate_across_restarts():
    with tempfile.TemporaryDirectory() as d:
        root=Path(d); s=ContinuityStore(root/'memory.sqlite3'); m=MemoryManager(s)
        p=m.create_project('Atlas','research'); assert m.active_project.id==p.id
        s2=ContinuityStore(root/'memory.sqlite3'); m2=MemoryManager(s2)
        assert m2.active_project and m2.active_project.name=='Atlas'


def test_project_scope_prevents_cross_project_leakage():
    with tempfile.TemporaryDirectory() as d:
        m=MemoryManager(ContinuityStore(Path(d)/'m.sqlite3'))
        p1=m.create_project('Alpha'); a=m.remember('secret alpha rocket',title='Alpha fact')
        m.create_project('Beta'); m.remember('beta ocean',title='Beta fact')
        hits=m.retrieve('secret alpha rocket')
        assert all(x.id!=a.id for x in hits)


def test_global_memory_is_visible_inside_projects():
    with tempfile.TemporaryDirectory() as d:
        m=MemoryManager(ContinuityStore(Path(d)/'m.sqlite3'))
        g=m.remember('Always use metric units',global_scope=True,title='Units')
        m.create_project('Gamma')
        assert any(x.id==g.id for x in m.retrieve('metric units'))


def test_correction_supersedes_old_memory_without_destroying_history():
    with tempfile.TemporaryDirectory() as d:
        s=ContinuityStore(Path(d)/'m.sqlite3'); m=MemoryManager(s); m.create_project('A')
        old=m.remember('Version is 1',title='Version')
        new=s.correct_memory(old.id,'Version is 2')
        assert s.get_memory(old.id) is None
        old_raw=s.get_memory(old.id,include_inactive=True)
        assert old_raw and old_raw.status=='superseded'
        assert new.parent_id==old.id and new.content=='Version is 2'


def test_forget_is_tombstone_not_silent_hard_delete():
    with tempfile.TemporaryDirectory() as d:
        s=ContinuityStore(Path(d)/'m.sqlite3'); m=MemoryManager(s); r=m.remember('erase me')
        assert s.forget_memory(r.id)
        assert s.get_memory(r.id) is None
        raw=s.get_memory(r.id,include_inactive=True); assert raw and raw.status=='deleted'


def test_tasks_and_resume_snapshot():
    with tempfile.TemporaryDirectory() as d:
        m=MemoryManager(ContinuityStore(Path(d)/'m.sqlite3')); p=m.create_project('Build')
        t=m.add_task('Run installer','on Windows',priority=5); m.record_decision('Use cloud model')
        snap=m.resume('installer')
        assert snap.project and snap.project.id==p.id
        assert any(x.id==t.id for x in snap.pending_tasks)
        assert any(x.kind==MemoryKind.DECISION for x in snap.decisions)


def test_checkpoint_roundtrip():
    with tempfile.TemporaryDirectory() as d:
        s=ContinuityStore(Path(d)/'m.sqlite3'); m=MemoryManager(s); p=m.create_project('C')
        cid=s.add_checkpoint(project_id=p.id,session_id=s.current_session_id(),label='checkpoint',state={'step':7})
        cp=s.latest_checkpoint(p.id); assert cp and cp['id']==cid and cp['state']['step']==7


def test_phase6_commands_create_project_task_decision_and_resume():
    with tempfile.TemporaryDirectory() as d:
        rt=build_phase6_runtime(Path(d),SimulatedDesktopBackend())
        assert rt.orchestrator.run('nuevo proyecto Jarvis').state==GoalState.VERIFIED
        assert rt.orchestrator.run('tarea: probar memoria').state==GoalState.VERIFIED
        assert rt.orchestrator.run('decisión: conservar arquitectura local de datos').state==GoalState.VERIFIED
        resumed=rt.orchestrator.run('continúa lo de ayer')
        assert resumed.state==GoalState.VERIFIED
        data=resumed.results[0].output
        assert data['project']['name']=='Jarvis'
        assert any(x['title']=='probar memoria' for x in data['pending_tasks'])


def test_structured_remember_and_search_command():
    with tempfile.TemporaryDirectory() as d:
        rt=build_phase6_runtime(Path(d),SimulatedDesktopBackend())
        rt.orchestrator.run('nuevo proyecto X')
        saved=rt.orchestrator.run('recuerda: la interfaz debe ser nativa de Windows')
        assert saved.state==GoalState.VERIFIED
        found=rt.orchestrator.run('qué recuerdas de interfaz Windows?')
        assert found.state==GoalState.VERIFIED
        assert any('nativa de Windows' in x['content'] for x in found.results[0].output)


def test_automatic_episode_and_checkpoint_after_goal():
    with tempfile.TemporaryDirectory() as d:
        rt=build_phase6_runtime(Path(d),SimulatedDesktopBackend()); rt.orchestrator.run('nuevo proyecto Audit')
        g=rt.orchestrator.run('estado'); assert g.state==GoalState.VERIFIED
        eps=rt.memory_manager.store.recent_memories(project_id=rt.memory_manager.active_project.id,kind=MemoryKind.EPISODE,limit=10,include_global=False)
        assert any('Goal: estado' in x.content for x in eps)
        cp=rt.memory_manager.store.latest_checkpoint(rt.memory_manager.active_project.id); assert cp and cp['state']['goal_id']==g.id


def test_disabling_memory_write_stops_automatic_capture():
    with tempfile.TemporaryDirectory() as d:
        rt=build_phase6_runtime(Path(d),SimulatedDesktopBackend()); rt.orchestrator.run('nuevo proyecto NoWrite')
        before=len(rt.memory_manager.store.recent_memories(kind=MemoryKind.EPISODE,limit=100))
        rt.policy.set('memory.write',False); rt.orchestrator.run('estado')
        after=len(rt.memory_manager.store.recent_memories(kind=MemoryKind.EPISODE,limit=100))
        assert after==before


def test_disabling_memory_read_stops_context_injection():
    with tempfile.TemporaryDirectory() as d:
        rt=build_phase6_runtime(Path(d),SimulatedDesktopBackend()); rt.orchestrator.run('recuerda: blue widget')
        rt.policy.set('memory.read',False); g=rt.orchestrator.run('estado')
        events=[e for e in rt.orchestrator.memory.recent_events(30) if e['goal_id']==g.id]
        assert not any(e['event_type']=='memory.context' for e in events)


def test_memory_manage_is_denied_to_agent_by_default():
    with tempfile.TemporaryDirectory() as d:
        rt=build_phase6_runtime(Path(d),SimulatedDesktopBackend())
        assert not rt.policy.is_allowed('memory.manage')


def test_session_changes_when_project_changes():
    with tempfile.TemporaryDirectory() as d:
        m=MemoryManager(ContinuityStore(Path(d)/'m.sqlite3')); first=m.store.current_session_id()
        m.create_project('One'); second=m.store.current_session_id(); m.create_project('Two'); third=m.store.current_session_id()
        assert first and second and third and len({first,second,third})==3


def test_retrieval_favors_active_project_over_global_when_both_match():
    with tempfile.TemporaryDirectory() as d:
        m=MemoryManager(ContinuityStore(Path(d)/'m.sqlite3'))
        m.remember('installer choice generic',global_scope=True,importance=.5)
        m.create_project('P'); local=m.remember('installer choice exact project',importance=.5)
        hits=m.retrieve('installer choice',limit=2)
        assert hits and hits[0].id==local.id
