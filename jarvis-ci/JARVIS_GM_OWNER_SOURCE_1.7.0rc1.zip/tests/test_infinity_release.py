from __future__ import annotations
from pathlib import Path
import hashlib,json,time,zipfile
import pytest

from jarvis_gm.runtime import build_infinity7_runtime
from jarvis_gm.control.simulated_backend import SimulatedDesktopBackend
from jarvis_gm.product.release import ReleaseManager, version_key
from jarvis_gm.product.recovery import SAFE_MODE_CAPABILITIES, RecoveryManager
from jarvis_gm.core.permissions import PermissionPolicy
from jarvis_gm.product.backup import BACKUP_ENTRIES


def _update(path:Path,version="1.7.0rc2",members=None):
    members=members or {"app/JARVIS_GM.exe":b"future-binary"}
    files=[]
    for name,data in members.items(): files.append({"path":name,"sha256":hashlib.sha256(data).hexdigest(),"size":len(data)})
    with zipfile.ZipFile(path,"w") as z:
        z.writestr("release_manifest.json",json.dumps({"format":1,"product":"JARVIS GM","version":version,"files":files}))
        for name,data in members.items():z.writestr("payload/"+name,data)
    return path


def test_infinity7_defaults_and_truthful_gate(tmp_path):
    rt=build_infinity7_runtime(tmp_path,SimulatedDesktopBackend())
    assert rt.policy.is_allowed("health.read") and rt.policy.is_allowed("health.monitor")
    assert not rt.policy.is_allowed("support.export") and not rt.policy.is_allowed("release.manage")
    gate=rt.release_gate.evaluate(rt)
    assert gate["automated_ready"] and gate["status"]=="physical-pending" and not gate["physical_ready"]
    assert gate["acceptance"]["pending"]>0
    rt.clean_shutdown()


def test_acceptance_is_owner_recorded_not_auto_passed(tmp_path):
    rt=build_infinity7_runtime(tmp_path,SimulatedDesktopBackend())
    before=rt.acceptance.report(); assert not before["all_required_passed"]
    for name in list(before["checks"]): rt.acceptance.set_owner_result(name,"passed","owner physical test")
    gate=rt.release_gate.evaluate(rt)
    assert gate["physical_ready"] and gate["status"]=="release-ready"
    rt.clean_shutdown()


def test_health_log_is_bounded_and_redacts_sensitive_payload(tmp_path):
    rt=build_infinity7_runtime(tmp_path,SimulatedDesktopBackend())
    rt.health.event("test",{"token":"abc","message":"hello","safe":"ok"})
    rows=rt.health.recent(10); last=rows[-1]
    assert last["payload"]["token"]=="<redacted>" and last["payload"]["message"]=="<redacted>" and last["payload"]["safe"]=="ok"
    snap=rt.health.sample(rt); assert snap.overall in {"ok","guarded","degraded"}
    rt.clean_shutdown(); assert not rt.health.running


def test_support_bundle_requires_permission_and_guardian_lease(tmp_path):
    rt=build_infinity7_runtime(tmp_path,SimulatedDesktopBackend()); dst=tmp_path/"support.zip"
    with pytest.raises(PermissionError): rt.export_support(dst)
    rt.policy.set("support.export",True)
    with pytest.raises(PermissionError): rt.export_support(dst)
    rt.guardian.grant_action("support_export",ttl_s=60,uses=1); rt.export_support(dst)
    assert dst.exists()
    with zipfile.ZipFile(dst) as z:
        names=set(z.namelist()); assert "diagnostics.json" in names and "support_manifest.json" in names
        joined="\n".join(z.read(n).decode("utf-8",errors="ignore") for n in names)
        assert "workspace/" not in joined and "<redacted-local-path>" in joined
    rt.clean_shutdown()


def test_update_validation_and_staging_requires_owner_lease(tmp_path):
    rt=build_infinity7_runtime(tmp_path/"data",SimulatedDesktopBackend()); pkg=_update(tmp_path/"next.jarvisupdate")
    val=ReleaseManager.validate_package(pkg,"1.7.0rc1"); assert val.ok and val.version=="1.7.0rc2"
    with pytest.raises(PermissionError): rt.release.stage(pkg)
    rt.policy.set("release.manage",True)
    with pytest.raises(PermissionError): rt.release.stage(pkg)
    rt.guardian.grant_action("release_stage",ttl_s=60,uses=1); staged=rt.release.stage(pkg)
    assert staged.exists() and rt.release.status()["status"]=="staged"
    rt.clean_shutdown()


def test_update_rejects_downgrade_hash_tamper_and_path_traversal(tmp_path):
    old=_update(tmp_path/"old.jarvisupdate",version="1.6.9")
    assert not ReleaseManager.validate_package(old,"1.7.0rc1").ok
    good=_update(tmp_path/"good.jarvisupdate")
    bad=tmp_path/"bad.jarvisupdate"
    with zipfile.ZipFile(good) as src,zipfile.ZipFile(bad,"w") as out:
        for i in src.infolist(): out.writestr(i,b"tampered" if i.filename.startswith("payload/") else src.read(i.filename))
    assert not ReleaseManager.validate_package(bad,"1.7.0rc1").ok
    evil=tmp_path/"evil.jarvisupdate"
    data=b"x";manifest={"format":1,"product":"JARVIS GM","version":"1.7.0rc2","files":[{"path":"../x","sha256":hashlib.sha256(data).hexdigest(),"size":1}]}
    with zipfile.ZipFile(evil,"w") as z:z.writestr("release_manifest.json",json.dumps(manifest));z.writestr("payload/../x",data)
    assert not ReleaseManager.validate_package(evil,"1.7.0rc1").ok


def test_version_ordering():
    assert version_key("1.7.0a1")<version_key("1.7.0b1")<version_key("1.7.0rc1")<version_key("1.7.0")<version_key("1.8.0a1")


def test_safe_mode_revokes_final_release_sensitive_caps(tmp_path):
    assert "support.export" in SAFE_MODE_CAPABILITIES and "release.manage" in SAFE_MODE_CAPABILITIES
    p=PermissionPolicy(path=tmp_path/"permissions.json");p.set("support.export",True);p.set("release.manage",True)
    RecoveryManager(tmp_path).begin(p)
    p2=PermissionPolicy(path=tmp_path/"permissions.json");state=RecoveryManager(tmp_path).begin(p2)
    assert state.safe_mode and not p2.is_allowed("support.export") and not p2.is_allowed("release.manage")


def test_infinity7_diagnostics_and_backup_contract(tmp_path):
    rt=build_infinity7_runtime(tmp_path,SimulatedDesktopBackend())
    diag=rt.diagnostics.run(rt)
    assert diag["version"]=="1.7.0rc1" and diag["release_gate"]["status"]=="physical-pending"
    assert "acceptance.json" in BACKUP_ENTRIES
    rt.clean_shutdown()


def test_release_gate_blocks_storage_error(tmp_path, monkeypatch):
    rt=build_infinity7_runtime(tmp_path,SimulatedDesktopBackend())
    orig=rt.diagnostics.run
    def fake(runtime=None):
        d=orig(runtime);d["storage"]["memory.sqlite"]={"status":"error","detail":"broken"};return d
    monkeypatch.setattr(rt.diagnostics,"run",fake)
    gate=rt.release_gate.evaluate(rt);assert gate["status"]=="release-blocked" and gate["blockers"]
    rt.clean_shutdown()

def test_diagnostics_release_gate_has_no_recursive_error(tmp_path):
    rt=build_infinity7_runtime(tmp_path,SimulatedDesktopBackend())
    d=rt.diagnostics.run(rt)
    assert d["release_gate"]["status"]=="physical-pending"
    assert d["release_gate"].get("detail") is None
    rt.clean_shutdown()


def test_release_gate_blocks_safe_mode_or_disabled_guardian(tmp_path):
    rt=build_infinity7_runtime(tmp_path,SimulatedDesktopBackend())
    rt.policy.set("guardian.enforce",False)
    assert "guardian_disabled" in rt.release_gate.evaluate(rt)["blockers"]
    rt.policy.set("guardian.enforce",True); rt.recovery_state.safe_mode=True
    assert "safe_mode" in rt.release_gate.evaluate(rt)["blockers"]
    rt.clean_shutdown()


def test_update_rejects_duplicate_members(tmp_path):
    p=tmp_path/"dup.jarvisupdate"; data=b"x"
    manifest={"format":1,"product":"JARVIS GM","version":"1.7.0rc2","files":[{"path":"x","sha256":hashlib.sha256(data).hexdigest(),"size":1}]}
    import warnings
    with warnings.catch_warnings():
        warnings.simplefilter("ignore",UserWarning)
        with zipfile.ZipFile(p,"w") as z:
            z.writestr("release_manifest.json",json.dumps(manifest)); z.writestr("payload/x",data); z.writestr("payload/x",data)
    v=ReleaseManager.validate_package(p,"1.7.0rc1")
    assert not v.ok and any("Duplicate" in e for e in v.errors)

def test_crash_journal_redacts_common_secret_shapes(tmp_path):
    from jarvis_gm.product.crashlog import CrashJournal
    j=CrashJournal(tmp_path)
    try: raise RuntimeError("token=SUPERSECRET Bearer abcdefghijklmnop https://x.test/?key=QUERYSECRET")
    except RuntimeError as exc:
        import sys
        j.record_exception(type(exc),exc,sys.exc_info()[2])
    text=(tmp_path/"logs"/"crash.jsonl").read_text(encoding="utf-8")
    assert "SUPERSECRET" not in text and "abcdefghijklmnop" not in text and "QUERYSECRET" not in text
    assert "<redacted>" in text


def test_corrupt_acceptance_fails_safe_to_pending(tmp_path):
    (tmp_path/"acceptance.json").write_text("{not json",encoding="utf-8")
    rt=build_infinity7_runtime(tmp_path,SimulatedDesktopBackend())
    r=rt.acceptance.report();assert r["counts"]["pending"]==len(r["checks"]) and not r["all_required_passed"]
    rt.clean_shutdown()


def test_health_monitor_stops_on_global_stop(tmp_path):
    rt=build_infinity7_runtime(tmp_path,SimulatedDesktopBackend())
    assert rt.health.running
    rt.kill_switch.engage()
    deadline=time.time()+3
    while rt.health.running and time.time()<deadline: time.sleep(.05)
    assert not rt.health.running
    rt.kill_switch.reset();rt.ensure_health_monitor();assert rt.health.running
    rt.clean_shutdown()


def test_acceptance_backup_restore_roundtrip(tmp_path):
    from jarvis_gm.product.backup import BackupManager,apply_pending_restore
    root=tmp_path/"data";rt=build_infinity7_runtime(root,SimulatedDesktopBackend())
    rt.acceptance.set_owner_result("camera_hands","passed","real owner test")
    backup=rt.backup.create(tmp_path/"owner.jarvisbackup");rt.clean_shutdown()
    (root/"acceptance.json").unlink();BackupManager(root).stage_restore(backup);assert apply_pending_restore(root)
    rt2=build_infinity7_runtime(root,SimulatedDesktopBackend());assert rt2.acceptance.report()["checks"]["camera_hands"]["status"]=="passed";rt2.clean_shutdown()

def test_support_bundle_redacts_device_identity_and_acceptance_notes(tmp_path):
    rt=build_infinity7_runtime(tmp_path,SimulatedDesktopBackend())
    rt.acceptance.set_owner_result("camera_hands","failed","private note 555-1234")
    dev,_=rt.mobile.manager.devices.pair("Private Phone",device_id="secret-device",relay_url="https://private.example:8765",cert_fingerprint="11"*32)
    rt.policy.set("support.export",True);rt.guardian.grant_action("support_export",ttl_s=60,uses=1)
    p=rt.export_support(tmp_path/"s.zip")
    with zipfile.ZipFile(p) as z: text="\n".join(z.read(n).decode("utf-8",errors="ignore") for n in z.namelist())
    assert "Private Phone" not in text and "secret-device" not in text and "private.example" not in text and "private note" not in text
    assert "<redacted-by-support-export>" in text
    rt.clean_shutdown()

def test_final_release_identity_is_consistent():
    root=Path(__file__).resolve().parents[1]
    assert 'version = "1.7.0rc1"' in (root/"pyproject.toml").read_text(encoding="utf-8")
    assert '__version__ = "1.7.0rc1"' in (root/"src/jarvis_gm/__init__.py").read_text(encoding="utf-8")
    iss=(root/"installer/JARVIS_GM.iss").read_text(encoding="utf-8")
    assert 'MyAppVersion "1.7.0-rc1"' in iss and "JARVIS_GM_Setup_INFINITY7" in iss and "VersionInfoVersion=1.7.0.1" in iss
    android=(root/"android_companion/app/build.gradle.kts").read_text(encoding="utf-8")
    assert 'versionCode = 7' in android and 'versionName = "1.7.0-rc1"' in android

def test_mobile_relay_never_suggests_loopback(monkeypatch,tmp_path):
    from jarvis_gm.mobile.system import MobileSubsystem
    from jarvis_gm.product.secrets import CredentialStore
    import socket as _socket
    m=MobileSubsystem.create(tmp_path,CredentialStore("JARVIS_TEST"))
    monkeypatch.setattr(_socket,"getaddrinfo",lambda *a,**k:[(_socket.AF_INET,_socket.SOCK_STREAM,0,"",("127.0.0.1",0))])
    class S:
        def connect(self,*a,**k): raise OSError("offline")
        def close(self): pass
    monkeypatch.setattr(_socket,"socket",lambda *a,**k:S())
    with pytest.raises(RuntimeError,match="LAN address"):
        m.suggest_relay_url()
