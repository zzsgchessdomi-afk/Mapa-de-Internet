from __future__ import annotations

from io import BytesIO
from pathlib import Path
import tempfile
import time

from PIL import Image, ImageDraw

from jarvis_gm.control.simulated_backend import SimulatedDesktopBackend
from jarvis_gm.screen.capture import CaptureFrame
from jarvis_gm.screen.grounding import GroundingConfig, GroundingEngine, TargetRegistry
from jarvis_gm.screen.models import GroundingStatus, Rect, ScreenElement
from jarvis_gm.screen.observer import ScreenObserver
from jarvis_gm.runtime import build_phase5_runtime
from jarvis_gm.perception.events import PerceptionEvent


class FixedScanner:
    def __init__(self, elements): self.elements=list(elements)
    def scan_active_window(self, backend, max_elements=600): return list(self.elements)[:max_elements]


class SequenceCapture:
    def __init__(self, variants=None):
        self.variants=list(variants or [0]); self.i=0
    def capture(self, rect=None, window_handle=None):
        value=self.variants[min(self.i, len(self.variants)-1)]; self.i+=1
        img=Image.new("RGB", (1920,1080), "white")
        if value:
            d=ImageDraw.Draw(img); d.rectangle((280,250,430,330), fill="black")
        out=BytesIO(); img.save(out, format="PNG")
        return CaptureFrame(out.getvalue(), 1920,1080, f"frame-{value}")


def button(name="Guardar", rect=Rect(300,250,420,310), id="save", interactive=True):
    return ScreenElement(id=id,name=name,control_type="Button",rect=rect,automation_id=id,interactive=interactive,patterns=("Invoke",))


def _event(kind, payload=None, confidence=1.0, ts=None):
    return PerceptionEvent(kind, "vision.hand" if kind.startswith("gesture.") else "voice", payload or {}, confidence, ts or time.time())


def _wait(fn, timeout=1.0):
    end=time.time()+timeout
    while time.time()<end:
        if fn(): return True
        time.sleep(.01)
    return fn()


def test_point_is_grounded_to_specific_interactive_control():
    b=SimulatedDesktopBackend(); obs=ScreenObserver(b, FixedScanner([button()]), SequenceCapture([0]))
    g=GroundingEngine(obs, config=GroundingConfig(min_confidence=.65))
    result=g.ground_point(360/1919, 280/1079, voice_text="haz clic en ese botón guardar", point_confidence=.99)
    assert result.status == GroundingStatus.GROUNDED
    assert result.target and result.target.label == "Guardar"
    assert result.target.source == "uia"


def test_overlapping_equally_plausible_controls_are_ambiguous():
    b=SimulatedDesktopBackend()
    a=button("Aceptar", Rect(300,250,420,310), "a")
    c=button("Confirmar", Rect(300,250,420,310), "c")
    obs=ScreenObserver(b, FixedScanner([a,c]), SequenceCapture([0]))
    g=GroundingEngine(obs, config=GroundingConfig(min_confidence=.60, ambiguity_margin=.12))
    result=g.ground_point(360/1919, 280/1079, point_confidence=.99)
    assert result.status == GroundingStatus.AMBIGUOUS
    assert len(result.candidates) >= 2


def test_spoken_label_disambiguates_overlapping_controls():
    b=SimulatedDesktopBackend()
    a=button("Guardar", Rect(300,250,420,310), "save")
    c=button("Cancelar", Rect(300,250,420,310), "cancel")
    obs=ScreenObserver(b, FixedScanner([a,c]), SequenceCapture([0]))
    g=GroundingEngine(obs, config=GroundingConfig(min_confidence=.60, ambiguity_margin=.08))
    result=g.ground_point(360/1919, 280/1079, voice_text="haz clic en ese botón guardar", point_confidence=.99)
    assert result.status == GroundingStatus.GROUNDED
    assert result.target and result.target.label == "Guardar"


def test_target_revalidation_fails_if_control_disappears():
    b=SimulatedDesktopBackend(); scanner=FixedScanner([button()]); obs=ScreenObserver(b, scanner, SequenceCapture([0]))
    g=GroundingEngine(obs, config=GroundingConfig(min_confidence=.60))
    result=g.ground_point(360/1919, 280/1079, point_confidence=.99)
    assert result.target
    scanner.elements=[]
    ok, reason, _=g.revalidate(result.target)
    assert not ok and "moved or disappeared" in reason


def test_registry_rejects_expired_target():
    b=SimulatedDesktopBackend(); obs=ScreenObserver(b, FixedScanner([button()]), SequenceCapture([0]))
    reg=TargetRegistry(); g=GroundingEngine(obs, reg, GroundingConfig(min_confidence=.60, target_ttl_s=.01))
    result=g.ground_point(360/1919, 280/1079, point_confidence=.99); assert result.target
    time.sleep(.02)
    try: reg.get(result.target.id)
    except KeyError: pass
    else: raise AssertionError("stale target should be rejected")


def test_phase5_voice_plus_point_uses_grounded_click_and_observes_effect():
    with tempfile.TemporaryDirectory() as d:
        b=SimulatedDesktopBackend()
        # grounding capture, before-action capture, after-action capture changed
        obs=ScreenObserver(b, FixedScanner([button()]), SequenceCapture([0,0,1]))
        rt=build_phase5_runtime(Path(d), b, obs); rt.policy.set("input.control", True); rt.start_bridge()
        t=time.time(); rt.perception.bus.publish(_event("gesture.armed", ts=t))
        rt.perception.bus.publish(_event("gesture.point", {"x":360/1919,"y":280/1079}, .99, t+.01))
        rt.perception.bus.publish(_event("voice.command", {"text":"haz clic en ese botón guardar"}, .99, t+.10))
        assert _wait(lambda: b.cursor == (360,280))
        assert _wait(lambda: any(x["event_type"]=="interaction.verified" and x["payload"].get("action")=="grounded_click" for x in rt.orchestrator.memory.recent_events(40)))
        events=rt.orchestrator.memory.recent_events(50)
        verified=[x for x in events if x["event_type"]=="interaction.verified" and x["payload"].get("action")=="grounded_click"]
        assert verified and verified[-1]["payload"]["ok"] is True
        rt.bridge.stop()


def test_phase5_refuses_deictic_click_when_no_control_is_grounded():
    with tempfile.TemporaryDirectory() as d:
        b=SimulatedDesktopBackend(); obs=ScreenObserver(b, FixedScanner([]), SequenceCapture([0]))
        rt=build_phase5_runtime(Path(d), b, obs); rt.policy.set("input.control", True); rt.start_bridge()
        t=time.time(); rt.perception.bus.publish(_event("gesture.armed", ts=t))
        rt.perception.bus.publish(_event("gesture.point", {"x":.5,"y":.5}, .99, t+.01))
        rt.perception.bus.publish(_event("voice.command", {"text":"haz clic ahí"}, .99, t+.10))
        time.sleep(.15); rt.bridge.stop()
        events=rt.orchestrator.memory.recent_events(50)
        assert not any(x["event_type"]=="interaction.request" and x["payload"].get("action")=="grounded_click" for x in events)
        assert any(x["event_type"]=="intent.ambiguous" for x in events)

class FakeCloud:
    def __init__(self, element=None, reason="visual match"):
        self.element=element; self.reason=reason; self.calls=0
    def ground(self, snapshot, nx, ny, voice_text=None):
        self.calls += 1
        class Result: pass
        r=Result(); r.element=self.element; r.reason=self.reason; return r


def test_local_screen_policy_can_disable_grounding_entirely():
    b=SimulatedDesktopBackend(); obs=ScreenObserver(b, FixedScanner([button()]), SequenceCapture([0]))
    g=GroundingEngine(obs, observe_allowed=lambda: False)
    result=g.ground_point(.2,.2,voice_text="haz clic ahí")
    assert result.status == GroundingStatus.UNRESOLVED
    assert "disabled by user policy" in result.reason


def test_cloud_fallback_is_never_called_without_explicit_permission():
    b=SimulatedDesktopBackend(); obs=ScreenObserver(b, FixedScanner([]), SequenceCapture([0]))
    visual=ScreenElement("visual", "Botón visual", "button", Rect(300,250,420,310), source="gemini_vision", confidence=.88, interactive=True)
    cloud=FakeCloud(visual)
    g=GroundingEngine(obs, cloud=cloud, cloud_allowed=lambda: False)
    result=g.ground_point(360/1919,280/1079,point_confidence=.99)
    assert result.status == GroundingStatus.UNRESOLVED and cloud.calls == 0


def test_opt_in_cloud_fallback_can_ground_custom_rendered_canvas_target():
    b=SimulatedDesktopBackend(); obs=ScreenObserver(b, FixedScanner([]), SequenceCapture([0]))
    visual=ScreenElement("visual", "Nodo 3D", "canvas_object", Rect(300,250,420,310), source="gemini_vision", confidence=.88)
    cloud=FakeCloud(visual)
    g=GroundingEngine(obs, cloud=cloud, cloud_allowed=lambda: True)
    result=g.ground_point(360/1919,280/1079,voice_text="selecciona eso",point_confidence=.99)
    assert result.status == GroundingStatus.GROUNDED and result.target
    assert result.target.source == "gemini_vision" and cloud.calls == 1


def test_effect_verifier_does_not_claim_success_when_screen_did_not_change():
    b=SimulatedDesktopBackend(); obs=ScreenObserver(b, FixedScanner([button()]), SequenceCapture([0,0]))
    before=obs.snapshot(include_image=True); after=obs.snapshot(include_image=True)
    effect=obs.verify_effect(before,after,button().rect)
    assert effect.observed is False
    assert "no post-action effect" in effect.reason
