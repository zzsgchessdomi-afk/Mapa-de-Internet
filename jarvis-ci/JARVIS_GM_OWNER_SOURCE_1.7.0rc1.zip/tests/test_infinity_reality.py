from __future__ import annotations

from pathlib import Path
import json
import time
import pytest

from jarvis_gm.core.permissions import PermissionPolicy
from jarvis_gm.core.kill_switch import KillSwitch
from jarvis_gm.guardian.store import GuardianStore
from jarvis_gm.guardian.engine import Guardian
from jarvis_gm.reality.store import RealityStore
from jarvis_gm.reality.engine import RealityBridge
from jarvis_gm.reality.models import DeviceRisk, DeviceState
from jarvis_gm.reality.adapters.home_assistant import HomeAssistantAdapter, HomeAssistantConfig
from jarvis_gm.product.backup import BackupManager


class FakeCreds:
    available=True
    def __init__(self): self.values={}
    def get(self,k): return self.values.get(k)
    def set(self,k,v): self.values[k]=v


class FakeAdapter:
    name="fake"
    def __init__(self): self.states={}
    def available(self): return True,"ready"
    def state(self,device):
        return DeviceState(device.id,self.states.get(device.id,"off"),{},time.time(),self.name)
    def command(self,device,command,args):
        if command=="on": self.states[device.id]="on"
        elif command=="off": self.states[device.id]="off"
        elif command=="toggle": self.states[device.id]="off" if self.states.get(device.id,"off")=="on" else "on"
        else: raise PermissionError(command)
        return {"ok":True}


def bridge(tmp_path: Path):
    policy=PermissionPolicy(path=tmp_path/"permissions.json")
    kill=KillSwitch(tmp_path/"STOP")
    guardian=Guardian(GuardianStore(tmp_path/"guardian.sqlite3"),policy=policy,kill_switch=kill)
    b=RealityBridge(RealityStore(tmp_path/"reality.sqlite3"),policy=policy,guardian=guardian,kill_switch=kill,credentials=FakeCreds(),config_path=tmp_path/"reality_config.json")
    fake=FakeAdapter();b.add_adapter(fake)
    return b,policy,guardian,fake


def enroll_low(b,policy,guardian):
    policy.set("reality.manage",True);guardian.grant_action("reality_enroll",ttl_s=30,uses=1)
    return b.enroll(adapter="fake",native_id="light.demo",label="Demo Light",kind="light",capabilities=("on","off","toggle"),risk=DeviceRisk.LOW)


def test_reality_defaults_are_read_only(tmp_path):
    p=PermissionPolicy(path=tmp_path/"permissions.json")
    assert p.is_allowed("reality.read")
    assert not p.is_allowed("reality.control")
    assert not p.is_allowed("reality.manage")
    assert not p.is_allowed("reality.security")
    assert not p.is_allowed("reality.cloud")


def test_enrollment_requires_owner_lease(tmp_path):
    b,p,g,_=bridge(tmp_path);p.set("reality.manage",True)
    with pytest.raises(PermissionError):
        b.enroll(adapter="fake",native_id="light.a",label="A",kind="light",capabilities=("on",),risk=DeviceRisk.LOW)
    g.grant_action("reality_enroll",ttl_s=30,uses=1)
    d=b.enroll(adapter="fake",native_id="light.a",label="A",kind="light",capabilities=("on",),risk=DeviceRisk.LOW)
    assert d.label=="A"


def test_low_risk_command_needs_control_and_verifies(tmp_path):
    b,p,g,f=bridge(tmp_path);d=enroll_low(b,p,g)
    with pytest.raises(PermissionError): b.command(d.id,"on")
    p.set("reality.control",True)
    out=b.command(d.id,"on")
    assert out.ok and out.before.state=="off" and out.after.state=="on"
    assert b.store.recent_events(1)[0]["event_type"]=="command"


def test_command_cannot_use_unenrolled_capability(tmp_path):
    b,p,g,_=bridge(tmp_path);d=enroll_low(b,p,g);p.set("reality.control",True)
    with pytest.raises(PermissionError): b.command(d.id,"delete_everything")


def test_high_risk_requires_security_permission_and_owner_lease(tmp_path):
    b,p,g,_=bridge(tmp_path);p.set("reality.manage",True);g.grant_action("reality_enroll",ttl_s=30,uses=1)
    d=b.enroll(adapter="fake",native_id="test.high",label="High",kind="test",capabilities=("on",),risk=DeviceRisk.HIGH)
    p.set("reality.control",True)
    with pytest.raises(PermissionError): b.command(d.id,"on")
    p.set("reality.security",True)
    with pytest.raises(PermissionError): b.command(d.id,"on")
    g.grant_capability("reality.security",ttl_s=30,uses=1)
    assert b.command(d.id,"on").ok


def test_home_assistant_config_never_writes_token_plaintext(tmp_path):
    b,p,g,_=bridge(tmp_path);p.set("reality.manage",True);g.grant_action("reality_configure",ttl_s=30,uses=1)
    b.configure_home_assistant("http://127.0.0.1:8123","super-secret-token")
    text=(tmp_path/"reality_config.json").read_text(encoding="utf-8")
    assert "super-secret-token" not in text and "127.0.0.1:8123" in text
    assert b.credentials.get("JARVIS_HOME_ASSISTANT_TOKEN")=="super-secret-token"


def test_home_assistant_rejects_public_plain_http():
    with pytest.raises(ValueError):
        HomeAssistantAdapter(HomeAssistantConfig("http://8.8.8.8:8123",lambda:"x"))


def test_home_assistant_limits_actuation_domains():
    adapter=HomeAssistantAdapter(HomeAssistantConfig("http://127.0.0.1:8123",lambda:"x"))
    class D: native_id="lock.front";id="1"
    with pytest.raises(PermissionError): adapter.command(D(),"unlock",{})


def test_backup_contract_includes_reality_without_secret(tmp_path):
    (tmp_path/"reality.sqlite3").write_bytes(b"db")
    (tmp_path/"reality_config.json").write_text(json.dumps({"home_assistant":{"base_url":"http://127.0.0.1:8123"}}),encoding="utf-8")
    archive=BackupManager(tmp_path,product_version="1.6.0a6").create(tmp_path/"x.jarvisbackup")
    validation=BackupManager.validate(archive)
    assert validation.ok and validation.files==2

class NoChangeAdapter(FakeAdapter):
    name="nochange"
    def command(self,device,command,args): return {"ok":True}


def test_transport_success_without_state_change_is_unverified(tmp_path):
    b,p,g,_=bridge(tmp_path); p.set("reality.manage",True); g.grant_action("reality_enroll",ttl_s=30,uses=1)
    nc=NoChangeAdapter(); b.add_adapter(nc); b.verify_timeout_s=0.01; b.verify_interval_s=0.01
    d=b.enroll(adapter="nochange",native_id="light.nochange",label="No Change",kind="light",capabilities=("on",),risk=DeviceRisk.LOW)
    p.set("reality.control",True)
    out=b.command(d.id,"on")
    assert not out.ok and "not verified" in out.detail


def test_monitor_stops_on_global_stop(tmp_path):
    b,p,g,_=bridge(tmp_path); d=enroll_low(b,p,g)
    p.set("reality.read",True); p.set("reality.continuous",True)
    b.start_monitor(interval_s=1.0)
    assert b.monitoring
    b.kill_switch.engage()
    end=time.time()+0.8
    while b.monitoring and time.time()<end: time.sleep(0.02)
    assert not b.monitoring


def test_reality_world_context_requires_separate_cloud_permission(tmp_path):
    from jarvis_gm.world.store import WorldModelStore
    from jarvis_gm.world.manager import WorldModelManager
    wm=WorldModelManager(WorldModelStore(tmp_path/"world.sqlite3"))
    wm.store.upsert_entity(kind="physical_device",key="lamp",label="Secret Lamp",attributes={"state":"on"},source="reality")
    wm.store.observe("reality.state",{"device":"Secret Lamp","state":"on"},source="reality")
    private=wm.cloud_context_for_goal("x",allow_reality=False)
    allowed=wm.cloud_context_for_goal("x",allow_reality=True)
    assert "Secret Lamp" not in str(private)
    assert "Secret Lamp" in str(allowed)


def test_personal_os_reality_route_still_uses_underlying_permissions(tmp_path):
    from jarvis_gm.runtime import build_infinity6_runtime
    from jarvis_gm.control.simulated_backend import SimulatedDesktopBackend
    rt=build_infinity6_runtime(tmp_path,SimulatedDesktopBackend())
    try:
        fake=FakeAdapter();rt.reality.add_adapter(fake);rt.policy.set("reality.manage",True);rt.guardian.grant_action("reality_enroll",ttl_s=30,uses=1)
        d=rt.reality.enroll(adapter="fake",native_id="light.os",label="OS Lamp",kind="light",capabilities=("on",),risk=DeviceRisk.LOW)
        rt.personal_os.sync(); physical=rt.personal_os.resources(kind="physical")
        ref=next(x["id"] for x in physical if x["label"]=="OS Lamp")
        rt.policy.set("os.route",True)
        blocked=rt.personal_os.execute("control",resource_ref=ref,payload={"command":"on"})
        assert not blocked["verified"] and blocked["result"]["blocked"]
        rt.policy.set("reality.control",True)
        ok=rt.personal_os.execute("control",resource_ref=ref,payload={"command":"on"})
        assert ok["verified"]
    finally: rt.clean_shutdown()

class OfflineAdapter(FakeAdapter):
    name="offline"
    def available(self): return False,"offline"
    def state(self,device): raise RuntimeError("offline")


def test_reality_backup_restore_roundtrip(tmp_path):
    root=tmp_path/"data"; root.mkdir()
    (root/"reality.sqlite3").write_bytes(b"reality-db-original")
    (root/"reality_config.json").write_text('{"home_assistant":{"base_url":"http://127.0.0.1:8123"}}',encoding="utf-8")
    manager=BackupManager(root,product_version="1.6.0a6")
    archive=manager.create(tmp_path/"r.jarvisbackup")
    (root/"reality.sqlite3").write_bytes(b"changed")
    manager.stage_restore(archive)
    from jarvis_gm.product.backup import apply_pending_restore
    assert apply_pending_restore(root)
    assert (root/"reality.sqlite3").read_bytes()==b"reality-db-original"


def test_safe_mode_revokes_reality_authority(tmp_path):
    from jarvis_gm.product.recovery import RecoveryManager
    p=PermissionPolicy(path=tmp_path/"permissions.json")
    for cap in ("reality.continuous","reality.control","reality.manage","reality.security","reality.cloud"):
        p.set(cap,True)
    RecoveryManager(tmp_path).begin(p)  # deliberately unclean
    p2=PermissionPolicy(path=tmp_path/"permissions.json")
    state=RecoveryManager(tmp_path).begin(p2)
    assert state.safe_mode
    assert all(not p2.is_allowed(cap) for cap in ("reality.continuous","reality.control","reality.manage","reality.security","reality.cloud"))


def test_offline_device_fails_closed_without_fake_success(tmp_path):
    b,p,g,_=bridge(tmp_path); off=OfflineAdapter(); b.add_adapter(off)
    p.set("reality.manage",True);g.grant_action("reality_enroll",ttl_s=30,uses=1)
    d=b.enroll(adapter="offline",native_id="light.dead",label="Dead",kind="light",capabilities=("on",),risk=DeviceRisk.LOW)
    p.set("reality.control",True)
    with pytest.raises(RuntimeError,match="offline"): b.command(d.id,"on")
    assert not any(e["event_type"]=="command" and e["payload"].get("ok") for e in b.store.recent_events(20))
