from __future__ import annotations

from pathlib import Path
import tempfile
import time

from jarvis_gm.control.simulated_backend import SimulatedDesktopBackend
from jarvis_gm.perception.events import PerceptionEvent
from jarvis_gm.runtime import build_phase3_runtime
from jarvis_gm.core.models import GoalState


def test_operator_permissions_default_deny_and_persist():
    with tempfile.TemporaryDirectory() as d:
        b=SimulatedDesktopBackend(); rt=build_phase3_runtime(Path(d), b)
        g=rt.orchestrator.run("mueve el cursor a 100, 200")
        assert g.state != GoalState.VERIFIED
        assert b.cursor == (0,0)
        rt.policy.set("input.control", True)
        g=rt.orchestrator.run("mueve el cursor a 100, 200")
        assert g.state == GoalState.VERIFIED
        assert b.cursor == (100,200)
        rt2=build_phase3_runtime(Path(d), SimulatedDesktopBackend())
        assert rt2.policy.is_allowed("input.control") is True


def test_open_app_is_registry_limited():
    with tempfile.TemporaryDirectory() as d:
        b=SimulatedDesktopBackend(); rt=build_phase3_runtime(Path(d), b); rt.policy.set("app.launch",True)
        assert rt.orchestrator.run("abre notepad").state == GoalState.VERIFIED
        assert b.opened_apps[-1][0] == "notepad.exe"
        bad=rt.orchestrator.run("abre cmd /c whoami")
        assert bad.state != GoalState.VERIFIED
        assert len(b.opened_apps)==1


def test_url_validation_and_permission():
    with tempfile.TemporaryDirectory() as d:
        b=SimulatedDesktopBackend(); rt=build_phase3_runtime(Path(d), b); rt.policy.set("browser.open",True)
        ok=rt.orchestrator.run("abre https://example.com")
        assert ok.state == GoalState.VERIFIED and b.opened_urls == ["https://example.com"]


def test_file_scope_blocks_escape():
    with tempfile.TemporaryDirectory() as d:
        root=Path(d); b=SimulatedDesktopBackend(); rt=build_phase3_runtime(root,b)
        rt.policy.set("filesystem.write",True); rt.policy.set("filesystem.read",True)
        inside=root/"workspace"/"docs"
        assert rt.orchestrator.run(f"crea carpeta: {inside}").state == GoalState.VERIFIED
        outside=root.parent/"jarvis_should_not_write_here"
        g=rt.orchestrator.run(f"crea carpeta: {outside}")
        assert g.state != GoalState.VERIFIED
        assert not outside.exists()


def test_kill_switch_blocks_direct_gateway_too():
    with tempfile.TemporaryDirectory() as d:
        b=SimulatedDesktopBackend(); rt=build_phase3_runtime(Path(d),b); rt.policy.set("input.control",True)
        rt.kill_switch.engage()
        action=b.cursor
        # retrieve through bridge gateway indirectly is cumbersome; typed action uses same executor.
        g=rt.orchestrator.run("mueve el cursor a 10, 20")
        assert g.state != GoalState.VERIFIED and b.cursor == action


def test_voice_bridge_runs_through_permissions():
    with tempfile.TemporaryDirectory() as d:
        b=SimulatedDesktopBackend(); rt=build_phase3_runtime(Path(d),b); rt.start_bridge()
        rt.perception.bus.publish(PerceptionEvent("voice.command","voice",{"text":"mueve el cursor a 321, 222"}))
        time.sleep(0.08)
        assert b.cursor == (0,0)
        rt.policy.set("input.control",True)
        rt.perception.bus.publish(PerceptionEvent("voice.command","voice",{"text":"mueve el cursor a 321, 222"}))
        deadline=time.time()+1
        while b.cursor != (321,222) and time.time()<deadline: time.sleep(0.01)
        rt.bridge.stop(); assert b.cursor == (321,222)


def test_gesture_point_pinch_and_swipe_use_gateway():
    with tempfile.TemporaryDirectory() as d:
        b=SimulatedDesktopBackend(); rt=build_phase3_runtime(Path(d),b)
        for cap in ("input.control","window.control"): rt.policy.set(cap,True)
        rt.start_bridge()
        rt.perception.bus.publish(PerceptionEvent("gesture.point","vision.hand",{"x":0.5,"y":0.25}))
        deadline=time.time()+1
        while b.cursor==(0,0) and time.time()<deadline: time.sleep(0.01)
        assert abs(b.cursor[0]-960)<=1 and abs(b.cursor[1]-270)<=1
        rt.perception.bus.publish(PerceptionEvent("gesture.pinch_start","vision.hand",{"x":0.5,"y":0.25}))
        rt.perception.bus.publish(PerceptionEvent("gesture.pinch_end","vision.hand",{"x":0.5,"y":0.25}))
        rt.perception.bus.publish(PerceptionEvent("gesture.swipe_right","vision.hand",{}))
        deadline=time.time()+1
        while ("alt","tab") not in b.hotkeys and time.time()<deadline: time.sleep(0.01)
        rt.bridge.stop(); assert "left" not in b.buttons; assert ("alt","tab") in b.hotkeys


def test_two_hand_transform_resizes_active_window():
    with tempfile.TemporaryDirectory() as d:
        b=SimulatedDesktopBackend(); rt=build_phase3_runtime(Path(d),b); rt.policy.set("window.control",True); rt.start_bridge()
        before=b.active_window().width
        rt.perception.bus.publish(PerceptionEvent("gesture.transform","vision.hand",{"center":{"x":0.5,"y":0.5},"scale_delta":1.2,"rotation_delta_deg":0}))
        deadline=time.time()+1
        while b.active_window().width==before and time.time()<deadline: time.sleep(0.01)
        rt.bridge.stop(); assert b.active_window().width > before


def test_hotkey_and_text_commands():
    with tempfile.TemporaryDirectory() as d:
        b=SimulatedDesktopBackend(); rt=build_phase3_runtime(Path(d),b); rt.policy.set("input.control",True)
        assert rt.orchestrator.run("presiona ctrl+l").state == GoalState.VERIFIED
        assert b.hotkeys[-1] == ("ctrl","l")
        assert rt.orchestrator.run("escribe: hola mundo").state == GoalState.VERIFIED
        assert b.typed[-1] == "hola mundo"

def test_emergency_release_clears_held_mouse_even_before_kill():
    with tempfile.TemporaryDirectory() as d:
        b=SimulatedDesktopBackend(); rt=build_phase3_runtime(Path(d),b); rt.policy.set("input.control",True)
        b.mouse_down("left"); b.mouse_down("right")
        assert b.buttons == {"left","right"}
        rt.emergency_release_inputs(); rt.kill_switch.engage()
        assert not b.buttons


def test_bridge_restart_discards_stale_queue_items():
    with tempfile.TemporaryDirectory() as d:
        b=SimulatedDesktopBackend(); rt=build_phase3_runtime(Path(d),b); rt.policy.set("input.control",True)
        rt.start_bridge(); rt.bridge.stop()
        # This event has no subscriber now and must not execute after restart.
        rt.perception.bus.publish(PerceptionEvent("voice.command","voice",{"text":"mueve el cursor a 444, 555"}))
        rt.start_bridge(); time.sleep(0.05); rt.bridge.stop()
        assert b.cursor == (0,0)
