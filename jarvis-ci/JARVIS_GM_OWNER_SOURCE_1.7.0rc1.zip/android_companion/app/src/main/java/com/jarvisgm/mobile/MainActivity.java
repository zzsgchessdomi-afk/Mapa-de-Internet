package com.jarvisgm.mobile;

import android.Manifest;
import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public final class MainActivity extends Activity {
    private EditText pairing; private TextView status;
    @Override public void onCreate(Bundle state){super.onCreate(state);buildUi();if(getIntent()!=null&&getIntent().getData()!=null)pairing.setText(getIntent().getData().toString());refresh();}

    private void buildUi(){
        ScrollView scroll=new ScrollView(this);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(32,32,32,32);scroll.addView(root);
        TextView title=new TextView(this);title.setText("JARVIS GM Companion");title.setTextSize(26);root.addView(title);
        TextView desc=new TextView(this);desc.setText("Tu teléfono conserva la autoridad de Android. El puente usa TLS fijado + comandos firmados. El PIN de pantalla no se guarda ni se transmite.");root.addView(desc);
        pairing=new EditText(this);pairing.setHint("Pega aquí jarvisgm://pair/…");root.addView(pairing);
        addButton(root,"Guardar emparejamiento",v->savePairing());
        addButton(root,"Conceder permisos de ubicación/contactos",v->requestRuntimePermissions());
        addButton(root,"Permitir ubicación en segundo plano",v->openPermissionSettings());
        addButton(root,"Activar permiso para BLOQUEO remoto",v->requestDeviceAdmin());
        addButton(root,"Activar puente + anti-theft",v->startBridge(true));
        addButton(root,"Activar puente sin GPS continuo",v->startBridge(false));
        addButton(root,"Detener puente",v->{stopService(new Intent(this,RelayService.class));getSharedPreferences("jarvis_mobile",MODE_PRIVATE).edit().putBoolean("anti_theft",false).apply();refresh();});
        addButton(root,"Probar autenticación del sistema",v->startActivity(new Intent(this,UnlockAssistActivity.class)));
        addButton(root,"Olvidar PC emparejado",v->{new SecurePairingStore(this).clear();stopService(new Intent(this,RelayService.class));refresh();});
        status=new TextView(this);status.setPadding(0,28,0,0);root.addView(status);setContentView(scroll);
    }
    private void addButton(LinearLayout root,String text,View.OnClickListener listener){Button b=new Button(this);b.setText(text);b.setOnClickListener(listener);root.addView(b);}

    private void savePairing(){try{PairingConfig c=PairingConfig.fromUri(pairing.getText().toString());new SecurePairingStore(this).save(c);Toast.makeText(this,"Emparejado con "+c.deviceName,Toast.LENGTH_LONG).show();refresh();}catch(Exception e){Toast.makeText(this,"No se pudo emparejar: "+e.getMessage(),Toast.LENGTH_LONG).show();}}
    private void requestRuntimePermissions(){
        java.util.ArrayList<String> p=new java.util.ArrayList<>();
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.ACCESS_FINE_LOCATION);
        if(checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.READ_CONTACTS);
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.POST_NOTIFICATIONS);
        if(!p.isEmpty())requestPermissions(p.toArray(new String[0]),2001);else Toast.makeText(this,"Permisos base ya concedidos",Toast.LENGTH_SHORT).show();
    }
    private void openPermissionSettings(){Intent i=new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:"+getPackageName()));startActivity(i);}
    private void requestDeviceAdmin(){DevicePolicyManager dpm=(DevicePolicyManager)getSystemService(DEVICE_POLICY_SERVICE);ComponentName admin=new ComponentName(this,JarvisDeviceAdminReceiver.class);if(dpm!=null&&dpm.isAdminActive(admin)){Toast.makeText(this,"Permiso de bloqueo ya activo",Toast.LENGTH_SHORT).show();return;}Intent i=new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN,admin);i.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,"JARVIS solo usará este permiso para bloquear tu propio teléfono cuando tú lo ordenes.");startActivity(i);}
    private void startBridge(boolean anti){
        try{if(new SecurePairingStore(this).load()==null){Toast.makeText(this,"Empareja primero el teléfono",Toast.LENGTH_LONG).show();return;}}catch(Exception e){Toast.makeText(this,"Emparejamiento inválido",Toast.LENGTH_LONG).show();return;}
        if(anti && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
            Toast.makeText(this,"Concede ubicación antes de activar anti-theft",Toast.LENGTH_LONG).show();return;
        }
        if(anti && Build.VERSION.SDK_INT>=29 && checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION)!=PackageManager.PERMISSION_GRANTED){
            Toast.makeText(this,"Anti-theft funcionará ahora, pero tras reinicio la ubicación quedará limitada hasta conceder ubicación en segundo plano.",Toast.LENGTH_LONG).show();
        }
        getSharedPreferences("jarvis_mobile",MODE_PRIVATE).edit().putBoolean("anti_theft",anti).apply();Intent i=new Intent(this,RelayService.class).setAction(RelayService.ACTION_START);startForegroundService(i);refresh();
    }
    private void refresh(){
        if(status==null)return;StringBuilder b=new StringBuilder();try{PairingConfig c=new SecurePairingStore(this).load();b.append("Emparejado: ").append(c==null?"NO":c.deviceName+"\nRelay: "+c.relayUrl);}catch(Exception e){b.append("Emparejamiento: ERROR");}
        boolean anti=getSharedPreferences("jarvis_mobile",MODE_PRIVATE).getBoolean("anti_theft",false);b.append("\nAnti-theft: ").append(anti?"ACTIVO":"apagado");
        DevicePolicyManager dpm=(DevicePolicyManager)getSystemService(DEVICE_POLICY_SERVICE);b.append("\nBloqueo remoto: ").append(dpm!=null&&dpm.isAdminActive(new ComponentName(this,JarvisDeviceAdminReceiver.class))?"autorizado":"sin autorizar");
        b.append("\nUbicación background: ").append(Build.VERSION.SDK_INT<29||checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION)==PackageManager.PERMISSION_GRANTED?"autorizada":"pendiente");
        b.append("\n\nNota: JARVIS puede solicitar que Android muestre la autenticación, pero Android sigue verificando PIN/biometría. El companion no almacena el PIN de la pantalla de bloqueo.");status.setText(b.toString());
    }
    @Override protected void onResume(){super.onResume();refresh();}
}
