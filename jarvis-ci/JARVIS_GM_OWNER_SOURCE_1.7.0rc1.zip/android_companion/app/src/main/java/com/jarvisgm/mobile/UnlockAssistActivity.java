package com.jarvisgm.mobile;

import android.app.Activity;
import android.app.KeyguardManager;
import android.os.Bundle;

public final class UnlockAssistActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        setShowWhenLocked(true); setTurnScreenOn(true);
        KeyguardManager km=(KeyguardManager)getSystemService(KEYGUARD_SERVICE);
        if(km==null || !km.isKeyguardLocked()){finish();return;}
        km.requestDismissKeyguard(this,new KeyguardManager.KeyguardDismissCallback(){
            @Override public void onDismissSucceeded(){finish();}
            @Override public void onDismissCancelled(){finish();}
            @Override public void onDismissError(){finish();}
        });
    }
}
