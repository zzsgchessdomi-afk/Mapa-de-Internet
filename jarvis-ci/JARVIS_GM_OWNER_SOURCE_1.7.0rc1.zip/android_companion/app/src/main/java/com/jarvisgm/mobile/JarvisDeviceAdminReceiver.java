package com.jarvisgm.mobile;

import android.app.admin.DeviceAdminReceiver;

public final class JarvisDeviceAdminReceiver extends DeviceAdminReceiver {}
