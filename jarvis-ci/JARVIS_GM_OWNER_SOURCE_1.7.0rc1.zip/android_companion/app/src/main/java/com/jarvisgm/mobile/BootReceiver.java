package com.jarvisgm.mobile;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public final class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;
        boolean anti = context.getSharedPreferences("jarvis_mobile", Context.MODE_PRIVATE).getBoolean("anti_theft", false);
        if (!anti) return;
        try {
            if (new SecurePairingStore(context).load() == null) return;
            Intent service = new Intent(context, RelayService.class).setAction(RelayService.ACTION_START);
            service.putExtra(RelayService.EXTRA_FROM_BOOT, true);
            context.startForegroundService(service);
        } catch (Exception ignored) {
            // The main app will surface pairing/permission problems next time it opens.
        }
    }
}
