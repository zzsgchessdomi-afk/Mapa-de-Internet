package com.jarvisgm.mobile;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONObject;

public final class RelayService extends Service {
    public static final String ACTION_START="com.jarvisgm.mobile.START";
    public static final String ACTION_STOP="com.jarvisgm.mobile.STOP";
    public static final String EXTRA_FROM_BOOT="from_boot";
    private static final String CHANNEL="jarvis_mobile_relay";
    private final AtomicBoolean running=new AtomicBoolean(false);
    private ExecutorService worker;
    private PowerManager.WakeLock wakeLock;

    @Override public void onCreate(){super.onCreate();worker=Executors.newSingleThreadExecutor();createChannel();}
    @Override public IBinder onBind(Intent i){return null;}

    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent!=null&&ACTION_STOP.equals(intent.getAction())){stopLoop();stopSelf();return START_NOT_STICKY;}
        startRelayForeground(intent!=null&&intent.getBooleanExtra(EXTRA_FROM_BOOT,false));
        if(running.compareAndSet(false,true))worker.submit(this::loop);
        return START_STICKY;
    }


    private void startRelayForeground(boolean fromBoot){
        Notification n=notification("Puente móvil activo. Los comandos siguen sujetos a tus permisos.");
        if(Build.VERSION.SDK_INT>=29){
            int types=ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE;
            boolean anti=getSharedPreferences("jarvis_mobile",MODE_PRIVATE).getBoolean("anti_theft",false);
            boolean hasLocation=checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED ||
                    checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED;
            boolean hasBackground=Build.VERSION.SDK_INT<29 || checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION)==PackageManager.PERMISSION_GRANTED;
            if(anti&&hasLocation&&(!fromBoot||hasBackground))types|=ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION;
            startForeground(4107,n,types);
        }else{
            startForeground(4107,n);
        }
    }

    private void loop(){
        PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);
        if(pm!=null){wakeLock=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"JARVISGM:MobileRelay");wakeLock.acquire(10*60*1000L);}
        long lastHeartbeat=0;
        while(running.get()){
            try{
                PairingConfig cfg=new SecurePairingStore(this).load();
                if(cfg==null)throw new IllegalStateException("No paired JARVIS desktop");
                PinnedHttps http=new PinnedHttps(cfg);
                long now=System.currentTimeMillis();
                if(now-lastHeartbeat>30000){sendHeartbeat(http,cfg);lastHeartbeat=now;}
                pollOnce(http,cfg);
            }catch(Exception e){updateNotification("Desconectado temporalmente: "+safe(e.getMessage()));}
            try{Thread.sleep(4000);}catch(InterruptedException e){Thread.currentThread().interrupt();break;}
        }
        releaseWakeLock();
    }

    private void pollOnce(PinnedHttps http,PairingConfig cfg)throws Exception{
        String path="/v1/poll?device_id="+URLEncoder.encode(cfg.deviceId, "UTF-8");
        PinnedHttps.Response r=http.get(path);if(r.code==204)return;if(r.code!=200)throw new IllegalStateException("Relay poll HTTP "+r.code);
        JSONObject cmd=new JSONObject(r.body);String sig=cmd.getString("signature");
        String id=cmd.getString("id"),deviceId=cmd.getString("device_id"),kind=cmd.getString("kind");long expires=cmd.getLong("expires_at_ms");JSONObject payload=cmd.optJSONObject("payload");if(payload==null)payload=new JSONObject();
        if(!cfg.deviceId.equals(deviceId))throw new SecurityException("Command device mismatch");
        String expected=Crypto.hmacHex(cfg.sharedSecret,Crypto.commandMessage(id,deviceId,kind,expires,payload));
        if(!constantTime(expected,sig))throw new SecurityException("Command signature invalid");
        if(System.currentTimeMillis()>expires){sendResponse(http,cfg,id,false,null,"Command expired");return;}
        JSONObject result;boolean ok=true;String error=null;
        try{result=execute(kind,payload);}catch(Exception e){ok=false;result=null;error=safe(e.getMessage());}
        sendResponse(http,cfg,id,ok,result,error);
    }

    private JSONObject execute(String kind,JSONObject p)throws Exception{
        DeviceActions a=new DeviceActions(this);
        switch(kind){
            case "status":return a.status();
            case "location.now":return a.currentLocation();
            case "device.ring":return a.ring(p.optInt("seconds",20));
            case "device.lock":return a.lock();
            case "device.request_auth":return a.requestAuthentication();
            case "app.open_url":return a.openUrl(p.getString("url"));
            case "app.open":return a.openApp(p.getString("package"));
            case "message.compose":return a.composeMessage(p.getString("channel"),p.getString("recipient"),p.getString("text"));
            case "contacts.search":return a.findContacts(p.getString("query"));
            default:throw new IllegalArgumentException("Unsupported command: "+kind);
        }
    }

    private void sendResponse(PinnedHttps http,PairingConfig cfg,String id,boolean ok,JSONObject result,String error)throws Exception{
        JSONObject j=new JSONObject();j.put("device_id",cfg.deviceId);j.put("command_id",id);j.put("ok",ok);if(result!=null)j.put("result",result);if(error!=null)j.put("error",error);
        PinnedHttps.Response r=http.post("/v1/response",j);if(r.code!=200)throw new IllegalStateException("Response HTTP "+r.code);
    }

    private void sendHeartbeat(PinnedHttps http,PairingConfig cfg)throws Exception{
        DeviceActions a=new DeviceActions(this);JSONObject status=a.status();JSONObject j=new JSONObject();j.put("device_id",cfg.deviceId);j.put("timestamp",System.currentTimeMillis()/1000.0);
        j.put("battery_percent",status.opt("battery_percent"));j.put("network",status.optString("network","unknown"));j.put("device_locked",status.optBoolean("device_locked",false));
        boolean anti=getSharedPreferences("jarvis_mobile",MODE_PRIVATE).getBoolean("anti_theft",false);j.put("anti_theft_enabled",anti);
        if(anti&&(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED||checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED)){
            try{JSONObject loc=a.currentLocation();j.put("latitude",loc.getDouble("latitude"));j.put("longitude",loc.getDouble("longitude"));j.put("accuracy_m",loc.opt("accuracy_m"));}catch(Exception ignored){}
        }
        PinnedHttps.Response r=http.post("/v1/heartbeat",j);if(r.code!=200)throw new IllegalStateException("Heartbeat HTTP "+r.code);
        updateNotification(anti?"Anti-theft activo • enlace con JARVIS":"Puente móvil activo");
    }

    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);if(nm!=null)nm.createNotificationChannel(new NotificationChannel(CHANNEL,getString(com.jarvisgm.mobile.R.string.relay_channel),NotificationManager.IMPORTANCE_LOW));}}
    private Notification notification(String text){return new Notification.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_lock_idle_lock).setContentTitle(getString(com.jarvisgm.mobile.R.string.relay_running)).setContentText(text).setOngoing(true).build();}
    private void updateNotification(String text){NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);if(nm!=null)nm.notify(4107,notification(text));}
    private static boolean constantTime(String a,String b){if(a==null||b==null||a.length()!=b.length())return false;int x=0;for(int i=0;i<a.length();i++)x|=a.charAt(i)^b.charAt(i);return x==0;}
    private static String safe(String s){return s==null?"error":(s.length()>120?s.substring(0,120):s);}
    private void stopLoop(){running.set(false);if(worker!=null)worker.shutdownNow();releaseWakeLock();}
    private void releaseWakeLock(){try{if(wakeLock!=null&&wakeLock.isHeld())wakeLock.release();}catch(Exception ignored){}wakeLock=null;}
    @Override public void onDestroy(){stopLoop();super.onDestroy();}
}
