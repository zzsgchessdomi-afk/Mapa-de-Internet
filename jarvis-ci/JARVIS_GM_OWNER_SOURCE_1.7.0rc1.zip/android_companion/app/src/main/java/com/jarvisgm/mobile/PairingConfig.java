package com.jarvisgm.mobile;

import android.net.Uri;
import android.util.Base64;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;

public final class PairingConfig {
    public final String deviceId;
    public final String deviceName;
    public final String relayUrl;
    public final String certFingerprint;
    public final String sharedSecret;

    public PairingConfig(String deviceId, String deviceName, String relayUrl, String certFingerprint, String sharedSecret) {
        this.deviceId = deviceId;
        this.deviceName = deviceName;
        this.relayUrl = relayUrl;
        this.certFingerprint = certFingerprint;
        this.sharedSecret = sharedSecret;
    }

    public static PairingConfig fromUri(String raw) throws Exception {
        Uri uri = Uri.parse(raw.trim());
        if (!"jarvisgm".equalsIgnoreCase(uri.getScheme()) || !"pair".equalsIgnoreCase(uri.getHost())) {
            throw new IllegalArgumentException("No es un URI de emparejamiento JARVIS GM");
        }
        if (uri.getPathSegments().isEmpty()) throw new IllegalArgumentException("Falta token de emparejamiento");
        String token = uri.getPathSegments().get(uri.getPathSegments().size() - 1);
        int pad = (4 - token.length() % 4) % 4;
        token = token + "====".substring(0, pad);
        byte[] bytes = Base64.decode(token, Base64.URL_SAFE | Base64.NO_WRAP);
        JSONObject json = new JSONObject(new String(bytes, StandardCharsets.UTF_8));
        if (json.optInt("format", 0) != 1) throw new IllegalArgumentException("Formato de emparejamiento no soportado");
        String id = json.getString("device_id");
        String name = json.optString("device_name", id);
        String relay = json.getString("relay_url");
        String fp = json.getString("relay_cert_sha256");
        String secret = json.getString("shared_secret");
        Uri relayUri=Uri.parse(relay);
        if (!"https".equalsIgnoreCase(relayUri.getScheme()) || relayUri.getHost()==null || relayUri.getHost().isEmpty())
            throw new IllegalArgumentException("El relay debe ser un origen HTTPS válido");
        if (relayUri.getUserInfo()!=null || relayUri.getQuery()!=null || relayUri.getFragment()!=null ||
                (relayUri.getPath()!=null && !relayUri.getPath().isEmpty() && !"/".equals(relayUri.getPath())))
            throw new IllegalArgumentException("El relay no puede incluir credenciales, ruta, query o fragmento");
        if (!id.matches("[A-Za-z0-9_.-]+")) throw new IllegalArgumentException("ID de dispositivo inválido");
        String fpHex=fp.replace(":","");
        if (!fpHex.matches("[0-9A-Fa-f]{64}")) throw new IllegalArgumentException("Huella TLS inválida");
        if (!secret.matches("[A-Za-z0-9_-]{40,128}")) throw new IllegalArgumentException("Secreto de emparejamiento inválido");
        return new PairingConfig(id, name, relay.replaceAll("/+$", ""), fp.toUpperCase(), secret);
    }

    public JSONObject toJson() throws Exception {
        JSONObject j = new JSONObject();
        j.put("device_id", deviceId); j.put("device_name", deviceName); j.put("relay_url", relayUrl);
        j.put("relay_cert_sha256", certFingerprint); j.put("shared_secret", sharedSecret);
        return j;
    }

    public static PairingConfig fromJson(JSONObject j) throws Exception {
        return new PairingConfig(j.getString("device_id"), j.optString("device_name", j.getString("device_id")),
                j.getString("relay_url"), j.getString("relay_cert_sha256"), j.getString("shared_secret"));
    }
}
