package com.jarvisgm.mobile;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.cert.X509Certificate;
import org.json.JSONObject;

public final class PinnedHttps {
    private final PairingConfig config;
    public PinnedHttps(PairingConfig config) { this.config=config; }

    private SSLContext context() throws Exception {
        String expected=config.certFingerprint.replace(":","").toLowerCase();
        X509TrustManager tm=new X509TrustManager(){
            public X509Certificate[] getAcceptedIssuers(){return new X509Certificate[0];}
            public void checkClientTrusted(X509Certificate[] chain,String authType){}
            public void checkServerTrusted(X509Certificate[] chain,String authType) throws java.security.cert.CertificateException {
                try {
                    if(chain==null||chain.length==0) throw new java.security.cert.CertificateException("No server certificate");
                    String actual=Crypto.hex(MessageDigest.getInstance("SHA-256").digest(chain[0].getEncoded()));
                    if(!actual.equalsIgnoreCase(expected)) throw new java.security.cert.CertificateException("JARVIS relay certificate pin mismatch");
                } catch(java.security.cert.CertificateException e){throw e;} catch(Exception e){throw new java.security.cert.CertificateException(e);}
            }
        };
        SSLContext ctx=SSLContext.getInstance("TLS");ctx.init(null,new TrustManager[]{tm},null);return ctx;
    }

    private HttpsURLConnection connection(String method,String path,byte[] body) throws Exception {
        URL url=new URL(config.relayUrl+path); HttpsURLConnection c=(HttpsURLConnection)url.openConnection();
        c.setSSLSocketFactory(context().getSocketFactory()); c.setHostnameVerifier((h,s)->true);
        c.setConnectTimeout(8000);c.setReadTimeout(15000);c.setRequestMethod(method);c.setUseCaches(false);
        long ts=System.currentTimeMillis();String nonce=Crypto.nonce();String authPath=new URL(config.relayUrl+path).getPath();
        String msg=Crypto.requestMessage(method,authPath,config.deviceId,ts,nonce,body);
        c.setRequestProperty("X-Jarvis-Device",config.deviceId);c.setRequestProperty("X-Jarvis-Timestamp",Long.toString(ts));
        c.setRequestProperty("X-Jarvis-Nonce",nonce);c.setRequestProperty("X-Jarvis-Signature",Crypto.hmacHex(config.sharedSecret,msg));
        if(body.length>0){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=utf-8");c.getOutputStream().write(body);}
        return c;
    }

    private static String read(InputStream in) throws Exception {
        if(in==null)return "";ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[4096];int n;
        while((n=in.read(b))!=-1)out.write(b,0,n);return new String(out.toByteArray(), StandardCharsets.UTF_8);
    }

    public Response get(String path) throws Exception {
        HttpsURLConnection c=connection("GET",path,new byte[0]);int code=c.getResponseCode();String body=read(code>=400?c.getErrorStream():c.getInputStream());c.disconnect();return new Response(code,body);
    }
    public Response post(String path,JSONObject json) throws Exception {
        byte[] body=json.toString().getBytes(StandardCharsets.UTF_8);HttpsURLConnection c=connection("POST",path,body);int code=c.getResponseCode();String text=read(code>=400?c.getErrorStream():c.getInputStream());c.disconnect();return new Response(code,text);
    }
    public static final class Response { public final int code; public final String body; public Response(int c,String b){code=c;body=b;} }
}
