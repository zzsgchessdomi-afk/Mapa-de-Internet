package com.jarvisgm.mobile;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import org.json.JSONObject;

public final class SecurePairingStore {
    private static final String ALIAS = "jarvis_gm_mobile_pairing_v1";
    private static final String PREFS = "jarvis_secure_pairing";
    private static final String KEY = "pairing_blob";
    private final Context context;

    public SecurePairingStore(Context context) { this.context = context.getApplicationContext(); }

    private SecretKey key() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
        if (ks.containsAlias(ALIAS)) return ((KeyStore.SecretKeyEntry) ks.getEntry(ALIAS, null)).getSecretKey();
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        kg.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
        return kg.generateKey();
    }

    public void save(PairingConfig config) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.ENCRYPT_MODE, key());
        byte[] ciphertext = cipher.doFinal(config.toJson().toString().getBytes(StandardCharsets.UTF_8));
        JSONObject blob = new JSONObject();
        blob.put("iv", Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP));
        blob.put("ct", Base64.encodeToString(ciphertext, Base64.NO_WRAP));
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, blob.toString()).apply();
    }

    public PairingConfig load() throws Exception {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String raw = prefs.getString(KEY, null); if (raw == null) return null;
        JSONObject blob = new JSONObject(raw);
        byte[] iv = Base64.decode(blob.getString("iv"), Base64.NO_WRAP);
        byte[] ct = Base64.decode(blob.getString("ct"), Base64.NO_WRAP);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, iv));
        byte[] clear = cipher.doFinal(ct);
        return PairingConfig.fromJson(new JSONObject(new String(clear, StandardCharsets.UTF_8)));
    }

    public void clear() {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY).apply();
    }
}
