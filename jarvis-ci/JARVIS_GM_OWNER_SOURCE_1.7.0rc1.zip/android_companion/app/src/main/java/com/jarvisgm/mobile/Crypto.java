package com.jarvisgm.mobile;

import org.json.JSONArray;
import org.json.JSONObject;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public final class Crypto {
    private Crypto() {}

    public static String hex(byte[] data) {
        StringBuilder b = new StringBuilder();
        for (byte x : data) b.append(String.format("%02x", x & 0xff));
        return b.toString();
    }

    public static String sha256Hex(byte[] data) throws Exception {
        return hex(MessageDigest.getInstance("SHA-256").digest(data));
    }

    public static String hmacHex(String secret, String message) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
        return hex(mac.doFinal(message.getBytes(StandardCharsets.UTF_8)));
    }

    public static String nonce() {
        byte[] b = new byte[18]; new SecureRandom().nextBytes(b); return hex(b);
    }

    public static String requestMessage(String method, String path, String deviceId, long timestampMs, String nonce, byte[] body) throws Exception {
        return String.join("\n", "JARVIS-REQ-1", method.toUpperCase(), path, deviceId, Long.toString(timestampMs), nonce, sha256Hex(body));
    }

    public static String commandMessage(String id, String deviceId, String kind, long expiresAtMs, JSONObject payload) throws Exception {
        String payloadHash = sha256Hex(canonical(payload).getBytes(StandardCharsets.UTF_8));
        return String.join("\n", "JARVIS-CMD-1", id, deviceId, kind, Long.toString(expiresAtMs), payloadHash);
    }

    public static String canonical(Object value) throws Exception {
        if (value == null || value == JSONObject.NULL) return "null";
        if (value instanceof JSONObject) {
            JSONObject obj = (JSONObject) value;
            List<String> keys = new ArrayList<>(); Iterator<String> it = obj.keys(); while (it.hasNext()) keys.add(it.next());
            Collections.sort(keys);
            StringBuilder b = new StringBuilder("{");
            for (int i=0;i<keys.size();i++) {
                if (i>0) b.append(','); String k=keys.get(i); b.append(JSONObject.quote(k)).append(':').append(canonical(obj.get(k)));
            }
            return b.append('}').toString();
        }
        if (value instanceof JSONArray) {
            JSONArray a=(JSONArray)value; StringBuilder b=new StringBuilder("[");
            for(int i=0;i<a.length();i++){ if(i>0)b.append(','); b.append(canonical(a.get(i))); }
            return b.append(']').toString();
        }
        if (value instanceof String) return JSONObject.quote((String)value);
        if (value instanceof Boolean) return ((Boolean)value) ? "true" : "false";
        if (value instanceof Number) return JSONObject.numberToString((Number)value);
        return JSONObject.quote(value.toString());
    }
}
