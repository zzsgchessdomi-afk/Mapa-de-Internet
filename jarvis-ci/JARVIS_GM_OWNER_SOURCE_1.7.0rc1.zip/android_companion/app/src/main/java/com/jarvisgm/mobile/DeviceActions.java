package com.jarvisgm.mobile;

import android.Manifest;
import android.app.Activity;
import android.app.KeyguardManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.location.Location;
import android.location.LocationManager;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.CancellationSignal;
import android.provider.ContactsContract;
import android.provider.Settings;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import org.json.JSONArray;
import org.json.JSONObject;

public final class DeviceActions {
    private final Context context;
    public DeviceActions(Context context){this.context=context.getApplicationContext();}

    public JSONObject status() throws Exception {
        JSONObject out=new JSONObject();
        BatteryManager bm=(BatteryManager)context.getSystemService(Context.BATTERY_SERVICE);
        out.put("battery_percent",bm==null?JSONObject.NULL:bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY));
        KeyguardManager km=(KeyguardManager)context.getSystemService(Context.KEYGUARD_SERVICE);
        out.put("device_locked",km!=null&&km.isDeviceLocked());out.put("network",networkType());
        out.put("android_sdk",Build.VERSION.SDK_INT);out.put("manufacturer",Build.MANUFACTURER);out.put("model",Build.MODEL);
        return out;
    }

    public JSONObject currentLocation() throws Exception {
        if(context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED &&
                context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED)
            throw new SecurityException("Location permission is not granted");
        LocationManager lm=(LocationManager)context.getSystemService(Context.LOCATION_SERVICE);
        if(lm==null)throw new IllegalStateException("LocationManager unavailable");
        Location best=null;
        for(String provider:lm.getProviders(true)){
            try{Location x=lm.getLastKnownLocation(provider);if(x!=null&&(best==null||x.getTime()>best.getTime()))best=x;}catch(SecurityException ignored){}
        }
        if(Build.VERSION.SDK_INT>=30){
            AtomicReference<Location> ref=new AtomicReference<>();CountDownLatch latch=new CountDownLatch(1);CancellationSignal cs=new CancellationSignal();
            String provider=lm.isProviderEnabled(LocationManager.GPS_PROVIDER)?LocationManager.GPS_PROVIDER:LocationManager.NETWORK_PROVIDER;
            lm.getCurrentLocation(provider,cs,context.getMainExecutor(),x->{ref.set(x);latch.countDown();});
            latch.await(10,TimeUnit.SECONDS);if(ref.get()!=null)best=ref.get();else cs.cancel();
        }
        if(best==null)throw new IllegalStateException("No location fix available");
        JSONObject out=new JSONObject();out.put("latitude",best.getLatitude());out.put("longitude",best.getLongitude());
        out.put("accuracy_m",best.hasAccuracy()?best.getAccuracy():JSONObject.NULL);out.put("timestamp",best.getTime()/1000.0);return out;
    }

    public JSONObject ring(int seconds) throws Exception {
        int duration=Math.max(1,Math.min(seconds,120)); Uri uri=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        if(uri==null)uri=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
        final Ringtone tone=RingtoneManager.getRingtone(context,uri);if(tone==null)throw new IllegalStateException("No ringtone available");
        tone.play();new Thread(()->{try{Thread.sleep(duration*1000L);}catch(InterruptedException ignored){}try{tone.stop();}catch(Exception ignored){}},"jarvis-ring-stop").start();
        return new JSONObject().put("ringing",true).put("seconds",duration);
    }

    public JSONObject lock() throws Exception {
        DevicePolicyManager dpm=(DevicePolicyManager)context.getSystemService(Context.DEVICE_POLICY_SERVICE);
        ComponentName admin=new ComponentName(context,JarvisDeviceAdminReceiver.class);
        if(dpm==null||!dpm.isAdminActive(admin))throw new SecurityException("JARVIS device-admin permission is not active");
        dpm.lockNow();return new JSONObject().put("locked",true);
    }

    public JSONObject requestAuthentication() throws Exception {
        Intent i=new Intent(context,UnlockAssistActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        JSONObject out=launchOrNotify(i,"JARVIS solicita autenticación","Toca para abrir la autenticación segura de Android");
        out.put("system_authentication_requested",true).put("pin_transmitted",false).put("pin_stored",false);
        return out;
    }

    public JSONObject openUrl(String url) throws Exception {
        Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return launchOrNotify(i,"Abrir enlace en JARVIS",url);
    }

    public JSONObject openApp(String packageName) throws Exception {
        Intent i=context.getPackageManager().getLaunchIntentForPackage(packageName);
        if(i==null)throw new IllegalArgumentException("Package is not installed: "+packageName);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return launchOrNotify(i,"Abrir aplicación",packageName);
    }

    public JSONObject findContacts(String query) throws Exception {
        if(context.checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED)
            throw new SecurityException("Contacts permission is not granted");
        JSONArray rows=new JSONArray();String like="%"+query+"%";
        String[] proj={ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,ContactsContract.CommonDataKinds.Phone.NUMBER};
        try(Cursor c=context.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,proj,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME+" LIKE ?",new String[]{like},ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME+" ASC")){
            if(c!=null)while(c.moveToNext()&&rows.length()<10){JSONObject x=new JSONObject();x.put("name",c.getString(0));x.put("phone",c.getString(1));rows.put(x);}
        }
        return new JSONObject().put("query",query).put("matches",rows);
    }

    public JSONObject composeMessage(String channel,String recipient,String text) throws Exception {
        Intent i; boolean resolvedLocally=false;
        if("whatsapp".equals(channel)){
            String phone=resolveRecipientNumber(recipient); resolvedLocally=!looksLikePhone(recipient);
            String link="https://wa.me/"+Uri.encode(phone)+"?text="+Uri.encode(text);
            i=new Intent(Intent.ACTION_VIEW,Uri.parse(link));i.setPackage("com.whatsapp");
        }else if("sms".equals(channel)){
            String phone=resolveRecipientNumber(recipient); resolvedLocally=!looksLikePhone(recipient);
            i=new Intent(Intent.ACTION_SENDTO,Uri.parse("smsto:"+Uri.encode(phone)));i.putExtra("sms_body",text);
        }else{
            i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,text);
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        JSONObject out=launchOrNotify(i,"Mensaje preparado",recipient);
        out.put("channel",channel);out.put("recipient_label",recipient);out.put("resolved_locally",resolvedLocally);
        out.put("sent",false);out.put("prepared",true);return out;
    }

    private static boolean looksLikePhone(String value){
        String digits=value==null?"":value.replaceAll("[^0-9]","");
        return digits.length()>=7;
    }

    private String resolveRecipientNumber(String recipient) throws Exception {
        if(looksLikePhone(recipient))return recipient.replaceAll("[^0-9+]","").replace("+","");
        if(context.checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED)
            throw new SecurityException("Contacts permission is required to resolve a contact name");
        String[] proj={ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,ContactsContract.CommonDataKinds.Phone.NUMBER};
        java.util.ArrayList<String> exactNumbers=new java.util.ArrayList<>();
        try(Cursor c=context.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,proj,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME+" LIKE ?",new String[]{"%"+recipient+"%"},ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME+" ASC")){
            if(c!=null)while(c.moveToNext()&&exactNumbers.size()<20){
                String name=c.getString(0),number=c.getString(1);
                if(name!=null&&name.trim().equalsIgnoreCase(recipient.trim())&&number!=null){
                    String clean=number.replaceAll("[^0-9+]","").replace("+","");
                    if(clean.length()>=7&&!exactNumbers.contains(clean))exactNumbers.add(clean);
                }
            }
        }
        if(exactNumbers.isEmpty())throw new IllegalArgumentException("No exact contact match for: "+recipient);
        if(exactNumbers.size()!=1)throw new IllegalArgumentException("Contact has multiple phone numbers; specify the number explicitly");
        return exactNumbers.get(0);
    }

    private JSONObject launchOrNotify(Intent intent,String title,String detail) throws Exception {
        try{context.startActivity(intent);return new JSONObject().put("launched",true).put("user_action_required",false);}
        catch(Exception blocked){
            String channel="jarvis_actions";NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
            if(nm==null)throw blocked;
            if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel(channel,"JARVIS actions",NotificationManager.IMPORTANCE_HIGH));
            PendingIntent pi=PendingIntent.getActivity(context,(int)System.nanoTime(),intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            Notification n=new Notification.Builder(context,channel).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(detail)
                    .setAutoCancel(true).setContentIntent(pi).build();nm.notify((int)(System.currentTimeMillis()&0x7fffffff),n);
            return new JSONObject().put("launched",false).put("user_action_required",true).put("notification_posted",true);
        }
    }

    public String networkType(){
        ConnectivityManager cm=(ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);if(cm==null)return "unknown";
        NetworkCapabilities nc=cm.getNetworkCapabilities(cm.getActiveNetwork());if(nc==null)return "offline";
        if(nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI))return "wifi";if(nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR))return "cellular";
        if(nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET))return "ethernet";return "other";
    }
}
