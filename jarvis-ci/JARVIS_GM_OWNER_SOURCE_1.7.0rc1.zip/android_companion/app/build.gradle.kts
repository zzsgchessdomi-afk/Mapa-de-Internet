plugins { id("com.android.application") }

android {
    namespace = "com.jarvisgm.mobile"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.jarvisgm.mobile"
        minSdk = 29
        targetSdk = 36
        versionCode = 7
        versionName = "1.7.0-rc1"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
