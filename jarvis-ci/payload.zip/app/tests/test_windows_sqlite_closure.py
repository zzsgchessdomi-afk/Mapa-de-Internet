from pathlib import Path

def test_sqlite_stores_use_explicit_closing_helper():
    src = Path(__file__).resolve().parents[1] / "src" / "jarvis_gm"
    offenders=[]
    for p in src.rglob("*.py"):
        text=p.read_text(encoding="utf-8")
        if "sqlite3.connect(" in text and p.name != "sqlite.py":
            # diagnostics is allowed only through contextlib.closing.
            if "with closing(sqlite3.connect(" not in text:
                offenders.append(str(p.relative_to(src)))
    assert offenders == []
