from __future__ import annotations
from pathlib import Path
import json, sqlite3, time

class SwarmStore:
    def __init__(self,path:Path)->None:
        self.path=Path(path);self.path.parent.mkdir(parents=True,exist_ok=True);self._init()
    def _connect(self):
        con=sqlite3.connect(self.path);con.row_factory=sqlite3.Row;return con
    def _init(self):
        with self._connect() as con:
            con.execute("CREATE TABLE IF NOT EXISTS runs(id TEXT PRIMARY KEY,state TEXT NOT NULL,goal TEXT NOT NULL,payload TEXT NOT NULL,updated_at REAL NOT NULL)")
            con.execute("CREATE INDEX IF NOT EXISTS idx_swarm_updated ON runs(updated_at DESC)")
    def save(self,report)->None:
        payload=json.dumps(report.as_dict(),ensure_ascii=False,sort_keys=True)
        with self._connect() as con:
            con.execute("INSERT INTO runs(id,state,goal,payload,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET state=excluded.state,goal=excluded.goal,payload=excluded.payload,updated_at=excluded.updated_at",(report.id,report.state.value,report.goal,payload,time.time()))
    def load(self,run_id:str)->dict:
        with self._connect() as con: row=con.execute("SELECT payload FROM runs WHERE id=?",(str(run_id),)).fetchone()
        if row is None: raise KeyError(run_id)
        return json.loads(row["payload"])
    def list(self,limit:int=50)->list[dict]:
        with self._connect() as con: rows=con.execute("SELECT id,state,goal,updated_at FROM runs ORDER BY updated_at DESC LIMIT ?",(max(1,min(int(limit),500)),)).fetchall()
        return [dict(x) for x in rows]
    def stats(self)->dict:
        with self._connect() as con:
            total=con.execute("SELECT COUNT(*) FROM runs").fetchone()[0]
            completed=con.execute("SELECT COUNT(*) FROM runs WHERE state='completed'").fetchone()[0]
        return {"runs":int(total),"completed":int(completed)}
