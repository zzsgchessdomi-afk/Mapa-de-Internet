from __future__ import annotations

from pathlib import Path
import json
import sqlite3
import time
import uuid

from .models import RealityDevice, DeviceRisk


class RealityStore:
    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as con:
            con.executescript(
                """
                CREATE TABLE IF NOT EXISTS reality_devices(
                    id TEXT PRIMARY KEY,
                    adapter TEXT NOT NULL,
                    native_id TEXT NOT NULL,
                    label TEXT NOT NULL,
                    kind TEXT NOT NULL,
                    capabilities_json TEXT NOT NULL,
                    risk TEXT NOT NULL,
                    enabled INTEGER NOT NULL,
                    metadata_json TEXT NOT NULL,
                    created_at REAL NOT NULL,
                    updated_at REAL NOT NULL,
                    UNIQUE(adapter,native_id)
                );
                CREATE TABLE IF NOT EXISTS reality_events(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    device_id TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    created_at REAL NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_reality_events_time ON reality_events(created_at DESC);
                """
            )

    def _connect(self):
        con = sqlite3.connect(self.path)
        con.row_factory = sqlite3.Row
        return con

    def enroll(self, *, adapter: str, native_id: str, label: str, kind: str,
               capabilities: tuple[str, ...] = (), risk: DeviceRisk = DeviceRisk.LOW,
               metadata: dict | None = None) -> RealityDevice:
        adapter = adapter.strip().casefold(); native_id = native_id.strip(); label = label.strip()
        if not adapter or not native_id or not label:
            raise ValueError("adapter, native_id and label are required")
        now = time.time(); device_id = str(uuid.uuid5(uuid.NAMESPACE_URL, f"jarvis-reality:{adapter}:{native_id}"))
        with self._connect() as con:
            con.execute(
                "INSERT INTO reality_devices(id,adapter,native_id,label,kind,capabilities_json,risk,enabled,metadata_json,created_at,updated_at) "
                "VALUES(?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(adapter,native_id) DO UPDATE SET "
                "label=excluded.label,kind=excluded.kind,capabilities_json=excluded.capabilities_json,risk=excluded.risk,metadata_json=excluded.metadata_json,updated_at=excluded.updated_at",
                (device_id,adapter,native_id,label,kind,json.dumps(list(capabilities)),risk.value,1,json.dumps(metadata or {},sort_keys=True),now,now),
            )
        return self.get(device_id)

    def get(self, device_id: str) -> RealityDevice:
        with self._connect() as con:
            row = con.execute("SELECT * FROM reality_devices WHERE id=?", (device_id,)).fetchone()
        if row is None:
            raise KeyError(device_id)
        return self._row(row)

    def find(self, ref: str) -> RealityDevice:
        needle = ref.strip().casefold()
        with self._connect() as con:
            rows = con.execute("SELECT * FROM reality_devices WHERE enabled=1 ORDER BY updated_at DESC").fetchall()
        exact = [self._row(r) for r in rows if r["id"].casefold()==needle or r["native_id"].casefold()==needle or r["label"].casefold()==needle]
        if len(exact) == 1: return exact[0]
        if len(exact) > 1: raise ValueError(f"Ambiguous reality device: {ref}")
        partial = [self._row(r) for r in rows if needle and needle in r["label"].casefold()]
        if len(partial) == 1: return partial[0]
        if len(partial) > 1: raise ValueError(f"Ambiguous reality device: {ref}")
        raise KeyError(ref)

    def list(self, *, enabled_only: bool = True, limit: int = 200) -> list[RealityDevice]:
        sql = "SELECT * FROM reality_devices" + (" WHERE enabled=1" if enabled_only else "") + " ORDER BY label LIMIT ?"
        with self._connect() as con:
            return [self._row(r) for r in con.execute(sql, (max(1,int(limit)),)).fetchall()]

    def set_enabled(self, device_id: str, enabled: bool) -> None:
        with self._connect() as con:
            if con.execute("UPDATE reality_devices SET enabled=?,updated_at=? WHERE id=?", (1 if enabled else 0,time.time(),device_id)).rowcount != 1:
                raise KeyError(device_id)

    def event(self, device_id: str, event_type: str, payload: dict) -> None:
        with self._connect() as con:
            con.execute("INSERT INTO reality_events(device_id,event_type,payload_json,created_at) VALUES(?,?,?,?)",
                        (device_id,event_type,json.dumps(payload,sort_keys=True,default=str),time.time()))
            con.execute("DELETE FROM reality_events WHERE id <= COALESCE((SELECT MAX(id)-5000 FROM reality_events),-1)")

    def recent_events(self, limit: int = 100) -> list[dict]:
        with self._connect() as con:
            rows = con.execute("SELECT * FROM reality_events ORDER BY id DESC LIMIT ?", (max(1,int(limit)),)).fetchall()
        return [{**dict(r),"payload":json.loads(r["payload_json"])} for r in rows]

    def stats(self) -> dict[str,int]:
        with self._connect() as con:
            a=con.execute("SELECT COUNT(*) FROM reality_devices WHERE enabled=1").fetchone()[0]
            b=con.execute("SELECT COUNT(*) FROM reality_devices").fetchone()[0]
            e=con.execute("SELECT COUNT(*) FROM reality_events").fetchone()[0]
        return {"enabled_devices":int(a),"devices":int(b),"events":int(e)}

    @staticmethod
    def _row(row) -> RealityDevice:
        return RealityDevice(str(row["id"]),str(row["adapter"]),str(row["native_id"]),str(row["label"]),str(row["kind"]),tuple(json.loads(row["capabilities_json"])),DeviceRisk(str(row["risk"])),bool(row["enabled"]),dict(json.loads(row["metadata_json"])))
