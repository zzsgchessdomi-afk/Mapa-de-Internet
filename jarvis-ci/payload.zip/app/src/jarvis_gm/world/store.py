from __future__ import annotations

from pathlib import Path
from typing import Any
import hashlib
import json
import sqlite3
import time

from .models import WorldEntity, WorldRelation


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)


class WorldModelStore:
    """Local graph-like world state with provenance, confidence and expiry.

    The store is deliberately deterministic and cloud-free. It models what JARVIS
    currently believes exists, how entities relate, and the observations that led
    to those beliefs. Expiring entities prevent stale UI/device context from
    becoming permanent truth.
    """

    def __init__(self, path: Path, *, max_observations: int = 5000) -> None:
        self.path = Path(path)
        self.max_observations = max(100, int(max_observations))
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        con = sqlite3.connect(self.path)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA foreign_keys=ON")
        return con

    def _init_db(self) -> None:
        with self._connect() as con:
            con.executescript(
                """
                CREATE TABLE IF NOT EXISTS world_entities(
                    id TEXT PRIMARY KEY,
                    kind TEXT NOT NULL,
                    label TEXT NOT NULL,
                    attributes_json TEXT NOT NULL,
                    source TEXT NOT NULL,
                    confidence REAL NOT NULL,
                    first_seen REAL NOT NULL,
                    last_seen REAL NOT NULL,
                    expires_at REAL,
                    status TEXT NOT NULL DEFAULT 'active'
                );
                CREATE INDEX IF NOT EXISTS idx_world_entities_kind ON world_entities(kind,status,last_seen DESC);
                CREATE INDEX IF NOT EXISTS idx_world_entities_expiry ON world_entities(expires_at);

                CREATE TABLE IF NOT EXISTS world_relations(
                    id TEXT PRIMARY KEY,
                    subject_id TEXT NOT NULL,
                    predicate TEXT NOT NULL,
                    object_id TEXT NOT NULL,
                    attributes_json TEXT NOT NULL,
                    source TEXT NOT NULL,
                    confidence REAL NOT NULL,
                    first_seen REAL NOT NULL,
                    last_seen REAL NOT NULL,
                    expires_at REAL,
                    status TEXT NOT NULL DEFAULT 'active'
                );
                CREATE INDEX IF NOT EXISTS idx_world_relations_subject ON world_relations(subject_id,predicate,status,last_seen DESC);
                CREATE INDEX IF NOT EXISTS idx_world_relations_object ON world_relations(object_id,predicate,status,last_seen DESC);

                CREATE TABLE IF NOT EXISTS world_observations(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_type TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    source TEXT NOT NULL,
                    confidence REAL NOT NULL,
                    observed_at REAL NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_world_observations_time ON world_observations(observed_at DESC);

                CREATE TABLE IF NOT EXISTS world_state(
                    key TEXT PRIMARY KEY,
                    value_json TEXT NOT NULL,
                    updated_at REAL NOT NULL
                );
                """
            )

    @staticmethod
    def stable_id(kind: str, key: str) -> str:
        digest = hashlib.sha256(f"{kind}\0{key}".encode("utf-8")).hexdigest()[:20]
        return f"{kind}:{digest}"

    @staticmethod
    def relation_id(subject_id: str, predicate: str, object_id: str) -> str:
        digest = hashlib.sha256(f"{subject_id}\0{predicate}\0{object_id}".encode("utf-8")).hexdigest()[:24]
        return f"rel:{digest}"

    def upsert_entity(self, *, kind: str, key: str, label: str, attributes: dict[str, Any] | None = None,
                      source: str = "system", confidence: float = 1.0, ttl_s: float | None = None,
                      now: float | None = None) -> WorldEntity:
        now = time.time() if now is None else float(now)
        entity_id = self.stable_id(kind, key)
        expires = None if ttl_s is None else now + max(0.0, float(ttl_s))
        attrs = dict(attributes or {})
        confidence = max(0.0, min(1.0, float(confidence)))
        with self._connect() as con:
            row = con.execute("SELECT first_seen FROM world_entities WHERE id=?", (entity_id,)).fetchone()
            first_seen = now if row is None else float(row["first_seen"])
            con.execute(
                "INSERT INTO world_entities(id,kind,label,attributes_json,source,confidence,first_seen,last_seen,expires_at,status) "
                "VALUES(?,?,?,?,?,?,?,?,?,'active') ON CONFLICT(id) DO UPDATE SET "
                "kind=excluded.kind,label=excluded.label,attributes_json=excluded.attributes_json,source=excluded.source," 
                "confidence=excluded.confidence,last_seen=excluded.last_seen,expires_at=excluded.expires_at,status='active'",
                (entity_id, kind, label, _json(attrs), source, confidence, first_seen, now, expires),
            )
        return WorldEntity(entity_id, kind, label, attrs, source, confidence, first_seen, now, expires, "active")

    def relate(self, subject_id: str, predicate: str, object_id: str, *, attributes: dict[str, Any] | None = None,
               source: str = "system", confidence: float = 1.0, ttl_s: float | None = None,
               now: float | None = None) -> WorldRelation:
        now = time.time() if now is None else float(now)
        rid = self.relation_id(subject_id, predicate, object_id)
        expires = None if ttl_s is None else now + max(0.0, float(ttl_s))
        attrs = dict(attributes or {})
        confidence = max(0.0, min(1.0, float(confidence)))
        with self._connect() as con:
            row = con.execute("SELECT first_seen FROM world_relations WHERE id=?", (rid,)).fetchone()
            first_seen = now if row is None else float(row["first_seen"])
            con.execute(
                "INSERT INTO world_relations(id,subject_id,predicate,object_id,attributes_json,source,confidence,first_seen,last_seen,expires_at,status) "
                "VALUES(?,?,?,?,?,?,?,?,?,?,'active') ON CONFLICT(id) DO UPDATE SET "
                "attributes_json=excluded.attributes_json,source=excluded.source,confidence=excluded.confidence," 
                "last_seen=excluded.last_seen,expires_at=excluded.expires_at,status='active'",
                (rid, subject_id, predicate, object_id, _json(attrs), source, confidence, first_seen, now, expires),
            )
        return WorldRelation(rid, subject_id, predicate, object_id, attrs, source, confidence, first_seen, now, expires, "active")

    def observe(self, event_type: str, payload: dict[str, Any], *, source: str, confidence: float = 1.0,
                observed_at: float | None = None) -> None:
        observed_at = time.time() if observed_at is None else float(observed_at)
        with self._connect() as con:
            con.execute(
                "INSERT INTO world_observations(event_type,payload_json,source,confidence,observed_at) VALUES(?,?,?,?,?)",
                (event_type, _json(payload), source, max(0.0, min(1.0, float(confidence))), observed_at),
            )
            con.execute(
                "DELETE FROM world_observations WHERE id <= COALESCE((SELECT MAX(id)-? FROM world_observations), -1)",
                (self.max_observations,),
            )

    def set_state(self, key: str, value: Any) -> None:
        now = time.time()
        with self._connect() as con:
            con.execute(
                "INSERT INTO world_state(key,value_json,updated_at) VALUES(?,?,?) "
                "ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json,updated_at=excluded.updated_at",
                (key, _json(value), now),
            )

    def get_state(self, key: str, default: Any = None) -> Any:
        with self._connect() as con:
            row = con.execute("SELECT value_json FROM world_state WHERE key=?", (key,)).fetchone()
        return default if row is None else json.loads(row["value_json"])

    def purge_expired(self, now: float | None = None) -> int:
        now = time.time() if now is None else float(now)
        with self._connect() as con:
            a = con.execute("UPDATE world_entities SET status='expired' WHERE status='active' AND expires_at IS NOT NULL AND expires_at<=?", (now,)).rowcount
            b = con.execute("UPDATE world_relations SET status='expired' WHERE status='active' AND expires_at IS NOT NULL AND expires_at<=?", (now,)).rowcount
        return int(a or 0) + int(b or 0)

    def entities(self, *, kinds: tuple[str, ...] | None = None, limit: int = 50, now: float | None = None) -> list[dict[str, Any]]:
        now = time.time() if now is None else float(now)
        query = "SELECT * FROM world_entities WHERE status='active' AND (expires_at IS NULL OR expires_at>?)"
        params: list[Any] = [now]
        if kinds:
            query += " AND kind IN (%s)" % ",".join("?" for _ in kinds)
            params.extend(kinds)
        query += " ORDER BY last_seen DESC LIMIT ?"
        params.append(max(1, int(limit)))
        with self._connect() as con:
            rows = con.execute(query, tuple(params)).fetchall()
        return [{**dict(r), "attributes": json.loads(r["attributes_json"])} for r in rows]

    def relations(self, *, limit: int = 80, now: float | None = None) -> list[dict[str, Any]]:
        now = time.time() if now is None else float(now)
        with self._connect() as con:
            rows = con.execute("SELECT * FROM world_relations WHERE status='active' AND (expires_at IS NULL OR expires_at>?) ORDER BY last_seen DESC LIMIT ?", (now, max(1, int(limit)))).fetchall()
        return [{**dict(r), "attributes": json.loads(r["attributes_json"])} for r in rows]

    def recent_observations(self, limit: int = 30) -> list[dict[str, Any]]:
        with self._connect() as con:
            rows = con.execute("SELECT event_type,payload_json,source,confidence,observed_at FROM world_observations ORDER BY id DESC LIMIT ?", (max(1, int(limit)),)).fetchall()
        return [{"event_type": r["event_type"], "payload": json.loads(r["payload_json"]), "source": r["source"], "confidence": r["confidence"], "observed_at": r["observed_at"]} for r in rows]

    def stats(self, now: float | None = None) -> dict[str, int]:
        now = time.time() if now is None else float(now)
        with self._connect() as con:
            e = con.execute("SELECT COUNT(*) FROM world_entities WHERE status='active' AND (expires_at IS NULL OR expires_at>?)", (now,)).fetchone()[0]
            r = con.execute("SELECT COUNT(*) FROM world_relations WHERE status='active' AND (expires_at IS NULL OR expires_at>?)", (now,)).fetchone()[0]
            o = con.execute("SELECT COUNT(*) FROM world_observations").fetchone()[0]
        return {"entities": int(e), "relations": int(r), "observations": int(o)}
