from __future__ import annotations

from pathlib import Path
from typing import Any
import hashlib
import json
import sqlite3
import time
import uuid


class GuardianStore:
    def __init__(self, path: Path, *, max_audit_rows: int = 10000) -> None:
        self.path = Path(path); self.max_audit_rows=max(500,int(max_audit_rows)); self.path.parent.mkdir(parents=True, exist_ok=True); self._init_db()

    def _connect(self):
        con = sqlite3.connect(self.path); con.row_factory = sqlite3.Row; return con

    def _init_db(self) -> None:
        with self._connect() as con:
            con.executescript(
                """
                CREATE TABLE IF NOT EXISTS guardian_audit(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    action TEXT NOT NULL, capability TEXT NOT NULL, risk TEXT NOT NULL,
                    decision TEXT NOT NULL, rule TEXT NOT NULL, reason TEXT NOT NULL,
                    args_json TEXT NOT NULL, created_at REAL NOT NULL
                );
                CREATE TABLE IF NOT EXISTS guardian_leases(
                    id TEXT PRIMARY KEY, scope_type TEXT NOT NULL, scope_value TEXT NOT NULL,
                    expires_at REAL NOT NULL, remaining_uses INTEGER, created_at REAL NOT NULL,
                    revoked_at REAL
                );
                """
            )

    def grant(self, scope_type: str, scope_value: str, *, ttl_s: float = 120.0, uses: int | None = 1) -> str:
        if scope_type not in {"action","capability","risk"}: raise ValueError("invalid guardian lease scope")
        lid = f"lease_{uuid.uuid4().hex}"
        now = time.time(); expires = now + max(1.0, min(float(ttl_s), 3600.0))
        remaining = None if uses is None else max(1, min(int(uses), 1000))
        with self._connect() as con:
            con.execute("DELETE FROM guardian_leases WHERE expires_at<=? OR (revoked_at IS NOT NULL AND revoked_at<?)", (now, now-86400.0))
            con.execute("INSERT INTO guardian_leases(id,scope_type,scope_value,expires_at,remaining_uses,created_at,revoked_at) VALUES(?,?,?,?,?,?,NULL)", (lid,scope_type,scope_value,expires,remaining,now))
        return lid

    def revoke_all(self) -> None:
        with self._connect() as con:
            con.execute("UPDATE guardian_leases SET revoked_at=? WHERE revoked_at IS NULL", (time.time(),))

    def consume(self, *, action: str, capability: str, risk: str) -> str | None:
        now = time.time()
        with self._connect() as con:
            rows = con.execute(
                "SELECT * FROM guardian_leases WHERE revoked_at IS NULL AND expires_at>? AND (remaining_uses IS NULL OR remaining_uses>0) ORDER BY created_at DESC",
                (now,),
            ).fetchall()
            for row in rows:
                match = ((row["scope_type"] == "action" and row["scope_value"] == action) or
                         (row["scope_type"] == "capability" and row["scope_value"] == capability) or
                         (row["scope_type"] == "risk" and row["scope_value"] == risk))
                if not match: continue
                if row["remaining_uses"] is not None:
                    con.execute("UPDATE guardian_leases SET remaining_uses=remaining_uses-1 WHERE id=?", (row["id"],))
                return str(row["id"])
        return None

    def audit(self, *, action: str, capability: str, risk: str, decision: str, rule: str, reason: str, args: dict[str, Any]) -> None:
        sensitive = capability in {"input.control","mobile.messaging","external.send","security.sensitive"}
        safe_args = self._redact(args, sensitive=sensitive)
        with self._connect() as con:
            con.execute("INSERT INTO guardian_audit(action,capability,risk,decision,rule,reason,args_json,created_at) VALUES(?,?,?,?,?,?,?,?)", (action,capability,risk,decision,rule,reason,json.dumps(safe_args,ensure_ascii=False,default=str),time.time()))
            con.execute("DELETE FROM guardian_audit WHERE id <= COALESCE((SELECT MAX(id)-? FROM guardian_audit), -1)", (self.max_audit_rows,))

    def recent_audit(self, limit: int = 100) -> list[dict[str, Any]]:
        with self._connect() as con:
            rows=con.execute("SELECT * FROM guardian_audit ORDER BY id DESC LIMIT ?",(max(1,int(limit)),)).fetchall()
        return [{**dict(r),"args":json.loads(r["args_json"])} for r in rows]

    @classmethod
    def _redact(cls, value: Any, *, sensitive: bool = False) -> Any:
        if isinstance(value, dict):
            out={}
            for k,v in value.items():
                key=str(k); low=key.casefold()
                if any(term in low for term in ("password","passwd","pin","secret","token","api_key","apikey","credential")):
                    out[key]="<redacted>"
                elif sensitive and low in {"text","content","message","recipient"}:
                    raw=str(v); digest=hashlib.sha256(raw.encode("utf-8")).hexdigest()[:12]
                    out[key]=f"<redacted len={len(raw)} sha256={digest}>"
                else: out[key]=cls._redact(v,sensitive=sensitive)
            return out
        if isinstance(value,list): return [cls._redact(x,sensitive=sensitive) for x in value]
        if isinstance(value,tuple): return [cls._redact(x,sensitive=sensitive) for x in value]
        return value
