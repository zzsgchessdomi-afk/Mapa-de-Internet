from __future__ import annotations

import json
import math
import sqlite3
import time
import uuid
from pathlib import Path
from typing import Iterable, Any

from .models import MemoryKind, MemoryRecord, ProjectRecord, TaskRecord


class ContinuityStore:
    """Structured, user-owned continuity data stored beside the Phase-1 audit DB.

    The store never needs a cloud model. FTS5 is used when SQLite provides it;
    otherwise search falls back to deterministic LIKE matching.
    """

    def __init__(self, db_path: Path) -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.fts_available = False
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        con = sqlite3.connect(self.db_path)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA foreign_keys=ON")
        return con

    def _init_db(self) -> None:
        with self._connect() as con:
            con.executescript(
                """
                CREATE TABLE IF NOT EXISTS continuity_state (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_at REAL NOT NULL
                );
                CREATE TABLE IF NOT EXISTS projects (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL COLLATE NOCASE UNIQUE,
                    summary TEXT NOT NULL DEFAULT '',
                    status TEXT NOT NULL DEFAULT 'active',
                    created_at REAL NOT NULL,
                    updated_at REAL NOT NULL,
                    last_active_at REAL NOT NULL
                );
                CREATE TABLE IF NOT EXISTS sessions (
                    id TEXT PRIMARY KEY,
                    project_id TEXT REFERENCES projects(id),
                    started_at REAL NOT NULL,
                    ended_at REAL,
                    summary TEXT NOT NULL DEFAULT ''
                );
                CREATE TABLE IF NOT EXISTS structured_memories (
                    id TEXT PRIMARY KEY,
                    project_id TEXT REFERENCES projects(id),
                    kind TEXT NOT NULL,
                    title TEXT NOT NULL,
                    content TEXT NOT NULL,
                    source TEXT NOT NULL,
                    confidence REAL NOT NULL,
                    importance REAL NOT NULL,
                    tags_json TEXT NOT NULL DEFAULT '[]',
                    status TEXT NOT NULL DEFAULT 'active',
                    parent_id TEXT REFERENCES structured_memories(id),
                    created_at REAL NOT NULL,
                    updated_at REAL NOT NULL,
                    last_accessed_at REAL,
                    access_count INTEGER NOT NULL DEFAULT 0
                );
                CREATE INDEX IF NOT EXISTS idx_structured_memories_project ON structured_memories(project_id,status,updated_at DESC);
                CREATE INDEX IF NOT EXISTS idx_structured_memories_kind ON structured_memories(kind,status,updated_at DESC);
                CREATE TABLE IF NOT EXISTS tasks (
                    id TEXT PRIMARY KEY,
                    project_id TEXT REFERENCES projects(id),
                    title TEXT NOT NULL,
                    details TEXT NOT NULL DEFAULT '',
                    status TEXT NOT NULL DEFAULT 'pending',
                    priority INTEGER NOT NULL DEFAULT 2,
                    created_at REAL NOT NULL,
                    updated_at REAL NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_tasks_project ON tasks(project_id,status,priority,updated_at DESC);
                CREATE TABLE IF NOT EXISTS checkpoints (
                    id TEXT PRIMARY KEY,
                    project_id TEXT REFERENCES projects(id),
                    session_id TEXT REFERENCES sessions(id),
                    label TEXT NOT NULL,
                    state_json TEXT NOT NULL,
                    created_at REAL NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_checkpoints_project ON checkpoints(project_id,created_at DESC);
                """
            )
            try:
                con.execute(
                    "CREATE VIRTUAL TABLE IF NOT EXISTS structured_memories_fts USING fts5(memory_id UNINDEXED, title, content, tags)"
                )
                self.fts_available = True
            except sqlite3.OperationalError:
                self.fts_available = False

    @staticmethod
    def _id(prefix: str) -> str:
        return f"{prefix}_{uuid.uuid4().hex}"

    def _set_state(self, key: str, value: str) -> None:
        now = time.time()
        with self._connect() as con:
            con.execute(
                "INSERT INTO continuity_state(key,value,updated_at) VALUES(?,?,?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at",
                (key, value, now),
            )

    def _get_state(self, key: str) -> str | None:
        with self._connect() as con:
            row = con.execute("SELECT value FROM continuity_state WHERE key=?", (key,)).fetchone()
        return None if row is None else str(row["value"])

    def create_project(self, name: str, summary: str = "") -> ProjectRecord:
        clean = " ".join(str(name).split()).strip()
        if not clean:
            raise ValueError("Project name cannot be empty")
        now = time.time(); pid = self._id("project")
        with self._connect() as con:
            existing = con.execute("SELECT * FROM projects WHERE name=? COLLATE NOCASE", (clean,)).fetchone()
            if existing is not None:
                return self._project(existing)
            con.execute(
                "INSERT INTO projects(id,name,summary,status,created_at,updated_at,last_active_at) VALUES(?,?,?,?,?,?,?)",
                (pid, clean, str(summary).strip(), "active", now, now, now),
            )
            row = con.execute("SELECT * FROM projects WHERE id=?", (pid,)).fetchone()
        return self._project(row)

    def list_projects(self, include_archived: bool = False) -> list[ProjectRecord]:
        q = "SELECT * FROM projects"
        args: tuple[Any, ...] = ()
        if not include_archived:
            q += " WHERE status!='archived'"
        q += " ORDER BY last_active_at DESC, name COLLATE NOCASE"
        with self._connect() as con: rows = con.execute(q, args).fetchall()
        return [self._project(r) for r in rows]

    def find_project(self, name_or_id: str) -> ProjectRecord | None:
        value = str(name_or_id).strip()
        with self._connect() as con:
            row = con.execute("SELECT * FROM projects WHERE id=? OR name=? COLLATE NOCASE LIMIT 1", (value, value)).fetchone()
        return None if row is None else self._project(row)

    def activate_project(self, name_or_id: str) -> ProjectRecord:
        project = self.find_project(name_or_id)
        if project is None:
            raise KeyError(f"Project not found: {name_or_id}")
        now = time.time()
        with self._connect() as con:
            con.execute("UPDATE projects SET last_active_at=?, updated_at=? WHERE id=?", (now, now, project.id))
        self._set_state("active_project_id", project.id)
        return self.find_project(project.id)  # type: ignore[return-value]

    def active_project(self) -> ProjectRecord | None:
        pid = self._get_state("active_project_id")
        return None if not pid else self.find_project(pid)

    def update_project_summary(self, project_id: str, summary: str) -> None:
        with self._connect() as con:
            con.execute("UPDATE projects SET summary=?, updated_at=? WHERE id=?", (str(summary).strip(), time.time(), project_id))

    def start_session(self, project_id: str | None = None) -> str:
        sid = self._id("session"); now = time.time()
        current = self._get_state("current_session_id")
        with self._connect() as con:
            if current:
                con.execute("UPDATE sessions SET ended_at=COALESCE(ended_at,?) WHERE id=?", (now, current))
            con.execute("INSERT INTO sessions(id,project_id,started_at) VALUES(?,?,?)", (sid, project_id, now))
        self._set_state("current_session_id", sid)
        return sid

    def current_session_id(self) -> str | None:
        return self._get_state("current_session_id")

    def end_session(self, summary: str = "") -> None:
        sid = self.current_session_id()
        if not sid: return
        with self._connect() as con:
            con.execute("UPDATE sessions SET ended_at=?, summary=? WHERE id=?", (time.time(), str(summary).strip(), sid))
        self._set_state("current_session_id", "")

    def add_memory(self, *, kind: MemoryKind | str, title: str, content: str, source: str,
                   project_id: str | None = None, confidence: float = 1.0, importance: float = 0.5,
                   tags: Iterable[str] = (), parent_id: str | None = None) -> MemoryRecord:
        k = MemoryKind(kind); title = " ".join(str(title).split()).strip(); content = str(content).strip()
        if not content: raise ValueError("Memory content cannot be empty")
        if not title: title = content[:80]
        confidence = max(0.0, min(1.0, float(confidence)))
        importance = max(0.0, min(1.0, float(importance)))
        clean_tags = tuple(sorted({str(t).strip().lower() for t in tags if str(t).strip()}))
        mid = self._id("mem"); now = time.time(); tags_json = json.dumps(clean_tags, ensure_ascii=False)
        with self._connect() as con:
            con.execute(
                "INSERT INTO structured_memories(id,project_id,kind,title,content,source,confidence,importance,tags_json,status,parent_id,created_at,updated_at) "
                "VALUES(?,?,?,?,?,?,?,?,?,'active',?,?,?)",
                (mid, project_id, k.value, title, content, str(source), confidence, importance, tags_json, parent_id, now, now),
            )
            if self.fts_available:
                con.execute("INSERT INTO structured_memories_fts(memory_id,title,content,tags) VALUES(?,?,?,?)",
                            (mid, title, content, " ".join(clean_tags)))
            row = con.execute("SELECT * FROM structured_memories WHERE id=?", (mid,)).fetchone()
        return self._memory(row)

    def get_memory(self, memory_id: str, include_inactive: bool = False) -> MemoryRecord | None:
        q = "SELECT * FROM structured_memories WHERE id=?"
        if not include_inactive: q += " AND status='active'"
        with self._connect() as con: row = con.execute(q, (memory_id,)).fetchone()
        return None if row is None else self._memory(row)

    def correct_memory(self, memory_id: str, new_content: str, *, source: str = "user.correction") -> MemoryRecord:
        old = self.get_memory(memory_id)
        if old is None: raise KeyError(f"Active memory not found: {memory_id}")
        with self._connect() as con:
            con.execute("UPDATE structured_memories SET status='superseded', updated_at=? WHERE id=?", (time.time(), old.id))
            if self.fts_available: con.execute("DELETE FROM structured_memories_fts WHERE memory_id=?", (old.id,))
        return self.add_memory(kind=old.kind, title=old.title, content=new_content, source=source,
                               project_id=old.project_id, confidence=1.0, importance=old.importance,
                               tags=old.tags, parent_id=old.id)

    def forget_memory(self, memory_id: str) -> bool:
        with self._connect() as con:
            cur = con.execute("UPDATE structured_memories SET status='deleted', updated_at=? WHERE id=? AND status='active'", (time.time(), memory_id))
            if cur.rowcount and self.fts_available: con.execute("DELETE FROM structured_memories_fts WHERE memory_id=?", (memory_id,))
        return bool(cur.rowcount)

    def recent_memories(self, *, project_id: str | None = None, kind: MemoryKind | str | None = None,
                        limit: int = 20, include_global: bool = True) -> list[MemoryRecord]:
        clauses=["status='active'"]; args: list[Any]=[]
        if project_id:
            clauses.append("(project_id=?" + (" OR project_id IS NULL)" if include_global else ")")); args.append(project_id)
        elif not include_global:
            clauses.append("project_id IS NOT NULL")
        if kind:
            clauses.append("kind=?"); args.append(MemoryKind(kind).value)
        args.append(int(limit))
        with self._connect() as con:
            rows=con.execute(f"SELECT * FROM structured_memories WHERE {' AND '.join(clauses)} ORDER BY updated_at DESC LIMIT ?", tuple(args)).fetchall()
        return [self._memory(r) for r in rows]

    def search_memories(self, query: str, *, project_id: str | None = None, limit: int = 8,
                        kinds: Iterable[MemoryKind | str] | None = None, include_global: bool = True) -> list[MemoryRecord]:
        query = " ".join(str(query).split()).strip()
        if not query: return self.recent_memories(project_id=project_id, limit=limit, include_global=include_global)
        kind_values = [MemoryKind(k).value for k in kinds] if kinds else []
        candidates: list[sqlite3.Row] = []
        with self._connect() as con:
            if self.fts_available:
                tokens = [x.replace('"','') for x in query.split() if x.strip()]
                match = " OR ".join(f'"{x}"' for x in tokens[:12]) or '""'
                try:
                    rows = con.execute(
                        "SELECT m.*, bm25(structured_memories_fts) AS bm FROM structured_memories_fts f "
                        "JOIN structured_memories m ON m.id=f.memory_id WHERE structured_memories_fts MATCH ? AND m.status='active' LIMIT 80",
                        (match,),
                    ).fetchall()
                    candidates.extend(rows)
                except sqlite3.OperationalError:
                    pass
            if not candidates:
                terms = [x.lower() for x in query.split() if len(x) >= 2][:8]
                if not terms: terms=[query.lower()]
                like_clause = " OR ".join("lower(title||' '||content||' '||tags_json) LIKE ?" for _ in terms)
                candidates = con.execute(
                    f"SELECT *, 0.0 AS bm FROM structured_memories WHERE status='active' AND ({like_clause}) LIMIT 80",
                    tuple(f"%{t}%" for t in terms),
                ).fetchall()
        now=time.time(); scored=[]
        for row in candidates:
            if project_id and row["project_id"] not in ({project_id, None} if include_global else {project_id}): continue
            if kind_values and row["kind"] not in kind_values: continue
            age_days=max(0.0,(now-float(row["updated_at"]))/86400.0)
            recency=math.exp(-age_days/30.0)
            text=(row["title"]+" "+row["content"]+" "+row["tags_json"]).lower()
            terms=[t.lower() for t in query.split() if t.strip()]
            lexical=(sum(1 for t in terms if t in text)/max(1,len(terms)))
            fts=max(0.0, 1.0/(1.0+abs(float(row["bm"] or 0.0)))) if "bm" in row.keys() else 0.0
            project_boost=0.12 if project_id and row["project_id"]==project_id else 0.0
            score=0.42*lexical+0.18*fts+0.16*float(row["importance"])+0.12*float(row["confidence"])+0.12*recency+project_boost
            rec=self._memory(row); rec.score=round(score,6); scored.append(rec)
        scored.sort(key=lambda x:(x.score,x.importance,x.updated_at), reverse=True)
        chosen=scored[:int(limit)]
        if chosen:
            ids=[x.id for x in chosen]
            marks=','.join('?' for _ in ids)
            with self._connect() as con:
                con.execute(f"UPDATE structured_memories SET access_count=access_count+1,last_accessed_at=? WHERE id IN ({marks})", (now,*ids))
        return chosen

    def add_task(self, title: str, *, details: str = "", project_id: str | None = None, priority: int = 2) -> TaskRecord:
        title=" ".join(str(title).split()).strip()
        if not title: raise ValueError("Task title cannot be empty")
        priority=max(1,min(5,int(priority))); tid=self._id("task"); now=time.time()
        with self._connect() as con:
            con.execute("INSERT INTO tasks(id,project_id,title,details,status,priority,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)",
                        (tid,project_id,title,str(details).strip(),"pending",priority,now,now))
            row=con.execute("SELECT * FROM tasks WHERE id=?",(tid,)).fetchone()
        return self._task(row)

    def pending_tasks(self, project_id: str | None = None, limit: int = 30) -> list[TaskRecord]:
        if project_id:
            q="SELECT * FROM tasks WHERE status='pending' AND project_id=? ORDER BY priority DESC,updated_at DESC LIMIT ?"; args=(project_id,limit)
        else:
            q="SELECT * FROM tasks WHERE status='pending' ORDER BY priority DESC,updated_at DESC LIMIT ?"; args=(limit,)
        with self._connect() as con: rows=con.execute(q,args).fetchall()
        return [self._task(r) for r in rows]

    def set_task_status(self, task_id: str, status: str) -> bool:
        if status not in {"pending","done","cancelled"}: raise ValueError("Invalid task status")
        with self._connect() as con: cur=con.execute("UPDATE tasks SET status=?,updated_at=? WHERE id=?",(status,time.time(),task_id))
        return bool(cur.rowcount)

    def add_checkpoint(self, *, project_id: str | None, session_id: str | None, label: str, state: dict[str, Any]) -> str:
        cid=self._id("checkpoint")
        with self._connect() as con:
            con.execute("INSERT INTO checkpoints(id,project_id,session_id,label,state_json,created_at) VALUES(?,?,?,?,?,?)",
                        (cid,project_id,session_id,str(label),json.dumps(state,ensure_ascii=False),time.time()))
        return cid

    def latest_checkpoint(self, project_id: str | None = None) -> dict[str, Any] | None:
        if project_id:
            q="SELECT * FROM checkpoints WHERE project_id=? ORDER BY created_at DESC LIMIT 1"; args=(project_id,)
        else:
            q="SELECT * FROM checkpoints ORDER BY created_at DESC LIMIT 1"; args=()
        with self._connect() as con: row=con.execute(q,args).fetchone()
        if row is None: return None
        return {"id":row["id"],"project_id":row["project_id"],"session_id":row["session_id"],"label":row["label"],
                "state":json.loads(row["state_json"]),"created_at":row["created_at"]}

    @staticmethod
    def _project(r: sqlite3.Row) -> ProjectRecord:
        return ProjectRecord(r["id"],r["name"],r["summary"],r["status"],float(r["created_at"]),float(r["updated_at"]),float(r["last_active_at"]))

    @staticmethod
    def _memory(r: sqlite3.Row) -> MemoryRecord:
        return MemoryRecord(r["id"],MemoryKind(r["kind"]),r["title"],r["content"],r["source"],float(r["confidence"]),float(r["importance"]),
                            r["project_id"],tuple(json.loads(r["tags_json"] or "[]")),r["status"],r["parent_id"],float(r["created_at"]),float(r["updated_at"]))

    @staticmethod
    def _task(r: sqlite3.Row) -> TaskRecord:
        return TaskRecord(r["id"],r["project_id"],r["title"],r["details"],r["status"],int(r["priority"]),float(r["created_at"]),float(r["updated_at"]))
