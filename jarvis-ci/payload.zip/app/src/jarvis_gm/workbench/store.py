from __future__ import annotations

from pathlib import Path
import json, sqlite3, threading, time
from typing import Any
from .models import WorkItem, WorkState, TERMINAL_STATES


class WorkbenchStore:
    def __init__(self, path: Path) -> None:
        self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True)
        self._lock=threading.RLock(); self._init()

    def _connect(self):
        con=sqlite3.connect(self.path,timeout=10); con.row_factory=sqlite3.Row
        con.execute("PRAGMA journal_mode=WAL"); con.execute("PRAGMA foreign_keys=ON")
        return con

    def _init(self):
        with self._connect() as con:
            con.executescript('''
            CREATE TABLE IF NOT EXISTS work_items(
              id TEXT PRIMARY KEY, goal TEXT NOT NULL, success_json TEXT NOT NULL, deps_json TEXT NOT NULL,
              priority INTEGER NOT NULL, step_budget INTEGER NOT NULL, replan_budget INTEGER NOT NULL,
              quantum INTEGER NOT NULL, state TEXT NOT NULL, mission_id TEXT NOT NULL, steps_used INTEGER NOT NULL,
              replans_used INTEGER NOT NULL, cycles INTEGER NOT NULL, checkpoint_seq INTEGER NOT NULL,
              conclusion TEXT NOT NULL, blocked_reason TEXT NOT NULL, created_at REAL NOT NULL, updated_at REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS checkpoints(
              work_id TEXT NOT NULL, seq INTEGER NOT NULL, created_at REAL NOT NULL, state TEXT NOT NULL,
              mission_id TEXT NOT NULL, mission_state TEXT NOT NULL, steps_used INTEGER NOT NULL,
              replans_used INTEGER NOT NULL, note TEXT NOT NULL, payload_json TEXT NOT NULL,
              PRIMARY KEY(work_id,seq), FOREIGN KEY(work_id) REFERENCES work_items(id) ON DELETE CASCADE
            );
            CREATE TABLE IF NOT EXISTS events(
              id INTEGER PRIMARY KEY AUTOINCREMENT, work_id TEXT NOT NULL, created_at REAL NOT NULL,
              kind TEXT NOT NULL, detail TEXT NOT NULL
            );
            ''')

    def save(self,item: WorkItem, *, allow_terminal_rewrite: bool=False) -> None:
        item.priority=max(0,min(int(item.priority),100)); item.step_budget=max(1,int(item.step_budget)); item.replan_budget=max(0,int(item.replan_budget)); item.quantum=max(1,min(int(item.quantum),10)); item.updated_at=time.time()
        with self._lock,self._connect() as con:
            old=con.execute("SELECT state FROM work_items WHERE id=?",(item.id,)).fetchone()
            if old is not None and WorkState(old[0]) in TERMINAL_STATES and WorkState(old[0]) != item.state and not allow_terminal_rewrite:
                raise RuntimeError(f"Terminal work item is immutable: {item.id}")
            con.execute('''INSERT INTO work_items VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
              ON CONFLICT(id) DO UPDATE SET goal=excluded.goal,success_json=excluded.success_json,deps_json=excluded.deps_json,
              priority=excluded.priority,step_budget=excluded.step_budget,replan_budget=excluded.replan_budget,quantum=excluded.quantum,
              state=excluded.state,mission_id=excluded.mission_id,steps_used=excluded.steps_used,replans_used=excluded.replans_used,
              cycles=excluded.cycles,checkpoint_seq=excluded.checkpoint_seq,conclusion=excluded.conclusion,
              blocked_reason=excluded.blocked_reason,updated_at=excluded.updated_at''',(
              item.id,item.goal,json.dumps(item.success_criteria),json.dumps(item.dependencies),item.priority,item.step_budget,item.replan_budget,
              item.quantum,item.state.value,item.mission_id,item.steps_used,item.replans_used,item.cycles,item.checkpoint_seq,
              item.conclusion,item.blocked_reason,item.created_at,item.updated_at))

    def get(self, work_id: str) -> WorkItem | None:
        with self._connect() as con: row=con.execute("SELECT * FROM work_items WHERE id=?",(work_id,)).fetchone()
        return self._row(row) if row else None

    def list(self, limit:int=100) -> list[WorkItem]:
        with self._connect() as con: rows=con.execute("SELECT * FROM work_items ORDER BY priority DESC, created_at ASC LIMIT ?",(max(1,int(limit)),)).fetchall()
        return [self._row(r) for r in rows]

    def checkpoint(self,item: WorkItem, *, mission_state:str="", note:str="", payload:dict[str,Any]|None=None) -> int:
        item.checkpoint_seq += 1
        self.save(item)
        with self._connect() as con:
            con.execute("INSERT INTO checkpoints VALUES(?,?,?,?,?,?,?,?,?,?)",(
              item.id,item.checkpoint_seq,time.time(),item.state.value,item.mission_id,mission_state,item.steps_used,item.replans_used,
              str(note)[:2000],json.dumps(payload or {},ensure_ascii=False,default=str)[:64000]))
        return item.checkpoint_seq

    def checkpoints(self,work_id:str,limit:int=50)->list[dict[str,Any]]:
        with self._connect() as con: rows=con.execute("SELECT * FROM checkpoints WHERE work_id=? ORDER BY seq DESC LIMIT ?",(work_id,max(1,int(limit)))).fetchall()
        return [dict(r) for r in rows]

    def event(self, work_id:str, kind:str, detail:str="") -> None:
        with self._connect() as con: con.execute("INSERT INTO events(work_id,created_at,kind,detail) VALUES(?,?,?,?)",(work_id,time.time(),kind,str(detail)[:4000]))

    def stats(self)->dict[str,Any]:
        with self._connect() as con:
            total=con.execute("SELECT COUNT(*) FROM work_items").fetchone()[0]
            rows=con.execute("SELECT state,COUNT(*) n FROM work_items GROUP BY state").fetchall()
        return {"total":total,"states":{r[0]:r[1] for r in rows}}

    @staticmethod
    def _row(r)->WorkItem:
        return WorkItem(goal=r["goal"],success_criteria=tuple(json.loads(r["success_json"])),dependencies=tuple(json.loads(r["deps_json"])),
          priority=r["priority"],step_budget=r["step_budget"],replan_budget=r["replan_budget"],quantum=r["quantum"],id=r["id"],
          state=WorkState(r["state"]),mission_id=r["mission_id"],steps_used=r["steps_used"],replans_used=r["replans_used"],cycles=r["cycles"],
          checkpoint_seq=r["checkpoint_seq"],conclusion=r["conclusion"],blocked_reason=r["blocked_reason"],created_at=r["created_at"],updated_at=r["updated_at"])
