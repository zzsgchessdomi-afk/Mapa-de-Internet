from __future__ import annotations

from pathlib import Path
from typing import Any
import hashlib
import json
import sqlite3
import time
import uuid

from .models import HandoffRecord, Resource, ResourceKind


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


class ResourceStore:
    """Persistent resource namespace for Personal AI OS.

    The store contains locators and aliases, not credentials. Secrets remain in the
    existing credential stores of the owning subsystem.
    """

    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._init()

    def _connect(self):
        con = sqlite3.connect(self.path)
        con.row_factory = sqlite3.Row
        return con

    def _init(self) -> None:
        with self._connect() as con:
            con.executescript(
                """
                CREATE TABLE IF NOT EXISTS resources(
                    id TEXT PRIMARY KEY,
                    kind TEXT NOT NULL,
                    rkey TEXT NOT NULL,
                    label TEXT NOT NULL,
                    locator_json TEXT NOT NULL,
                    device_id TEXT,
                    capabilities_json TEXT NOT NULL,
                    metadata_json TEXT NOT NULL,
                    source TEXT NOT NULL,
                    confidence REAL NOT NULL,
                    last_seen REAL NOT NULL,
                    expires_at REAL,
                    status TEXT NOT NULL DEFAULT 'active'
                );
                CREATE UNIQUE INDEX IF NOT EXISTS idx_resources_kind_key ON resources(kind,rkey);
                CREATE INDEX IF NOT EXISTS idx_resources_kind_status ON resources(kind,status,last_seen DESC);
                CREATE TABLE IF NOT EXISTS aliases(
                    alias TEXT PRIMARY KEY,
                    resource_id TEXT NOT NULL,
                    created_at REAL NOT NULL
                );
                CREATE TABLE IF NOT EXISTS handoffs(
                    id TEXT PRIMARY KEY,
                    resource_id TEXT NOT NULL,
                    destination_id TEXT NOT NULL,
                    operation TEXT NOT NULL,
                    state TEXT NOT NULL,
                    created_at REAL NOT NULL,
                    updated_at REAL NOT NULL,
                    action TEXT,
                    verification TEXT,
                    error TEXT
                );
                CREATE INDEX IF NOT EXISTS idx_handoffs_updated ON handoffs(updated_at DESC);
                """
            )

    @staticmethod
    def stable_id(kind: str | ResourceKind, key: str) -> str:
        k = kind.value if isinstance(kind, ResourceKind) else str(kind)
        digest = hashlib.sha256(f"{k}\0{key}".encode("utf-8")).hexdigest()[:20]
        return f"res:{k}:{digest}"

    def upsert(self, *, kind: ResourceKind, key: str, label: str, locator: dict[str, Any] | None = None,
               device_id: str | None = None, capabilities: tuple[str, ...] | list[str] = (),
               metadata: dict[str, Any] | None = None, source: str = "system", confidence: float = 1.0,
               ttl_s: float | None = None, now: float | None = None) -> Resource:
        now = time.time() if now is None else float(now)
        rid = self.stable_id(kind, key)
        expires = None if ttl_s is None else now + max(0.0, float(ttl_s))
        caps = tuple(sorted({str(x) for x in capabilities if str(x)}))
        with self._connect() as con:
            con.execute(
                "INSERT INTO resources(id,kind,rkey,label,locator_json,device_id,capabilities_json,metadata_json,source,confidence,last_seen,expires_at,status) "
                "VALUES(?,?,?,?,?,?,?,?,?,?,?,?, 'active') ON CONFLICT(id) DO UPDATE SET "
                "label=excluded.label,locator_json=excluded.locator_json,device_id=excluded.device_id,capabilities_json=excluded.capabilities_json,"
                "metadata_json=excluded.metadata_json,source=excluded.source,confidence=excluded.confidence,last_seen=excluded.last_seen,"
                "expires_at=excluded.expires_at,status='active'",
                (rid, kind.value, key, label, _json(locator or {}), device_id, _json(list(caps)), _json(metadata or {}), source,
                 max(0.0, min(1.0, float(confidence))), now, expires),
            )
        return Resource(rid, kind, key, label, dict(locator or {}), device_id, caps, dict(metadata or {}), source,
                        max(0.0, min(1.0, float(confidence))), now, expires, "active")

    @staticmethod
    def _row(row) -> Resource:
        return Resource(
            id=row["id"], kind=ResourceKind(row["kind"]), key=row["rkey"], label=row["label"],
            locator=json.loads(row["locator_json"]), device_id=row["device_id"],
            capabilities=tuple(json.loads(row["capabilities_json"])), metadata=json.loads(row["metadata_json"]),
            source=row["source"], confidence=float(row["confidence"]), last_seen=float(row["last_seen"]),
            expires_at=row["expires_at"], status=row["status"],
        )

    def get(self, resource_id: str, *, now: float | None = None) -> Resource | None:
        now = time.time() if now is None else float(now)
        with self._connect() as con:
            row = con.execute("SELECT * FROM resources WHERE id=? AND status='active' AND (expires_at IS NULL OR expires_at>?)", (resource_id, now)).fetchone()
        return None if row is None else self._row(row)

    def list(self, *, kind: ResourceKind | None = None, device_id: str | None = None, limit: int = 100,
             now: float | None = None) -> list[Resource]:
        now = time.time() if now is None else float(now)
        q = "SELECT * FROM resources WHERE status='active' AND (expires_at IS NULL OR expires_at>?)"
        params: list[Any] = [now]
        if kind is not None:
            q += " AND kind=?"; params.append(kind.value)
        if device_id is not None:
            q += " AND device_id=?"; params.append(device_id)
        q += " ORDER BY last_seen DESC,label COLLATE NOCASE LIMIT ?"; params.append(max(1, min(int(limit), 500)))
        with self._connect() as con:
            rows = con.execute(q, tuple(params)).fetchall()
        return [self._row(r) for r in rows]

    def bind_alias(self, alias: str, resource_id: str) -> None:
        key = str(alias).strip().casefold()
        if not key: raise ValueError("Alias is required")
        if self.get(resource_id) is None: raise KeyError(resource_id)
        with self._connect() as con:
            con.execute("INSERT INTO aliases(alias,resource_id,created_at) VALUES(?,?,?) ON CONFLICT(alias) DO UPDATE SET resource_id=excluded.resource_id,created_at=excluded.created_at", (key, resource_id, time.time()))

    def resolve(self, ref: str, *, kinds: tuple[ResourceKind, ...] | None = None) -> Resource:
        text = str(ref).strip()
        if not text: raise ValueError("Resource reference is required")
        direct = self.get(text)
        if direct is not None and (not kinds or direct.kind in kinds): return direct
        with self._connect() as con:
            a = con.execute("SELECT resource_id FROM aliases WHERE alias=?", (text.casefold(),)).fetchone()
        if a is not None:
            res = self.get(a["resource_id"])
            if res is not None and (not kinds or res.kind in kinds): return res
        candidates = [r for r in self.list(limit=300) if r.label.casefold() == text.casefold() and (not kinds or r.kind in kinds)]
        if len(candidates) == 1: return candidates[0]
        if len(candidates) > 1: raise ValueError(f"Ambiguous resource reference: {text}")
        raise KeyError(text)

    def expire_missing(self, *, source_prefix: str, active_ids: set[str]) -> int:
        with self._connect() as con:
            rows = con.execute("SELECT id FROM resources WHERE status='active' AND source LIKE ?", (source_prefix + "%",)).fetchall()
            stale = [r["id"] for r in rows if r["id"] not in active_ids]
            for rid in stale: con.execute("UPDATE resources SET status='stale' WHERE id=?", (rid,))
        return len(stale)

    def create_handoff(self, resource_id: str, destination_id: str, operation: str) -> HandoffRecord:
        now = time.time(); hid = uuid.uuid4().hex
        rec = HandoffRecord(hid, resource_id, destination_id, operation, "planned", now, now)
        with self._connect() as con:
            con.execute("INSERT INTO handoffs(id,resource_id,destination_id,operation,state,created_at,updated_at) VALUES(?,?,?,?,?,?,?)",
                        (hid, resource_id, destination_id, operation, rec.state, now, now))
        return rec

    def update_handoff(self, handoff_id: str, *, state: str, action: str | None = None,
                       verification: str | None = None, error: str | None = None) -> None:
        terminal={"verified","failed","blocked","unverified","expired"}
        with self._connect() as con:
            row=con.execute("SELECT state FROM handoffs WHERE id=?",(handoff_id,)).fetchone()
            if row is None: raise KeyError(handoff_id)
            if str(row["state"]) in terminal:
                return
            con.execute("UPDATE handoffs SET state=?,updated_at=?,action=COALESCE(?,action),verification=COALESCE(?,verification),error=? WHERE id=?",
                        (state, time.time(), action, verification, error, handoff_id))

    def handoffs(self, limit: int = 50) -> list[dict[str, Any]]:
        with self._connect() as con:
            rows = con.execute("SELECT * FROM handoffs ORDER BY updated_at DESC LIMIT ?", (max(1, min(int(limit), 200)),)).fetchall()
        return [dict(r) for r in rows]
