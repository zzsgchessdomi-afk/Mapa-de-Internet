from __future__ import annotations
from pathlib import Path
import sqlite3,json,time
from .models import EvolutionCandidate,CandidateState

class EvolutionStore:
    def __init__(self,path:Path)->None:self.path=Path(path);self.path.parent.mkdir(parents=True,exist_ok=True);self._init()
    def _connect(self):con=sqlite3.connect(self.path);con.row_factory=sqlite3.Row;return con
    def _init(self):
        with self._connect() as con:
            con.execute("CREATE TABLE IF NOT EXISTS candidates(id TEXT PRIMARY KEY,base_skill TEXT NOT NULL,state TEXT NOT NULL,payload TEXT NOT NULL,updated_at REAL NOT NULL)")
            con.execute("CREATE INDEX IF NOT EXISTS idx_evo_updated ON candidates(updated_at DESC)")
    def save(self,c:EvolutionCandidate)->None:
        c.updated_at=time.time();payload=json.dumps(c.as_dict(),ensure_ascii=False,sort_keys=True)
        with self._connect() as con:con.execute("INSERT INTO candidates(id,base_skill,state,payload,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET state=excluded.state,payload=excluded.payload,updated_at=excluded.updated_at",(c.id,c.base_skill,c.state.value,payload,c.updated_at))
    def load(self,candidate_id:str)->EvolutionCandidate:
        with self._connect() as con:r=con.execute("SELECT payload FROM candidates WHERE id=?",(str(candidate_id),)).fetchone()
        if r is None:raise KeyError(candidate_id)
        raw=json.loads(r["payload"]);return EvolutionCandidate(base_skill=raw["base_skill"],objective=raw["objective"],candidate_skill=dict(raw["candidate_skill"]),base_snapshot=dict(raw.get("base_snapshot") or {}),baseline=dict(raw["baseline"]),benchmark=dict(raw["benchmark"]),rationale=str(raw.get("rationale") or ""),id=raw["id"],state=CandidateState(raw["state"]),created_at=float(raw["created_at"]),updated_at=float(raw["updated_at"]))
    def list(self,limit:int=50)->list[dict]:
        with self._connect() as con:rows=con.execute("SELECT id,base_skill,state,updated_at FROM candidates ORDER BY updated_at DESC LIMIT ?",(max(1,min(int(limit),500)),)).fetchall()
        return [dict(x) for x in rows]
    def stats(self)->dict:
        with self._connect() as con:
            total=con.execute("SELECT COUNT(*) FROM candidates").fetchone()[0];promoted=con.execute("SELECT COUNT(*) FROM candidates WHERE state='promoted'").fetchone()[0]
        return {"candidates":int(total),"promoted":int(promoted)}
